import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';

import '../../providers.dart';
import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../core/unit_utils.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/product.dart';
import '../../domain/models/activity_log.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/number_field.dart';
import '../widgets/money_field.dart';

class PurchaseFormPage extends ConsumerStatefulWidget {
  final Purchase? initial;
  final bool showAsSheet;
  const PurchaseFormPage({super.key, this.initial, this.showAsSheet = false});

  @override
  ConsumerState<PurchaseFormPage> createState() => _PurchaseFormPageState();
}

class _PurchaseFormPageState extends ConsumerState<PurchaseFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();

  String paymentMethod = 'Cash';

  final supplierC = TextEditingController();

  final List<_Row> rows = [_Row()];

  @override
  void initState() {
    super.initState();
    final init = widget.initial;
    if (init != null) {
      date = fromEpochDay(init.dateEpochDay);
      paymentMethod = init.paymentMethod;
      supplierC.text = init.supplier;
      rows
        ..clear()
        ..addAll(init.items.map((it) {
          final r = _Row();
          r.productId = it.productId;
          r.qtyC.text = it.qty.toStringAsFixed(2);
          r.priceC.text = it.buyPrice.toStringAsFixed(0);
          return r;
        }));
      if (rows.isEmpty) rows.add(_Row());
    }
  }

  @override
  void dispose() {
    supplierC.dispose();
    for (final r in rows) {
      r.qtyC.dispose();
      r.priceC.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productRepoProvider).all();
    final suppliers = ref
        .watch(purchaseRepoProvider)
        .all()
        .map((e) => e.supplier.trim())
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    final favoriteSuppliers = ref.watch(metaRepoProvider).favoriteSuppliers;
    final currentSupplier = supplierC.text.trim();
    final isFavoriteSupplier = currentSupplier.isNotEmpty &&
        favoriteSuppliers.any((e) => e.toLowerCase() == currentSupplier.toLowerCase());
    final formContent = Form(
      key: _formKey,
      child: ListView(
        shrinkWrap: widget.showAsSheet,
        physics: widget.showAsSheet ? const NeverScrollableScrollPhysics() : null,
        padding: EdgeInsets.fromLTRB(16, 8, 16,
            widget.showAsSheet ? MediaQuery.of(context).viewInsets.bottom + 24 : 16),
        children: [
          if (widget.showAsSheet) ...[
            Center(
              child: Container(
                width: 36, height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: Colors.grey.withOpacity(0.3), borderRadius: BorderRadius.circular(2)),
              ),
            ),
            Row(children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(color: const Color(0xFFB7EFCE), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.shopping_cart_rounded, color: Color(0xFF0B5E38), size: 18),
              ),
              const SizedBox(width: 10),
              Text('Tambah Pembelian', style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 16),
          ],
          DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: paymentMethod,
            decoration: const InputDecoration(labelText: 'Metode pembayaran'),
            items: const [
              DropdownMenuItem(value: 'Cash', child: Text('Cash')),
              DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
              DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
            ],
            onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: supplierC,
            decoration: InputDecoration(
              labelText: 'Supplier (opsional)',
              suffixIcon: IconButton(
                tooltip: isFavoriteSupplier ? 'Hapus dari favorit' : 'Simpan ke favorit',
                onPressed: currentSupplier.isEmpty
                    ? null
                    : () async {
                        await ref.read(metaRepoProvider).toggleFavoriteSupplier(currentSupplier);
                        if (!mounted) return;
                        setState(() {});
                      },
                icon: Icon(isFavoriteSupplier ? Icons.star_rounded : Icons.star_border_rounded),
              ),
            ),
            onChanged: (_) => setState(() {}),
          ),
          if (favoriteSuppliers.isNotEmpty) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Text('Supplier favorit', style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.hint)),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: favoriteSuppliers.map((s) {
                return ActionChip(
                  avatar: const Icon(Icons.star_rounded, size: 16, color: Color(0xFFFFB300)),
                  label: Text(s),
                  onPressed: () => setState(() => supplierC.text = s),
                );
              }).toList(),
            ),
          ],
          if (suppliers.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: suppliers.take(8).map((s) {
                return ActionChip(label: Text(s), onPressed: () => setState(() => supplierC.text = s));
              }).toList(),
            ),
          ],
          const SizedBox(height: 12),
          if (products.isEmpty) const Text('Belum ada produk. Tambahkan produk dulu di tab Produk.'),
          ...List.generate(rows.length, (i) => _buildRow(products, i)),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => setState(() => rows.add(_Row())),
            icon: const Icon(Icons.add_circle_outline_rounded),
            label: Text('Tambah item', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ),
          // ── Preview total pembelian real-time ────────────────────────────
          Builder(builder: (_) {
            double total = 0;
            for (final r in rows) {
              final qty = normalizeQty(double.tryParse(r.qtyC.text.trim().replaceAll(',', '.')) ?? 0.0);
              final price = (parseRupiah(r.priceC.text.trim()) ?? 0).toDouble();
              total += qty * price;
            }
            if (total <= 0) return const SizedBox.shrink();
            return Container(
              margin: const EdgeInsets.only(top: 4),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFE3F2FD),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF90CAF9), width: 1),
              ),
              child: Row(
                children: [
                  const Icon(Icons.shopping_cart_rounded,
                      color: Color(0xFF1565C0), size: 18),
                  const SizedBox(width: 10),
                  Text('Total Pembelian:',
                    style: GoogleFonts.poppins(fontSize: 13, color: AppColors.hint)),
                  const Spacer(),
                  Text(fmtMoney(total),
                    style: GoogleFonts.poppins(
                      fontSize: 15, fontWeight: FontWeight.w700,
                      color: const Color(0xFF1565C0))),
                ],
              ),
            );
          }),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: products.isEmpty ? null : _save,
            icon: const Icon(Icons.save_rounded),
            label: Text(
              widget.initial == null ? 'Simpan Pembelian' : 'Simpan Perubahan',
              style: GoogleFonts.poppins(fontWeight: FontWeight.w700, fontSize: 15),
            ),
          ),
        ],
      ),
    );

    if (widget.showAsSheet) {
      return Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: SingleChildScrollView(child: formContent),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Tambah Pembelian' : 'Edit Pembelian')),
      body: formContent,
    );
  }

  Widget _buildRow(List<Product> products, int i) {
    final r = rows[i];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              initialValue: r.productId,
              decoration: const InputDecoration(labelText: 'Produk'),
              items: products.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(),
              onChanged: (v) => setState(() => r.productId = v),
              validator: (v) => (v == null || v.isEmpty) ? 'Pilih produk' : null,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: NumberField(
                    controller: r.qtyC, label: 'Qty', requiredField: true,
                    onChanged: (_) => setState(() {}))),
                const SizedBox(width: 12),
                Expanded(
                  child: NumberField(
                    controller: r.priceC,
                    label: 'Harga beli /unit',
                    requiredField: true,
                    integerOnly: true,
                    onChanged: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: rows.length <= 1 ? null : () => setState(() => rows.removeAt(i)),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Hapus item'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final items = <PurchaseItem>[];
    for (final r in rows) {
      final qty = normalizeQty(double.tryParse(r.qtyC.text.trim().replaceAll(',', '.')) ?? 0.0);
      final price = (parseRupiah(r.priceC.text.trim()) ?? 0).toDouble();
      if (r.productId == null) continue;
      if (qty <= 0) continue;
      items.add(PurchaseItem(productId: r.productId!, qty: qty, buyPrice: price));
    }

    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Isi minimal 1 item pembelian')));
      return;
    }

    final isEdit = widget.initial != null;
    final id = widget.initial?.id ?? newId('buy');

    final purchase = Purchase(
      id: id,
      dateEpochDay: epochDay(date),
      supplier: supplierC.text.trim(),
      paymentMethod: paymentMethod,
      items: items,
    );

    if (isEdit) {
      final old = widget.initial!;
      await ref.read(purchaseRepoProvider).remove(old.id);
      await ref.read(purchaseRepoProvider).add(purchase);
      await ref.read(activityLogRepoProvider).add(
            ActivityLog(
              id: newId('log'),
              dateEpochDay: purchase.dateEpochDay,
              type: 'edit_purchase',
              refId: old.id,
              oldJson: jsonEncode(old.toJson()),
              newJson: jsonEncode(purchase.toJson()),
            ),
          );
    } else {
      await ref.read(purchaseRepoProvider).add(purchase);
    }

    if (!mounted) return;
    Navigator.pop(context);
  }
}

class _Row {
  String? productId;
  final qtyC = TextEditingController();
  final priceC = TextEditingController();
}
