const String kUnitMigrationV5Final = 'unit_migration_v5_final_gram';

String normalizeUnitLabel(String unit) {
  final u = unit.trim().toLowerCase();
  if (u == 'kg' || u == 'kilogram' || u == 'kilograms') return 'gram';
  if (u == 'gr') return 'gram';
  return unit.trim().isEmpty ? 'pcs' : unit.trim();
}

bool isWeightUnit(String unit) {
  final u = unit.trim().toLowerCase();
  return u == 'kg' || u == 'kilogram' || u == 'kilograms' || u == 'gram' || u == 'gr';
}

double normalizeQty(double value) => double.parse(value.toStringAsFixed(3));
double normalizeMoney(double value) => double.parse(value.toStringAsFixed(2));
double normalizeRate(double value) => double.parse(value.toStringAsFixed(6));
