import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../providers.dart';

import '../dashboard/dashboard_page.dart';
import '../products/products_page.dart';
import '../purchases/purchases_page.dart';
import '../sales/sales_page.dart';
import '../cash/cash_page.dart';

import '../expenses/expenses_page.dart';
import '../debts/debts_page.dart';
import '../reports/reports_page.dart';
import '../settings/backup_page.dart';
import '../analytics/analytics_page.dart';
import '../restock/restock_page.dart';
import '../activity/activity_log_page.dart';
import '../rejected/rejected_page.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage>
    with TickerProviderStateMixin {
  int _index = 0;
  late final AnimationController _fabController;

  final _pages = const [
    DashboardPage(key: PageStorageKey('tab-dashboard')),
    ProductsPage(key: PageStorageKey('tab-products')),
    SalesPage(key: PageStorageKey('tab-sales')),
    PurchasesPage(key: PageStorageKey('tab-purchases')),
    CashPage(key: PageStorageKey('tab-cash')),
    RejectedPage(key: PageStorageKey('tab-rejected')),
  ];

  final _labels = const ['Dashboard', 'Produk', 'Penjualan', 'Pembelian', 'Kas', 'Retur'];

  final _iconAssets = const [
    'assets/icons/ic_dashboard.png',
    'assets/icons/ic_products.png',
    'assets/icons/ic_sales.png',
    'assets/icons/ic_purchases.png',
    'assets/icons/ic_cash.png',
    '', // Rejek uses Icon widget
  ];

  @override
  void initState() {
    super.initState();
    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await ref.read(backupServiceProvider).autoBackupIfDue(
              meta: ref.read(metaRepoProvider),
              logs: ref.read(activityLogRepoProvider),
            );
      } catch (_) {}
    });
  }

  @override
  void dispose() {
    _fabController.dispose();
    super.dispose();
  }

  void _openDrawerPage(String title, Widget page) {
    Navigator.of(context).pop();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: Text(title)),
          body: page,
        ),
      ),
    );
  }

  Future<void> _switchRole() async {
    final meta = ref.read(metaRepoProvider);
    final settings = ref.read(settingsRepoProvider);
    final cur = meta.role;
    final next = cur == 'admin' ? 'kasir' : 'admin';

    if (next == 'admin' && settings.get().pinEnabled) {
      final controller = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Masuk mode Admin'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(labelText: 'PIN Admin'),
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Batal')),
            FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('OK')),
          ],
        ),
      );
      if (ok != true) return;
      if (!settings.verifyPin(controller.text)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('PIN salah.')));
        }
        return;
      }
    }

    await meta.setRole(next);
    await ref
        .read(activityLogRepoProvider)
        .log('switch_role', 'Role berubah: $cur -> $next');
    if (mounted) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Mode aktif: $next')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final role = ref.watch(metaRepoProvider).role;
    final isAdmin = role == 'admin';

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.cardGreen1, AppColors.cardGreen2],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.storefront_rounded,
                  color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              _labels[_index],
              style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.onSurface),
            ),
          ],
        ),
        actions: [
          // Role badge
          Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: isAdmin
                  ? const Color(0xFFB7EFCE)
                  : AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  isAdmin
                      ? Icons.admin_panel_settings_rounded
                      : Icons.person_rounded,
                  size: 14,
                  color: isAdmin ? AppColors.primary : AppColors.hint,
                ),
                const SizedBox(width: 4),
                Text(
                  isAdmin ? 'Admin' : 'Kasir',
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: isAdmin ? AppColors.primary : AppColors.hint,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(role, isAdmin),
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildDrawer(String role, bool isAdmin) {
    return Drawer(
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(24)),
      ),
      child: Column(
        children: [
          // Gradient header
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.drawerHeader1, AppColors.drawerHeader2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius:
                  BorderRadius.vertical(bottom: Radius.circular(20)),
            ),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 20,
              left: 20,
              right: 20,
              bottom: 24,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color: Colors.white.withOpacity(0.3), width: 1.5),
                  ),
                  child: const Icon(Icons.storefront_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(height: 14),
                Text(
                  'Warung Arasaan',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(height: 6),
                InkWell(
                  onTap: () async {
                    Navigator.of(context).pop();
                    await _switchRole();
                  },
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: Colors.white.withOpacity(0.3), width: 1),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isAdmin
                              ? Icons.admin_panel_settings_rounded
                              : Icons.person_rounded,
                          size: 13,
                          color: Colors.white.withOpacity(0.9),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          isAdmin ? 'Mode Admin' : 'Mode Kasir',
                          style: GoogleFonts.poppins(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Icon(Icons.swap_horiz_rounded,
                            size: 13,
                            color: Colors.white.withOpacity(0.7)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Menu items
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              children: [
                _DrawerSection(title: 'Laporan & Analisis'),
                _DrawerItem(
                  icon: Icons.receipt_long_rounded,
                  color: AppColors.iconGreen,
                  title: 'Laporan',
                  onTap: () => _openDrawerPage('Laporan', const ReportsPage()),
                ),
                _DrawerItem(
                  icon: Icons.insights_rounded,
                  color: AppColors.iconBlue,
                  title: 'Analytics',
                  onTap: () =>
                      _openDrawerPage('Analytics', const AnalyticsPage()),
                ),
                _DrawerItem(
                  icon: Icons.shopping_basket_rounded,
                  color: AppColors.iconRed,
                  title: 'Saran Belanja',
                  onTap: () =>
                      _openDrawerPage('Saran Belanja', const RestockPage()),
                ),
                _DrawerItem(
                  icon: Icons.history_rounded,
                  color: AppColors.iconPurple,
                  title: 'Log Aktivitas',
                  onTap: () => _openDrawerPage(
                      'Log Aktivitas', const ActivityLogPage()),
                ),
                const SizedBox(height: 8),
                _DrawerSection(title: 'Keuangan'),
                _DrawerItem(
                  icon: Icons.payments_rounded,
                  color: AppColors.iconAmber,
                  title: 'Hutang',
                  onTap: () => _openDrawerPage('Hutang', const DebtsPage()),
                ),
                _DrawerItem(
                  icon: Icons.request_quote_rounded,
                  color: AppColors.iconCrimson,
                  title: 'Biaya',
                  onTap: () =>
                      _openDrawerPage('Biaya', const ExpensesPage()),
                ),
                if (isAdmin) ...[
                  const SizedBox(height: 8),
                  _DrawerSection(title: 'Pengaturan'),
                  _DrawerItem(
                    icon: Icons.backup_rounded,
                    color: AppColors.iconSlate,
                    title: 'Backup & Restore',
                    onTap: () =>
                        _openDrawerPage('Backup', const BackupPage()),
                  ),
                ],
              ],
            ),
          ),

          // Bottom version tag
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Icon(Icons.storefront_rounded,
                    size: 14, color: AppColors.hint.withOpacity(0.6)),
                const SizedBox(width: 6),
                Text(
                  'Warung Arasaan V5 Final',
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    color: AppColors.hint,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.primaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'V6–V8 Build',
                    style: GoogleFonts.poppins(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: NavigationBar(
        selectedIndex: _index,
        elevation: 0,
        backgroundColor: Colors.transparent,
        onDestinationSelected: (i) {
          if (i == _index) return;
          setState(() => _index = i);
        },
        destinations: List.generate(
          _labels.length,
          (i) {
            final selected = _index == i;
            // Tab Retur (index 5) uses a themed icon; indicator color differs to signal special nature
            if (i == 5) {
              final color = selected ? AppColors.iconRejek : AppColors.hint;
              return NavigationDestination(
                icon: Icon(
                  Icons.remove_shopping_cart_rounded,
                  color: color,
                  size: 22,
                ),
                selectedIcon: Icon(
                  Icons.remove_shopping_cart_rounded,
                  color: AppColors.iconRejek,
                  size: 22,
                ),
                label: _labels[i],
              );
            }
            return NavigationDestination(
              icon: ColorFiltered(
                colorFilter: ColorFilter.mode(
                  selected ? AppColors.primary : AppColors.hint,
                  BlendMode.srcIn,
                ),
                child: Image.asset(_iconAssets[i], width: 22, height: 22),
              ),
              selectedIcon: ColorFiltered(
                colorFilter: const ColorFilter.mode(
                  AppColors.primary,
                  BlendMode.srcIn,
                ),
                child: Image.asset(_iconAssets[i], width: 22, height: 22),
              ),
              label: _labels[i],
            );
          },
        ),
      ),
    );
  }
}

// ─── Drawer helpers ──────────────────────────────────────────────────────────

class _DrawerSection extends StatelessWidget {
  final String title;
  const _DrawerSection({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 4),
      child: Text(
        title.toUpperCase(),
        style: GoogleFonts.poppins(
          fontSize: 10,
          fontWeight: FontWeight.w700,
          color: AppColors.hint,
          letterSpacing: 0.8,
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppColors.onSurface,
                ),
              ),
              const Spacer(),
              const Icon(Icons.chevron_right_rounded,
                  color: AppColors.hint, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}
