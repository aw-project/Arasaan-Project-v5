package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.warungarasaan.app.core.PermissionCenter
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private data class HoldCartSnapshot(
    val label: String,
    val selected: Map<String, Int>,
    val paymentMethod: String,
    val customerName: String,
    val discountText: String,
    val cashReceivedText: String,
)

private data class FastPosDraftSnapshot(
    val selected: Map<String, Int>,
    val paymentMethod: String,
    val customerName: String,
    val discountText: String,
    val cashReceivedText: String,
)

private fun parseMoney(value: String): Double = value.trim().replace(",", ".").toDoubleOrNull() ?: 0.0

private fun normalizedFastPosQuery(raw: String): String = raw.trim()
    .removeSuffix("\n")
    .removeSuffix("\r")
    .substringAfter("sku:", raw.trim())
    .substringAfter("barcode:", raw.trim())
    .substringAfter("code:", raw.trim())
    .trim()
    .lowercase()
    .replace(" ", "")
    .replace("-", "")
    .replace(".", "")

private const val FAST_POS_HOLD_KEY = "fast_pos_hold_carts_v1"
private const val FAST_POS_SCANNER_MODE_KEY = "fast_pos_scanner_mode_v1"
private const val FAST_POS_DRAFT_KEY = "fast_pos_current_draft_v1"
private const val FAST_POS_CONTINUOUS_SCAN_KEY = "fast_pos_continuous_scan_v1"

private fun fastPosValidationMessage(
    cartSize: Int,
    grossTotal: Double,
    discountAmount: Double,
    paymentMethod: String,
    cashReceived: Double,
    netTotal: Double,
    customerName: String,
): String? {
    if (cartSize <= 0) return "Keranjang masih kosong."
    if (discountAmount > grossTotal) return "Diskon melebihi total belanja."
    if (paymentMethod.equals("Cash", ignoreCase = true) && cashReceived > 0.0 && cashReceived < netTotal) {
        return "Uang bayar masih kurang."
    }
    if (paymentMethod.equals("Tempo", ignoreCase = true) && customerName.isBlank()) {
        return "Nama customer wajib diisi untuk transaksi tempo."
    }
    return null
}

private fun quickCashSuggestions(total: Double): List<Double> {
    val safeTotal = total.coerceAtLeast(0.0)
    if (safeTotal <= 0.0) return listOf(5000.0, 10000.0, 20000.0, 50000.0)
    val exact = kotlin.math.ceil(safeTotal).toInt().toDouble()
    val next5k = (kotlin.math.ceil(safeTotal / 5000.0) * 5000.0).coerceAtLeast(exact)
    val next10k = (kotlin.math.ceil(safeTotal / 10000.0) * 10000.0).coerceAtLeast(next5k)
    val next20k = (kotlin.math.ceil(safeTotal / 20000.0) * 20000.0).coerceAtLeast(next10k)
    return linkedSetOf(exact, next5k, next10k, next20k).toList()
}


private fun HoldCartSnapshot.toJson(): JSONObject = JSONObject()
    .put("label", label)
    .put("paymentMethod", paymentMethod)
    .put("customerName", customerName)
    .put("discountText", discountText)
    .put("cashReceivedText", cashReceivedText)
    .put(
        "selected",
        JSONArray().apply {
            selected.entries.sortedBy { it.key }.forEach { (productId, qty) ->
                put(JSONObject().put("productId", productId).put("qty", qty))
            }
        },
    )


private fun FastPosDraftSnapshot.toJson(): JSONObject = JSONObject()
    .put("paymentMethod", paymentMethod)
    .put("customerName", customerName)
    .put("discountText", discountText)
    .put("cashReceivedText", cashReceivedText)
    .put(
        "selected",
        JSONArray().apply {
            selected.entries.sortedBy { it.key }.forEach { (productId, qty) ->
                put(JSONObject().put("productId", productId).put("qty", qty))
            }
        },
    )

private fun encodeFastPosDraft(snapshot: FastPosDraftSnapshot): String = snapshot.toJson().toString()

private fun decodeFastPosDraft(raw: String): FastPosDraftSnapshot? {
    if (raw.isBlank()) return null
    return runCatching {
        val item = JSONObject(raw)
        val selected = linkedMapOf<String, Int>()
        val selectedArray = item.optJSONArray("selected") ?: JSONArray()
        for (selectedIndex in 0 until selectedArray.length()) {
            val selectedRow = selectedArray.optJSONObject(selectedIndex) ?: continue
            val productId = selectedRow.optString("productId")
            val qty = selectedRow.optInt("qty", 0)
            if (productId.isNotBlank() && qty > 0) {
                selected[productId] = qty
            }
        }
        FastPosDraftSnapshot(
            selected = selected,
            paymentMethod = item.optString("paymentMethod").ifBlank { "Cash" },
            customerName = item.optString("customerName"),
            discountText = item.optString("discountText").ifBlank { "0" },
            cashReceivedText = item.optString("cashReceivedText"),
        )
    }.getOrNull()
}


private fun encodeHoldCarts(rows: List<HoldCartSnapshot>): String = JSONArray().apply {
    rows.forEach { put(it.toJson()) }
}.toString()

private fun decodeHoldCarts(raw: String): List<HoldCartSnapshot> {
    if (raw.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val selected = linkedMapOf<String, Int>()
                val selectedArray = item.optJSONArray("selected") ?: JSONArray()
                for (selectedIndex in 0 until selectedArray.length()) {
                    val selectedRow = selectedArray.optJSONObject(selectedIndex) ?: continue
                    val productId = selectedRow.optString("productId")
                    val qty = selectedRow.optInt("qty", 0)
                    if (productId.isNotBlank() && qty > 0) {
                        selected[productId] = qty
                    }
                }
                add(
                    HoldCartSnapshot(
                        label = item.optString("label").ifBlank { "Hold #${index + 1}" },
                        selected = selected,
                        paymentMethod = item.optString("paymentMethod").ifBlank { "Cash" },
                        customerName = item.optString("customerName"),
                        discountText = item.optString("discountText").ifBlank { "0" },
                        cashReceivedText = item.optString("cashReceivedText"),
                    ),
                )
            }
        }
    }.getOrDefault(emptyList())
}

private fun normalizeHoldLabels(rows: List<HoldCartSnapshot>): List<HoldCartSnapshot> =
    rows.mapIndexed { index, row -> row.copy(label = "Hold #${index + 1}") }

private fun mergeSelections(base: Map<String, Int>, incoming: Map<String, Int>): MutableMap<String, Int> {
    val merged = base.toMutableMap()
    incoming.forEach { (productId, qty) ->
        merged[productId] = (merged[productId] ?: 0) + qty
    }
    return merged
}

private fun holdEstimate(snapshot: HoldCartSnapshot, products: List<Product>): Double {
    val productMap = products.associateBy { it.id }
    return snapshot.selected.entries.sumOf { (productId, qty) ->
        (productMap[productId]?.activeSellPrice ?: 0.0) * qty
    }
}

@Composable
fun FastPosModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var salesToday by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var recentCustomers by remember { mutableStateOf<List<String>>(emptyList()) }
    var recommendedProducts by remember { mutableStateOf<List<Product>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var scannerMode by remember { mutableStateOf(true) }
    var continuousScanMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<MutableMap<String, Int>>(mutableMapOf()) }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var customerName by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("0") }
    var cashReceivedText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var holdCarts by remember { mutableStateOf<List<HoldCartSnapshot>>(emptyList()) }
    var cameraScannerVisible by remember { mutableStateOf(false) }
    var cameraPermissionRequested by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        cameraPermissionRequested = true
        cameraScannerVisible = granted
        if (!granted) {
            message = "Izin kamera dibutuhkan untuk scan barcode lewat kamera."
        }
    }

    suspend fun reload() {
        products = container.productRepository.all().filter { it.stockQty > 0.0 }
        val allSales = container.salesRepository.all()
        salesToday = allSales.filter { it.dateEpochDay == AppUtils.epochDayNow() }
        recentCustomers = allSales
            .sortedByDescending { it.dateEpochDay }
            .map { it.customerName.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(8)
        val analyticsService = AnalyticsService()
        recommendedProducts = analyticsService
            .topSelling(allSales, products, 30)
            .mapNotNull { kpi -> products.firstOrNull { it.id == kpi.productId } }
            .filter { it.stockQty > 0.0 }
            .distinctBy { it.id }
            .take(8)
        holdCarts = normalizeHoldLabels(decodeHoldCarts(container.metaRepository.getString(FAST_POS_HOLD_KEY)))
        scannerMode = container.metaRepository.getBoolean(FAST_POS_SCANNER_MODE_KEY, true)
        continuousScanMode = container.metaRepository.getBoolean(FAST_POS_CONTINUOUS_SCAN_KEY, false)
        decodeFastPosDraft(container.metaRepository.getString(FAST_POS_DRAFT_KEY))?.let { draft ->
            selected = draft.selected.toMutableMap()
            paymentMethod = draft.paymentMethod
            customerName = draft.customerName
            discountText = draft.discountText
            cashReceivedText = draft.cashReceivedText
        }
    }

    fun applyQuickAmount(amount: Double) {
        cashReceivedText = ((parseMoney(cashReceivedText)).coerceAtLeast(0.0) + amount).toInt().toString()
    }

    fun applyExactPayment(total: Double) {
        cashReceivedText = total.coerceAtLeast(0.0).toInt().toString()
    }

    fun persistHolds(nextRows: List<HoldCartSnapshot>) {
        scope.launch {
            container.metaRepository.setString(FAST_POS_HOLD_KEY, encodeHoldCarts(normalizeHoldLabels(nextRows)))
        }
    }

    fun persistScannerMode(next: Boolean) {
        scope.launch {
            container.metaRepository.setBoolean(FAST_POS_SCANNER_MODE_KEY, next)
        }
    }

    fun persistDraft() {
        val raw = if (selected.isEmpty() && customerName.isBlank() && discountText.trim().ifBlank { "0" } == "0" && cashReceivedText.isBlank()) {
            ""
        } else {
            encodeFastPosDraft(
                FastPosDraftSnapshot(
                    selected = selected.toMap(),
                    paymentMethod = paymentMethod,
                    customerName = customerName,
                    discountText = discountText,
                    cashReceivedText = cashReceivedText,
                ),
            )
        }
        scope.launch {
            container.metaRepository.setString(FAST_POS_DRAFT_KEY, raw)
        }
    }

    fun clearDraftState() {
        selected = mutableMapOf()
        customerName = ""
        discountText = "0"
        cashReceivedText = ""
        persistDraft()
    }

    fun saveCurrentAsHold() {
        if (selected.isEmpty()) {
            message = "Keranjang kosong. Belum ada yang bisa di-hold."
            return
        }
        val nextRows = normalizeHoldLabels(
            holdCarts + HoldCartSnapshot(
                label = "Hold #${holdCarts.size + 1}",
                selected = selected.toMap(),
                paymentMethod = paymentMethod,
                customerName = customerName,
                discountText = discountText,
                cashReceivedText = cashReceivedText,
            ),
        )
        holdCarts = nextRows
        persistHolds(nextRows)
        clearDraftState()
        message = "${nextRows.lastOrNull()?.label ?: "Hold"} disimpan."
    }

    fun loadHold(snapshot: HoldCartSnapshot) {
        val hadActiveCart = selected.isNotEmpty()
        selected = if (hadActiveCart) mergeSelections(selected, snapshot.selected) else snapshot.selected.toMutableMap()
        paymentMethod = snapshot.paymentMethod
        customerName = snapshot.customerName
        discountText = snapshot.discountText
        cashReceivedText = snapshot.cashReceivedText
        val nextRows = normalizeHoldLabels(holdCarts.filterNot { it.label == snapshot.label })
        holdCarts = nextRows
        persistHolds(nextRows)
        message = if (hadActiveCart) {
            "${snapshot.label} digabung ke keranjang aktif."
        } else {
            "${snapshot.label} dimuat kembali."
        }
    }

    fun removeHold(snapshot: HoldCartSnapshot) {
        val nextRows = normalizeHoldLabels(holdCarts.filterNot { it.label == snapshot.label })
        holdCarts = nextRows
        persistHolds(nextRows)
        message = "${snapshot.label} dihapus."
    }

    fun loadSaleToCart(sale: Sale) {
        val next = selected.toMutableMap()
        var addedItems = 0
        sale.items.forEach { row ->
            val product = products.firstOrNull { it.id == row.productId } ?: return@forEach
            val currentQty = next[product.id] ?: 0
            val maxQty = product.stockQty.toInt().coerceAtLeast(0)
            val requested = row.qty.toInt().coerceAtLeast(1)
            val finalQty = (currentQty + requested).coerceAtMost(maxQty)
            if (finalQty > currentQty) {
                next[product.id] = finalQty
                addedItems += (finalQty - currentQty)
            }
        }
        selected = next
        paymentMethod = sale.paymentMethod.ifBlank { paymentMethod }
        if (customerName.isBlank()) {
            customerName = sale.customerName
        }
        message = if (addedItems > 0) {
            "Item dari ${sale.id} dimuat ke keranjang."
        } else {
            "Tidak ada item tambahan yang bisa dimuat dari ${sale.id}."
        }
    }

    fun addProduct(product: Product, amount: Int = 1) {
        val currentQty = selected[product.id] ?: 0
        val maxQty = product.stockQty.toInt().coerceAtLeast(0)
        val next = (currentQty + amount).coerceAtMost(maxQty)
        selected = selected.toMutableMap().apply {
            if (next <= 0) remove(product.id) else put(product.id, next)
        }
        if (amount > 0 && maxQty <= 0) {
            message = "Stok ${product.name} habis."
        } else if (amount > 0 && currentQty + amount > maxQty && maxQty > 0) {
            message = "Qty ${product.name} dibatasi stok tersedia."
        }
    }

    fun launchCameraScanner() {
        if (PermissionCenter.isGranted(context, Manifest.permission.CAMERA)) {
            cameraScannerVisible = true
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun applyScannedCode(raw: String): Boolean {
        val normalized = normalizedFastPosQuery(raw)
        if (normalized.isBlank()) {
            message = "Barcode tidak terbaca."
            return false
        }
        val matched = products.firstOrNull {
            normalizedFastPosQuery(it.sku) == normalized || normalizedFastPosQuery(it.id) == normalized
        } ?: products.firstOrNull {
            normalized.length >= 3 && (
                normalizedFastPosQuery(it.sku).startsWith(normalized) ||
                    normalizedFastPosQuery(it.id).startsWith(normalized) ||
                    it.name.lowercase().startsWith(normalized)
            )
        } ?: products.firstOrNull {
            normalized.length >= 4 && (
                it.name.lowercase().contains(normalized) ||
                    normalizedFastPosQuery(it.sku).contains(normalized)
            )
        }
        if (matched == null) {
            query = normalized
            message = "Barcode belum cocok langsung. Kode dipindahkan ke pencarian agar kasir bisa pilih manual."
            return false
        } else {
            addProduct(matched)
            query = ""
            message = if (continuousScanMode) {
                "${matched.name} ditambahkan. Kamera tetap aktif."
            } else {
                "${matched.name} ditambahkan dari kamera."
            }
            return true
        }
    }

    LaunchedEffect(Unit) { reload() }

    LaunchedEffect(selected, paymentMethod, customerName, discountText, cashReceivedText) {
        persistDraft()
    }

    val normalizedQuery = remember(query) { normalizedFastPosQuery(query) }

    val filtered = remember(products, normalizedQuery) {
        products.filter {
            normalizedQuery.isBlank() ||
                it.name.lowercase().contains(normalizedQuery) ||
                normalizedFastPosQuery(it.sku).contains(normalizedQuery) ||
                it.category.lowercase().contains(normalizedQuery) ||
                normalizedFastPosQuery(it.id).contains(normalizedQuery)
        }
    }

    val quickMatch = remember(products, normalizedQuery) {
        if (normalizedQuery.isBlank()) {
            null
        } else {
            products.firstOrNull {
                normalizedFastPosQuery(it.sku) == normalizedQuery ||
                    it.name.lowercase() == normalizedQuery ||
                    normalizedFastPosQuery(it.id) == normalizedQuery
            } ?: products.firstOrNull {
                normalizedQuery.length >= 3 && (
                    normalizedFastPosQuery(it.sku).startsWith(normalizedQuery) ||
                        it.name.lowercase().startsWith(normalizedQuery)
                    )
            }
        }
    }

    LaunchedEffect(normalizedQuery, scannerMode, products) {
        if (!scannerMode || normalizedQuery.isBlank()) return@LaunchedEffect
        val matched = products.firstOrNull {
            normalizedFastPosQuery(it.sku) == normalizedQuery || normalizedFastPosQuery(it.id) == normalizedQuery
        } ?: return@LaunchedEffect
        addProduct(matched)
        query = ""
        message = "${matched.name} ditambahkan dari scanner."
    }

    val cart = remember(products, selected) {
        products.mapNotNull { product ->
            val qty = selected[product.id] ?: 0
            if (qty <= 0) null else product to qty.toDouble()
        }
    }
    val grossTotal = remember(cart) { cart.sumOf { (product, qty) -> product.activeSellPrice * qty } }
    val itemCount = remember(cart) { cart.sumOf { it.second } }
    val discountAmount = remember(discountText) { parseMoney(discountText).coerceAtLeast(0.0) }
    val netTotal = (grossTotal - discountAmount).coerceAtLeast(0.0)
    val cashReceived = remember(cashReceivedText) { parseMoney(cashReceivedText) }
    val changeAmount = (cashReceived - netTotal).coerceAtLeast(0.0)
    val quickCashRows = remember(netTotal) { quickCashSuggestions(netTotal) }
    val paymentGap = (netTotal - cashReceived).coerceAtLeast(0.0)
    val validationMessage = fastPosValidationMessage(
        cartSize = cart.size,
        grossTotal = grossTotal,
        discountAmount = discountAmount,
        paymentMethod = paymentMethod,
        cashReceived = cashReceived,
        netTotal = netTotal,
        customerName = customerName,
    )
    val lastSale = salesToday.maxByOrNull { it.id }

    if (cameraScannerVisible) {
        FastPosCameraScannerDialog(
            onDismiss = { cameraScannerVisible = false },
            keepOpenOnSuccess = continuousScanMode,
            onBarcodeDetected = { code ->
                val matched = applyScannedCode(code)
                val shouldClose = !continuousScanMode || !matched
                if (shouldClose) {
                    cameraScannerVisible = false
                }
                shouldClose
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    validationMessage?.let {
                        message = it
                        return@FloatingActionButton
                    }
                    scope.launch {
                        val items = cart.map { (product, qty) ->
                            SaleItem(
                                productId = product.id,
                                qty = qty,
                                sellPrice = product.activeSellPrice,
                                hppAtSale = product.avgHpp,
                            )
                        }
                        val sale = Sale(
                            id = AppUtils.newId("sale"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            items = items,
                            paymentMethod = paymentMethod,
                            customerName = customerName.trim(),
                            discountAmount = discountAmount,
                            paymentSplits = listOf(PaymentSplit(paymentMethod, netTotal)),
                        )
                        container.salesRepository.add(sale)
                        container.activityLogRepository.log(
                            "fast_pos",
                            "Fast POS ${sale.id} total ${UiFormat.money(netTotal)} untuk ${customerName.ifBlank { "umum" }}",
                        )
                        clearDraftState()
                        message = "Transaksi tersimpan."
                        reload()
                    }
                },
            ) { Text("Bayar") }
        },
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SectionCard(
                    title = "Fast POS",
                    subtitle = "Kasir cepat dengan quick payment, draft persisten, mode scanner keyboard, dan scan barcode kamera.",
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Cari produk / SKU / kategori") },
                        placeholder = { Text("Contoh: sku:TMT-01 atau scan barcode scanner") },
                        singleLine = true,
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Mode scanner" to scannerMode, "Input manual" to !scannerMode)) { (label, active) ->
                            FilterChip(
                                selected = active,
                                onClick = {
                                    val nextMode = label == "Mode scanner"
                                    scannerMode = nextMode
                                    persistScannerMode(nextMode)
                                },
                                label = { Text(label) },
                            )
                        }
                        item {
                            FilterChip(
                                selected = false,
                                onClick = { query = "" },
                                label = { Text("Reset cari") },
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { launchCameraScanner() }) {
                            Text("Scan Kamera")
                        }
                        FilterChip(
                            selected = continuousScanMode,
                            onClick = {
                                val nextMode = !continuousScanMode
                                continuousScanMode = nextMode
                                persistScannerMode(nextMode)
                            },
                            label = { Text(if (continuousScanMode) "Scan beruntun aktif" else "Scan sekali") },
                        )
                        if (cameraPermissionRequested && !PermissionCenter.isGranted(context, Manifest.permission.CAMERA)) {
                            Text("Izin kamera belum diberikan.")
                        }
                    }
                    quickMatch?.let { product ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Cocok cepat: ${product.name}")
                            TextButton(onClick = {
                                addProduct(product)
                                query = ""
                                message = "${product.name} ditambahkan."
                            }) {
                                Text("Tambah")
                            }
                            TextButton(onClick = {
                                addProduct(product, 5)
                                query = ""
                                message = "${product.name} ditambahkan +5."
                            }) {
                                Text("+5")
                            }
                            TextButton(onClick = {
                                addProduct(product, 10)
                                query = ""
                                message = "${product.name} ditambahkan +10."
                            }) {
                                Text("+10")
                            }
                        }
                    }
                    if (recommendedProducts.isNotEmpty()) {
                        Text("Produk favorit 30 hari")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(recommendedProducts, key = { it.id }) { product ->
                                FilterChip(
                                    selected = false,
                                    onClick = {
                                        addProduct(product)
                                        message = "${product.name} ditambahkan dari favorit."
                                    },
                                    label = { Text(product.name) },
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Nama customer") },
                    )
                    if (recentCustomers.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(recentCustomers) { customer ->
                                FilterChip(
                                    selected = customerName.equals(customer, ignoreCase = true),
                                    onClick = { customerName = customer },
                                    label = { Text(customer) },
                                )
                            }
                        }
                    }
                    lastSale?.let { sale ->
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                FilterChip(
                                    selected = false,
                                    onClick = { loadSaleToCart(sale) },
                                    label = { Text("Ulangi transaksi terakhir") },
                                )
                            }
                            item {
                                InfoChip("Nota ${sale.id}")
                            }
                        }
                    }
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { discountText = it },
                        label = { Text("Diskon nominal") },
                    )
                    OutlinedTextField(
                        value = cashReceivedText,
                        onValueChange = { cashReceivedText = it },
                        label = { Text("Uang diterima") },
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Cash", "QRIS", "Transfer", "Tempo")) { method ->
                            FilterChip(
                                selected = paymentMethod == method,
                                onClick = { paymentMethod = method },
                                label = { Text(method) },
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip(if (scannerMode) "Scanner aktif" else "Input manual")
                        InfoChip(if (continuousScanMode) "Kamera beruntun" else "Kamera scan")
                        InfoChip("Mode $paymentMethod")
                        if (holdCarts.isNotEmpty()) {
                            InfoChip("${holdCarts.size} hold")
                        }
                        if (selected.isNotEmpty()) {
                            InfoChip("Draft aktif")
                        }
                        if (recommendedProducts.isNotEmpty()) {
                            InfoChip("${recommendedProducts.size} favorit")
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(quickCashRows) { amount ->
                            FilterChip(
                                selected = false,
                                onClick = { cashReceivedText = amount.toInt().toString() },
                                label = {
                                    Text(
                                        if (amount == netTotal.coerceAtLeast(0.0).toInt().toDouble()) {
                                            "Pas ${UiFormat.money(amount)}"
                                        } else {
                                            "Bayar ${UiFormat.money(amount)}"
                                        }
                                    )
                                },
                            )
                        }
                        item {
                            FilterChip(
                                selected = false,
                                onClick = { applyQuickAmount(5000.0) },
                                label = { Text("+5.000") },
                            )
                        }
                        item {
                            FilterChip(
                                selected = false,
                                onClick = { applyExactPayment(netTotal) },
                                label = { Text("Uang pas") },
                            )
                        }
                        item {
                            FilterChip(
                                selected = false,
                                onClick = { cashReceivedText = "" },
                                label = { Text("Reset bayar") },
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip("Item ${UiFormat.qty(itemCount)}")
                        InfoChip("Subtotal ${UiFormat.money(grossTotal)}")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip("Diskon ${UiFormat.money(discountAmount)}")
                        InfoChip("Total ${UiFormat.money(netTotal)}")
                    }
                    if (cashReceived > 0.0 && cashReceived >= netTotal) {
                        InfoChip("Kembalian ${UiFormat.money(changeAmount)}")
                    } else if (paymentMethod.equals("Cash", ignoreCase = true) && cart.isNotEmpty() && paymentGap > 0.0) {
                        InfoChip("Kurang ${UiFormat.money(paymentGap)}")
                    }
                    validationMessage?.let { InfoChip(it) }
                    if (paymentMethod.equals("Tempo", ignoreCase = true) && customerName.isNotBlank()) {
                        InfoChip("Piutang customer ${customerName.trim()}")
                    }
                    if (lastSale != null) {
                        Text("Transaksi terakhir: ${lastSale.id} • ${UiFormat.money(lastSale.totalSales)}")
                    }
                    if (salesToday.isNotEmpty()) {
                        Text("Transaksi hari ini: ${salesToday.size}")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { saveCurrentAsHold() }) { Text("Simpan Hold") }
                        TextButton(onClick = {
                            clearDraftState()
                            message = "Keranjang dikosongkan."
                        }) { Text("Kosongkan") }
                        TextButton(onClick = {
                            persistDraft()
                            message = "Draft kasir disimpan di perangkat ini."
                        }) { Text("Simpan Draft") }
                    }
                    if (message.isNotBlank()) {
                        Text(message)
                    }
                }
            }

            if (holdCarts.isNotEmpty()) {
                item {
                    SectionCard(
                        title = "Hold Cart",
                        subtitle = "Simpan transaksi sementara dan lanjutkan kembali saat pelanggan siap.",
                    ) {
                        holdCarts.forEach { hold ->
                            ListItem(
                                headlineContent = { Text(hold.label) },
                                supportingContent = {
                                    Text("${hold.selected.values.sum()} item • ${hold.paymentMethod} • ${hold.customerName.ifBlank { "Umum" }} • ${UiFormat.money(holdEstimate(hold, products))}")
                                },
                                trailingContent = {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        TextButton(onClick = { loadHold(hold) }) {
                                            Text("Muat")
                                        }
                                        TextButton(onClick = { removeHold(hold) }) {
                                            Text("Hapus")
                                        }
                                    }
                                },
                            )
                        }
                    }
                }
            }

            item {
                SectionCard(
                    title = "Keranjang",
                    subtitle = if (cart.isEmpty()) "Belum ada item." else "Kelola qty cepat di sini.",
                ) {
                    if (cart.isEmpty()) {
                        EmptyHint("Keranjang kosong", "Pilih produk di daftar bawah atau gunakan SKU yang cocok cepat.")
                    } else {
                        cart.forEach { (product, qty) ->
                            ListItem(
                                headlineContent = { Text(product.name) },
                                supportingContent = { Text("${UiFormat.qty(qty)} ${product.unit} • ${UiFormat.money(product.activeSellPrice * qty)}") },
                                trailingContent = {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        TextButton(onClick = { addProduct(product, -1) }) { Text("-1") }
                                        TextButton(onClick = { addProduct(product, 1) }) { Text("+1") }
                                        TextButton(onClick = { addProduct(product, 5) }) { Text("+5") }
                                        TextButton(onClick = { addProduct(product, 10) }) { Text("+10") }
                                    }
                                },
                            )
                        }
                    }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyHint(
                        title = "Produk tidak ditemukan",
                        subtitle = "Coba kata kunci lain atau tambah stok dahulu.",
                    )
                }
            } else {
                items(filtered, key = { it.id }) { product ->
                    val currentQty = selected[product.id] ?: 0
                    ListItem(
                        headlineContent = { Text(product.name) },
                        supportingContent = {
                            Text("Stock ${UiFormat.qty(product.stockQty)} • ${UiFormat.money(product.activeSellPrice)} • SKU ${product.sku.ifBlank { "-" }}")
                        },
                        trailingContent = {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(currentQty.toString())
                                TextButton(onClick = { addProduct(product, 1) }) { Text("+1") }
                                TextButton(onClick = { addProduct(product, 5) }) { Text("+5") }
                            }
                        },
                    )
                }
            }
        }
    }
}
