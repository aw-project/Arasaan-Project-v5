package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AssistChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.data.service.BusinessActionItem
import com.warungarasaan.app.data.service.BusinessDecisionSummary
import com.warungarasaan.app.data.service.ForecastKpi
import com.warungarasaan.app.data.service.SmartRestockKpi
import com.warungarasaan.app.data.service.MarginDropAlert
import com.warungarasaan.app.data.service.ProductKpi
import com.warungarasaan.app.data.service.ProfitAlert
import com.warungarasaan.app.data.service.PurchasePriceTrend
import com.warungarasaan.app.data.service.SalePriceRecommendation
import com.warungarasaan.app.data.service.SupplierInsight
import com.warungarasaan.app.data.service.SupplierScorecard
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.QuickRangeChips
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun AnalyticsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var rangeDays by remember { mutableStateOf(30) }
    var horizonDays by remember { mutableStateOf(14) }
    var topSelling by remember { mutableStateOf<List<ProductKpi>>(emptyList()) }
    var topProfit by remember { mutableStateOf<List<ProductKpi>>(emptyList()) }
    var lowMargin by remember { mutableStateOf<List<Pair<Product, Double>>>(emptyList()) }
    var forecast by remember { mutableStateOf<List<ForecastKpi>>(emptyList()) }
    var supplierSpend by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }
    var customerRevenue by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }
    var supplierInsights by remember { mutableStateOf<List<SupplierInsight>>(emptyList()) }
    var purchaseTrends by remember { mutableStateOf<List<PurchasePriceTrend>>(emptyList()) }
    var profitAlerts by remember { mutableStateOf<List<ProfitAlert>>(emptyList()) }
    var supplierScorecards by remember { mutableStateOf<List<SupplierScorecard>>(emptyList()) }
    var salePriceRecommendations by remember { mutableStateOf<List<SalePriceRecommendation>>(emptyList()) }
    var marginDropAlerts by remember { mutableStateOf<List<MarginDropAlert>>(emptyList()) }
    var smartRestock by remember { mutableStateOf<List<SmartRestockKpi>>(emptyList()) }
    var decisionSummary by remember { mutableStateOf<BusinessDecisionSummary?>(null) }
    var businessActions by remember { mutableStateOf<List<BusinessActionItem>>(emptyList()) }

    LaunchedEffect(rangeDays, horizonDays) {
        val sales = container.salesRepository.all()
        val purchases = container.purchaseRepository.all()
        val products = container.productRepository.all()
        val service = AnalyticsService()
        topSelling = service.topSelling(sales, products, rangeDays).take(10)
        topProfit = service.topProfit(sales, products, rangeDays).take(10)
        lowMargin = service.lowMarginProducts(products).take(10)
        forecast = service.restockForecast(sales, products, horizonDays = horizonDays).filter { it.suggestBuy > 0 }.take(10)
        supplierSpend = service.supplierSpend(purchases).take(8)
        customerRevenue = service.customerRevenue(sales).take(8)
        supplierInsights = service.supplierInsights(purchases).take(6)
        purchaseTrends = service.purchasePriceTrends(purchases, products).take(6)
        profitAlerts = service.profitAlerts(products).filter { it.status != "AMAN" }.take(8)
        supplierScorecards = service.supplierScorecards(purchases).take(6)
        salePriceRecommendations = service.salePriceRecommendations(products).filter { it.status != "AMAN" }.take(8)
        marginDropAlerts = service.marginDropAlerts(purchases, products).take(8)
        smartRestock = service.smartRestock(sales, products, purchases = purchases).take(8)
        decisionSummary = service.businessDecisionSummary(sales, purchases, products)
        businessActions = service.businessActionItems(sales, purchases, products, limit = 8)
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Analytics", style = MaterialTheme.typography.headlineSmall) }
        item {
            QuickRangeChips(
                currentValue = rangeDays,
                options = listOf(7, 30, 90, 365),
                onSelect = { rangeDays = it },
            )
        }
        item {
            QuickRangeChips(
                currentValue = horizonDays,
                options = listOf(7, 14, 30),
                onSelect = { horizonDays = it },
            )
        }

        item {
            StatCard(
                title = "Top Produk",
                value = topSelling.firstOrNull()?.name ?: "-",
                subtitle = topSelling.firstOrNull()?.let { "Terjual ${UiFormat.qty(it.qty)}" } ?: "Belum ada data",
            )
        }
        item {
            StatCard(
                title = "Produk Profit Tertinggi",
                value = topProfit.firstOrNull()?.name ?: "-",
                subtitle = topProfit.firstOrNull()?.let { UiFormat.money(it.profit) } ?: "Belum ada data",
            )
        }
        item {
            StatCard(
                title = "Supplier Skor Tertinggi",
                value = supplierScorecards.firstOrNull()?.supplier ?: "-",
                subtitle = supplierScorecards.firstOrNull()?.let { "Skor ${"%.1f".format(it.totalScore)} • ${it.recommendation}" } ?: "Belum ada data supplier",
            )
        }
        item {
            StatCard(
                title = "Harga Perlu Review",
                value = salePriceRecommendations.firstOrNull()?.name ?: "-",
                subtitle = salePriceRecommendations.firstOrNull()?.let {
                    "Rekomendasi ${UiFormat.money(it.recommendedSellPrice)}"
                } ?: "Belum ada alert harga jual",
            )
        }

        item {
            StatCard(
                title = "Restock Mendesak",
                value = "${decisionSummary?.criticalRestockCount ?: 0} item",
                subtitle = "Saran beli ${UiFormat.qty(decisionSummary?.criticalRestockBuyQty ?: 0.0)}",
            )
        }
        item {
            StatCard(
                title = "Margin Turun",
                value = "${decisionSummary?.marginAlertCount ?: 0} alert",
                subtitle = "Pantau dampak kenaikan harga beli",
            )
        }
        item {
            StatCard(
                title = "Supplier BI Utama",
                value = decisionSummary?.bestSupplierName ?: "-",
                subtitle = if ((decisionSummary?.bestSupplierScore ?: 0.0) > 0.0) {
                    "Skor ${"%.1f".format(decisionSummary?.bestSupplierScore ?: 0.0)}"
                } else {
                    "Belum ada data supplier"
                },
            )
        }

        item {
            SectionCard("Produk Terlaris") {
                if (topSelling.isEmpty()) {
                    EmptyHint("Belum ada data", "Penjualan akan muncul di sini setelah transaksi berjalan.")
                } else {
                    topSelling.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = { Text("Qty ${UiFormat.qty(row.qty)} • Omzet ${UiFormat.money(row.revenue)}") },
                            trailingContent = { Text(UiFormat.money(row.profit)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Produk Profit Tertinggi") {
                if (topProfit.isEmpty()) {
                    EmptyHint("Belum ada data", "Belum ada profit yang bisa dihitung.")
                } else {
                    topProfit.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = { Text("Margin ${"%.1f".format(row.marginPercent)}%") },
                            trailingContent = { Text(UiFormat.money(row.profit)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Produk Margin Rendah") {
                if (lowMargin.isEmpty()) {
                    EmptyHint("Belum ada data", "Semua produk akan diringkas di sini.")
                } else {
                    lowMargin.forEach { (product, margin) ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(product.name) },
                            supportingContent = { Text("Jual ${UiFormat.money(product.activeSellPrice)} • HPP ${UiFormat.money(product.avgHpp)}") },
                            trailingContent = { Text("${"%.1f".format(margin)}%") },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Forecast Restock") {
                if (forecast.isEmpty()) {
                    EmptyHint("Belum ada kebutuhan restock", "Stok aman untuk horizon yang dipilih.")
                } else {
                    forecast.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = { Text("Avg/hari ${UiFormat.qty(row.avgPerDay)} • Stok ${UiFormat.qty(row.stockQty)}") },
                            trailingContent = { Text("Saran ${UiFormat.qty(row.suggestBuy)}") },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Supplier Teratas") {
                if (supplierSpend.isEmpty()) {
                    EmptyHint("Belum ada pembelian", "Belanja ke supplier akan diringkas di sini.")
                } else {
                    supplierSpend.forEach { (supplier, total) ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(supplier) },
                            trailingContent = { Text(UiFormat.money(total)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Pelanggan Teratas") {
                if (customerRevenue.isEmpty()) {
                    EmptyHint("Belum ada pelanggan", "Pelanggan dengan omzet tertinggi akan muncul di sini.")
                } else {
                    customerRevenue.forEach { (customer, total) ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(customer) },
                            trailingContent = { Text(UiFormat.money(total)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Supplier Intelligence",
                subtitle = "Pantau supplier yang paling aktif dan paling besar kontribusinya.",
            ) {
                if (supplierInsights.isEmpty()) {
                    EmptyHint("Belum ada data supplier", "Insight supplier akan aktif setelah pembelian tercatat.")
                } else {
                    supplierInsights.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.supplier) },
                            supportingContent = {
                                Text("${row.purchaseCount} transaksi • Rata-rata ${UiFormat.money(row.averageOrderValue)} • ${row.stabilityLabel}")
                            },
                            trailingContent = { Text(UiFormat.money(row.totalSpend)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Supplier Scorecard",
                subtitle = "V10: nilai supplier dari stabilitas, harga, dan cakupan produk.",
            ) {
                if (supplierScorecards.isEmpty()) {
                    EmptyHint("Belum ada score supplier", "Skor supplier akan aktif setelah histori pembelian cukup.")
                } else {
                    supplierScorecards.forEach { row ->
                        val priceLabel = when {
                            row.priceIndexPercent >= 5.0 -> "Harga unggul"
                            row.priceIndexPercent >= 0.0 -> "Harga wajar"
                            else -> "Harga lebih mahal"
                        }
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.supplier) },
                            supportingContent = {
                                Text(
                                    "Skor ${"%.1f".format(row.totalScore)} • ${row.purchaseCount} trx • " +
                                        "${row.productCoverage} produk • $priceLabel"
                                )
                            },
                            trailingContent = { Text(row.recommendation) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Tren Harga Beli",
                subtitle = "Lihat produk dengan perubahan harga beli paling besar.",
            ) {
                if (purchaseTrends.isEmpty()) {
                    EmptyHint("Belum ada histori harga", "Harga beli akan dianalisis setelah ada pembelian produk.")
                } else {
                    purchaseTrends.forEach { row ->
                        val direction = when {
                            row.changePercent > 0.001 -> "Naik"
                            row.changePercent < -0.001 -> "Turun"
                            else -> "Stabil"
                        }
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text("Awal ${UiFormat.money(row.firstPrice)} • Terbaru ${UiFormat.money(row.latestPrice)} • Rata-rata ${UiFormat.money(row.averagePrice)}")
                            },
                            trailingContent = { Text("$direction ${"%.1f".format(kotlin.math.abs(row.changePercent))}%") },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Profit Alert",
                subtitle = "Tandai produk rugi atau margin terlalu tipis.",
            ) {
                if (profitAlerts.isEmpty()) {
                    EmptyHint("Semua margin masih aman", "Belum ada produk yang masuk alert profit.")
                } else {
                    profitAlerts.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text("Jual ${UiFormat.money(row.sellPrice)} • HPP ${UiFormat.money(row.avgHpp)} • Margin ${"%.1f".format(row.marginPercent)}%")
                            },
                            trailingContent = { Text(row.status) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Rekomendasi Harga Jual",
                subtitle = "V10: tandai produk yang harga jualnya perlu dinaikkan atau ditinjau ulang.",
            ) {
                if (salePriceRecommendations.isEmpty()) {
                    EmptyHint("Belum ada rekomendasi harga", "Produk dengan gap margin akan muncul di sini.")
                } else {
                    salePriceRecommendations.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text(
                                    "Jual ${UiFormat.money(row.currentSellPrice)} • " +
                                        "Saran ${UiFormat.money(row.recommendedSellPrice)} • " +
                                        "Target ${"%.0f".format(row.targetMarginPercent)}%"
                                )
                            },
                            trailingContent = { Text(row.status) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Alert Margin Turun",
                subtitle = "V10: pantau produk yang marginnya turun setelah harga beli naik.",
            ) {
                if (marginDropAlerts.isEmpty()) {
                    EmptyHint("Belum ada penurunan margin", "Perubahan margin akan dipantau dari histori pembelian.")
                } else {
                    marginDropAlerts.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text(
                                    "Margin lama ${"%.1f".format(row.previousMarginPercent)}% • " +
                                        "sekarang ${"%.1f".format(row.currentMarginPercent)}% • " +
                                        "buy ${UiFormat.money(row.previousBuyPrice)} → ${UiFormat.money(row.latestBuyPrice)}"
                                )
                            },
                            trailingContent = { Text(row.status) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Dashboard BI Utama",
                subtitle = "Ringkas prioritas keputusan bisnis dari restock, harga, dan supplier.",
            ) {
                val summary = decisionSummary
                if (summary == null) {
                    EmptyHint("Belum ada ringkasan BI", "Lengkapi transaksi pembelian dan penjualan agar insight makin akurat.")
                } else {
                    Text("Restock kritis: ${summary.criticalRestockCount} item • saran ${UiFormat.qty(summary.criticalRestockBuyQty)}")
                    Text("Stok mati: ${summary.deadStockCount} • stok lambat: ${summary.slowStockCount}")
                    Text("Alert margin turun: ${summary.marginAlertCount}")
                    Text("Produk harga perlu review: ${summary.priceReviewCount}")
                    Text("Supplier utama: ${summary.bestSupplierName}")
                }
            }
        }

        item {
            SectionCard(
                title = "Supplier-aware Restock",
                subtitle = "Prioritas restock disertai supplier yang paling layak dijadikan acuan beli.",
            ) {
                val rows = smartRestock.filter { it.status in setOf("HABIS", "KRITIS", "WASPADA") }.take(6)
                if (rows.isEmpty()) {
                    EmptyHint("Belum ada restock prioritas", "Saat stok mulai kritis, rekomendasi supplier akan muncul di sini.")
                } else {
                    rows.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text(
                                    "${row.status} • Saran ${UiFormat.qty(row.suggestBuy)} • " +
                                        (if (row.preferredSupplier.isBlank()) "supplier belum cukup data" else "supplier ${row.preferredSupplier}")
                                )
                            },
                            trailingContent = {
                                Text(
                                    if (row.latestBuyPrice > 0.0) UiFormat.money(row.latestBuyPrice) else "-"
                                )
                            },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            AssistChip(
                onClick = {},
                label = { Text("Tahap berikutnya: scanner native, supplier-aware restock, dan dashboard BI utama") },
            )
        }
    }
}
