package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.UiDebouncer
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.redesign.NativeModuleRoutes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import org.json.JSONArray

private const val SEARCH_RECENT_KEY = "global_search_recent_v1"

private data class SearchHit(
    val kind: String,
    val title: String,
    val subtitle: String,
    val trailing: String,
    val score: Int,
    val routeTarget: String,
)

private data class SearchQuerySpec(
    val normalized: String,
    val moduleFilter: String,
)

private fun parseSearchQuery(raw: String, currentFilter: String): SearchQuerySpec {
    val value = raw.trim()
    val lowered = value.lowercase()
    val prefixed = when {
        lowered.startsWith("sku:") -> SearchQuerySpec(lowered.removePrefix("sku:").trim(), "Produk")
        lowered.startsWith("barcode:") -> SearchQuerySpec(lowered.removePrefix("barcode:").trim(), "Produk")
        lowered.startsWith("code:") -> SearchQuerySpec(lowered.removePrefix("code:").trim(), "Produk")
        lowered.startsWith("trx:") -> SearchQuerySpec(lowered.removePrefix("trx:").trim(), "Transaksi")
        lowered.startsWith("transaksi:") -> SearchQuerySpec(lowered.removePrefix("transaksi:").trim(), "Transaksi")
        lowered.startsWith("penjualan:") -> SearchQuerySpec(lowered.removePrefix("penjualan:").trim(), "Penjualan")
        lowered.startsWith("pembelian:") -> SearchQuerySpec(lowered.removePrefix("pembelian:").trim(), "Pembelian")
        lowered.startsWith("supplier:") -> SearchQuerySpec(lowered.removePrefix("supplier:").trim(), "Supplier")
        lowered.startsWith("vendor:") -> SearchQuerySpec(lowered.removePrefix("vendor:").trim(), "Supplier")
        lowered.startsWith("pelanggan:") -> SearchQuerySpec(lowered.removePrefix("pelanggan:").trim(), "Pelanggan")
        lowered.startsWith("customer:") -> SearchQuerySpec(lowered.removePrefix("customer:").trim(), "Pelanggan")
        lowered.startsWith("hutang:") -> SearchQuerySpec(lowered.removePrefix("hutang:").trim(), "Hutang")
        lowered.startsWith("tempo:") -> SearchQuerySpec(lowered.removePrefix("tempo:").trim(), "Hutang")
        lowered.startsWith("aktivitas:") -> SearchQuerySpec(lowered.removePrefix("aktivitas:").trim(), "Aktivitas")
        lowered.startsWith("log:") -> SearchQuerySpec(lowered.removePrefix("log:").trim(), "Aktivitas")
        lowered.startsWith("produk:") -> SearchQuerySpec(lowered.removePrefix("produk:").trim(), "Produk")
        lowered.startsWith("beli:") -> SearchQuerySpec(lowered.removePrefix("beli:").trim(), "Pembelian")
        lowered.startsWith("jual:") -> SearchQuerySpec(lowered.removePrefix("jual:").trim(), "Penjualan")
        lowered.startsWith("kategori:") -> SearchQuerySpec(lowered.removePrefix("kategori:").trim(), "Produk")
        lowered.startsWith("metode:") -> SearchQuerySpec(lowered.removePrefix("metode:").trim(), "Transaksi")
        lowered.startsWith("payment:") -> SearchQuerySpec(lowered.removePrefix("payment:").trim(), "Transaksi")
        lowered.startsWith("pembayaran:") -> SearchQuerySpec(lowered.removePrefix("pembayaran:").trim(), "Transaksi")
        lowered.startsWith("nota:") -> SearchQuerySpec(lowered.removePrefix("nota:").trim(), "Transaksi")
        lowered.startsWith("stok:") -> SearchQuerySpec(lowered.removePrefix("stok:").trim(), "Produk")
        else -> SearchQuerySpec(lowered, currentFilter)
    }
    return prefixed.copy(moduleFilter = prefixed.moduleFilter.ifBlank { currentFilter })
}

private fun moduleWeight(kind: String): Int = when (kind) {
    "Produk" -> 50
    "Penjualan" -> 40
    "Pembelian" -> 35
    "Pelanggan" -> 30
    "Supplier" -> 25
    "Hutang" -> 20
    "Aktivitas" -> 10
    else -> 0
}

private fun routeForHit(kind: String): String = when (kind) {
    "Produk" -> NativeModuleRoutes.Products
    "Penjualan" -> NativeModuleRoutes.Sales
    "Pembelian" -> NativeModuleRoutes.Purchases
    "Pelanggan" -> NativeModuleRoutes.Customers
    "Supplier" -> NativeModuleRoutes.Suppliers
    "Hutang" -> NativeModuleRoutes.Debts
    "Aktivitas" -> NativeModuleRoutes.ActivityLog
    else -> NativeModuleRoutes.GlobalSearch
}

private fun scoreText(title: String, subtitle: String, query: String): Int {
    if (query.isBlank()) return 0
    val t = title.lowercase()
    val s = subtitle.lowercase()
    return when {
        t == query -> 100
        t.startsWith(query) -> 80
        t.contains(query) -> 60
        s.contains(query) -> 20
        else -> 0
    }
}

private fun decodeRecentSearches(raw: String): List<String> {
    if (raw.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optString(index).trim()
                if (item.isNotBlank()) add(item)
            }
        }
    }.getOrDefault(emptyList())
}

private fun encodeRecentSearches(values: List<String>): String = JSONArray().apply {
    values.forEach { put(it) }
}.toString()

private fun updateRecentSearches(current: List<String>, value: String): List<String> {
    val cleaned = value.trim()
    if (cleaned.length < 2 || cleaned.endsWith(":")) return current
    return (listOf(cleaned) + current.filterNot { it.equals(cleaned, ignoreCase = true) }).take(8)
}

private suspend fun buildHits(container: AppContainer, keyword: String, filter: String): List<SearchHit> {
    val spec = parseSearchQuery(keyword, filter)
    val q = spec.normalized
    if (q.isBlank()) return emptyList()

    val products = container.productRepository.all().mapNotNull {
        val subtitle = "${it.category} • SKU ${it.sku.ifBlank { "-" }}"
        val baseScore = scoreText("${it.name} ${it.sku} ${it.id}", subtitle, q)
        if (baseScore <= 0) {
            null
        } else {
            SearchHit(
                kind = "Produk",
                title = it.name,
                subtitle = subtitle,
                trailing = "Stok ${UiFormat.qty(it.stockQty)}",
                score = baseScore + moduleWeight("Produk"),
                routeTarget = routeForHit("Produk"),
            )
        }
    }

    val purchases = container.purchaseRepository.all().mapNotNull {
        val title = it.supplier.ifBlank { "Tanpa supplier" }
        val subtitle = "${it.id} • ${UiFormat.date(it.dateEpochDay)}"
        val text = "$title ${it.id}"
        val baseScore = scoreText(text, subtitle, q)
        if (baseScore <= 0) {
            null
        } else {
            SearchHit(
                kind = "Pembelian",
                title = title,
                subtitle = subtitle,
                trailing = UiFormat.money(it.items.sumOf { row -> row.qty * row.buyPrice }),
                score = baseScore + moduleWeight("Pembelian"),
                routeTarget = routeForHit("Pembelian"),
            )
        }
    }

    val sales = container.salesRepository.all().mapNotNull {
        val title = it.customerName.ifBlank { "Umum" }
        val subtitle = "${it.id} • ${it.paymentSummary}"
        val text = "$title ${it.id} ${it.paymentMethod}"
        val baseScore = scoreText(text, subtitle, q)
        if (baseScore <= 0) {
            null
        } else {
            SearchHit(
                kind = "Penjualan",
                title = title,
                subtitle = subtitle,
                trailing = UiFormat.money(it.totalSales),
                score = baseScore + moduleWeight("Penjualan"),
                routeTarget = routeForHit("Penjualan"),
            )
        }
    }

    val debts = container.debtRepository.all().mapNotNull {
        val subtitle = it.note.ifBlank { "Tanpa catatan" }
        val text = "${it.creditor} ${it.note} ${it.id}"
        val baseScore = scoreText(text, subtitle, q)
        if (baseScore <= 0) {
            null
        } else {
            SearchHit(
                kind = "Hutang",
                title = it.creditor,
                subtitle = subtitle,
                trailing = UiFormat.money(it.remaining),
                score = baseScore + moduleWeight("Hutang"),
                routeTarget = routeForHit("Hutang"),
            )
        }
    }

    val customerHits = sales.groupBy { it.title }.mapNotNull { (customer, rows) ->
        val score = scoreText(customer, "Pelanggan", q)
        if (score <= 0) {
            null
        } else {
            SearchHit(
                kind = "Pelanggan",
                title = customer,
                subtitle = "Dari transaksi penjualan",
                trailing = "${rows.size} transaksi",
                score = score + moduleWeight("Pelanggan"),
                routeTarget = routeForHit("Pelanggan"),
            )
        }
    }

    val supplierHits = purchases.groupBy { it.title }.mapNotNull { (supplier, rows) ->
        val score = scoreText(supplier, "Supplier", q)
        if (score <= 0) {
            null
        } else {
            SearchHit(
                kind = "Supplier",
                title = supplier,
                subtitle = "Dari transaksi pembelian",
                trailing = "${rows.size} pembelian",
                score = score + moduleWeight("Supplier"),
                routeTarget = routeForHit("Supplier"),
            )
        }
    }

    val logs = container.activityLogRepository.recent(200).mapNotNull {
        val subtitle = it.newJson.ifBlank { it.refId.ifBlank { "Tanpa detail" } }
        val text = "${it.type} ${it.newJson} ${it.refId}"
        val baseScore = scoreText(text, subtitle, q)
        if (baseScore <= 0) {
            null
        } else {
            SearchHit(
                kind = "Aktivitas",
                title = it.type,
                subtitle = subtitle,
                trailing = UiFormat.date(it.dateEpochDay),
                score = baseScore + moduleWeight("Aktivitas"),
                routeTarget = routeForHit("Aktivitas"),
            )
        }
    }

    val all = products + purchases + sales + debts + customerHits + supplierHits + logs
    val filtered = when (spec.moduleFilter) {
        "Semua" -> all
        "Transaksi" -> all.filter { it.kind in setOf("Penjualan", "Pembelian") }
        else -> all.filter { it.kind == spec.moduleFilter }
    }
    return filtered.sortedWith(compareByDescending<SearchHit> { it.score }.thenBy { it.title.lowercase() })
}

@Composable
fun SearchModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    onNavigate: ((String) -> Unit)? = null,
) {
    val scope: CoroutineScope = rememberCoroutineScope()
    val debouncer = remember(scope) { UiDebouncer(scope, 220L) }

    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Semua") }
    var hits by remember { mutableStateOf<List<SearchHit>>(emptyList()) }
    var recentQueries by remember { mutableStateOf<List<String>>(emptyList()) }

    suspend fun persistRecent(value: String) {
        val nextRows = updateRecentSearches(recentQueries, value)
        if (nextRows == recentQueries) return
        recentQueries = nextRows
        container.metaRepository.setString(SEARCH_RECENT_KEY, encodeRecentSearches(nextRows))
    }

    fun requestReload(nextQuery: String = query, nextFilter: String = filter) {
        debouncer.submit {
            val nextHits = buildHits(container, nextQuery, nextFilter)
            hits = nextHits
            if (nextQuery.isNotBlank() && nextHits.isNotEmpty()) {
                persistRecent(nextQuery)
            }
        }
    }

    fun applySuggestion(value: String) {
        query = value
        requestReload(nextQuery = value)
    }

    LaunchedEffect(Unit) {
        recentQueries = decodeRecentSearches(container.metaRepository.getString(SEARCH_RECENT_KEY))
        requestReload(query, filter)
    }
    LaunchedEffect(filter) { requestReload(query, filter) }

    val hitCounts = remember(hits) { hits.groupingBy { it.kind }.eachCount() }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    requestReload(nextQuery = it)
                },
                modifier = Modifier,
                label = { Text("Cari produk, trx, supplier, pelanggan, hutang") },
                placeholder = { Text("Contoh: tomat, sku:TM-01, trx:sale") },
                singleLine = true,
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Semua", "Produk", "Transaksi", "Pelanggan", "Supplier", "Hutang", "Aktivitas")) { option ->
                    FilterChip(
                        selected = filter == option,
                        onClick = { filter = option },
                        label = { Text(option) },
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoChip(if (query.isBlank()) "Masukkan kata kunci" else "Hasil ${hits.size}")
                if (query.isNotBlank()) {
                    hitCounts["Produk"]?.takeIf { it > 0 }?.let { InfoChip("Produk $it") }
                    hitCounts["Penjualan"]?.takeIf { it > 0 }?.let { InfoChip("Jual $it") }
                    hitCounts["Pembelian"]?.takeIf { it > 0 }?.let { InfoChip("Beli $it") }
                }
                if (query.isNotBlank() || filter != "Semua") {
                    TextButton(onClick = {
                        query = ""
                        filter = "Semua"
                        hits = emptyList()
                    }) {
                        Text("Reset")
                    }
                }
            }
        }

        if (query.isBlank()) {
            item {
                EmptyHint(
                    "Pencarian global",
                    "Dukungan query pintar: sku:, trx:, supplier:, pelanggan:, hutang:, produk:, beli:, jual:, kategori:, metode:.",
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("sku:", "trx:", "supplier:", "pelanggan:", "hutang:", "produk:", "beli:", "jual:", "kategori:", "metode:", "tomat", "kentang")) { suggestion ->
                        FilterChip(
                            selected = false,
                            onClick = { applySuggestion(suggestion) },
                            label = { Text(suggestion) },
                        )
                    }
                }
            }
            if (recentQueries.isNotEmpty()) {
                item { Text("Pencarian terbaru") }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(recentQueries) { suggestion ->
                            FilterChip(
                                selected = false,
                                onClick = { applySuggestion(suggestion) },
                                label = { Text(suggestion) },
                            )
                        }
                        item {
                            TextButton(onClick = {
                                recentQueries = emptyList()
                                scope.launch {
                                    container.metaRepository.setString(SEARCH_RECENT_KEY, "")
                                }
                            }) {
                                Text("Hapus riwayat")
                            }
                        }
                    }
                }
            }
        } else if (hits.isEmpty()) {
            item {
                EmptyHint(
                    "Tidak ada hasil",
                    if (filter == "Semua") {
                        "Coba kata kunci lain, SKU, nama mitra, atau ID transaksi."
                    } else {
                        "Belum ada hasil pada modul $filter. Coba ganti kata kunci atau reset filter."
                    },
                )
            }
        } else {
            items(hits) { hit ->
                ListItem(
                    modifier = Modifier.clickable(enabled = onNavigate != null) {
                        onNavigate?.invoke(hit.routeTarget)
                    },
                    headlineContent = { Text("${hit.kind} • ${hit.title}") },
                    supportingContent = { Text(hit.subtitle) },
                    trailingContent = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(hit.trailing)
                            if (onNavigate != null) {
                                TextButton(onClick = { onNavigate(hit.routeTarget) }) {
                                    Text("Buka")
                                }
                            }
                        }
                    },
                )
            }
        }
    }
}
