
package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.LabeledNumberField
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.warungarasaan.app.ui.viewmodel.SalesViewModel
import com.warungarasaan.app.ui.viewmodel.SalesEvent


private data class SaleDraftRow(
    val key: String = AppUtils.newId("row"),
    val productId: String = "",
    val qty: String = "1",
    val sellPrice: String = "0",
)

@Composable
fun SalesModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: SalesViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    if (state.showDialog) {
        SaleEditorDialog(
            products = state.products,
            initial = state.editing,
            easyModeDefault = state.easyMode,
            onDismiss = { vm.onEvent(SalesEvent.DismissDialog) },
            onSave = { id, customer, paymentMethod, rows, discount, splitMethod2, splitAmount2 ->
                val items = rows.mapNotNull { row ->
                    val product = state.products.firstOrNull { it.id == row.productId } ?: return@mapNotNull null
                    SaleItem(row.productId, row.qty.toDouble(), row.sellPrice.toDouble(), product.avgHpp)
                }
                val discountValue = discount.toDoubleOrNull() ?: 0.0
                val total = (items.sumOf { it.total } - discountValue).coerceAtLeast(0.0)
                val splits = mutableListOf<PaymentSplit>()
                val split2 = splitAmount2.toDoubleOrNull() ?: 0.0
                if (splitMethod2.isNotBlank() && split2 > 0.0) {
                    val mainAmount = (total - split2).coerceAtLeast(0.0)
                    if (mainAmount > 0.0) splits += PaymentSplit(paymentMethod, mainAmount)
                    splits += PaymentSplit(splitMethod2, split2)
                }
                vm.onEvent(SalesEvent.Save(
                    id = id,
                    customer = customer,
                    paymentMethod = paymentMethod,
                    items = items,
                    discount = discountValue,
                    splits = splits,
                    existingDate = state.editing?.dateEpochDay,
                ))
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = { FloatingActionButton(onClick = { vm.onEvent(SalesEvent.AddNew) }) { Text("+") } },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SectionCard(
                    title = if (state.easyMode) "Penjualan Harian" else "Penjualan Lengkap",
                    subtitle = if (state.easyMode) "Cari transaksi, tambah penjualan, lalu simpan. Gunakan mode lengkap bila butuh diskon dan split bayar." else "Semua opsi penjualan ditampilkan."
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { vm.onEvent(SalesEvent.EasyModeChanged(true)) }) { Text("Mode Mudah") }
                        TextButton(onClick = { vm.onEvent(SalesEvent.EasyModeChanged(false)) }) { Text("Mode Lengkap") }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = state.query,
                    onValueChange = { vm.onEvent(SalesEvent.QueryChanged(it)) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(if (state.easyMode) "Cari pembeli / nota / cara bayar" else "Cari customer / ID / metode bayar") },
                    singleLine = true,
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip("Transaksi ${state.sales.size}")
                    InfoChip("Omzet ${UiFormat.money(state.sales.sumOf { it.totalSales })}")
                }
            }
            if (state.message.isNotBlank()) item { SectionCard("Status") { Text(state.message) } }
            if (state.products.isEmpty()) {
                item { EmptyHint("Belum ada produk", "Tambah produk terlebih dulu agar penjualan bisa dicatat.") }
            } else if (state.filtered.isEmpty()) {
                item { EmptyHint("Belum ada penjualan", "Gunakan tombol tambah untuk input penjualan multi-item.") }
            } else {
                itemsIndexed(state.filtered, key = { _, item -> item.id }) { _, sale ->
                    val itemText = sale.items.joinToString { item ->
                        val name = state.productMap[item.productId]?.name ?: item.productId
                        "$name x ${UiFormat.qty(item.qty)}"
                    }
                    SectionCard(
                        title = sale.customerName.ifBlank { "Umum" },
                        subtitle = "${sale.id} • ${UiFormat.date(sale.dateEpochDay)} • ${sale.paymentSummary}",
                    ) {
                        Text(itemText)
                        Text("Netto: ${UiFormat.money(sale.totalSales)} • Profit: ${UiFormat.money(sale.totalProfit)}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { vm.onEvent(SalesEvent.SelectDetail(sale)) }) { Text("Lihat") }
                            TextButton(onClick = { vm.onEvent(SalesEvent.EditRequest(sale)) }) { Text("Ubah") }
                            TextButton(onClick = { vm.onEvent(SalesEvent.Delete(sale.id)) }) { Text("Hapus") }
                        }
                    }
                }
            }
        }
    }

    selected?.let { sale ->
        AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Tutup") } },
            title = { Text("Detail penjualan") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Text("${sale.id} • ${UiFormat.date(sale.dateEpochDay)}") }
                    item { Text("Customer: ${sale.customerName.ifBlank { "Umum" }}") }
                    item { Text("Pembayaran: ${sale.paymentSummary}") }
                    item { Text("Diskon: ${UiFormat.money(sale.discountAmount)}") }
                    itemsIndexed(sale.items) { _, item ->
                        val product = state.productMap[item.productId]
                        ListItem(
                            headlineContent = { Text(product?.name ?: item.productId) },
                            supportingContent = { Text("Qty ${UiFormat.qty(item.qty)} • ${UiFormat.money(item.sellPrice)}") },
                            trailingContent = { Text(UiFormat.money(item.total)) },
                        )
                    }
                }
            },
        )
    }
}

@Composable
private fun SaleEditorDialog(
    products: List<Product>,
    initial: Sale?,
    easyModeDefault: Boolean = true,
    onDismiss: () -> Unit,
    onSave: (
        id: String,
        customer: String,
        paymentMethod: String,
        rows: List<SaleDraftRow>,
        discount: String,
        splitMethod2: String,
        splitAmount2: String,
    ) -> Unit,
) {
    var customer by remember(initial) { mutableStateOf(initial?.customerName.orEmpty()) }
    var paymentMethod by remember(initial) { mutableStateOf(initial?.paymentMethod ?: "Cash") }
    var discount by remember(initial) { mutableStateOf(UiFormat.qty(initial?.discountAmount ?: 0.0)) }
    var splitMethod2 by remember(initial) { mutableStateOf(initial?.paymentSplits?.getOrNull(1)?.method.orEmpty()) }
    var splitAmount2 by remember(initial) { mutableStateOf(UiFormat.qty(initial?.paymentSplits?.getOrNull(1)?.amount ?: 0.0)) }
    var easyMode by remember(initial, easyModeDefault) { mutableStateOf(easyModeDefault) }
    var rows by remember(initial, products) {
        mutableStateOf(
            initial?.items?.map {
                SaleDraftRow(
                    productId = it.productId,
                    qty = UiFormat.qty(it.qty),
                    sellPrice = UiFormat.qty(it.sellPrice),
                )
            } ?: listOf(
                SaleDraftRow(
                    productId = products.firstOrNull()?.id.orEmpty(),
                    sellPrice = UiFormat.qty(products.firstOrNull()?.activeSellPrice ?: 0.0),
                ),
            )
        )
    }

    fun update(index: Int, transform: (SaleDraftRow) -> SaleDraftRow) {
        rows = rows.mapIndexed { i, row -> if (i == index) transform(row) else row }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        initial?.id.orEmpty(),
                        customer,
                        paymentMethod,
                        rows.filter { it.productId.isNotBlank() && (it.qty.toDoubleOrNull() ?: 0.0) > 0.0 },
                        discount,
                        splitMethod2,
                        splitAmount2,
                    )
                },
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text(if (initial == null) "Input penjualan" else "Ubah penjualan") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    SectionCard(
                        title = if (easyMode) "Mode Mudah" else "Mode Lengkap",
                        subtitle = if (easyMode) "Isi pembeli, cara bayar, lalu pilih barang." else "Tampilkan diskon dan pembayaran campuran."
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { easyMode = true }) { Text("Mode Mudah") }
                            TextButton(onClick = { easyMode = false }) { Text("Mode Lengkap") }
                        }
                    }
                }
                item { OutlinedTextField(customer, { customer = it }, label = { Text("Nama pembeli (boleh kosong)") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(paymentMethod, { paymentMethod = it }, label = { Text("Cara bayar") }, modifier = Modifier.fillMaxWidth()) }
                if (!easyMode) item { LabeledNumberField("Diskon", discount, { discount = it }) }
                if (!easyMode) item {
                    SectionCard("Pembayaran campuran", subtitle = "Isi metode kedua dan nominalnya bila pembayaran dibagi.") {
                        OutlinedTextField(splitMethod2, { splitMethod2 = it }, label = { Text("Cara bayar kedua") }, modifier = Modifier.fillMaxWidth())
                        LabeledNumberField("Nominal cara bayar kedua", splitAmount2, { splitAmount2 = it })
                    }
                }
                itemsIndexed(rows, key = { _, row -> row.key }) { index, row ->
                    SectionCard(title = "Baris ${index + 1}", subtitle = if (easyMode) "Pilih barang, isi jumlah, lalu simpan." else "Gunakan ID barang dari master produk.") {
                        OutlinedTextField(
                            value = row.productId,
                            onValueChange = { value -> update(index) { rowValue -> rowValue.copy(productId = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(if (easyMode) "ID barang" else "Product ID") },
                            singleLine = true,
                        )
                        LabeledNumberField("Qty", row.qty, { value -> update(index) { rowValue -> rowValue.copy(qty = value) } })
                        LabeledNumberField("Harga jual", row.sellPrice, { value -> update(index) { rowValue -> rowValue.copy(sellPrice = value) } })
                        val product = products.firstOrNull { it.id == row.productId }
                        if (product != null) {
                            Text("Produk: ${product.name} • Stok ${UiFormat.qty(product.stockQty)} • HPP ${UiFormat.money(product.avgHpp)}")
                        }
                        TextButton(onClick = { if (rows.size > 1) rows = rows.filterIndexed { i, _ -> i != index } }) { Text("Hapus baris") }
                    }
                }
                item {
                    TextButton(
                        onClick = {
                            rows = rows + SaleDraftRow(
                                productId = products.firstOrNull()?.id.orEmpty(),
                                sellPrice = UiFormat.qty(products.firstOrNull()?.activeSellPrice ?: 0.0),
                            )
                        },
                    ) { Text("+ Tambah barang") }
                }
            }
        },
    )
}
