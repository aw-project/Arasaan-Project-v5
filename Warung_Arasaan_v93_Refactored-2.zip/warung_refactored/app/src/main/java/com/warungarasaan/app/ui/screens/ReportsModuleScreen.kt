package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.service.ReportExportService
import com.warungarasaan.app.data.service.ReportingService
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.ui.QuickRangeChips
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.viewmodel.ReportsViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private data class ProductSalesRow(
    val productName: String,
    val qty: Double,
    val omzet: Double,
    val hpp: Double,
)

@Composable
fun ReportsModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: ReportsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Laporan", style = MaterialTheme.typography.headlineSmall) }
        item {
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7, 30, 90, 365).forEach { days ->
                    AssistChip(
                        onClick = { vm.onEvent(ReportsEvent.RangeDaysChanged(days)) },
                        label = { Text("$days hari") },
                    )
                }
            }
        }
        item { StatCard("Periode Aktif", "${state.rangeDays} hari", "Filter ringkas untuk mendekatkan halaman reports Flutter") }
        item { StatCard("Omzet", UiFormat.money(state.omzet), "Akumulasi total penjualan") }
        item { StatCard("HPP", UiFormat.money(state.hpp), "Akumulasi cost barang terjual") }
        item { StatCard("Profit kotor", UiFormat.money(omzet - hpp), "Omzet - HPP") }
        item { StatCard("Biaya operasional", UiFormat.money(state.expense), "Total pengeluaran") }
        item { StatCard("Profit bersih estimasi", UiFormat.money((omzet - hpp) - expense - rejectLoss), "Profit kotor - biaya - kerugian rejek") }
        item { HorizontalDivider() }
        item { StatCard("Nilai pembelian", UiFormat.money(state.purchase), "Pembelian stok pada periode aktif") }
        item { StatCard("Sisa hutang", UiFormat.money(state.debtRemaining), "Outstanding hutang yang belum lunas") }
        item { StatCard("Nilai stok", UiFormat.money(state.stockValue), "StockQty x AvgHPP") }
        item { StatCard("Rugi rejek", UiFormat.money(state.rejectLoss), "Estimasi loss barang reject/retur") }
        item { HorizontalDivider() }
        item {
            SectionCard("Produk terlaris", subtitle = "Top 10 berdasarkan omzet periode aktif") {
                if (state.topProducts.isEmpty()) {
                    Text("Belum ada data penjualan pada periode ini.")
                } else {
                    state.topProducts.forEach { row ->
                        Text("${row.productName} • Qty ${UiFormat.qty(row.qty)} • Omzet ${UiFormat.money(row.omzet)} • Profit ${UiFormat.money(row.omzet - row.hpp)}")
                    }
                }
            }
        }
        item {
            SectionCard("Stok kritis", subtitle = "Produk yang perlu restock segera") {
                if (state.lowStock.isEmpty()) {
                    Text("Tidak ada stok kritis.")
                } else {
                    state.lowStock.forEach { product ->
                        Text("${product.name} • Stok ${UiFormat.qty(product.stockQty)} / Min ${UiFormat.qty(product.minStock)}")
                    }
                }
            }
        }
        item {
            SectionCard("Preview CSV Penjualan", subtitle = "Potongan isi export CSV, belum menulis langsung ke file pada layar ini.") {
                OutlinedTextField(
                    value = csvPreview,
                    onValueChange = {},
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp),
                    readOnly = true,
                    label = { Text("CSV") },
                )
                TextButton(onClick = {
                    csvPreview = state.csvPreview
                }) { Text("Refresh Preview") }
            }
        }
    }
}
