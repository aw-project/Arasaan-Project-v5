package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AssistChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.data.service.BusinessActionItem
import com.warungarasaan.app.data.service.BusinessDecisionSummary
import com.warungarasaan.app.data.service.ForecastKpi
import com.warungarasaan.app.data.service.SmartRestockKpi
import com.warungarasaan.app.data.service.MarginDropAlert
import com.warungarasaan.app.data.service.ProductKpi
import com.warungarasaan.app.data.service.ProfitAlert
import com.warungarasaan.app.data.service.PurchasePriceTrend
import com.warungarasaan.app.data.service.SalePriceRecommendation
import com.warungarasaan.app.data.service.SupplierInsight
import com.warungarasaan.app.data.service.SupplierRestockPriority
import com.warungarasaan.app.data.service.SupplierScorecard
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.QuickRangeChips
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.viewmodel.AnalyticsViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun AnalyticsModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: AnalyticsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()


    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Analytics", style = MaterialTheme.typography.headlineSmall) }
        item {
            QuickRangeChips(
                currentValue = state.rangeDays,
                options = listOf(7, 30, 90, 365),
                onSelect = { vm.onEvent(AnalyticsEvent.RangeDaysChanged(it)) },
            )
        }
        item {
            QuickRangeChips(
                currentValue = state.horizonDays,
                options = listOf(7, 14, 30),
                onSelect = { vm.onEvent(AnalyticsEvent.HorizonDaysChanged(it)) },
            )
        }

        item {
            StatCard(
                title = "Top Produk",
                value = state.topSelling.firstOrNull()?.name ?: "-",
                subtitle = state.topSelling.firstOrNull()?.let { "Terjual ${UiFormat.qty(it.qty)}" } ?: "Belum ada data",
            )
        }
        item {
            StatCard(
                title = "Produk Profit Tertinggi",
                value = state.topProfit.firstOrNull()?.name ?: "-",
                subtitle = state.topProfit.firstOrNull()?.let { UiFormat.money(it.profit) } ?: "Belum ada data",
            )
        }
        item {
            StatCard(
                title = "Supplier Skor Tertinggi",
                value = state.supplierScorecards.firstOrNull()?.supplier ?: "-",
                subtitle = state.supplierScorecards.firstOrNull()?.let { "Skor ${"%.1f".format(it.totalScore)} • ${it.recommendation}" } ?: "Belum ada data supplier",
            )
        }
        item {
            StatCard(
                title = "Harga Perlu Review",
                value = state.salePriceRecommendations.firstOrNull()?.name ?: "-",
                subtitle = state.salePriceRecommendations.firstOrNull()?.let {
                    "Rekomendasi ${UiFormat.money(it.recommendedSellPrice)}"
                } ?: "Belum ada alert harga jual",
            )
        }

        item {
            StatCard(
                title = "Restock Mendesak",
                value = "${state.decisionSummary?.criticalRestockCount ?: 0} item",
                subtitle = "Saran beli ${UiFormat.qty(state.decisionSummary?.criticalRestockBuyQty ?: 0.0)}",
            )
        }
        item {
            StatCard(
                title = "Margin Turun",
                value = "${state.decisionSummary?.marginAlertCount ?: 0} alert",
                subtitle = "Pantau dampak kenaikan harga beli",
            )
        }
        item {
            StatCard(
                title = "Supplier BI Utama",
                value = state.decisionSummary?.bestSupplierName ?: "-",
                subtitle = if ((state.decisionSummary?.bestSupplierScore ?: 0.0) > 0.0) {
                    "Skor ${"%.1f".format(state.decisionSummary?.bestSupplierScore ?: 0.0)}"
                } else {
                    "Belum ada data supplier"
                },
            )
        }

        item {
            StatCard(
                title = "Supplier Restock Tersibuk",
                value = state.supplierRestockPriorities.firstOrNull()?.supplier ?: "-",
                subtitle = state.supplierRestockPriorities.firstOrNull()?.let {
                    "${it.criticalItemCount} kritis • estimasi ${UiFormat.money(it.estimatedPurchaseValue)}"
                } ?: "Belum ada prioritas supplier restock",
            )
        }

        item {
            SectionCard("Produk Terlaris") {
                if (state.topSelling.isEmpty()) {
                    EmptyHint("Belum ada data", "Penjualan akan muncul di sini setelah transaksi berjalan.")
                } else {
                    state.topSelling.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = { Text("Qty ${UiFormat.qty(row.qty)} • Omzet ${UiFormat.money(row.revenue)}") },
                            trailingContent = { Text(UiFormat.money(row.profit)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Produk Profit Tertinggi") {
                if (state.topProfit.isEmpty()) {
                    EmptyHint("Belum ada data", "Belum ada profit yang bisa dihitung.")
                } else {
                    state.topProfit.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = { Text("Margin ${"%.1f".format(row.marginPercent)}%") },
                            trailingContent = { Text(UiFormat.money(row.profit)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Produk Margin Rendah") {
                if (state.lowMargin.isEmpty()) {
                    EmptyHint("Belum ada data", "Semua produk akan diringkas di sini.")
                } else {
                    state.lowMargin.forEach { (product, margin) ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(product.name) },
                            supportingContent = { Text("Jual ${UiFormat.money(product.activeSellPrice)} • HPP ${UiFormat.money(product.avgHpp)}") },
                            trailingContent = { Text("${"%.1f".format(margin)}%") },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Forecast Restock") {
                if (state.forecast.isEmpty()) {
                    EmptyHint("Belum ada kebutuhan restock", "Stok aman untuk horizon yang dipilih.")
                } else {
                    state.forecast.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = { Text("Avg/hari ${UiFormat.qty(row.avgPerDay)} • Stok ${UiFormat.qty(row.stockQty)}") },
                            trailingContent = { Text("Saran ${UiFormat.qty(row.suggestBuy)}") },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Supplier Teratas") {
                if (state.supplierSpend.isEmpty()) {
                    EmptyHint("Belum ada pembelian", "Belanja ke supplier akan diringkas di sini.")
                } else {
                    state.supplierSpend.forEach { (supplier, total) ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(supplier) },
                            trailingContent = { Text(UiFormat.money(total)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard("Pelanggan Teratas") {
                if (state.customerRevenue.isEmpty()) {
                    EmptyHint("Belum ada pelanggan", "Pelanggan dengan omzet tertinggi akan muncul di sini.")
                } else {
                    state.customerRevenue.forEach { (customer, total) ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(customer) },
                            trailingContent = { Text(UiFormat.money(total)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Supplier Intelligence",
                subtitle = "Pantau supplier yang paling aktif dan paling besar kontribusinya.",
            ) {
                if (state.supplierInsights.isEmpty()) {
                    EmptyHint("Belum ada data supplier", "Insight supplier akan aktif setelah pembelian tercatat.")
                } else {
                    state.supplierInsights.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.supplier) },
                            supportingContent = {
                                Text("${row.purchaseCount} transaksi • Rata-rata ${UiFormat.money(row.averageOrderValue)} • ${row.stabilityLabel}")
                            },
                            trailingContent = { Text(UiFormat.money(row.totalSpend)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Supplier Scorecard",
                subtitle = "V10: nilai supplier dari stabilitas, harga, dan cakupan produk.",
            ) {
                if (state.supplierScorecards.isEmpty()) {
                    EmptyHint("Belum ada score supplier", "Skor supplier akan aktif setelah histori pembelian cukup.")
                } else {
                    state.supplierScorecards.forEach { row ->
                        val priceLabel = when {
                            row.priceIndexPercent >= 5.0 -> "Harga unggul"
                            row.priceIndexPercent >= 0.0 -> "Harga wajar"
                            else -> "Harga lebih mahal"
                        }
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.supplier) },
                            supportingContent = {
                                Text(
                                    "Skor ${"%.1f".format(row.totalScore)} • ${row.purchaseCount} trx • " +
                                        "${row.productCoverage} produk • $priceLabel"
                                )
                            },
                            trailingContent = { Text(row.recommendation) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Tren Harga Beli",
                subtitle = "Lihat produk dengan perubahan harga beli paling besar.",
            ) {
                if (state.purchaseTrends.isEmpty()) {
                    EmptyHint("Belum ada histori harga", "Harga beli akan dianalisis setelah ada pembelian produk.")
                } else {
                    state.purchaseTrends.forEach { row ->
                        val direction = when {
                            row.changePercent > 0.001 -> "Naik"
                            row.changePercent < -0.001 -> "Turun"
                            else -> "Stabil"
                        }
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text("Awal ${UiFormat.money(row.firstPrice)} • Terbaru ${UiFormat.money(row.latestPrice)} • Rata-rata ${UiFormat.money(row.averagePrice)}")
                            },
                            trailingContent = { Text("$direction ${"%.1f".format(kotlin.math.abs(row.changePercent))}%") },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Profit Alert",
                subtitle = "Tandai produk rugi atau margin terlalu tipis.",
            ) {
                if (state.profitAlerts.isEmpty()) {
                    EmptyHint("Semua margin masih aman", "Belum ada produk yang masuk alert profit.")
                } else {
                    state.profitAlerts.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text("Jual ${UiFormat.money(row.sellPrice)} • HPP ${UiFormat.money(row.avgHpp)} • Margin ${"%.1f".format(row.marginPercent)}%")
                            },
                            trailingContent = { Text(row.status) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Rekomendasi Harga Jual",
                subtitle = "V10: tandai produk yang harga jualnya perlu dinaikkan atau ditinjau ulang.",
            ) {
                if (state.salePriceRecommendations.isEmpty()) {
                    EmptyHint("Belum ada rekomendasi harga", "Produk dengan gap margin akan muncul di sini.")
                } else {
                    state.salePriceRecommendations.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text(
                                    "Jual ${UiFormat.money(row.currentSellPrice)} • " +
                                        "Saran ${UiFormat.money(row.recommendedSellPrice)} • " +
                                        "Target ${"%.0f".format(row.targetMarginPercent)}%"
                                )
                            },
                            trailingContent = { Text(row.status) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Alert Margin Turun",
                subtitle = "V10: pantau produk yang marginnya turun setelah harga beli naik.",
            ) {
                if (state.marginDropAlerts.isEmpty()) {
                    EmptyHint("Belum ada penurunan margin", "Perubahan margin akan dipantau dari histori pembelian.")
                } else {
                    state.marginDropAlerts.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text(
                                    "Margin lama ${"%.1f".format(row.previousMarginPercent)}% • " +
                                        "sekarang ${"%.1f".format(row.currentMarginPercent)}% • " +
                                        "buy ${UiFormat.money(row.previousBuyPrice)} → ${UiFormat.money(row.latestBuyPrice)}"
                                )
                            },
                            trailingContent = { Text(row.status) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }


        item {
            SectionCard(
                title = "Supplier Restock Priority",
                subtitle = "Gabungkan restock kritis berdasarkan supplier agar belanja lebih efisien.",
            ) {
                if (state.supplierRestockPriorities.isEmpty()) {
                    EmptyHint("Belum ada supplier restock prioritas", "Saat item kritis memiliki histori supplier, prioritas belanja supplier akan muncul di sini.")
                } else {
                    state.supplierRestockPriorities.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.supplier) },
                            supportingContent = {
                                Text(
                                    "${row.criticalItemCount} kritis • ${row.watchItemCount} waspada • " +
                                        "saran ${UiFormat.qty(row.totalSuggestBuyQty)} • " +
                                        (if (row.topProductName.isBlank()) "cek item prioritas" else "utama ${row.topProductName}")
                                )
                            },
                            trailingContent = {
                                Text(
                                    if (row.estimatedPurchaseValue > 0.0) UiFormat.money(row.estimatedPurchaseValue) else "-"
                                )
                            },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            SectionCard(
                title = "Dashboard BI Utama",
                subtitle = "Ringkas prioritas keputusan bisnis dari restock, harga, dan supplier.",
            ) {
                val summary = decisionSummary
                if (summary == null) {
                    EmptyHint("Belum ada ringkasan BI", "Lengkapi transaksi pembelian dan penjualan agar insight makin akurat.")
                } else {
                    Text("Restock kritis: ${summary.criticalRestockCount} item • saran ${UiFormat.qty(summary.criticalRestockBuyQty)}")
                    Text("Stok mati: ${summary.deadStockCount} • stok lambat: ${summary.slowStockCount}")
                    Text("Alert margin turun: ${summary.marginAlertCount}")
                    Text("Produk harga perlu review: ${summary.priceReviewCount}")
                    Text("Supplier utama: ${summary.bestSupplierName}")
                }
            }
        }

        item {
            SectionCard(
                title = "Supplier-aware Restock",
                subtitle = "Prioritas restock disertai supplier yang paling layak dijadikan acuan beli.",
            ) {
                val rows = state.smartRestock.filter { it.status in setOf("HABIS", "KRITIS", "WASPADA") }.take(6)
                if (rows.isEmpty()) {
                    EmptyHint("Belum ada restock prioritas", "Saat stok mulai kritis, rekomendasi supplier akan muncul di sini.")
                } else {
                    rows.forEach { row ->
                        androidx.compose.material3.ListItem(
                            headlineContent = { Text(row.name) },
                            supportingContent = {
                                Text(
                                    "${row.status} • Saran ${UiFormat.qty(row.suggestBuy)} • " +
                                        (if (row.preferredSupplier.isBlank()) "supplier belum cukup data" else "supplier ${row.preferredSupplier}")
                                )
                            },
                            trailingContent = {
                                Text(
                                    if (row.latestBuyPrice > 0.0) UiFormat.money(row.latestBuyPrice) else "-"
                                )
                            },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }

        item {
            AssistChip(
                onClick = {},
                label = { Text("Tahap berikutnya: scanner native, supplier-aware restock, dan dashboard BI utama") },
            )
        }
    }
}
