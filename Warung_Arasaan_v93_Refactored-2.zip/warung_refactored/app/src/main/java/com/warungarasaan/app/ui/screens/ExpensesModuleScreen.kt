package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.LabeledNumberField
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch
import com.warungarasaan.app.ui.viewmodel.ExpensesViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun ExpensesModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: ExpensesViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    if (state.showDialog) {
        ExpenseEditorDialog(
            onDismiss = { vm.onEvent(ExpensesEvent.DismissDialog) },
            onSave = { note, amount, category, method ->
                vm.onEvent(ExpensesEvent.Save(note, amount, category, method))
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { vm.onEvent(ExpensesEvent.AddNew) }) { Text("+") }
        },
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SectionCard(
                    title = "Biaya / Expenses",
                    subtitle = "Modul terpisah untuk mendekati expenses_page.dart di Flutter.",
                ) {
                    OutlinedTextField(
                        value = state.query,
                        onValueChange = { vm.onEvent(ExpensesEvent.QueryChanged(it)) },
                        label = { Text("Cari biaya / kategori / metode") },
                    )
                    androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip("Total entri", state.filtered.size.toString())
                        InfoChip("Total biaya", UiFormat.money(state.filtered.sumOf { it.amount }))
                    }
                }
            }
            if (state.filtered.isEmpty()) {
                item { EmptyHint("Belum ada biaya", "Tambah biaya operasional agar kas dan laporan lebih lengkap.") }
            } else {
                items(state.filtered, key = { it.id }) { expense ->
                    ListItem(
                        headlineContent = { Text(expense.note) },
                        supportingContent = { Text("${expense.category} • ${expense.paymentMethod}") },
                        trailingContent = { Text(UiFormat.money(expense.amount)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun ExpenseEditorDialog(
    onDismiss: () -> Unit,
    onSave: (String, Double, String, String) -> Unit,
) {
    var note by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Lainnya") }
    var method by remember { mutableStateOf("Cash") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Biaya") },
        text = {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Catatan") })
                LabeledNumberField(label = "Nominal", value = amountText, onValueChange = { amountText = it })
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Kategori") })
                OutlinedTextField(value = method, onValueChange = { method = it }, label = { Text("Metode bayar") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (note.isNotBlank() && amount > 0.0) onSave(note.trim(), amount, category.trim().ifBlank { "Lainnya" }, method.trim().ifBlank { "Cash" })
                },
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}
