package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class TransactionLineUi(
    val id: String,
    val productName: String,
    val qty: String,
    val price: String,
    val subtotal: String
)

data class TransactionEditorUi(
    val title: String,
    val partnerLabel: String,
    val dateLabel: String,
    val notes: String,
    val totalLabel: String,
    val lines: List<TransactionLineUi>
)

@Composable
fun NativeTransactionEditor(
    state: TransactionEditorUi,
    onPartnerChange: (String) -> Unit,
    onDateChange: (String) -> Unit,
    onNotesChange: (String) -> Unit,
    onAddLine: () -> Unit,
    onEditLine: (Int) -> Unit,
    onRemoveLine: (Int) -> Unit,
    onSave: () -> Unit
) {
    var easyMode by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(if (easyMode) "Input Transaksi" else state.title)
        }
        item {
            Card {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(if (easyMode) "Mode Mudah: isi pembeli, tambah barang, lalu simpan." else "Mode Lengkap: semua kolom transaksi ditampilkan.")
                    Button(onClick = { easyMode = !easyMode }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (easyMode) "Pakai Mode Lengkap" else "Kembali ke Mode Mudah")
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = state.partnerLabel,
                onValueChange = onPartnerChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(if (easyMode) "Nama pelanggan / supplier" else "Partner") }
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = state.dateLabel,
                    onValueChange = onDateChange,
                    modifier = Modifier.weight(1f),
                    label = { Text("Tanggal") }
                )
                OutlinedTextField(
                    value = state.totalLabel,
                    onValueChange = {},
                    modifier = Modifier.weight(1f),
                    readOnly = true,
                    label = { Text(if (easyMode) "Total belanja" else "Total") }
                )
            }
        }
        itemsIndexed(state.lines) { index, line ->
            Card {
                ListItem(
                    headlineContent = { Text(line.productName) },
                    supportingContent = { Text("Qty ${line.qty} • Harga ${line.price} • Subtotal ${line.subtotal}") },
                    trailingContent = {
                        Row {
                            IconButton(onClick = { onEditLine(index) }) {
                                Icon(Icons.Rounded.Add, contentDescription = "Ubah")
                            }
                            IconButton(onClick = { onRemoveLine(index) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Hapus")
                            }
                        }
                    }
                )
            }
        }
        item {
            Button(onClick = onAddLine, modifier = Modifier.fillMaxWidth()) {
                Text("Tambah barang")
            }
        }
        if (!easyMode) {
            item {
                OutlinedTextField(
                    value = state.notes,
                    onValueChange = onNotesChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Catatan tambahan") }
                )
            }
        }
        item {
            Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) {
                Text(if (easyMode) "Simpan transaksi" else "Simpan")
            }
        }
    }
}
