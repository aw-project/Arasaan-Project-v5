package com.warungarasaan.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.repository.ActivityLogRepository
import com.warungarasaan.app.data.repository.ProductRepository
import com.warungarasaan.app.domain.model.Product
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── UiState ──────────────────────────────────────────────────────────────────
data class ProductsState(
    val products: List<Product> = emptyList(),
    val query: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
    val showDialog: Boolean = false,
    val editing: Product? = null,
    val adjusting: Product? = null,
    val opnameTarget: Product? = null,
    val easyMode: Boolean = true,
    val message: String = "",
) {
    val filtered: List<Product> get() {
        val q = query.trim().lowercase()
        return if (q.isBlank()) products
        else products.filter {
            it.name.lowercase().contains(q) ||
            it.sku.lowercase().contains(q) ||
            it.category.lowercase().contains(q)
        }
    }
}

// ── UiEvent ───────────────────────────────────────────────────────────────────
sealed interface ProductsEvent {
    data class QueryChanged(val q: String) : ProductsEvent
    data object AddNew : ProductsEvent
    data class EditRequest(val product: Product) : ProductsEvent
    data class AdjustRequest(val product: Product) : ProductsEvent
    data class OpnameRequest(val product: Product) : ProductsEvent
    data object DismissDialog : ProductsEvent
    data class Save(val product: Product) : ProductsEvent
    data class Delete(val id: String) : ProductsEvent
    data class AdjustStock(val product: Product, val delta: Double, val note: String) : ProductsEvent
    data class SetOpnameStock(val product: Product, val counted: Double, val note: String) : ProductsEvent
    data class EasyModeChanged(val enabled: Boolean) : ProductsEvent
    data object ClearMessage : ProductsEvent
}

// ── ViewModel ─────────────────────────────────────────────────────────────────
@HiltViewModel
class ProductsViewModel @Inject constructor(
    private val productRepo: ProductRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(ProductsState())
    val state: StateFlow<ProductsState> = _state.asStateFlow()

    init {
        loadProducts()
    }

    private fun loadProducts() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching { productRepo.all() }
                .onSuccess { list -> _state.update { it.copy(products = list, isLoading = false) } }
                .onFailure { e -> _state.update { it.copy(error = e.message, isLoading = false) } }
        }
    }

    fun onEvent(event: ProductsEvent) {
        when (event) {
            is ProductsEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is ProductsEvent.AddNew -> _state.update { it.copy(showDialog = true, editing = null) }
            is ProductsEvent.EditRequest -> _state.update { it.copy(showDialog = true, editing = event.product) }
            is ProductsEvent.AdjustRequest -> _state.update { it.copy(adjusting = event.product) }
            is ProductsEvent.OpnameRequest -> _state.update { it.copy(opnameTarget = event.product) }
            is ProductsEvent.DismissDialog -> _state.update { it.copy(showDialog = false, editing = null, adjusting = null, opnameTarget = null) }
            is ProductsEvent.EasyModeChanged -> _state.update { it.copy(easyMode = event.enabled) }
            is ProductsEvent.ClearMessage -> _state.update { it.copy(message = "") }

            is ProductsEvent.Save -> viewModelScope.launch {
                runCatching { productRepo.upsert(event.product) }
                    .onSuccess {
                        activityLogRepo.log("product", "Produk ${event.product.name} disimpan")
                        _state.update { it.copy(showDialog = false, editing = null, message = "Produk berhasil disimpan.") }
                        loadProducts()
                    }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menyimpan produk.") } }
            }

            is ProductsEvent.Delete -> viewModelScope.launch {
                runCatching { productRepo.remove(event.id) }
                    .onSuccess {
                        activityLogRepo.log("product_delete", "Produk ${event.id} dihapus")
                        _state.update { it.copy(message = "Produk dihapus.") }
                        loadProducts()
                    }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menghapus produk.") } }
            }

            is ProductsEvent.AdjustStock -> viewModelScope.launch {
                runCatching {
                    val updated = event.product.copy(stockQty = (event.product.stockQty + event.delta).coerceAtLeast(0.0))
                    productRepo.upsert(updated)
                    activityLogRepo.log("stock_adjust", "Stok ${event.product.name} disesuaikan ${event.delta} — ${event.note}")
                }
                    .onSuccess {
                        _state.update { it.copy(adjusting = null, message = "Stok berhasil disesuaikan.") }
                        loadProducts()
                    }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menyesuaikan stok.") } }
            }

            is ProductsEvent.SetOpnameStock -> viewModelScope.launch {
                runCatching {
                    val updated = event.product.copy(stockQty = event.counted)
                    productRepo.upsert(updated)
                    activityLogRepo.log("stock_opname", "Opname ${event.product.name} → ${event.counted} — ${event.note}")
                }
                    .onSuccess {
                        _state.update { it.copy(opnameTarget = null, message = "Stok opname berhasil.") }
                        loadProducts()
                    }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal opname stok.") } }
            }
        }
    }
}
