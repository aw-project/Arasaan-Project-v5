package com.warungarasaan.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.warungarasaan.app.data.service.NotificationService
import com.warungarasaan.app.ui.SplashGate
import com.warungarasaan.app.ui.AppEntry
import com.warungarasaan.app.ui.theme.WarungArasaanTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as WarungArasaanApp).container
        val notificationService = NotificationService(this)
        notificationService.init()

        lifecycleScope.launch {
            notificationService.checkLowStock(container.productRepository.all())
        }

        setContent {
            WarungArasaanTheme {
                SplashGate {
                    AppEntry(container)
                }
            }
        }
    }
}
