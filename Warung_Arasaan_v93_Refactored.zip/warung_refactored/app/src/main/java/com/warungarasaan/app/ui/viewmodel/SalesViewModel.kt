package com.warungarasaan.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.warungarasaan.app.data.repository.ActivityLogRepository
import com.warungarasaan.app.data.repository.ProductRepository
import com.warungarasaan.app.data.repository.SalesRepository
import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import com.warungarasaan.app.core.AppUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SalesState(
    val sales: List<Sale> = emptyList(),
    val products: List<Product> = emptyList(),
    val query: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
    val showDialog: Boolean = false,
    val editing: Sale? = null,
    val selected: Sale? = null,
    val easyMode: Boolean = true,
    val message: String = "",
) {
    val productMap: Map<String, Product> get() = products.associateBy { it.id }
    val filtered: List<Sale> get() {
        val q = query.trim().lowercase()
        return if (q.isBlank()) sales
        else sales.filter {
            it.customerName.lowercase().contains(q) ||
            it.id.lowercase().contains(q) ||
            it.paymentMethod.lowercase().contains(q)
        }
    }
}

sealed interface SalesEvent {
    data class QueryChanged(val q: String) : SalesEvent
    data object AddNew : SalesEvent
    data class EditRequest(val sale: Sale) : SalesEvent
    data class SelectDetail(val sale: Sale) : SalesEvent
    data object DismissDialog : SalesEvent
    data object DismissDetail : SalesEvent
    data class EasyModeChanged(val enabled: Boolean) : SalesEvent
    data object ClearMessage : SalesEvent
    data class Save(
        val id: String,
        val customer: String,
        val paymentMethod: String,
        val items: List<SaleItem>,
        val discount: Double,
        val splits: List<PaymentSplit>,
        val existingDate: Int?,
    ) : SalesEvent
    data class Delete(val id: String) : SalesEvent
}

@HiltViewModel
class SalesViewModel @Inject constructor(
    private val salesRepo: SalesRepository,
    private val productRepo: ProductRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(SalesState())
    val state: StateFlow<SalesState> = _state.asStateFlow()

    init { load() }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching {
                val sales = salesRepo.all()
                val products = productRepo.all()
                _state.update { it.copy(sales = sales, products = products, isLoading = false) }
            }.onFailure { e -> _state.update { it.copy(error = e.message, isLoading = false) } }
        }
    }

    fun onEvent(event: SalesEvent) {
        when (event) {
            is SalesEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is SalesEvent.AddNew -> _state.update { it.copy(showDialog = true, editing = null) }
            is SalesEvent.EditRequest -> _state.update { it.copy(showDialog = true, editing = event.sale) }
            is SalesEvent.SelectDetail -> _state.update { it.copy(selected = event.sale) }
            is SalesEvent.DismissDialog -> _state.update { it.copy(showDialog = false, editing = null) }
            is SalesEvent.DismissDetail -> _state.update { it.copy(selected = null) }
            is SalesEvent.EasyModeChanged -> _state.update { it.copy(easyMode = event.enabled) }
            is SalesEvent.ClearMessage -> _state.update { it.copy(message = "") }

            is SalesEvent.Save -> viewModelScope.launch {
                runCatching {
                    val isNew = _state.value.editing == null
                    val sale = Sale(
                        id = event.id.ifBlank { AppUtils.newId("sal") },
                        dateEpochDay = event.existingDate ?: AppUtils.epochDayNow(),
                        items = event.items,
                        paymentMethod = event.paymentMethod,
                        customerName = event.customer,
                        discountAmount = event.discount,
                        paymentSplits = event.splits,
                    )
                    if (isNew) salesRepo.add(sale) else salesRepo.replace(sale)
                    activityLogRepo.log(if (isNew) "sale" else "sale_edit", "Penjualan ${sale.id}")
                    _state.update { it.copy(showDialog = false, editing = null, message = "Penjualan berhasil disimpan.") }
                    load()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menyimpan penjualan.") } }
            }

            is SalesEvent.Delete -> viewModelScope.launch {
                runCatching { salesRepo.remove(event.id) }
                    .onSuccess {
                        activityLogRepo.log("sale_delete", "Penjualan ${event.id} dihapus")
                        _state.update { it.copy(selected = null, message = "Penjualan dihapus.") }
                        load()
                    }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menghapus penjualan.") } }
            }
        }
    }
}
