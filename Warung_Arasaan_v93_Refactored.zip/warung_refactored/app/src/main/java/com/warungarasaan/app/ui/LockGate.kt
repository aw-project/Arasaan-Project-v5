package com.warungarasaan.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import kotlinx.coroutines.launch

/**
 * BUG FIX #1 (Security Bypass):
 *   Sebelumnya content() dipanggil tanpa syarat — seluruh UI sudah dirender di bawah dialog PIN.
 *   Fix: content() HANYA dipanggil setelah unlocked == true.
 *
 * BUG FIX #5 (Layout Crash):
 *   Column menggunakan fillMaxSize() di dalam AlertDialog — diganti fillMaxWidth().
 */
@Composable
fun LockGate(
    container: AppContainer,
    content: @Composable () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var pinEnabled by remember { mutableStateOf(false) }
    var unlocked by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        pinEnabled = container.settingsRepository.get()?.pinEnabled == true
        unlocked = !pinEnabled
    }

    // BUG FIX #1: content() hanya dirender setelah unlocked
    if (unlocked) {
        content()
    }

    if (pinEnabled && !unlocked) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        unlocked = container.settingsRepository.verifyPin(pinInput)
                        errorText = if (unlocked) "" else "PIN salah."
                        if (unlocked) pinInput = ""
                    }
                }) { Text("Buka") }
            },
            title = { Text("Aplikasi Terkunci") },
            text = {
                // BUG FIX #5: fillMaxSize() → fillMaxWidth() agar tidak crash di AlertDialog
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Masukkan PIN untuk membuka Warung Arasaan.")
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { pinInput = it },
                        label = { Text("PIN") },
                    )
                    if (errorText.isNotBlank()) {
                        Text(errorText)
                    }
                }
            },
        )
    }
}
