package com.warungarasaan.app.di

import com.warungarasaan.app.data.local.*
import com.warungarasaan.app.data.repository.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Singleton
    @Provides
    fun provideMetaRepository(metaStore: MetaStore): MetaRepository =
        MetaRepository(metaStore)

    @Singleton
    @Provides
    fun provideProductRepository(dao: ProductDao, meta: MetaRepository): ProductRepository =
        ProductRepository(dao, meta)

    @Singleton
    @Provides
    fun providePurchaseRepository(
        purchaseDao: PurchaseDao,
        purchaseItemDao: PurchaseItemDao,
        productDao: ProductDao,
        stockMovementDao: StockMovementDao,
        cashDao: CashDao,
        meta: MetaRepository,
    ): PurchaseRepository = PurchaseRepository(purchaseDao, purchaseItemDao, productDao, stockMovementDao, cashDao, meta)

    @Singleton
    @Provides
    fun provideSalesRepository(
        saleDao: SaleDao,
        saleItemDao: SaleItemDao,
        paymentSplitDao: PaymentSplitDao,
        productDao: ProductDao,
        stockMovementDao: StockMovementDao,
        cashDao: CashDao,
        meta: MetaRepository,
    ): SalesRepository = SalesRepository(saleDao, saleItemDao, paymentSplitDao, productDao, stockMovementDao, cashDao, meta)

    @Singleton
    @Provides
    fun provideExpenseRepository(expenseDao: ExpenseDao, cashDao: CashDao, meta: MetaRepository): ExpenseRepository =
        ExpenseRepository(expenseDao, cashDao, meta)

    @Singleton
    @Provides
    fun provideDebtRepository(debtDao: DebtDao, cashDao: CashDao, meta: MetaRepository): DebtRepository =
        DebtRepository(debtDao, cashDao, meta)

    @Singleton
    @Provides
    fun provideCashRepository(cashDao: CashDao, meta: MetaRepository): CashRepository =
        CashRepository(cashDao, meta)

    @Singleton
    @Provides
    fun provideMovementRepository(stockMovementDao: StockMovementDao, meta: MetaRepository): MovementRepository =
        MovementRepository(stockMovementDao, meta)

    @Singleton
    @Provides
    fun provideRejectedRepository(
        rejectedItemDao: RejectedItemDao,
        productDao: ProductDao,
        stockMovementDao: StockMovementDao,
        cashDao: CashDao,
        meta: MetaRepository,
    ): RejectedRepository = RejectedRepository(rejectedItemDao, productDao, stockMovementDao, cashDao, meta)

    @Singleton
    @Provides
    fun provideActivityLogRepository(activityLogDao: ActivityLogDao, meta: MetaRepository): ActivityLogRepository =
        ActivityLogRepository(activityLogDao, meta)

    @Singleton
    @Provides
    fun provideSettingsRepository(appSettingsDao: AppSettingsDao, meta: MetaRepository): SettingsRepository =
        SettingsRepository(appSettingsDao, meta)
}
