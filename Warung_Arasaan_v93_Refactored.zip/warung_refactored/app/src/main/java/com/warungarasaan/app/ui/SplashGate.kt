package com.warungarasaan.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOutBack
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashGate(content: @Composable () -> Unit) {
    var ready by remember { mutableStateOf(false) }
    // BUG FIX #3: Animatable(0.8f) agar scale benar-benar beranimasi dari 0.8 → 1.0
    val scale = remember { Animatable(0.8f) }

    LaunchedEffect(Unit) {
        launch {
            scale.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 600, easing = EaseOutBack),
            )
        }
        delay(1600)
        ready = true
    }

    AnimatedVisibility(visible = ready) {
        content()
    }

    if (!ready) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .scale(scale.value)
                        .background(
                            color = Color.White.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(28.dp),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "WA",
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White,
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Warung Arasaan", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                    Text(
                        "Manajemen Warung Cerdas",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.78f),
                    )
                }
                CircularProgressIndicator(color = Color.White)
            }
        }
    }
}
