
package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.StockMovement
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.LabeledNumberField
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.viewmodel.*
import kotlinx.coroutines.launch

private data class ProductFormState(
    val id: String = "",
    val name: String = "",
    val unit: String = "pcs",
    val price: String = "0",
    val avgHpp: String = "0",
    val stockQty: String = "0",
    val minStock: String = "0",
    val targetStock: String = "0",
    val sku: String = "",
    val category: String = "Lainnya",
)

@Composable
fun ProductsModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: ProductsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    if (state.showDialog) {
        ProductEditorDialog(
            initial = state.editing,
            onDismiss = { vm.onEvent(ProductsEvent.DismissDialog) },
            onSave = { form ->
                val product = Product(
                    id = form.id.ifBlank { AppUtils.newId("prd") },
                    name = form.name.trim(),
                    unit = form.unit.trim().ifEmpty { "pcs" },
                    defaultMarginPercent = 0.0,
                    activeSellPrice = form.price.toDoubleOrNull() ?: 0.0,
                    stockQty = form.stockQty.toDoubleOrNull() ?: 0.0,
                    avgHpp = form.avgHpp.toDoubleOrNull() ?: 0.0,
                    minStock = form.minStock.toDoubleOrNull() ?: 0.0,
                    targetStock = form.targetStock.toDoubleOrNull() ?: 0.0,
                    sku = form.sku.trim(),
                    category = form.category.trim().ifEmpty { "Lainnya" },
                    imagePath = null,
                )
                vm.onEvent(ProductsEvent.Save(product))
            },
        )
    }

    state.adjusting?.let { product ->
        StockAdjustmentDialog(
            product = product,
            onDismiss = { vm.onEvent(ProductsEvent.DismissDialog) },
            onApply = { delta, note -> vm.onEvent(ProductsEvent.AdjustStock(product, delta, note)) },
        )
    }

    state.opnameTarget?.let { product ->
        StockOpnameDialog(
            product = product,
            onDismiss = { vm.onEvent(ProductsEvent.DismissDialog) },
            onApply = { counted, note -> vm.onEvent(ProductsEvent.SetOpnameStock(product, counted, note)) },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { vm.onEvent(ProductsEvent.AddNew) }) { Text("+") }
        },
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(padding),
        ) {
            item {
                SectionCard(
                    title = if (state.easyMode) "Daftar Barang" else "Produk Lengkap",
                    subtitle = if (state.easyMode) "Cari barang, cek stok, lalu ubah bila perlu." else "Semua detail produk ditampilkan."
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { vm.onEvent(ProductsEvent.EasyModeChanged(true)) }) { Text("Mode Mudah") }
                        TextButton(onClick = { vm.onEvent(ProductsEvent.EasyModeChanged(false)) }) { Text("Mode Lengkap") }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = state.query,
                    onValueChange = { vm.onEvent(ProductsEvent.QueryChanged(it)) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(if (state.easyMode) "Cari barang" else "Cari produk / SKU / kategori") },
                    singleLine = true,
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip("Total ${state.products.size}")
                    InfoChip("Stok menipis ${state.products.count { it.minStock > 0 && it.stockQty <= it.minStock }}")
                }
            }
            if (state.message.isNotBlank()) {
                item { SectionCard("Status") { Text(state.message) } }
            }
            if (state.filtered.isEmpty()) {
                item {
                    EmptyHint(
                        "Belum ada produk",
                        "Tambahkan master produk terlebih dulu.",
                        "Tambah Produk",
                    ) { vm.onEvent(ProductsEvent.AddNew) }
                }
            } else {
                items(state.filtered, key = { it.id }) { product ->
                    ListItem(
                        headlineContent = { Text(product.name) },
                        supportingContent = {
                            Text("${product.category} • ${UiFormat.qty(product.stockQty)} ${product.unit} • HPP ${UiFormat.money(product.avgHpp)}")
                        },
                        overlineContent = { Text(product.sku.ifBlank { product.id }) },
                        trailingContent = { Text(UiFormat.money(product.activeSellPrice)) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TextButton(onClick = { vm.onEvent(ProductsEvent.AdjustRequest(product)) }) { Text("Ubah stok") }
                        TextButton(onClick = { vm.onEvent(ProductsEvent.OpnameRequest(product)) }) { Text("Cek stok") }
                        TextButton(onClick = { vm.onEvent(ProductsEvent.EditRequest(product)) }) { Text("Ubah") }
                        TextButton(onClick = { vm.onEvent(ProductsEvent.Delete(product.id)) }) { Text("Hapus") }
                    }
                }
            }
        }
    }
}


@Composable
private fun ProductEditorDialog(
    initial: Product?,
    onDismiss: () -> Unit,
    onSave: (ProductFormState) -> Unit,
) {
    var form by remember(initial) {
        mutableStateOf(
            ProductFormState(
                id = initial?.id.orEmpty(),
                name = initial?.name.orEmpty(),
                unit = initial?.unit ?: "pcs",
                price = ((initial?.activeSellPrice) ?: 0.0).toString(),
                avgHpp = ((initial?.avgHpp) ?: 0.0).toString(),
                stockQty = ((initial?.stockQty) ?: 0.0).toString(),
                minStock = ((initial?.minStock) ?: 0.0).toString(),
                targetStock = ((initial?.targetStock) ?: 0.0).toString(),
                sku = initial?.sku.orEmpty(),
                category = initial?.category ?: "Lainnya",
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(form) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text(if (initial == null) "Tambah Produk" else "Edit Produk") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(form.name, { form = form.copy(name = it) }, label = { Text("Nama") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(form.category, { form = form.copy(category = it) }, label = { Text("Kategori") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(form.sku, { form = form.copy(sku = it) }, label = { Text("SKU") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(form.unit, { form = form.copy(unit = it) }, label = { Text("Satuan") }, modifier = Modifier.fillMaxWidth()) }
                item { LabeledNumberField("Harga jual", form.price, { form = form.copy(price = it) }) }
                item { LabeledNumberField("HPP rata-rata", form.avgHpp, { form = form.copy(avgHpp = it) }) }
                item { LabeledNumberField("Stok", form.stockQty, { form = form.copy(stockQty = it) }) }
                item { LabeledNumberField("Min stok", form.minStock, { form = form.copy(minStock = it) }) }
                item { LabeledNumberField("Target stok", form.targetStock, { form = form.copy(targetStock = it) }) }
            }
        },
    )
}

@Composable
private fun ProductDetailDialog(
    product: Product,
    container: AppContainer,
    onDismiss: () -> Unit,
) {
    var movements by remember { mutableStateOf<List<StockMovement>>(emptyList()) }
    var purchasesTotal by remember { mutableStateOf(0.0) }
    var salesTotal by remember { mutableStateOf(0.0) }

    LaunchedEffect(product.id) {
        movements = container.movementRepository.byProduct(product.id).take(30)
        purchasesTotal = container.purchaseRepository.all()
            .flatMap { it.items }
            .filter { it.productId == product.id }
            .sumOf { it.qty }
        salesTotal = container.salesRepository.all()
            .flatMap { it.items }
            .filter { it.productId == product.id }
            .sumOf { it.qty }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Detail Produk") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text(product.name) }
                item { Text("SKU: ${product.sku.ifBlank { "-" }}") }
                item { Text("Kategori: ${product.category}") }
                item { Text("Stok: ${UiFormat.qty(product.stockQty)} ${product.unit}") }
                item { Text("Harga jual: ${UiFormat.money(product.activeSellPrice)}") }
                item { Text("Avg HPP: ${UiFormat.money(product.avgHpp)}") }
                item { Text("Min stok: ${UiFormat.qty(product.minStock)} • Target: ${UiFormat.qty(product.targetStock)}") }
                item { Text("Akumulasi beli: ${UiFormat.qty(purchasesTotal)} • Jual: ${UiFormat.qty(salesTotal)}") }
                item { Text("Riwayat stok terbaru") }
                if (movements.isEmpty()) {
                    item { Text("Belum ada movement") }
                } else {
                    itemsIndexed(movements) { _, row ->
                        ListItem(
                            headlineContent = { Text("${row.type} • ${UiFormat.qty(row.qtyDelta)}") },
                            supportingContent = { Text("${UiFormat.date(row.dateEpochDay)} • ${row.note}") },
                        )
                    }
                }
            }
        },
    )
}

@Composable
private fun StockAdjustmentDialog(
    product: Product,
    onDismiss: () -> Unit,
    onApply: (delta: Double, note: String) -> Unit,
) {
    var qtyDelta by remember { mutableStateOf("0") }
    var note by remember { mutableStateOf("Penyesuaian stok manual") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onApply(qtyDelta.toDoubleOrNull() ?: 0.0, note) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Stock Adjustment") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("${product.name} • Stok sekarang ${UiFormat.qty(product.stockQty)} ${product.unit}") }
                item { LabeledNumberField("Qty adjustment (+/-)", qtyDelta, { qtyDelta = it }) }
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}

@Composable
private fun StockOpnameDialog(
    product: Product,
    onDismiss: () -> Unit,
    onApply: (physicalQty: Double, note: String) -> Unit,
) {
    var physicalQty by remember { mutableStateOf(UiFormat.qty(product.stockQty)) }
    var note by remember { mutableStateOf("Stock opname") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onApply(physicalQty.toDoubleOrNull() ?: 0.0, note) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Stock Opname") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("${product.name} • Sistem ${UiFormat.qty(product.stockQty)} ${product.unit}") }
                item { LabeledNumberField("Stok fisik", physicalQty, { physicalQty = it }) }
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}
