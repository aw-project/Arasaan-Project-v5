package com.warungarasaan.app.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.BackupService
import com.warungarasaan.app.data.service.FileDocumentService
import com.warungarasaan.app.data.service.ReportExportService
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import kotlinx.coroutines.launch
import com.warungarasaan.app.ui.viewmodel.BackupViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun BackupModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: BackupViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(title = "Status backup") {
                InlineLabelValue("Auto backup", if (autoBackup) "Aktif" else "Nonaktif")
                InlineLabelValue("Interval", "$backupDays hari")
                InlineLabelValue("Backup terakhir", lastBackupText)
            }
        }
        item {
            SectionCard(title = "Pengaturan backup") {
                androidx.compose.material3.ListItem(
                    headlineContent = { Text("Aktifkan auto backup") },
                    trailingContent = {
                        Switch(
                            checked = state.autoBackup,
                            onCheckedChange = { checked ->
                                scope.launch {
                                    container.metaRepository.setAutoBackupEnabled(checked)
                                    reloadMeta()
                                }
                            },
                        )
                    },
                )
                OutlinedTextField(
                    value = state.backupDays,
                    onValueChange = { vm.onEvent(BackupEvent.BackupDaysChanged(it)) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Interval backup (hari)") },
                )
                TextButton(onClick = {
                    scope.launch {
                        container.metaRepository.setAutoBackupDays(backupDays.toIntOrNull() ?: 7)
                        reloadMeta()
                    }
                }) { Text("Simpan interval") }
            }
        }
        item {
            SectionCard(title = "Backup file", subtitle = "Gunakan Storage Access Framework Android") {
                TextButton(onClick = { exportBackupLauncher.launch("warung_arasaan_backup.json") }) {
                    Text("Export backup ke file JSON")
                }
                TextButton(onClick = { importBackupLauncher.launch(arrayOf("application/json", "text/plain")) }) {
                    Text("Import backup dari file")
                }
                TextButton(onClick = { exportReportLauncher.launch("laporan_stok.csv") }) {
                    Text("Export laporan stok CSV")
                }
            }
        }
        item {
            SectionCard(title = "Payload backup", subtitle = "Masih tersedia untuk copy-paste manual") {
                if (state.exportJson.isBlank()) {
                    EmptyHint("Belum ada payload", "Tekan export atau tunggu data ter-load.")
                } else {
                    OutlinedTextField(
                        value = exportJson,
                        onValueChange = { exportJson = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 180.dp),
                        label = { Text("JSON backup") },
                    )
                }
            }
        }
        item {
            SectionCard(title = "Restore manual") {
                OutlinedTextField(
                    value = importJson,
                    onValueChange = { vm.onEvent(BackupEvent.ImportJsonChanged(it)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp),
                    label = { Text("Tempel JSON di sini") },
                )
                TextButton(onClick = {
                    scope.launch {
                        runCatching {
                            BackupService.restoreJson(container.database, importJson)
                            resultMessage = "Restore manual selesai."
                        }.onFailure {
                            resultMessage = "Restore manual gagal: ${it.message}"
                        }
                    }
                }) {
                    Text("Restore JSON manual")
                }
            }
        }
        item {
            if (resultMessage.isNotBlank()) {
                Text(state.resultMessage)
            }
        }
    }
}
