package com.warungarasaan.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.repository.*
import com.warungarasaan.app.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ─────────────────────────────────────────────────────────────────────────────
// EXPENSES
// ─────────────────────────────────────────────────────────────────────────────

data class ExpensesState(
    val expenses: List<Expense> = emptyList(),
    val query: String = "",
    val isLoading: Boolean = false,
    val showDialog: Boolean = false,
    val message: String = "",
) {
    val filtered: List<Expense> get() {
        val q = query.trim().lowercase()
        return if (q.isBlank()) expenses
        else expenses.filter {
            it.note.lowercase().contains(q) ||
            it.category.lowercase().contains(q) ||
            it.paymentMethod.lowercase().contains(q)
        }
    }
}

sealed interface ExpensesEvent {
    data class QueryChanged(val q: String) : ExpensesEvent
    data object AddNew : ExpensesEvent
    data object DismissDialog : ExpensesEvent
    data object ClearMessage : ExpensesEvent
    data class Save(val note: String, val amount: Double, val category: String, val method: String) : ExpensesEvent
    data class Delete(val id: String) : ExpensesEvent
}

@HiltViewModel
class ExpensesViewModel @Inject constructor(
    private val expenseRepo: ExpenseRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(ExpensesState())
    val state: StateFlow<ExpensesState> = _state.asStateFlow()

    init { load() }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching { expenseRepo.all() }
                .onSuccess { list -> _state.update { it.copy(expenses = list, isLoading = false) } }
                .onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }

    fun onEvent(event: ExpensesEvent) {
        when (event) {
            is ExpensesEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is ExpensesEvent.AddNew -> _state.update { it.copy(showDialog = true) }
            is ExpensesEvent.DismissDialog -> _state.update { it.copy(showDialog = false) }
            is ExpensesEvent.ClearMessage -> _state.update { it.copy(message = "") }
            is ExpensesEvent.Save -> viewModelScope.launch {
                runCatching {
                    expenseRepo.add(Expense(AppUtils.newId("exp"), AppUtils.epochDayNow(), event.note, event.amount, event.method, event.category))
                    activityLogRepo.log("expense", "Biaya ${event.note}")
                    _state.update { it.copy(showDialog = false, message = "Biaya disimpan.") }
                    load()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menyimpan biaya.") } }
            }
            is ExpensesEvent.Delete -> viewModelScope.launch {
                runCatching { expenseRepo.remove(event.id) }
                    .onSuccess { _state.update { it.copy(message = "Biaya dihapus.") }; load() }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// DEBTS
// ─────────────────────────────────────────────────────────────────────────────

data class DebtsState(
    val debts: List<Debt> = emptyList(),
    val query: String = "",
    val isLoading: Boolean = false,
    val showCreate: Boolean = false,
    val payDebtId: String? = null,
    val message: String = "",
) {
    val filtered: List<Debt> get() {
        val q = query.trim().lowercase()
        return if (q.isBlank()) debts
        else debts.filter { it.creditor.lowercase().contains(q) || it.note.lowercase().contains(q) }
    }
}

sealed interface DebtsEvent {
    data class QueryChanged(val q: String) : DebtsEvent
    data object AddNew : DebtsEvent
    data class PayRequest(val id: String) : DebtsEvent
    data object DismissDialog : DebtsEvent
    data object ClearMessage : DebtsEvent
    data class Create(val creditor: String, val note: String, val principal: Double) : DebtsEvent
    data class Pay(val id: String, val amount: Double, val method: String) : DebtsEvent
    data class Delete(val id: String) : DebtsEvent
}

@HiltViewModel
class DebtsViewModel @Inject constructor(
    private val debtRepo: DebtRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(DebtsState())
    val state: StateFlow<DebtsState> = _state.asStateFlow()

    init { load() }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching { debtRepo.all() }
                .onSuccess { list -> _state.update { it.copy(debts = list, isLoading = false) } }
                .onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }

    fun onEvent(event: DebtsEvent) {
        when (event) {
            is DebtsEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is DebtsEvent.AddNew -> _state.update { it.copy(showCreate = true) }
            is DebtsEvent.PayRequest -> _state.update { it.copy(payDebtId = event.id) }
            is DebtsEvent.DismissDialog -> _state.update { it.copy(showCreate = false, payDebtId = null) }
            is DebtsEvent.ClearMessage -> _state.update { it.copy(message = "") }
            is DebtsEvent.Create -> viewModelScope.launch {
                runCatching {
                    debtRepo.add(Debt(AppUtils.newId("debt"), AppUtils.epochDayNow(), event.creditor, event.note, event.principal, 0.0))
                    activityLogRepo.log("debt", "Tambah hutang ${event.creditor}")
                    _state.update { it.copy(showCreate = false, message = "Hutang ditambahkan.") }
                    load()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
            is DebtsEvent.Pay -> viewModelScope.launch {
                runCatching {
                    debtRepo.addPayment(event.id, event.amount, AppUtils.epochDayNow(), event.method)
                    activityLogRepo.log("debt_payment", "Bayar hutang ${event.id}")
                    _state.update { it.copy(payDebtId = null, message = "Pembayaran dicatat.") }
                    load()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
            is DebtsEvent.Delete -> viewModelScope.launch {
                runCatching { debtRepo.remove(event.id) }
                    .onSuccess { _state.update { it.copy(message = "Hutang dihapus.") }; load() }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// REJECTED
// ─────────────────────────────────────────────────────────────────────────────

data class RejectedState(
    val rejected: List<RejectedItem> = emptyList(),
    val products: List<Product> = emptyList(),
    val query: String = "",
    val reasonFilter: String = "Semua",
    val handlingFilter: String = "Semua",
    val rangeDays: Int = 30,
    val isLoading: Boolean = false,
    val showDialog: Boolean = false,
    val message: String = "",
) {
    val productMap: Map<String, Product> get() = products.associateBy { it.id }
    val reasons: List<String> get() = listOf("Semua") + rejected.map { it.reason }.distinct().sorted()
    val handlings: List<String> get() = listOf("Semua") + rejected.map { it.handling }.distinct().sorted()
    val filtered: List<RejectedItem> get() {
        val q = query.trim().lowercase()
        val today = AppUtils.epochDayNow()
        val minDay = today - (rangeDays - 1)
        return rejected.filter { item ->
            val name = productMap[item.productId]?.name.orEmpty().lowercase()
            val queryOk = q.isBlank() || item.reason.lowercase().contains(q) || item.handling.lowercase().contains(q) || name.contains(q)
            val reasonOk = reasonFilter == "Semua" || item.reason == reasonFilter
            val handlingOk = handlingFilter == "Semua" || item.handling == handlingFilter
            val dayOk = item.dateEpochDay in minDay..today
            queryOk && reasonOk && handlingOk && dayOk
        }
    }
}

sealed interface RejectedEvent {
    data class QueryChanged(val q: String) : RejectedEvent
    data class ReasonFilterChanged(val f: String) : RejectedEvent
    data class HandlingFilterChanged(val f: String) : RejectedEvent
    data class RangeDaysChanged(val days: Int) : RejectedEvent
    data object AddNew : RejectedEvent
    data object DismissDialog : RejectedEvent
    data object ClearMessage : RejectedEvent
    data class Save(val productId: String, val qty: Double, val reason: String, val handling: String, val note: String) : RejectedEvent
    data class Delete(val id: String) : RejectedEvent
}

@HiltViewModel
class RejectedViewModel @Inject constructor(
    private val rejectedRepo: RejectedRepository,
    private val productRepo: ProductRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(RejectedState())
    val state: StateFlow<RejectedState> = _state.asStateFlow()

    init { load() }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching {
                val rejected = rejectedRepo.all()
                val products = productRepo.all()
                _state.update { it.copy(rejected = rejected, products = products, isLoading = false) }
            }.onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }

    fun onEvent(event: RejectedEvent) {
        when (event) {
            is RejectedEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is RejectedEvent.ReasonFilterChanged -> _state.update { it.copy(reasonFilter = event.f) }
            is RejectedEvent.HandlingFilterChanged -> _state.update { it.copy(handlingFilter = event.f) }
            is RejectedEvent.RangeDaysChanged -> _state.update { it.copy(rangeDays = event.days) }
            is RejectedEvent.AddNew -> _state.update { it.copy(showDialog = true) }
            is RejectedEvent.DismissDialog -> _state.update { it.copy(showDialog = false) }
            is RejectedEvent.ClearMessage -> _state.update { it.copy(message = "") }
            is RejectedEvent.Save -> viewModelScope.launch {
                runCatching {
                    val product = _state.value.products.firstOrNull { it.id == event.productId }
                        ?: error("Produk tidak ditemukan")
                    val loss = event.qty * product.avgHpp
                    rejectedRepo.add(RejectedItem(AppUtils.newId("rej"), AppUtils.epochDayNow(), product.id, event.qty, event.reason, event.handling, event.note, product.avgHpp, loss))
                    activityLogRepo.log("rejected", "Reject ${product.name} ${event.qty} ${product.unit}")
                    _state.update { it.copy(showDialog = false, message = "Barang reject dicatat.") }
                    load()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
            is RejectedEvent.Delete -> viewModelScope.launch {
                runCatching { rejectedRepo.remove(event.id) }
                    .onSuccess { _state.update { it.copy(message = "Dihapus.") }; load() }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CASH
// ─────────────────────────────────────────────────────────────────────────────

data class CashState(
    val entries: List<CashEntry> = emptyList(),
    val query: String = "",
    val isLoading: Boolean = false,
    val showDialog: Boolean = false,
    val message: String = "",
) {
    val filtered: List<CashEntry> get() {
        val q = query.trim().lowercase()
        return if (q.isBlank()) entries
        else entries.filter { it.note.lowercase().contains(q) || it.source.lowercase().contains(q) || it.method.lowercase().contains(q) }
    }
    val saldo: Double get() = entries.sumOf { if (it.direction == "in") it.amount else -it.amount }
}

sealed interface CashEvent {
    data class QueryChanged(val q: String) : CashEvent
    data object AddNew : CashEvent
    data object DismissDialog : CashEvent
    data object ClearMessage : CashEvent
    data class Save(val direction: String, val amount: Double, val method: String, val note: String) : CashEvent
    data class Delete(val id: String) : CashEvent
}

@HiltViewModel
class CashViewModel @Inject constructor(
    private val cashRepo: CashRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(CashState())
    val state: StateFlow<CashState> = _state.asStateFlow()

    init { load() }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching { cashRepo.all() }
                .onSuccess { list -> _state.update { it.copy(entries = list, isLoading = false) } }
                .onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }

    fun onEvent(event: CashEvent) {
        when (event) {
            is CashEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is CashEvent.AddNew -> _state.update { it.copy(showDialog = true) }
            is CashEvent.DismissDialog -> _state.update { it.copy(showDialog = false) }
            is CashEvent.ClearMessage -> _state.update { it.copy(message = "") }
            is CashEvent.Save -> viewModelScope.launch {
                runCatching {
                    cashRepo.add(CashEntry(AppUtils.newId("cash"), AppUtils.epochDayNow(), event.direction, "manual", event.method, event.note, event.amount, ""))
                    activityLogRepo.log("cash_manual", "${event.direction} ${event.note}")
                    _state.update { it.copy(showDialog = false, message = "Kas dicatat.") }
                    load()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
            is CashEvent.Delete -> viewModelScope.launch {
                runCatching { cashRepo.remove(event.id) }
                    .onSuccess { _state.update { it.copy(message = "Entri dihapus.") }; load() }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal.") } }
            }
        }
    }
}
