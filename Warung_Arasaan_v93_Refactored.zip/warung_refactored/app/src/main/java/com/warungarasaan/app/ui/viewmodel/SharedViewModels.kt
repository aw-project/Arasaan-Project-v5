package com.warungarasaan.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.local.MetaStore
import com.warungarasaan.app.data.repository.*
import com.warungarasaan.app.data.service.*
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ─────────────────────────────────────────────────────────────────────────────
// HOME HUB
// ─────────────────────────────────────────────────────────────────────────────

data class HomeState(
    val omzetToday: Double = 0.0,
    val labaToday: Double = 0.0,
    val saldoKas: Double = 0.0,
    val txCount: Int = 0,
    val activeDebts: Int = 0,
    val lowStockCount: Int = 0,
    val lowStockItems: List<Pair<String, String>> = emptyList(),
    val topSold: List<Triple<String, String, String>> = emptyList(),
    val omzet7: Double = 0.0,
    val omzet30: Double = 0.0,
    val decisionText: String = "",
    val recentLogs: List<ActivityLog> = emptyList(),
    val activeRole: String = "admin",
    val isLoading: Boolean = false,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val salesRepo: SalesRepository,
    private val purchaseRepo: PurchaseRepository,
    private val productRepo: ProductRepository,
    private val expenseRepo: ExpenseRepository,
    private val rejectedRepo: RejectedRepository,
    private val cashRepo: CashRepository,
    private val debtRepo: DebtRepository,
    private val activityLogRepo: ActivityLogRepository,
    private val metaRepo: MetaRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state.asStateFlow()

    // BUG FIX: role sebagai Flow reaktif, tidak dipanggil ulang setiap navigasi
    val activeRole: StateFlow<String> = metaRepo.roleFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, "admin")

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching {
                val today = AppUtils.epochDayNow()
                val sales = salesRepo.all()
                val purchases = purchaseRepo.all()
                val products = productRepo.all()
                val expenses = expenseRepo.all()
                val rejected = rejectedRepo.all()
                val cash = cashRepo.all()
                val debts = debtRepo.all()
                val role = metaRepo.role()
                val recentLogs = activityLogRepo.recent(5)

                val todaySales = sales.filter { it.dateEpochDay == today }
                val analytics = AnalyticsService()

                val saldo = cash
                    .filter { PaymentMethods.isCashFlow(it.method) }
                    .sumOf { if (it.direction == "in") it.amount else -it.amount }

                val omzet7 = sales.filter { it.dateEpochDay >= today - 6 }.sumOf { it.totalSales }
                val omzet30 = sales.filter { it.dateEpochDay >= today - 29 }.sumOf { it.totalSales }

                val lowStock = products.filter { it.minStock > 0 && it.stockQty <= it.minStock }

                val productNames = products.associateBy { it.id }
                val top3 = analytics.topSelling(sales, products, 30).take(3).map {
                    Triple(it.name, "×${"%.1f".format(it.totalQty)}", "Rp${"%.0f".format(it.totalOmzet)}")
                }

                val summary = ReportingService.summarize(todaySales, emptyList(), emptyList())
                val decisionSummary = analytics.businessDecisionSummary(sales, purchases, products, expenses, rejected)

                _state.update {
                    it.copy(
                        omzetToday = summary.omzet,
                        labaToday = summary.labaBersih,
                        saldoKas = saldo,
                        txCount = todaySales.size,
                        activeDebts = debts.count { d -> !d.isSettled },
                        lowStockCount = lowStock.size,
                        lowStockItems = lowStock.take(5).map { p -> Pair(p.name, "${p.stockQty} ${p.unit}") },
                        topSold = top3,
                        omzet7 = omzet7,
                        omzet30 = omzet30,
                        decisionText = decisionSummary.summary,
                        recentLogs = recentLogs,
                        activeRole = role,
                        isLoading = false,
                    )
                }
            }.onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// REPORTS
// ─────────────────────────────────────────────────────────────────────────────

data class ReportsState(
    val rangeDays: Int = 7,
    val omzet: Double = 0.0,
    val hpp: Double = 0.0,
    val expense: Double = 0.0,
    val purchase: Double = 0.0,
    val debtRemaining: Double = 0.0,
    val stockValue: Double = 0.0,
    val rejectLoss: Double = 0.0,
    val csvPreview: String = "",
    val topProducts: List<ProductSalesRow> = emptyList(),
    val lowStock: List<com.warungarasaan.app.domain.model.Product> = emptyList(),
    val isLoading: Boolean = false,
)

data class ProductSalesRow(
    val productName: String,
    val qty: Double,
    val omzet: Double,
    val hpp: Double,
)

sealed interface ReportsEvent {
    data class RangeDaysChanged(val days: Int) : ReportsEvent
}

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val salesRepo: SalesRepository,
    private val expenseRepo: ExpenseRepository,
    private val purchaseRepo: PurchaseRepository,
    private val debtRepo: DebtRepository,
    private val productRepo: ProductRepository,
    private val rejectedRepo: RejectedRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(ReportsState())
    val state: StateFlow<ReportsState> = _state.asStateFlow()

    init { load(7) }

    fun onEvent(event: ReportsEvent) {
        when (event) {
            is ReportsEvent.RangeDaysChanged -> {
                _state.update { it.copy(rangeDays = event.days) }
                load(event.days)
            }
        }
    }

    private fun load(rangeDays: Int) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching {
                val today = AppUtils.epochDayNow()
                val minDay = today - (rangeDays - 1)
                val sales = salesRepo.all().filter { it.dateEpochDay in minDay..today }
                val expenses = expenseRepo.all().filter { it.dateEpochDay in minDay..today }
                val purchases = purchaseRepo.all().filter { it.dateEpochDay in minDay..today }
                val debts = debtRepo.all()
                val products = productRepo.all()
                val rejected = rejectedRepo.all().filter { it.dateEpochDay in minDay..today }

                val summary = ReportingService.summarize(sales, expenses, rejected)
                val productNames = products.associateBy({ it.id }, { it.name })
                val top = sales.flatMap { it.items }
                    .groupBy { it.productId }
                    .map { (pid, rows) ->
                        ProductSalesRow(
                            productName = productNames[pid] ?: pid,
                            qty = rows.sumOf { it.qty },
                            omzet = rows.sumOf { it.total },
                            hpp = rows.sumOf { it.totalHpp },
                        )
                    }.sortedByDescending { it.omzet }

                _state.update {
                    it.copy(
                        omzet = summary.omzet,
                        hpp = summary.totalHpp,
                        expense = summary.totalBiaya,
                        purchase = purchases.sumOf { p -> p.items.sumOf { i -> i.qty * i.buyPrice } },
                        debtRemaining = debts.sumOf { d -> d.remaining },
                        stockValue = products.sumOf { p -> p.stockQty * p.avgHpp },
                        rejectLoss = summary.rugiRejek,
                        csvPreview = ReportExportService.salesCsv(sales.take(25), products),
                        topProducts = top,
                        lowStock = products.filter { p -> p.minStock > 0 && p.stockQty <= p.minStock },
                        isLoading = false,
                    )
                }
            }.onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SETTINGS
// ─────────────────────────────────────────────────────────────────────────────

data class SettingsState(
    val settings: AppSettings? = null,
    val role: String = "",
    val autoBackup: Boolean = false,
    val autoBackupDays: String = "7",
    val pinInput: String = "",
    val verifyInput: String = "",
    val verifyResult: String = "",
    val message: String = "",
)

sealed interface SettingsEvent {
    data class RoleChanged(val role: String) : SettingsEvent
    data object SaveRole : SettingsEvent
    data class AutoBackupChanged(val enabled: Boolean) : SettingsEvent
    data class AutoBackupDaysChanged(val days: String) : SettingsEvent
    data object SaveAutoBackupDays : SettingsEvent
    data class PinInputChanged(val pin: String) : SettingsEvent
    data object SavePin : SettingsEvent
    data class VerifyInputChanged(val pin: String) : SettingsEvent
    data object VerifyPin : SettingsEvent
    data object ClearMessage : SettingsEvent
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepo: SettingsRepository,
    private val metaRepo: MetaRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    init { load() }

    private fun load() {
        viewModelScope.launch {
            val settings = settingsRepo.get()
            val role = metaRepo.role()
            val autoBackup = metaRepo.autoBackupEnabled()
            val autoBackupDays = metaRepo.autoBackupDays()
            _state.update { it.copy(settings = settings, role = role, autoBackup = autoBackup, autoBackupDays = autoBackupDays.toString()) }
        }
    }

    fun onEvent(event: SettingsEvent) {
        when (event) {
            is SettingsEvent.RoleChanged -> _state.update { it.copy(role = event.role) }
            is SettingsEvent.SaveRole -> viewModelScope.launch {
                metaRepo.setRole(_state.value.role)
                _state.update { it.copy(message = "Role disimpan.") }
            }
            is SettingsEvent.AutoBackupChanged -> viewModelScope.launch {
                metaRepo.setAutoBackupEnabled(event.enabled)
                _state.update { it.copy(autoBackup = event.enabled) }
            }
            is SettingsEvent.AutoBackupDaysChanged -> _state.update { it.copy(autoBackupDays = event.days) }
            is SettingsEvent.SaveAutoBackupDays -> viewModelScope.launch {
                metaRepo.setAutoBackupDays(_state.value.autoBackupDays.toIntOrNull() ?: 7)
                _state.update { it.copy(message = "Interval disimpan.") }
            }
            is SettingsEvent.PinInputChanged -> _state.update { it.copy(pinInput = event.pin) }
            is SettingsEvent.SavePin -> viewModelScope.launch {
                val pin = _state.value.pinInput
                if (pin.isBlank()) settingsRepo.disablePin() else settingsRepo.setPin(pin)
                _state.update { it.copy(pinInput = "", message = if (pin.isBlank()) "PIN dinonaktifkan." else "PIN disimpan.") }
                load()
            }
            is SettingsEvent.VerifyInputChanged -> _state.update { it.copy(verifyInput = event.pin) }
            is SettingsEvent.VerifyPin -> viewModelScope.launch {
                val ok = settingsRepo.verifyPin(_state.value.verifyInput)
                _state.update { it.copy(verifyResult = if (ok) "PIN benar ✓" else "PIN salah ✗") }
            }
            is SettingsEvent.ClearMessage -> _state.update { it.copy(message = "") }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ACTIVITY LOG
// ─────────────────────────────────────────────────────────────────────────────

data class ActivityState(
    val activities: List<ActivityLog> = emptyList(),
    val isLoading: Boolean = false,
)

@HiltViewModel
class ActivityViewModel @Inject constructor(
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(ActivityState())
    val state: StateFlow<ActivityState> = _state.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching { activityLogRepo.all() }
                .onSuccess { list -> _state.update { it.copy(activities = list, isLoading = false) } }
                .onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }
}
