package com.warungarasaan.app.di

import android.content.Context
import androidx.room.Room
import com.warungarasaan.app.data.local.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Singleton
    @Provides
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "warung_arasaan.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideProductDao(db: AppDatabase): ProductDao = db.productDao()
    @Provides fun providePurchaseDao(db: AppDatabase): PurchaseDao = db.purchaseDao()
    @Provides fun providePurchaseItemDao(db: AppDatabase): PurchaseItemDao = db.purchaseItemDao()
    @Provides fun provideSaleDao(db: AppDatabase): SaleDao = db.saleDao()
    @Provides fun provideSaleItemDao(db: AppDatabase): SaleItemDao = db.saleItemDao()
    @Provides fun providePaymentSplitDao(db: AppDatabase): PaymentSplitDao = db.paymentSplitDao()
    @Provides fun provideExpenseDao(db: AppDatabase): ExpenseDao = db.expenseDao()
    @Provides fun provideDebtDao(db: AppDatabase): DebtDao = db.debtDao()
    @Provides fun provideCashDao(db: AppDatabase): CashDao = db.cashDao()
    @Provides fun provideStockMovementDao(db: AppDatabase): StockMovementDao = db.stockMovementDao()
    @Provides fun provideRejectedItemDao(db: AppDatabase): RejectedItemDao = db.rejectedItemDao()
    @Provides fun provideActivityLogDao(db: AppDatabase): ActivityLogDao = db.activityLogDao()
    @Provides fun provideAppSettingsDao(db: AppDatabase): AppSettingsDao = db.appSettingsDao()

    @Singleton
    @Provides
    fun provideMetaStore(@ApplicationContext context: Context): MetaStore = MetaStore(context)
}
