package com.warungarasaan.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.repository.ActivityLogRepository
import com.warungarasaan.app.data.repository.ProductRepository
import com.warungarasaan.app.data.repository.PurchaseRepository
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.PurchaseItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PurchasesState(
    val purchases: List<Purchase> = emptyList(),
    val products: List<Product> = emptyList(),
    val query: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
    val showDialog: Boolean = false,
    val editing: Purchase? = null,
    val selected: Purchase? = null,
    val easyMode: Boolean = true,
    val message: String = "",
) {
    val productMap: Map<String, Product> get() = products.associateBy { it.id }
    val filtered: List<Purchase> get() {
        val q = query.trim().lowercase()
        return if (q.isBlank()) purchases
        else purchases.filter {
            it.supplier.lowercase().contains(q) ||
            it.id.lowercase().contains(q) ||
            it.paymentMethod.lowercase().contains(q)
        }
    }
}

sealed interface PurchasesEvent {
    data class QueryChanged(val q: String) : PurchasesEvent
    data object AddNew : PurchasesEvent
    data class EditRequest(val purchase: Purchase) : PurchasesEvent
    data class SelectDetail(val purchase: Purchase) : PurchasesEvent
    data object DismissDialog : PurchasesEvent
    data object DismissDetail : PurchasesEvent
    data class EasyModeChanged(val enabled: Boolean) : PurchasesEvent
    data object ClearMessage : PurchasesEvent
    data class Save(
        val id: String,
        val supplier: String,
        val paymentMethod: String,
        val items: List<PurchaseItem>,
        val existingDate: Int?,
    ) : PurchasesEvent
    data class Delete(val id: String) : PurchasesEvent
}

@HiltViewModel
class PurchasesViewModel @Inject constructor(
    private val purchaseRepo: PurchaseRepository,
    private val productRepo: ProductRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(PurchasesState())
    val state: StateFlow<PurchasesState> = _state.asStateFlow()

    init { load() }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching {
                val purchases = purchaseRepo.all()
                val products = productRepo.all()
                _state.update { it.copy(purchases = purchases, products = products, isLoading = false) }
            }.onFailure { e -> _state.update { it.copy(error = e.message, isLoading = false) } }
        }
    }

    fun onEvent(event: PurchasesEvent) {
        when (event) {
            is PurchasesEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is PurchasesEvent.AddNew -> _state.update { it.copy(showDialog = true, editing = null) }
            is PurchasesEvent.EditRequest -> _state.update { it.copy(showDialog = true, editing = event.purchase) }
            is PurchasesEvent.SelectDetail -> _state.update { it.copy(selected = event.purchase) }
            is PurchasesEvent.DismissDialog -> _state.update { it.copy(showDialog = false, editing = null) }
            is PurchasesEvent.DismissDetail -> _state.update { it.copy(selected = null) }
            is PurchasesEvent.EasyModeChanged -> _state.update { it.copy(easyMode = event.enabled) }
            is PurchasesEvent.ClearMessage -> _state.update { it.copy(message = "") }

            is PurchasesEvent.Save -> viewModelScope.launch {
                runCatching {
                    val isNew = _state.value.editing == null
                    val purchase = Purchase(
                        id = event.id.ifBlank { AppUtils.newId("pur") },
                        dateEpochDay = event.existingDate ?: AppUtils.epochDayNow(),
                        supplier = event.supplier,
                        paymentMethod = event.paymentMethod,
                        items = event.items,
                    )
                    if (isNew) purchaseRepo.add(purchase) else purchaseRepo.replace(purchase)
                    activityLogRepo.log(if (isNew) "purchase" else "purchase_edit", "Pembelian ${purchase.id}")
                    _state.update { it.copy(showDialog = false, editing = null, message = "Pembelian berhasil disimpan.") }
                    load()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menyimpan pembelian.") } }
            }

            is PurchasesEvent.Delete -> viewModelScope.launch {
                runCatching { purchaseRepo.remove(event.id) }
                    .onSuccess {
                        activityLogRepo.log("purchase_delete", "Pembelian ${event.id} dihapus")
                        _state.update { it.copy(selected = null, message = "Pembelian dihapus.") }
                        load()
                    }
                    .onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal menghapus pembelian.") } }
            }
        }
    }
}
