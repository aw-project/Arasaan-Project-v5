package com.warung.arasaan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
