import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ─── Color Palette: "Deep Jungle" ─────────────────────────────────────────
class AppColors {
  // Primaries
  static const primary = Color(0xFF0B5E38);
  static const primaryLight = Color(0xFF1A7A50);
  static const primaryDark = Color(0xFF073D25);

  // Accent / Secondary
  static const gold = Color(0xFFD4870A);
  static const goldLight = Color(0xFFF5B942);

  // Backgrounds
  static const bg = Color(0xFFF2F7EF);
  static const surface = Color(0xFFFFFFFF);
  static const primaryContainer = Color(0xFFB7EFCE);
  static const surfaceVariant = Color(0xFFE4EEE0);
  static const surfaceDim = Color(0xFFEBF3E6);

  // On-colors
  static const onPrimary = Colors.white;
  static const onSurface = Color(0xFF111D0E);
  static const onSurfaceVariant = Color(0xFF3D4E39);
  static const hint = Color(0xFF8FA88A);

  // Status colors
  static const positive = Color(0xFF1A7A50);
  static const negative = Color(0xFFBF2D0D);

  // Stat card gradients
  static const cardGreen1 = Color(0xFF0A5C38);
  static const cardGreen2 = Color(0xFF168050);

  static const cardTeal1 = Color(0xFF00696A);
  static const cardTeal2 = Color(0xFF00897B);

  static const cardIndigo1 = Color(0xFF1A3A8F);
  static const cardIndigo2 = Color(0xFF1E52C8);

  static const cardAmber1 = Color(0xFFC05300);
  static const cardAmber2 = Color(0xFFE67000);

  // Drawer
  static const drawerHeader1 = Color(0xFF073D25);
  static const drawerHeader2 = Color(0xFF0F6040);

  // Drawer icon accent colors (used consistently instead of raw hex)
  static const iconGreen   = Color(0xFF1A7A50);  // Laporan
  static const iconBlue    = Color(0xFF1565C0);  // Analytics
  static const iconRed     = Color(0xFFBF360C);  // Saran Belanja
  static const iconPurple  = Color(0xFF6A1B9A);  // Log Aktivitas / Saran Beli
  static const iconAmber   = Color(0xFFB06000);  // Hutang
  static const iconCrimson = Color(0xFFC62828);  // Biaya
  static const iconSlate   = Color(0xFF37474F);  // Backup
  static const iconRejek   = Color(0xFFB83232);  // Retur/Rusak tab
}

// ─── AppTheme ────────────────────────────────────────────────────────────────
class AppTheme {
  static ThemeData get light {
    final base = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: Brightness.light,
    ).copyWith(
      primary: AppColors.primary,
      onPrimary: Colors.white,
      primaryContainer: const Color(0xFFB7EFCE),
      onPrimaryContainer: AppColors.primaryDark,
      secondary: AppColors.gold,
      onSecondary: Colors.white,
      secondaryContainer: const Color(0xFFFFE0A6),
      onSecondaryContainer: const Color(0xFF3D2400),
      background: AppColors.bg,
      onBackground: AppColors.onSurface,
      surface: AppColors.surface,
      onSurface: AppColors.onSurface,
      surfaceVariant: AppColors.surfaceVariant,
      onSurfaceVariant: AppColors.onSurfaceVariant,
      outline: const Color(0xFFA8BEA3),
      outlineVariant: const Color(0xFFD0E0CB),
      error: AppColors.negative,
      onError: Colors.white,
      errorContainer: const Color(0xFFFFDAD6),
      onErrorContainer: const Color(0xFF410002),
    );

    final poppins = GoogleFonts.poppinsTextTheme().copyWith(
      displayLarge: GoogleFonts.poppins(
          fontSize: 57, fontWeight: FontWeight.w700, letterSpacing: -0.5),
      displayMedium: GoogleFonts.poppins(
          fontSize: 45, fontWeight: FontWeight.w700, letterSpacing: -0.3),
      headlineLarge: GoogleFonts.poppins(
          fontSize: 32, fontWeight: FontWeight.w700, letterSpacing: -0.3),
      headlineMedium: GoogleFonts.poppins(
          fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: -0.2),
      headlineSmall: GoogleFonts.poppins(
          fontSize: 22, fontWeight: FontWeight.w700),
      titleLarge: GoogleFonts.poppins(
          fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: -0.2),
      titleMedium: GoogleFonts.poppins(
          fontSize: 16, fontWeight: FontWeight.w600, letterSpacing: -0.1),
      titleSmall: GoogleFonts.poppins(
          fontSize: 14, fontWeight: FontWeight.w600),
      bodyLarge: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w400),
      bodyMedium: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w400),
      bodySmall: GoogleFonts.poppins(
          fontSize: 12, fontWeight: FontWeight.w400, color: AppColors.hint),
      labelLarge: GoogleFonts.poppins(
          fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.1),
      labelMedium: GoogleFonts.poppins(
          fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 0.3),
      labelSmall: GoogleFonts.poppins(
          fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.4),
    );

    return ThemeData(
      colorScheme: base,
      useMaterial3: true,
      textTheme: poppins,
      scaffoldBackgroundColor: AppColors.bg,
      splashFactory: InkRipple.splashFactory,

      // AppBar
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 2,
        shadowColor: Colors.black.withOpacity(0.08),
        surfaceTintColor: Colors.transparent,
        titleTextStyle: GoogleFonts.poppins(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: AppColors.onSurface,
          letterSpacing: -0.2,
        ),
        iconTheme: const IconThemeData(color: AppColors.primary),
        actionsIconTheme: const IconThemeData(color: AppColors.primary),
      ),

      // Card
      cardTheme: CardThemeData(
        elevation: 0,
        color: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFFDEEBD8), width: 1),
        ),
        margin: EdgeInsets.zero,
      ),

      // Inputs
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceDim,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFCCD9C6)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFCCD9C6)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.primary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.negative, width: 1),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        labelStyle: GoogleFonts.poppins(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: AppColors.onSurfaceVariant),
        hintStyle: GoogleFonts.poppins(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: AppColors.hint),
        prefixIconColor: AppColors.primary,
      ),

      // Navigation bar
      navigationBarTheme: NavigationBarThemeData(
        height: 64,
        elevation: 0,
        shadowColor: Colors.transparent,
        backgroundColor: Colors.transparent,
        indicatorColor: const Color(0xFFD4F0E2),
        surfaceTintColor: Colors.transparent,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return GoogleFonts.poppins(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.primary);
          }
          return GoogleFonts.poppins(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: AppColors.hint);
        }),
      ),

      // Buttons
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          textStyle:
              GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          padding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          elevation: 0,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.primary,
          side: const BorderSide(color: AppColors.primary),
          textStyle:
              GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          padding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.primary,
          textStyle:
              GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
        ),
      ),

      // FAB
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
      ),

      // Divider
      dividerTheme: const DividerThemeData(
        color: Color(0xFFE4EEE0),
        thickness: 1,
        space: 1,
      ),

      // Chip
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.surfaceVariant,
        selectedColor: const Color(0xFFB7EFCE),
        labelStyle:
            GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
        side: BorderSide.none,
      ),

      // SnackBar
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.onSurface,
        contentTextStyle: GoogleFonts.poppins(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: Colors.white),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
      ),

      // Dialog
      dialogTheme: DialogThemeData(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
        backgroundColor: AppColors.surface,
        elevation: 8,
        titleTextStyle: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.onSurface),
      ),

      // List tile
      listTileTheme: ListTileThemeData(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
        minLeadingWidth: 0,
      ),
    );
  }
}
