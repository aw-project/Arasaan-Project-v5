import 'dart:async';

class UiDebouncer {
  UiDebouncer({this.delay = const Duration(milliseconds: 220)});

  final Duration delay;
  Timer? _timer;

  void run(void Function() action) {
    _timer?.cancel();
    _timer = Timer(delay, action);
  }

  void flush(void Function() action) {
    _timer?.cancel();
    action();
  }

  void dispose() {
    _timer?.cancel();
  }
}
