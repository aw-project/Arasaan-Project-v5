import 'package:flutter/material.dart';

/// Mixin untuk pagination sederhana.
///
/// TIDAK menggunakan `on State` agar kompatibel dengan `ConsumerState` Riverpod.
///
/// Cara pakai:
/// 1. Panggil [initPagination] di dalam `initState()`.
/// 2. Panggil [disposePagination] di dalam `dispose()` SEBELUM `super.dispose()`.
/// 3. Gunakan [paginatedScrollController] sebagai controller ListView.
/// 4. Gunakan [paginate(list)] untuk mendapatkan subset yang terlihat.
/// 5. Panggil [resetPagination] saat filter/search berubah.
mixin PaginationMixin {
  late int _pageSize;
  int _visibleCount = 0;
  late ScrollController _scrollController;
  VoidCallback? _onLoadMore;

  ScrollController get paginatedScrollController => _scrollController;

  void initPagination({int pageSize = 30, required VoidCallback onLoadMore}) {
    _pageSize = pageSize;
    _visibleCount = pageSize;
    _onLoadMore = onLoadMore;
    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
  }

  void resetPagination() {
    _visibleCount = _pageSize;
    if (_scrollController.hasClients) {
      _scrollController.jumpTo(0);
    }
    _onLoadMore?.call();
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final pos = _scrollController.position;
    if (pos.pixels >= pos.maxScrollExtent - 200) {
      _visibleCount += _pageSize;
      _onLoadMore?.call();
    }
  }

  List<T> paginate<T>(List<T> allItems) =>
      allItems.take(_visibleCount).toList();

  bool hasMore<T>(List<T> allItems) => allItems.length > _visibleCount;

  /// Wajib dipanggil di dispose() SEBELUM super.dispose().
  void disposePagination() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
  }
}
