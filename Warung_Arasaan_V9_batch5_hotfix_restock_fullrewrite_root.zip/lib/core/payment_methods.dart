/// Konstanta metode pembayaran yang digunakan di seluruh aplikasi.
/// Gunakan ini mengganti string literal langsung agar konsisten.
class PaymentMethods {
  PaymentMethods._();

  static const cash = 'Cash';
  static const qris = 'QRIS';
  static const transfer = 'Transfer';
  static const hutang = 'Hutang';
  static const nonCash = 'Non-Cash'; // untuk entry non-kas seperti rugi rejek

  /// Metode yang tersedia untuk penjualan
  static const List<String> forSale = [cash, qris, transfer, hutang];

  /// Metode yang tersedia untuk pembelian
  static const List<String> forPurchase = [cash, transfer, hutang];

  /// Metode yang tersedia untuk biaya/expense
  static const List<String> forExpense = [cash, transfer];

  /// Apakah metode ini mencatat arus kas nyata (bukan hutang/non-cash)
  static bool isCashFlow(String method) =>
      method != hutang && method != nonCash;
}
