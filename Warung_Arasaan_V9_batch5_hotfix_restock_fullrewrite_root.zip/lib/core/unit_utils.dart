const String kUnitMigrationV5Final = 'unit_migration_v5_final_gram';

String normalizeUnitLabel(String unit) {
  final u = unit.trim().toLowerCase();
  if (u == 'kg' || u == 'kilogram' || u == 'kilograms') return 'gram';
  if (u == 'gr') return 'gram';
  return unit.trim().isEmpty ? 'pcs' : unit.trim();
}

bool isWeightUnit(String unit) {
  final u = unit.trim().toLowerCase();
  return u == 'kg' || u == 'kilogram' || u == 'kilograms' || u == 'gram' || u == 'gr';
}

double normalizeQty(double value) => double.parse(value.toStringAsFixed(3));
double normalizeMoney(double value) => double.parse(value.toStringAsFixed(2));
double normalizeRate(double value) => double.parse(value.toStringAsFixed(6));

bool usesKgPriceInput(String unit) => isWeightUnit(unit);

String purchaseQtyLabel(String unit) => usesKgPriceInput(unit) ? 'Qty (gram)' : 'Qty';

String purchasePriceLabel(String unit) => usesKgPriceInput(unit) ? 'Harga beli / kg' : 'Harga beli / unit';

double purchaseInputPriceToStored(String unit, double inputPrice) {
  if (!usesKgPriceInput(unit)) return normalizeRate(inputPrice);
  return normalizeRate(inputPrice / 1000);
}

double purchaseStoredPriceToInput(String unit, double storedPrice) {
  if (!usesKgPriceInput(unit)) return normalizeRate(storedPrice);
  return normalizeMoney(storedPrice * 1000);
}

String purchasePriceHint(String unit) {
  return usesKgPriceInput(unit)
      ? 'Masukkan harga per kg. Sistem akan hitung otomatis ke gram.'
      : 'Masukkan harga per unit item.';
}
