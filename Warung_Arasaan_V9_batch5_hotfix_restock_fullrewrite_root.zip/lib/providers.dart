import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';

import 'domain/models/product.dart';
import 'domain/models/purchase.dart';
import 'domain/models/sale.dart';
import 'domain/models/expense.dart';
import 'domain/models/debt.dart';
import 'domain/models/stock_movement.dart';
import 'domain/models/cash_entry.dart';
import 'domain/models/app_settings.dart';
import 'domain/models/activity_log.dart';
import 'domain/models/rejected_item.dart';

import 'data/repositories/product_repo.dart';
import 'data/repositories/purchase_repo.dart';
import 'data/repositories/sales_repo.dart';
import 'data/repositories/expense_repo.dart';
import 'data/repositories/debt_repo.dart';
import 'data/repositories/movement_repo.dart';
import 'data/repositories/cash_repo.dart';
import 'data/repositories/settings_repo.dart';
import 'data/repositories/activity_log_repo.dart';
import 'data/repositories/meta_repo.dart';
import 'data/repositories/rejected_repo.dart';
import 'data/services/backup_service.dart';
import 'data/services/notification_service.dart';

final productsBoxProvider = Provider<Box<Product>>((ref) => throw UnimplementedError());
final purchasesBoxProvider = Provider<Box<Purchase>>((ref) => throw UnimplementedError());
final salesBoxProvider = Provider<Box<Sale>>((ref) => throw UnimplementedError());
final expensesBoxProvider = Provider<Box<Expense>>((ref) => throw UnimplementedError());
final debtsBoxProvider = Provider<Box<Debt>>((ref) => throw UnimplementedError());
final movementsBoxProvider = Provider<Box<StockMovement>>((ref) => throw UnimplementedError());
final cashBoxProvider = Provider<Box<CashEntry>>((ref) => throw UnimplementedError());
final settingsBoxProvider = Provider<Box<AppSettings>>((ref) => throw UnimplementedError());
final activityLogsBoxProvider = Provider<Box<ActivityLog>>((ref) => throw UnimplementedError());
final metaBoxProvider = Provider<Box>((ref) => throw UnimplementedError());
final rejectedItemsBoxProvider = Provider<Box<RejectedItem>>((ref) => throw UnimplementedError());

// ── Reactive repo providers ──────────────────────────────────────────────────
// Each provider listens to its Hive box streams via box.watch() and calls
// ref.invalidateSelf() when data changes, triggering UI rebuilds automatically.

final productRepoProvider = Provider<ProductRepo>((ref) {
  final box = ref.watch(productsBoxProvider);
  final repo = ProductRepo(box);
  // Cek stok menipis setiap kali data produk berubah → kirim notifikasi
  final sub = box.watch().listen((_) {
    ref.invalidateSelf();
    NotificationService.checkLowStock(box.values.toList());
  });
  ref.onDispose(sub.cancel);
  // Cek awal saat provider pertama dibuat
  Future.microtask(() => NotificationService.checkLowStock(box.values.toList()));
  return repo;
});

final purchaseRepoProvider = Provider<PurchaseRepo>((ref) {
  final pb = ref.watch(purchasesBoxProvider);
  final prb = ref.watch(productsBoxProvider);
  final mb = ref.watch(movementsBoxProvider);
  final cb = ref.watch(cashBoxProvider);
  final subs = [
    pb.watch().listen((_) => ref.invalidateSelf()),
    prb.watch().listen((_) => ref.invalidateSelf()),
  ];
  ref.onDispose(() { for (final s in subs) s.cancel(); });
  return PurchaseRepo(pb, prb, mb, cb);
});

final salesRepoProvider = Provider<SalesRepo>((ref) {
  final sb = ref.watch(salesBoxProvider);
  final prb = ref.watch(productsBoxProvider);
  final mb = ref.watch(movementsBoxProvider);
  final cb = ref.watch(cashBoxProvider);
  final subs = [
    sb.watch().listen((_) => ref.invalidateSelf()),
    prb.watch().listen((_) => ref.invalidateSelf()),
  ];
  ref.onDispose(() { for (final s in subs) s.cancel(); });
  return SalesRepo(sb, prb, mb, cb);
});

final expenseRepoProvider = Provider<ExpenseRepo>((ref) {
  final eb = ref.watch(expensesBoxProvider);
  final cb = ref.watch(cashBoxProvider);
  final subs = [
    eb.watch().listen((_) => ref.invalidateSelf()),
    cb.watch().listen((_) => ref.invalidateSelf()),
  ];
  ref.onDispose(() { for (final s in subs) s.cancel(); });
  return ExpenseRepo(eb, cb);
});

final debtRepoProvider = Provider<DebtRepo>((ref) {
  final db = ref.watch(debtsBoxProvider);
  final cb = ref.watch(cashBoxProvider);
  final subs = [
    db.watch().listen((_) => ref.invalidateSelf()),
    cb.watch().listen((_) => ref.invalidateSelf()),
  ];
  ref.onDispose(() { for (final s in subs) s.cancel(); });
  return DebtRepo(db, cb);
});

final movementRepoProvider = Provider<MovementRepo>((ref) {
  final box = ref.watch(movementsBoxProvider);
  final sub = box.watch().listen((_) => ref.invalidateSelf());
  ref.onDispose(sub.cancel);
  return MovementRepo(box);
});

final cashRepoProvider = Provider<CashRepo>((ref) {
  final box = ref.watch(cashBoxProvider);
  final sub = box.watch().listen((_) => ref.invalidateSelf());
  ref.onDispose(sub.cancel);
  return CashRepo(box);
});

final settingsRepoProvider = Provider<SettingsRepo>((ref) {
  final box = ref.watch(settingsBoxProvider);
  final sub = box.watch().listen((_) => ref.invalidateSelf());
  ref.onDispose(sub.cancel);
  return SettingsRepo(box);
});

final activityLogRepoProvider = Provider<ActivityLogRepo>((ref) {
  final box = ref.watch(activityLogsBoxProvider);
  // LazyBox: watch() stream still works for invalidation
  final sub = box.watch().listen((_) => ref.invalidateSelf());
  ref.onDispose(sub.cancel);
  return ActivityLogRepo(box);
});

final metaRepoProvider = Provider<MetaRepo>((ref) => MetaRepo(ref.watch(metaBoxProvider)));

final rejectedRepoProvider = Provider<RejectedRepo>((ref) {
  final rb = ref.watch(rejectedItemsBoxProvider);
  final prb = ref.watch(productsBoxProvider);
  final mb = ref.watch(movementsBoxProvider);
  final cb = ref.watch(cashBoxProvider);
  final subs = [
    rb.watch().listen((_) => ref.invalidateSelf()),
    prb.watch().listen((_) => ref.invalidateSelf()),
    cb.watch().listen((_) => ref.invalidateSelf()),
  ];
  ref.onDispose(() { for (final s in subs) s.cancel(); });
  return RejectedRepo(rb, prb, mb, cb);
});

final backupServiceProvider = Provider<BackupService>((ref) => BackupService(
      products: ref.watch(productsBoxProvider),
      purchases: ref.watch(purchasesBoxProvider),
      sales: ref.watch(salesBoxProvider),
      expenses: ref.watch(expensesBoxProvider),
      debts: ref.watch(debtsBoxProvider),
      movements: ref.watch(movementsBoxProvider),
      cash: ref.watch(cashBoxProvider),
      settings: ref.watch(settingsBoxProvider),
      activityLogs: ref.watch(activityLogsBoxProvider),
      meta: ref.watch(metaBoxProvider),
    ));
