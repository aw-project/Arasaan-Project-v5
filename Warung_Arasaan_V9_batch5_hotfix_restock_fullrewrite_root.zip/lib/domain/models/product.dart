class Product {
  final String id;
  String name;
  String unit;
  double defaultMarginPercent;
  double activeSellPrice;
  double stockQty;
  double avgHpp;
  /// Batas stok minimum untuk peringatan "stok menipis".
  /// Jika 0, berarti tidak ada peringatan.
  double minStock;
  /// Target stok untuk saran belanja.
  /// Jika 0, maka sistem akan menggunakan minStock sebagai target.
  double targetStock;
  String sku;
  String category;
  String? imagePath;

  Product({
    required this.id,
    required this.name,
    required this.unit,
    required this.defaultMarginPercent,
    required this.activeSellPrice,
    required this.stockQty,
    required this.avgHpp,
    this.minStock = 0,
    this.targetStock = 0,
    this.sku = '',
    this.category = 'Lainnya',
    this.imagePath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'unit': unit,
        'defaultMarginPercent': defaultMarginPercent,
        'activeSellPrice': activeSellPrice,
        'stockQty': stockQty,
        'avgHpp': avgHpp,
        'minStock': minStock,
        'targetStock': targetStock,
        'sku': sku,
        'category': category,
        'imagePath': imagePath,
      };

  static Product fromJson(Map<String, dynamic> j) => Product(
        id: j['id'] as String,
        name: j['name'] as String,
        unit: j['unit'] as String,
        defaultMarginPercent: (j['defaultMarginPercent'] as num).toDouble(),
        activeSellPrice: (j['activeSellPrice'] as num).toDouble(),
        stockQty: (j['stockQty'] as num).toDouble(),
        avgHpp: (j['avgHpp'] as num).toDouble(),
        minStock: ((j['minStock'] ?? 0) as num).toDouble(),
        targetStock: ((j['targetStock'] ?? 0) as num).toDouble(),
        sku: (j['sku'] as String?) ?? '',
        category: (j['category'] as String?) ?? 'Lainnya',
        imagePath: j['imagePath'] as String?,
      );
}
