/// Model untuk pencatatan barang rejek / rusak / kadaluarsa.
class RejectedItem {
  final String id;

  /// Tanggal pencatatan (epoch day).
  int dateEpochDay;

  /// Produk yang direjek.
  String productId;

  /// Jumlah barang yang direjek.
  double qty;

  /// Alasan penolakan.
  /// Nilai: 'Kadaluarsa' | 'Rusak/Cacat' | 'Retur Pelanggan' | 'Retur Supplier' | 'Lainnya'
  String reason;

  /// Penanganan barang rejek.
  /// Nilai: 'Dibuang' | 'Dikembalikan ke Supplier' | 'Dijual Diskon' | 'Diproses Ulang' | 'Lainnya'
  String handling;

  /// Catatan tambahan (opsional).
  String note;

  /// HPP produk saat pencatatan, untuk kalkulasi estimasi kerugian.
  double hppAtTime;

  /// Estimasi kerugian = qty × hppAtTime.
  double estimatedLoss;

  RejectedItem({
    required this.id,
    required this.dateEpochDay,
    required this.productId,
    required this.qty,
    required this.reason,
    required this.handling,
    this.note = '',
    required this.hppAtTime,
    required this.estimatedLoss,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'productId': productId,
        'qty': qty,
        'reason': reason,
        'handling': handling,
        'note': note,
        'hppAtTime': hppAtTime,
        'estimatedLoss': estimatedLoss,
      };

  static RejectedItem fromJson(Map<String, dynamic> j) => RejectedItem(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        productId: j['productId'] as String,
        qty: (j['qty'] as num).toDouble(),
        reason: j['reason'] as String,
        handling: j['handling'] as String,
        note: (j['note'] as String?) ?? '',
        hppAtTime: (j['hppAtTime'] as num).toDouble(),
        estimatedLoss: (j['estimatedLoss'] as num).toDouble(),
      );

  // ─── Constants ─────────────────────────────────────────────────────────────

  static const List<String> reasons = [
    'Kadaluarsa',
    'Rusak/Cacat',
    'Retur Pelanggan',
    'Retur Supplier',
    'Lainnya',
  ];

  static const List<String> handlings = [
    'Dibuang',
    'Dikembalikan ke Supplier',
    'Dijual Diskon',
    'Diproses Ulang',
    'Lainnya',
  ];
}
