class SaleItem {
  String productId;
  double qty;
  double sellPrice;
  double hppAtSale;

  SaleItem({required this.productId, required this.qty, required this.sellPrice, required this.hppAtSale});

  double get total => qty * sellPrice;
  double get totalHpp => qty * hppAtSale;

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'qty': qty,
        'sellPrice': sellPrice,
        'hppAtSale': hppAtSale,
      };

  static SaleItem fromJson(Map<String, dynamic> j) => SaleItem(
        productId: j['productId'] as String,
        qty: (j['qty'] as num).toDouble(),
        sellPrice: (j['sellPrice'] as num).toDouble(),
        hppAtSale: (j['hppAtSale'] as num).toDouble(),
      );
}

class PaymentSplit {
  String method;
  double amount;

  PaymentSplit({required this.method, required this.amount});

  Map<String, dynamic> toJson() => {'method': method, 'amount': amount};

  static PaymentSplit fromJson(Map<String, dynamic> j) => PaymentSplit(
        method: (j['method'] as String?) ?? 'Cash',
        amount: ((j['amount'] ?? 0) as num).toDouble(),
      );
}

class Sale {
  final String id;
  int dateEpochDay;
  List<SaleItem> items;
  String paymentMethod; // Cash/QRIS/Transfer/Hutang
  String customerName;
  double discountAmount;
  List<PaymentSplit> paymentSplits;

  Sale({
    required this.id,
    required this.dateEpochDay,
    required this.items,
    required this.paymentMethod,
    this.customerName = '',
    this.discountAmount = 0,
    List<PaymentSplit>? paymentSplits,
  }) : paymentSplits = paymentSplits ?? const [];

  double get grossSales => items.fold(0.0, (p, e) => p + e.total);
  double get totalSales {
    final net = grossSales - discountAmount;
    return net < 0 ? 0 : net;
  }

  double get totalHpp => items.fold(0.0, (p, e) => p + e.totalHpp);
  double get totalProfit => totalSales - totalHpp;
  bool get hasDiscount => discountAmount > 0.0001;
  bool get isSplitPayment => paymentSplits.length > 1;

  List<PaymentSplit> get normalizedSplits {
    if (paymentSplits.isNotEmpty) {
      return paymentSplits.where((e) => e.amount > 0).toList();
    }
    return [PaymentSplit(method: paymentMethod, amount: totalSales)];
  }

  String get paymentSummary {
    final splits = normalizedSplits;
    if (splits.length <= 1) return paymentMethod;
    return splits.map((e) => '${e.method} ${_fmtCompact(e.amount)}').join(' + ');
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'paymentMethod': paymentMethod,
        'customerName': customerName,
        'discountAmount': discountAmount,
        'paymentSplits': paymentSplits.map((e) => e.toJson()).toList(),
        'items': items.map((e) => e.toJson()).toList(),
      };

  static Sale fromJson(Map<String, dynamic> j) => Sale(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        paymentMethod: (j['paymentMethod'] as String?) ?? 'Cash',
        customerName: (j['customerName'] as String?) ?? '',
        discountAmount: ((j['discountAmount'] ?? 0) as num).toDouble(),
        paymentSplits: (j['paymentSplits'] as List?)
                ?.map((e) => PaymentSplit.fromJson(Map<String, dynamic>.from(e)))
                .toList() ??
            const [],
        items: (j['items'] as List)
            .map((e) => SaleItem.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

String _fmtCompact(double value) {
  if (value == value.roundToDouble()) return value.toStringAsFixed(0);
  return value.toStringAsFixed(2);
}
