class Expense {
  final String id;
  int dateEpochDay;
  String note;
  double amount;
  String paymentMethod; // Cash/Transfer
  String category; // Operasional/Transport/Belanja Alat/Lainnya

  Expense({
    required this.id,
    required this.dateEpochDay,
    required this.note,
    required this.amount,
    this.paymentMethod = 'Cash',
    this.category = 'Lainnya',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'note': note,
        'amount': amount,
        'paymentMethod': paymentMethod,
        'category': category,
      };

  static Expense fromJson(Map<String, dynamic> j) => Expense(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        note: j['note'] as String,
        amount: (j['amount'] as num).toDouble(),
        paymentMethod: (j['paymentMethod'] as String?) ?? 'Cash',
        category: (j['category'] as String?) ?? 'Lainnya',
      );
}
