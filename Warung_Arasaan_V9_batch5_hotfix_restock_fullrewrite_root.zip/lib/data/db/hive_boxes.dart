import 'package:hive/hive.dart';

import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/stock_movement.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/app_settings.dart';
import '../../domain/models/activity_log.dart';
import '../../domain/models/rejected_item.dart';

class Boxes {
  static const products = 'products';
  static const purchases = 'purchases';
  static const sales = 'sales';
  static const expenses = 'expenses';
  static const debts = 'debts';
  static const movements = 'movements';
  static const cash = 'cash';
  static const settings = 'settings';
  static const activityLogs = 'activity_logs';
  static const meta = 'meta';
  static const rejectedItems = 'rejected_items';
}


Future<Box<Product>> openProducts() => Hive.openBox<Product>(Boxes.products);
Future<Box<Purchase>> openPurchases() => Hive.openBox<Purchase>(Boxes.purchases);
Future<Box<Sale>> openSales() => Hive.openBox<Sale>(Boxes.sales);
Future<Box<Expense>> openExpenses() => Hive.openBox<Expense>(Boxes.expenses);
Future<Box<Debt>> openDebts() => Hive.openBox<Debt>(Boxes.debts);

Future<Box<StockMovement>> openMovements() => Hive.openBox<StockMovement>(Boxes.movements);

Future<Box<CashEntry>> openCash() => Hive.openBox<CashEntry>(Boxes.cash);
Future<Box<AppSettings>> openSettings() => Hive.openBox<AppSettings>(Boxes.settings);

Future<Box<ActivityLog>> openActivityLogs() => Hive.openBox<ActivityLog>(Boxes.activityLogs);

// Tahap 11: meta box untuk setting tambahan (role, auto-backup) tanpa migrasi model.
Future<Box> openMeta() => Hive.openBox(Boxes.meta);
Future<Box<RejectedItem>> openRejectedItems() => Hive.openBox<RejectedItem>(Boxes.rejectedItems);