import 'package:hive/hive.dart';

import '../../core/unit_utils.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/stock_movement.dart';

class UnitMigrationService {
  static const _flagKey = kUnitMigrationV5Final;

  static Future<void> migrateKgToGramOnce({
    required Box<Product> products,
    required Box<Purchase> purchases,
    required Box<Sale> sales,
    required Box<StockMovement> movements,
    required Box meta,
  }) async {
    final done = (meta.get(_flagKey) as bool?) ?? false;
    if (done) return;

    final gramProductIds = <String>{};

    for (final product in products.values) {
      final unit = product.unit.trim().toLowerCase();
      if (unit == 'kg' || unit == 'kilogram' || unit == 'kilograms') {
        product.unit = 'gram';
        product.stockQty = normalizeQty(product.stockQty * 1000);
        product.minStock = normalizeQty(product.minStock * 1000);
        product.targetStock = normalizeQty(product.targetStock * 1000);
        product.avgHpp = normalizeRate(product.avgHpp / 1000);
        product.activeSellPrice = normalizeRate(product.activeSellPrice / 1000);
        gramProductIds.add(product.id);
        await products.put(product.id, product);
      } else if (unit == 'gr') {
        product.unit = 'gram';
        await products.put(product.id, product);
      }
    }

    if (gramProductIds.isNotEmpty) {
      for (final purchase in purchases.values) {
        var changed = false;
        for (final item in purchase.items) {
          if (!gramProductIds.contains(item.productId)) continue;
          item.qty = normalizeQty(item.qty * 1000);
          item.buyPrice = normalizeRate(item.buyPrice / 1000);
          changed = true;
        }
        if (changed) await purchases.put(purchase.id, purchase);
      }

      for (final sale in sales.values) {
        var changed = false;
        for (final item in sale.items) {
          if (!gramProductIds.contains(item.productId)) continue;
          item.qty = normalizeQty(item.qty * 1000);
          item.sellPrice = normalizeRate(item.sellPrice / 1000);
          item.hppAtSale = normalizeRate(item.hppAtSale / 1000);
          changed = true;
        }
        if (changed) await sales.put(sale.id, sale);
      }

      for (final movement in movements.values) {
        if (!gramProductIds.contains(movement.productId)) continue;
        movement.qtyDelta = normalizeQty(movement.qtyDelta * 1000);
        await movements.put(movement.id, movement);
      }
    }

    await meta.put(_flagKey, true);
  }
}
