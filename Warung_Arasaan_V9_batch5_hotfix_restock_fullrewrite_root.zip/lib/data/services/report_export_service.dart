import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../core/dates.dart';
import '../repositories/reporting.dart';

class ReportExportService {
  static Future<void> shareSummaryPdf({
    required DateTime start,
    required DateTime end,
    required ReportSummary summary,
    required double totalPurchase,
    required double totalStockValue,
    required double totalRemainingDebt,
    required double totalLoss,
  }) async {
    final pdf = pw.Document();
    final nf = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    String money(double v) => nf.format(v);

    pw.Widget metric(String label, String value) {
      return pw.Container(
        margin: const pw.EdgeInsets.only(bottom: 10),
        padding: const pw.EdgeInsets.all(12),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey300),
          borderRadius: pw.BorderRadius.circular(8),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(label, style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
            pw.SizedBox(height: 4),
            pw.Text(value, style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          ],
        ),
      );
    }

    pdf.addPage(
      pw.MultiPage(
        margin: const pw.EdgeInsets.all(24),
        build: (context) => [
          pw.Text('Laporan Ringkasan Warung Arasaan', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          pw.Text('Periode ${fmtDate(start)} – ${fmtDate(end)}'),
          pw.SizedBox(height: 18),
          metric('Omzet', money(summary.omzet)),
          metric('Total HPP', money(summary.totalHpp)),
          metric('Laba Kotor', money(summary.labaKotor)),
          metric('Total Pembelian', money(totalPurchase)),
          metric('Total Biaya', money(summary.totalBiaya)),
          metric('Kerugian / Susut', money(totalLoss)),
          metric('Laba Bersih', money(summary.labaBersih)),
          metric('Nilai Stok Saat Ini', money(totalStockValue)),
          metric('Sisa Hutang', money(totalRemainingDebt)),
          pw.SizedBox(height: 14),
          pw.Text(
            'Catatan: laporan PDF ini adalah ringkasan eksekutif. Detail transaksi tetap tersedia di export CSV detail.',
            style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700),
          ),
        ],
      ),
    );

    final bytes = Uint8List.fromList(await pdf.save());
    await Printing.sharePdf(
      bytes: bytes,
      filename: 'laporan_ringkasan_${DateFormat('yyyyMMdd').format(start)}_${DateFormat('yyyyMMdd').format(end)}.pdf',
    );
  }
}
