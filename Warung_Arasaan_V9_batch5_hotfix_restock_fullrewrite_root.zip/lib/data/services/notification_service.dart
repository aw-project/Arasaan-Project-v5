import 'dart:io';
import 'package:flutter/material.dart' show Color;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../../domain/models/product.dart';

class NotificationService {
  NotificationService._();

  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  // Channel IDs
  static const _channelLowStock = 'low_stock';

  static Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    await _plugin.initialize(
      const InitializationSettings(android: android, iOS: ios),
    );

    // Request permission on Android 13+
    if (Platform.isAndroid) {
      final android = _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
    }
  }

  /// Cek stok menipis dan tampilkan notifikasi jika ada.
  /// Dipanggil saat app dibuka atau saat data produk berubah.
  static Future<void> checkLowStock(List<Product> products) async {
    if (!_initialized) return;

    final lowStockItems = products
        .where((p) => p.minStock > 0 && p.stockQty <= p.minStock)
        .toList();

    if (lowStockItems.isEmpty) {
      // Batalkan notifikasi stok menipis jika sudah tidak ada
      await _plugin.cancel(1);
      return;
    }

    final count = lowStockItems.length;
    final names = lowStockItems.take(3).map((p) => p.name).join(', ');
    final body = count == 1
        ? '$names hampir habis. Segera lakukan restok.'
        : '$names${count > 3 ? ', dan ${count - 3} lainnya' : ''} hampir habis.';

    const androidDetails = AndroidNotificationDetails(
      _channelLowStock,
      'Stok Menipis',
      channelDescription: 'Notifikasi produk dengan stok di bawah minimum',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      color: Color(0xFF0B5E38),
      onlyAlertOnce: true, // Tidak berbunyi berulang untuk item yang sama
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: false,
      presentSound: false,
    );

    await _plugin.show(
      1, // ID tetap agar notifikasi diperbarui, bukan ditambah baru
      '⚠️ $count Produk Stok Menipis',
      body,
      const NotificationDetails(android: androidDetails, iOS: iosDetails),
    );
  }

  // scheduleDailyStockReminder: tidak diimplementasi karena warung offline-first
  // tidak membutuhkan background scheduler. Notifikasi dipicu langsung saat
  // data produk berubah via checkLowStock().

  static void cancel(int id) => _plugin.cancel(id);
}
