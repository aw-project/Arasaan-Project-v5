import 'dart:convert';
import 'dart:io';

import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/ids.dart';
import '../../domain/models/activity_log.dart';
import '../../domain/models/app_settings.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/stock_movement.dart';
import '../db/hive_boxes.dart';
import '../repositories/activity_log_repo.dart';
import '../repositories/meta_repo.dart';

class BackupService {
  final Box<Product> products;
  final Box<Purchase> purchases;
  final Box<Sale> sales;
  final Box<Expense> expenses;
  final Box<Debt> debts;
  final Box<StockMovement> movements;
  final Box<CashEntry> cash;
  final Box<AppSettings> settings;
  final Box<ActivityLog> activityLogs;
  final Box meta;

  BackupService({
    required this.products,
    required this.purchases,
    required this.sales,
    required this.expenses,
    required this.debts,
    required this.movements,
    required this.cash,
    required this.settings,
    required this.activityLogs,
    required this.meta,
  });

  Map<String, dynamic> buildBackupMap() => {
        Boxes.products: products.values.map((e) => e.toJson()).toList(),
        Boxes.purchases: purchases.values.map((e) => e.toJson()).toList(),
        Boxes.sales: sales.values.map((e) => e.toJson()).toList(),
        Boxes.expenses: expenses.values.map((e) => e.toJson()).toList(),
        Boxes.debts: debts.values.map((e) => e.toJson()).toList(),
        Boxes.movements: movements.values.map((e) => e.toJson()).toList(),
        Boxes.cash: cash.values
            .map((e) => {
                  'id': e.id,
                  'dateEpochDay': e.dateEpochDay,
                  'direction': e.direction,
                  'source': e.source,
                  'method': e.method,
                  'note': e.note,
                  'amount': e.amount,
                  'refId': e.refId,
                })
            .toList(),
        Boxes.settings: settings.values
            .map((s) => {
                  'id': s.id,
                  'pinEnabled': s.pinEnabled,
                  'pinHash': s.pinHash,
                })
            .toList(),
        Boxes.activityLogs: activityLogs.values
            .map((log) => {
                  'id': log.id,
                  'dateEpochDay': log.dateEpochDay,
                  'type': log.type,
                  'refId': log.refId,
                  'oldJson': log.oldJson,
                  'newJson': log.newJson,
                })
            .toList(),
        Boxes.meta: {
          MetaRepo.kRole: meta.get(MetaRepo.kRole),
          MetaRepo.kAutoBackupEnabled: meta.get(MetaRepo.kAutoBackupEnabled),
          MetaRepo.kAutoBackupDays: meta.get(MetaRepo.kAutoBackupDays),
          MetaRepo.kLastAutoBackupEpochMs: meta.get(MetaRepo.kLastAutoBackupEpochMs),
          MetaRepo.kFavoriteSuppliers: meta.get(MetaRepo.kFavoriteSuppliers),
          MetaRepo.kExpenseCategories: meta.get(MetaRepo.kExpenseCategories),
        },
        '_meta': {
          'app': 'warung_arasaan',
          'ts': DateTime.now().toIso8601String(),
          'version': 3,
          'includes': [Boxes.activityLogs, Boxes.meta],
        },
      };

  String buildBackupJson() => const JsonEncoder.withIndent('  ').convert(buildBackupMap());

  Future<File> createBackupFile() async {
    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_arasaan_backup_$ts.json');
    await f.writeAsString(buildBackupJson());
    return f;
  }

  Future<void> shareBackup() async {
    final f = await createBackupFile();
    await Share.shareXFiles([XFile(f.path)], text: 'Backup Warung Arasaan');
  }

  Future<void> autoBackupIfDue({
    required MetaRepo meta,
    required ActivityLogRepo logs,
    int keepLast = 10,
  }) async {
    if (!meta.autoBackupEnabled) return;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final lastMs = meta.lastAutoBackupEpochMs;
    final days = meta.autoBackupDays;
    final dueMs = Duration(days: days).inMilliseconds;
    if (lastMs != 0 && (nowMs - lastMs) < dueMs) return;

    final dir = await getApplicationDocumentsDirectory();
    final backupDir = Directory('${dir.path}/auto_backups');
    if (!await backupDir.exists()) {
      await backupDir.create(recursive: true);
    }
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${backupDir.path}/auto_backup_$ts.json');
    await f.writeAsString(buildBackupJson());

    await meta.setLastAutoBackupEpochMs(nowMs);
    await logs.log('auto_backup', 'Auto backup dibuat: ${f.path.split('/').last}');

    final files = backupDir
        .listSync()
        .whereType<File>()
        .where((x) => x.path.endsWith('.json'))
        .toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    if (files.length > keepLast) {
      for (final old in files.sublist(keepLast)) {
        try {
          await old.delete();
        } catch (_) {}
      }
    }
  }

  Future<void> restoreFromPicker() async {
    final res = await FilePicker.platform.pickFiles(
      dialogTitle: 'Pilih file backup (.json)',
      type: FileType.custom,
      allowedExtensions: ['json'],
    );
    if (res == null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path == null) return;

    final raw = await File(path).readAsString();
    await restoreFromJson(raw);
  }

  Future<void> restoreFromJson(String raw) async {
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Format backup tidak valid.');
    }
    await restoreFromMap(decoded);
  }

  Future<void> restoreFromMap(Map<String, dynamic> j) async {
    _validateSnapshot(j);

    final nextProducts = <Product>[];
    final nextPurchases = <Purchase>[];
    final nextSales = <Sale>[];
    final nextExpenses = <Expense>[];
    final nextDebts = <Debt>[];
    final nextMovements = <StockMovement>[];
    final nextCash = <CashEntry>[];
    final nextSettings = <AppSettings>[];
    final nextLogs = <ActivityLog>[];

    for (final p in (j[Boxes.products] as List? ?? const [])) {
      nextProducts.add(Product.fromJson(Map<String, dynamic>.from(p as Map)));
    }
    for (final x in (j[Boxes.purchases] as List? ?? const [])) {
      nextPurchases.add(Purchase.fromJson(Map<String, dynamic>.from(x as Map)));
    }
    for (final x in (j[Boxes.sales] as List? ?? const [])) {
      nextSales.add(Sale.fromJson(Map<String, dynamic>.from(x as Map)));
    }
    for (final x in (j[Boxes.expenses] as List? ?? const [])) {
      nextExpenses.add(Expense.fromJson(Map<String, dynamic>.from(x as Map)));
    }
    for (final x in (j[Boxes.debts] as List? ?? const [])) {
      nextDebts.add(Debt.fromJson(Map<String, dynamic>.from(x as Map)));
    }
    for (final x in (j[Boxes.movements] as List? ?? const [])) {
      nextMovements.add(StockMovement.fromJson(Map<String, dynamic>.from(x as Map)));
    }
    for (final x in (j[Boxes.cash] as List? ?? const [])) {
      final m = Map<String, dynamic>.from(x as Map);
      nextCash.add(
        CashEntry(
          id: m['id'] as String,
          dateEpochDay: (m['dateEpochDay'] as num).toInt(),
          direction: (m['direction'] as String?) ?? 'in',
          source: (m['source'] as String?) ?? 'manual',
          method: (m['method'] as String?) ?? 'Cash',
          note: (m['note'] as String?) ?? '',
          amount: (m['amount'] as num).toDouble(),
          refId: (m['refId'] as String?) ?? '',
        ),
      );
    }
    for (final x in (j[Boxes.settings] as List? ?? const [])) {
      final m = Map<String, dynamic>.from(x as Map);
      nextSettings.add(
        AppSettings(
          id: (m['id'] as String?) ?? 'app',
          pinEnabled: (m['pinEnabled'] as bool?) ?? false,
          pinHash: (m['pinHash'] as String?) ?? '',
        ),
      );
    }
    for (final x in (j[Boxes.activityLogs] as List? ?? const [])) {
      final m = Map<String, dynamic>.from(x as Map);
      nextLogs.add(
        ActivityLog(
          id: (m['id'] as String?) ?? newId('log'),
          dateEpochDay: (m['dateEpochDay'] as num?)?.toInt() ?? 0,
          type: (m['type'] as String?) ?? 'restore',
          refId: (m['refId'] as String?) ?? '',
          oldJson: (m['oldJson'] as String?) ?? '',
          newJson: (m['newJson'] as String?) ?? '',
        ),
      );
    }

    final metaMap = Map<String, dynamic>.from((j[Boxes.meta] as Map?) ?? const {});

    await products.clear();
    await purchases.clear();
    await sales.clear();
    await expenses.clear();
    await debts.clear();
    await movements.clear();
    await cash.clear();
    await settings.clear();
    await activityLogs.clear();
    await meta.clear();

    for (final obj in nextProducts) {
      await products.put(obj.id, obj);
    }
    for (final obj in nextPurchases) {
      await purchases.put(obj.id, obj);
    }
    for (final obj in nextSales) {
      await sales.put(obj.id, obj);
    }
    for (final obj in nextExpenses) {
      await expenses.put(obj.id, obj);
    }
    for (final obj in nextDebts) {
      await debts.put(obj.id, obj);
    }
    for (final obj in nextMovements) {
      await movements.put(obj.id, obj);
    }
    for (final obj in nextCash) {
      await cash.put(obj.id, obj);
    }
    for (final obj in nextSettings) {
      await settings.put(obj.id, obj);
    }
    for (final obj in nextLogs) {
      await activityLogs.put(obj.id, obj);
    }

    for (final entry in metaMap.entries) {
      await meta.put(entry.key, entry.value);
    }
  }

  void _validateSnapshot(Map<String, dynamic> j) {
    final requiredLists = [
      Boxes.products,
      Boxes.purchases,
      Boxes.sales,
      Boxes.expenses,
      Boxes.debts,
      Boxes.movements,
      Boxes.cash,
      Boxes.settings,
    ];
    for (final key in requiredLists) {
      final v = j[key];
      if (v != null && v is! List) {
        throw FormatException('Bagian "$key" pada backup tidak valid.');
      }
    }
    final metaInfo = j['_meta'];
    if (metaInfo != null && metaInfo is! Map) {
      throw const FormatException('Metadata backup tidak valid.');
    }
  }

  int _toEpochDay(DateTime dt) {
    final utc = DateTime.utc(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    return utc.difference(base).inDays;
  }

  DateTime _fromEpochDay(int day) {
    final base = DateTime.utc(1970, 1, 1);
    final du = base.add(Duration(days: day));
    return DateTime(du.year, du.month, du.day);
  }

  Future<File> exportReportCsv({required DateTime start, required DateTime end}) async {
    final s0 = _toEpochDay(start);
    final s1 = _toEpochDay(end);

    final mapOmzet = <int, double>{};
    final mapHpp = <int, double>{};
    for (final s in sales.values) {
      if (s.dateEpochDay < s0 || s.dateEpochDay > s1) continue;
      mapOmzet[s.dateEpochDay] = (mapOmzet[s.dateEpochDay] ?? 0.0) + s.totalSales;
      mapHpp[s.dateEpochDay] = (mapHpp[s.dateEpochDay] ?? 0.0) + s.totalHpp;
    }

    final mapBiaya = <int, double>{};
    for (final e in expenses.values) {
      if (e.dateEpochDay < s0 || e.dateEpochDay > s1) continue;
      mapBiaya[e.dateEpochDay] = (mapBiaya[e.dateEpochDay] ?? 0.0) + e.amount;
    }

    final rows = <List<String>>[
      ['tanggal', 'omzet', 'hpp', 'laba_kotor', 'biaya', 'laba_bersih'],
    ];

    for (int day = s0; day <= s1; day++) {
      final omzet = mapOmzet[day] ?? 0;
      final hpp = mapHpp[day] ?? 0;
      final biaya = mapBiaya[day] ?? 0;
      final lk = omzet - hpp;
      final lb = lk - biaya;

      final t = _fromEpochDay(day);
      final tanggal =
          '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      rows.add([tanggal, omzet.toStringAsFixed(0), hpp.toStringAsFixed(0), lk.toStringAsFixed(0), biaya.toStringAsFixed(0), lb.toStringAsFixed(0)]);
    }

    final csv = rows.map((r) => r.map(_escapeCsv).join(',')).join('\n');

    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_arasaan_report_$ts.csv');
    await f.writeAsString(csv);
    return f;
  }

  Future<void> shareReportCsv({required DateTime start, required DateTime end}) async {
    final f = await exportReportCsv(start: start, end: end);
    await Share.shareXFiles([XFile(f.path)], text: 'Laporan CSV Warung Arasaan');
  }

  Future<File> exportReportDetailCsv({required DateTime start, required DateTime end}) async {
    final s0 = _toEpochDay(start);
    final s1 = _toEpochDay(end);

    String dateStrFromEpochDay(int day) {
      final t = _fromEpochDay(day);
      return '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
    }

    final rows = <List<String>>[
      [
        'tanggal',
        'tipe',
        'ref_id',
        'pihak',
        'produk',
        'qty',
        'unit',
        'harga',
        'subtotal',
        'hpp',
        'laba',
        'catatan',
      ],
    ];

    for (final p in purchases.values) {
      if (p.dateEpochDay < s0 || p.dateEpochDay > s1) continue;
      final tanggal = dateStrFromEpochDay(p.dateEpochDay);
      final pihak = p.supplier.trim();
      for (final it in p.items) {
        final pr = products.get(it.productId);
        final name = pr?.name ?? it.productId;
        final unit = pr?.unit ?? '';
        final subtotal = it.qty * it.buyPrice;
        rows.add([
          tanggal,
          'pembelian',
          p.id,
          pihak,
          name,
          it.qty.toStringAsFixed(2),
          unit,
          it.buyPrice.toStringAsFixed(0),
          subtotal.toStringAsFixed(0),
          '',
          '',
          '',
        ]);
      }
    }

    for (final s in sales.values) {
      if (s.dateEpochDay < s0 || s.dateEpochDay > s1) continue;
      final tanggal = dateStrFromEpochDay(s.dateEpochDay);
      for (final it in s.items) {
        final pr = products.get(it.productId);
        final name = pr?.name ?? it.productId;
        final unit = pr?.unit ?? '';
        final subtotal = it.qty * it.sellPrice;
        final hpp = it.qty * it.hppAtSale;
        final laba = subtotal - hpp;
        rows.add([
          tanggal,
          'penjualan',
          s.id,
          '',
          name,
          it.qty.toStringAsFixed(2),
          unit,
          it.sellPrice.toStringAsFixed(0),
          subtotal.toStringAsFixed(0),
          hpp.toStringAsFixed(0),
          laba.toStringAsFixed(0),
          '',
        ]);
      }
    }

    for (final e in expenses.values) {
      if (e.dateEpochDay < s0 || e.dateEpochDay > s1) continue;
      final tanggal = dateStrFromEpochDay(e.dateEpochDay);
      rows.add([
        tanggal,
        'biaya',
        e.id,
        '',
        '',
        '',
        '',
        '',
        e.amount.toStringAsFixed(0),
        '',
        '',
        '[${e.category}] ${e.note}',
      ]);
    }

    final head = rows.first;
    final body = rows.skip(1).toList();
    body.sort((a, b) => a.first.compareTo(b.first));
    final csv = ([head] + body).map((r) => r.map(_escapeCsv).join(',')).join('\n');

    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_arasaan_report_detail_$ts.csv');
    await f.writeAsString(csv);
    return f;
  }

  Future<void> shareReportDetailCsv({required DateTime start, required DateTime end}) async {
    final f = await exportReportDetailCsv(start: start, end: end);
    await Share.shareXFiles([XFile(f.path)], text: 'Laporan Detail CSV Warung Arasaan');
  }

  String _escapeCsv(String s) {
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      return '"${s.replaceAll('"', '""')}"';
    }
    return s;
  }

  Future<int> importProductsFromCsv() async {
    final res = await FilePicker.platform.pickFiles(
      dialogTitle: 'Pilih file CSV Produk',
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );
    if (res == null || res.files.isEmpty) return 0;
    final path = res.files.single.path;
    if (path == null) return 0;

    final raw = await File(path).readAsString();
    final rows = const CsvToListConverter(eol: '\n').convert(raw);
    if (rows.isEmpty) return 0;

    final header = rows.first.map((e) => e.toString().trim()).toList();
    int idx(String key) => header.indexWhere((h) => h.toLowerCase() == key.toLowerCase());

    final iName = idx('name');

    int count = 0;
    for (int r = 1; r < rows.length; r++) {
      final row = rows[r];
      if (row.isEmpty) continue;
      final name = (row[(iName >= 0 ? iName : 0)] ?? '').toString().trim();
      if (name.isEmpty) continue;

      String getS(String key, {String def = ''}) {
        final i = idx(key);
        if (i < 0 || i >= row.length) return def;
        return (row[i] ?? def).toString();
      }

      double getD(String key, {double def = 0}) {
        final i = idx(key);
        if (i < 0 || i >= row.length) return def;
        final v = row[i];
        if (v is num) return v.toDouble();
        return double.tryParse(v.toString()) ?? def;
      }

      final unit = getS('unit');
      final margin = getD('defaultMarginPercent');
      final sell = getD('activeSellPrice');
      final stock = getD('stockQty');
      final hpp = getD('avgHpp');
      final minStock = getD('minStock');
      final targetStock = getD('targetStock');
      final category = getS('category', def: 'Lainnya');
      final imagePath = getS('imagePath');

      Product? existing;
      for (final p in products.values) {
        if (p.name.toLowerCase().trim() == name.toLowerCase()) {
          existing = p;
          break;
        }
      }

      if (existing != null) {
        existing
          ..unit = unit.isEmpty ? existing.unit : unit
          ..defaultMarginPercent = margin == 0 ? existing.defaultMarginPercent : margin
          ..activeSellPrice = sell == 0 ? existing.activeSellPrice : sell
          ..stockQty = stock
          ..avgHpp = hpp
          ..minStock = minStock
          ..targetStock = targetStock == 0 ? existing.targetStock : targetStock
          ..category = category.isEmpty ? existing.category : category
          ..imagePath = imagePath.isEmpty ? existing.imagePath : imagePath;
        await products.put(existing.id, existing);
      } else {
        final id = newId('prd');
        await products.put(
          id,
          Product(
            id: id,
            name: name,
            unit: unit.isEmpty ? 'pcs' : unit,
            defaultMarginPercent: margin,
            activeSellPrice: sell,
            stockQty: stock,
            avgHpp: hpp,
            minStock: minStock,
            targetStock: targetStock,
            category: category.isEmpty ? 'Lainnya' : category,
            imagePath: imagePath.isEmpty ? null : imagePath,
          ),
        );
      }

      count++;
    }
    return count;
  }
}
