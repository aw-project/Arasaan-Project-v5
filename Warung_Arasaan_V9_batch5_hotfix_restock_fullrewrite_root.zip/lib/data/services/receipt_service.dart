import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/dates.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';

class ReceiptService {
  static String buildSaleText({required Sale sale, required Map<String, Product> productsById}) {
    final b = StringBuffer();
    b.writeln('Warung Sayur');
    b.writeln('Struk Penjualan');
    b.writeln('Tanggal: ${fmtDateFromEpochDay(sale.dateEpochDay)}');
    b.writeln('Pembayaran: ${sale.paymentSummary}');
    if (sale.customerName.trim().isNotEmpty) {
      b.writeln('Pelanggan: ${sale.customerName.trim()}');
    }
    b.writeln('------------------------------');
    for (final it in sale.items) {
      final p = productsById[it.productId];
      final name = p?.name ?? it.productId;
      final unit = p?.unit ?? '';
      b.writeln(name);
      b.writeln('  ${it.qty.toStringAsFixed(2)} $unit x ${fmtMoney(it.sellPrice)} = ${fmtMoney(it.total)}');
    }
    b.writeln('------------------------------');
    b.writeln('BRUTO: ${fmtMoney(sale.grossSales)}');
    if (sale.discountAmount > 0) b.writeln('DISKON: ${fmtMoney(sale.discountAmount)}');
    b.writeln('TOTAL: ${fmtMoney(sale.totalSales)}');
    b.writeln('Terima kasih 🙏');
    return b.toString();
  }

  static Future<void> shareSaleText({required Sale sale, required Map<String, Product> productsById}) async {
    final text = buildSaleText(sale: sale, productsById: productsById);
    await Share.share(text);
  }

  static pw.Document _buildSalePdf({required Sale sale, required Map<String, Product> productsById}) {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a6,
        build: (ctx) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Warung Sayur', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
              pw.Text('Struk Penjualan'),
              pw.SizedBox(height: 6),
              pw.Text('Tanggal: ${fmtDateFromEpochDay(sale.dateEpochDay)}'),
              pw.Text('Pembayaran: ${sale.paymentSummary}'),
              if (sale.customerName.trim().isNotEmpty) pw.Text('Pelanggan: ${sale.customerName.trim()}'),
              pw.Divider(),
              ...sale.items.map((it) {
                final p = productsById[it.productId];
                final name = p?.name ?? it.productId;
                final unit = p?.unit ?? '';
                return pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(name, style: const pw.TextStyle(fontSize: 11)),
                    pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        pw.Text('${it.qty.toStringAsFixed(2)} $unit x ${fmtMoney(it.sellPrice)}', style: const pw.TextStyle(fontSize: 10)),
                        pw.Text(fmtMoney(it.total), style: const pw.TextStyle(fontSize: 10)),
                      ],
                    ),
                    pw.SizedBox(height: 4),
                  ],
                );
              }),
              pw.Divider(),
              pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [pw.Text('BRUTO'), pw.Text(fmtMoney(sale.grossSales))]),
              if (sale.discountAmount > 0)
                pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [pw.Text('DISKON'), pw.Text(fmtMoney(sale.discountAmount))]),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('TOTAL', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.Text(fmtMoney(sale.totalSales), style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                ],
              ),
              pw.SizedBox(height: 8),
              pw.Center(child: pw.Text('Terima kasih 🙏', style: const pw.TextStyle(fontSize: 10))),
            ],
          );
        },
      ),
    );
    return pdf;
  }

  static Future<void> shareSalePdf({required Sale sale, required Map<String, Product> productsById}) async {
    final pdf = _buildSalePdf(sale: sale, productsById: productsById);
    final bytes = await pdf.save();
    await Printing.sharePdf(bytes: Uint8List.fromList(bytes), filename: 'struk_${sale.id}.pdf');
  }

  static Future<void> printSalePdf({required Sale sale, required Map<String, Product> productsById}) async {
    final pdf = _buildSalePdf(sale: sale, productsById: productsById);
    final bytes = await pdf.save();
    await Printing.layoutPdf(onLayout: (_) async => Uint8List.fromList(bytes), name: 'struk_${sale.id}');
  }
}
