import '../../core/payment_methods.dart';
import 'package:hive/hive.dart';

import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/product.dart';
import '../../domain/models/rejected_item.dart';
import '../../domain/models/stock_movement.dart';

class RejectedRepo {
  final Box<RejectedItem> box;
  final Box<Product> productBox;
  final Box<StockMovement> movementsBox;
  final Box<CashEntry> cashBox;

  RejectedRepo(this.box, this.productBox, this.movementsBox, this.cashBox);

  // ─── Read ─────────────────────────────────────────────────────────────────

  List<RejectedItem> all() =>
      box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  List<RejectedItem> byDateRange(int fromEpochDay, int toEpochDay) =>
      box.values
          .where((r) => r.dateEpochDay >= fromEpochDay && r.dateEpochDay <= toEpochDay)
          .toList()
        ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  double totalLoss() => box.values.fold(0, (s, r) => s + r.estimatedLoss);

  double totalLossThisMonth() {
    final now = DateTime.now();
    return box.values
        .where((r) {
          final d = DateTime.fromMillisecondsSinceEpoch(
              (r.dateEpochDay + 0) * 86400000,
              isUtc: true);
          return d.year == now.year && d.month == now.month;
        })
        .fold(0, (s, r) => s + r.estimatedLoss);
  }

  // ─── Write ────────────────────────────────────────────────────────────────

  /// Tambah barang rejek:
  /// 1. Simpan record RejectedItem.
  /// 2. Kurangi stok produk.
  /// 3. Catat StockMovement tipe 'reject'.
  Future<void> add(RejectedItem item) async {
    // Validasi qty
    if (item.qty <= 0) {
      throw const FormatException('Jumlah barang rejek harus lebih dari 0.');
    }

    final product = productBox.get(item.productId);
    if (product == null) throw const FormatException('Produk tidak ditemukan.');

    if (product.stockQty < item.qty) {
      throw FormatException(
          'Stok tidak cukup. Stok tersedia: ${product.stockQty} ${product.unit}.');
    }

    // 1. Simpan record
    await box.put(item.id, item);

    // 2. Kurangi stok produk
    product.stockQty -= item.qty;
    await productBox.put(product.id, product);

    // 3. Catat movement
    final movId = newId('mv');
    await movementsBox.put(
      movId,
      StockMovement(
        id: movId,
        dateEpochDay: item.dateEpochDay,
        productId: item.productId,
        type: 'reject',
        qtyDelta: -item.qty,
        note: 'Rejek: ${item.reason} — ${item.note}',
        lossType: item.reason,
        lossAmount: item.estimatedLoss,
      ),
    );

    // 4. Catat kerugian sebagai CashEntry (out) agar muncul di laporan & laba
    if (item.estimatedLoss > 0) {
      final cashId = newId('cash');
      await cashBox.put(
        cashId,
        CashEntry(
          id: cashId,
          dateEpochDay: item.dateEpochDay,
          direction: 'out',
          source: 'reject',
          method: PaymentMethods.nonCash,
          note: 'Kerugian Rejek: ${item.reason}',
          amount: item.estimatedLoss,
          refId: item.id,
        ),
      );
    }
  }

  /// Hapus catatan rejek:
  /// 1. Kembalikan stok produk (undo deduction).
  /// 2. Hapus StockMovement terkait.
  /// 3. Hapus record RejectedItem.
  Future<void> remove(String id) async {
    final item = box.get(id);
    if (item == null) return;

    // 1. Kembalikan stok
    final product = productBox.get(item.productId);
    if (product != null) {
      product.stockQty += item.qty;
      await productBox.put(product.id, product);
    }

    // 2. Hapus movement terkait
    final movToDelete = movementsBox.toMap().entries
        .where((e) =>
            e.value.type == 'reject' &&
            e.value.productId == item.productId &&
            e.value.dateEpochDay == item.dateEpochDay &&
            (e.value.qtyDelta + item.qty).abs() < 0.001)
        .map((e) => e.key)
        .toList();
    for (final k in movToDelete) {
      await movementsBox.delete(k);
    }

    // 3. Hapus CashEntry kerugian terkait
    final cashToDelete = cashBox.toMap().entries
        .where((e) => e.value.source == 'reject' && e.value.refId == id)
        .map((e) => e.key)
        .toList();
    for (final k in cashToDelete) {
      await cashBox.delete(k);
    }

    // 4. Hapus record
    await box.delete(id);
  }
}
