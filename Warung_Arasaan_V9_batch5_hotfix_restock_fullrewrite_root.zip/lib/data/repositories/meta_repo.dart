import 'package:hive/hive.dart';

import '../../domain/models/sale.dart';

class HeldCart {
  final String id;
  final String label;
  final int savedAtMs;
  final Map<String, double> cart;
  final String paymentMethod;
  final double discountAmount;
  final List<PaymentSplit> paymentSplits;

  HeldCart({
    required this.id,
    required this.label,
    required this.savedAtMs,
    required this.cart,
    required this.paymentMethod,
    this.discountAmount = 0,
    this.paymentSplits = const [],
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'savedAtMs': savedAtMs,
        'cart': cart,
        'paymentMethod': paymentMethod,
        'discountAmount': discountAmount,
        'paymentSplits': paymentSplits.map((e) => e.toJson()).toList(),
      };

  static HeldCart fromJson(Map<String, dynamic> j) {
    final rawCart = Map<String, dynamic>.from((j['cart'] as Map?) ?? const {});
    return HeldCart(
      id: (j['id'] as String?) ?? '',
      label: (j['label'] as String?) ?? 'Hold',
      savedAtMs: ((j['savedAtMs'] ?? 0) as num).toInt(),
      cart: {
        for (final e in rawCart.entries)
          e.key: ((e.value ?? 0) as num).toDouble(),
      },
      paymentMethod: (j['paymentMethod'] as String?) ?? 'Cash',
      discountAmount: ((j['discountAmount'] ?? 0) as num).toDouble(),
      paymentSplits: (j['paymentSplits'] as List?)
              ?.map((e) => PaymentSplit.fromJson(Map<String, dynamic>.from(e)))
              .toList() ??
          const [],
    );
  }
}

class MetaRepo {
  final Box box;
  MetaRepo(this.box);

  static const kRole = 'role';
  static const kAutoBackupEnabled = 'auto_backup_enabled';
  static const kAutoBackupDays = 'auto_backup_days';
  static const kLastAutoBackupEpochMs = 'last_auto_backup_ms';
  static const kFavoriteSuppliers = 'favorite_suppliers';
  static const kExpenseCategories = 'expense_categories';
  static const kHeldSalesCarts = 'held_sales_carts';
  static const kRecentCustomers = 'recent_customers';

  String get role => (box.get(kRole) as String?) ?? 'admin';
  Future<void> setRole(String role) => box.put(kRole, role);

  bool get autoBackupEnabled => (box.get(kAutoBackupEnabled) as bool?) ?? false;
  Future<void> setAutoBackupEnabled(bool v) => box.put(kAutoBackupEnabled, v);

  int get autoBackupDays => (box.get(kAutoBackupDays) as int?) ?? 7;
  Future<void> setAutoBackupDays(int days) => box.put(kAutoBackupDays, days);

  int get lastAutoBackupEpochMs => (box.get(kLastAutoBackupEpochMs) as int?) ?? 0;
  Future<void> setLastAutoBackupEpochMs(int ms) => box.put(kLastAutoBackupEpochMs, ms);

  List<String> get favoriteSuppliers {
    final raw = box.get(kFavoriteSuppliers);
    if (raw is List) {
      return raw.map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toSet().toList()
        ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    }
    return const [];
  }

  Future<void> setFavoriteSuppliers(List<String> names) async {
    final cleaned = names.map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    await box.put(kFavoriteSuppliers, cleaned);
  }

  Future<void> toggleFavoriteSupplier(String name) async {
    final cleaned = name.trim();
    if (cleaned.isEmpty) return;
    final list = [...favoriteSuppliers];
    final idx = list.indexWhere((e) => e.toLowerCase() == cleaned.toLowerCase());
    if (idx >= 0) {
      list.removeAt(idx);
    } else {
      list.add(cleaned);
    }
    await setFavoriteSuppliers(list);
  }

  List<String> get expenseCategories {
    final raw = box.get(kExpenseCategories);
    if (raw is List) {
      final fromBox = raw.map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toSet().toList()
        ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
      if (fromBox.isNotEmpty) return fromBox;
    }
    return const ['Operasional', 'Transport', 'Belanja Alat', 'Utilitas', 'Lainnya'];
  }

  Future<void> setExpenseCategories(List<String> categories) async {
    final cleaned = categories.map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    await box.put(kExpenseCategories, cleaned);
  }

  Future<void> addExpenseCategory(String category) async {
    final cleaned = category.trim();
    if (cleaned.isEmpty) return;
    final list = [...expenseCategories];
    if (!list.any((e) => e.toLowerCase() == cleaned.toLowerCase())) {
      list.add(cleaned);
      await setExpenseCategories(list);
    }
  }


  List<String> get recentCustomers {
    final raw = box.get(kRecentCustomers);
    if (raw is List) {
      return raw.map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toSet().toList()
        ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    }
    return const [];
  }

  Future<void> setRecentCustomers(List<String> names) async {
    final cleaned = names.map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    await box.put(kRecentCustomers, cleaned);
  }

  Future<void> saveRecentCustomer(String name) async {
    final cleaned = name.trim();
    if (cleaned.isEmpty) return;
    final list = [...recentCustomers];
    list.removeWhere((e) => e.toLowerCase() == cleaned.toLowerCase());
    list.insert(0, cleaned);
    await setRecentCustomers(list.take(50).toList());
  }

  List<HeldCart> get heldSalesCarts {
    final raw = box.get(kHeldSalesCarts);
    if (raw is List) {
      final items = raw
          .whereType<Map>()
          .map((e) => HeldCart.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      items.sort((a, b) => b.savedAtMs.compareTo(a.savedAtMs));
      return items;
    }
    return const [];
  }

  Future<void> setHeldSalesCarts(List<HeldCart> carts) async {
    await box.put(kHeldSalesCarts, carts.map((e) => e.toJson()).toList());
  }

  Future<void> saveHeldSalesCart(HeldCart cart) async {
    final list = [...heldSalesCarts]..removeWhere((e) => e.id == cart.id);
    list.add(cart);
    await setHeldSalesCarts(list);
  }

  Future<void> deleteHeldSalesCart(String id) async {
    final list = [...heldSalesCarts]..removeWhere((e) => e.id == id);
    await setHeldSalesCarts(list);
  }
}
