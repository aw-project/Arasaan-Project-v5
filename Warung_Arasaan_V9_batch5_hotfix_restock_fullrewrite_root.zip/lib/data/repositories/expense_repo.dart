import 'package:hive/hive.dart';

import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/expense.dart';

class ExpenseRepo {
  final Box<Expense> box;
  final Box<CashEntry> cashBox;
  ExpenseRepo(this.box, this.cashBox);

  List<Expense> all() => box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Expense e) async {
    if (e.amount <= 0) {
      throw const FormatException('Nominal biaya harus lebih dari 0.');
    }

    String? cashId;
    var expenseSaved = false;
    try {
      await box.put(e.id, e);
      expenseSaved = true;

      cashId = newId('cash');
      await cashBox.put(
        cashId,
        CashEntry(
          id: cashId,
          dateEpochDay: e.dateEpochDay,
          direction: 'out',
          source: 'expense',
          method: e.paymentMethod,
          note: e.note,
          amount: e.amount,
          refId: e.id,
        ),
      );
    } catch (_) {
      if (cashId != null) {
        await cashBox.delete(cashId);
      }
      if (expenseSaved) {
        await box.delete(e.id);
      }
      rethrow;
    }
  }

  Future<void> remove(String id) async {
    await box.delete(id);
    final keys = <dynamic>[];
    for (final entry in cashBox.toMap().entries) {
      final c = entry.value;
      if (c.source == 'expense' && c.refId == id) keys.add(entry.key);
    }
    for (final k in keys) {
      await cashBox.delete(k);
    }
  }
}
