import 'package:hive/hive.dart';

import '../../domain/models/activity_log.dart';
import '../../core/ids.dart';

/// ActivityLog dibatasi max [_kMaxLogs] entri terbaru.
/// Entri lama otomatis dibersihkan saat penambahan baru melebihi batas.
class ActivityLogRepo {
  final Box<ActivityLog> box;
  ActivityLogRepo(this.box);

  static const _kMaxLogs = 500;

  List<ActivityLog> all() => box.values.toList()
    ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  /// Ambil [limit] log terbaru (lebih efisien untuk UI).
  List<ActivityLog> recent({int limit = 100}) {
    final sorted = all();
    return sorted.length > limit ? sorted.sublist(0, limit) : sorted;
  }

  Future<void> add(ActivityLog log) async {
    await box.put(log.id, log);
    // Auto-trim jika melebihi batas
    if (box.length > _kMaxLogs) {
      final old = all().skip(_kMaxLogs).toList();
      for (final l in old) {
        await box.delete(l.id);
      }
    }
  }

  Future<void> log(String type, String message) {
    final id = newId('log');
    final now = DateTime.now();
    final epochDay = DateTime.utc(now.year, now.month, now.day)
        .difference(DateTime.utc(1970, 1, 1))
        .inDays;
    return add(ActivityLog(
        id: id, type: type, refId: '', oldJson: '', newJson: message,
        dateEpochDay: epochDay));
  }

  Future<void> clear() => box.clear();
}
