import '../../core/payment_methods.dart';
import 'package:hive/hive.dart';

import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/debt.dart';

class DebtRepo {
  final Box<Debt> box;
  final Box<CashEntry> cashBox;
  DebtRepo(this.box, this.cashBox);

  List<Debt> all() => box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));
  Future<void> add(Debt d) => box.put(d.id, d);
  /// Hapus hutang beserta semua catatan pembayaran kas terkait.
  Future<void> remove(String id) async {
    // Hapus semua CashEntry dengan source='debt_payment' dan refId == id
    final cashToDelete = cashBox.toMap().entries
        .where((e) => e.value.source == 'debt_payment' && e.value.refId == id)
        .map((e) => e.key)
        .toList();
    for (final k in cashToDelete) {
      await cashBox.delete(k);
    }
    await box.delete(id);
  }

  Future<void> addPayment(String id, double amount, {required int dateEpochDay, String method = 'Cash'}) async {
    if (amount <= 0) {
      throw const FormatException('Nominal pembayaran hutang harus lebih dari 0.');
    }

    final d = box.get(id);
    if (d == null) return;

    final oldPaid = d.paid;
    String? cashId;
    try {
      d.paid = (d.paid + amount).clamp(0, d.principal);
      await box.put(d.id, d);

      cashId = newId('cash');
      await cashBox.put(
        cashId,
        CashEntry(
          id: cashId,
          dateEpochDay: dateEpochDay,
          direction: 'out',
          source: 'debt_payment',
          method: method,
          note: 'Bayar hutang: ${d.creditor}',
          amount: amount,
          refId: d.id,
        ),
      );
    } catch (_) {
      d.paid = oldPaid;
      await box.put(d.id, d);
      if (cashId != null) {
        await cashBox.delete(cashId);
      }
      rethrow;
    }
  }
}
