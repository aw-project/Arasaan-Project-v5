import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/app_theme.dart';
import '../../data/services/analytics_service.dart';
import '../../domain/models/product.dart';
import '../../providers.dart';
import '../products/product_detail_page.dart';
import '../widgets/empty_state.dart';

class RestockPage extends ConsumerStatefulWidget {
  const RestockPage({super.key});

  @override
  ConsumerState<RestockPage> createState() => _RestockPageState();
}

class _RestockPageState extends ConsumerState<RestockPage> {
  int windowDays = 7;
  int horizonDays = 3;
  String statusFilter = 'semua';
  String sortBy = 'prioritas';
  bool actionableOnly = false;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Smart Restock'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'Restock Cerdas'),
              Tab(text: 'Prediksi'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _restockTab(context),
            _forecastTab(context),
          ],
        ),
      ),
    );
  }

  Widget _restockTab(BuildContext context) {
    final productsBox = ref.watch(productsBoxProvider);
    final salesBox = ref.watch(salesBoxProvider);
    final analytics = const AnalyticsService();
    final smart = analytics.stockIntelligence(
      salesBox,
      productsBox,
      DateTime.now(),
      windowDays: windowDays,
      horizonDays: horizonDays,
      deadStockDays: windowDays,
    );

    final emptyStock = smart.where((e) => e.status == 'habis').toList();
    final criticalStock = smart.where((e) => e.status == 'kritis').toList();
    final warningStock = smart.where((e) => e.status == 'waspada').toList();
    final deadStock = smart.where((e) => e.status == 'mati').toList();
    final slowMoving = smart.where((e) => e.status == 'lambat').toList();

    var visible = statusFilter == 'semua'
        ? List<StockInsightKpi>.from(smart)
        : smart.where((e) => e.status == statusFilter).toList();

    if (actionableOnly) {
      visible = visible
          .where((e) => e.suggestBuy > 0 || e.status == 'habis' || e.status == 'kritis')
          .toList();
    }

    visible.sort((a, b) {
      switch (sortBy) {
        case 'kebutuhan':
          final byNeed = b.suggestBuy.compareTo(a.suggestBuy);
          if (byNeed != 0) return byNeed;
          return b.weeklyNeed.compareTo(a.weeklyNeed);
        case 'hari_aman':
          return a.daysLeft.compareTo(b.daysLeft);
        case 'nama':
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
        case 'prioritas':
        default:
          final byPriority = b.priorityScore.compareTo(a.priorityScore);
          if (byPriority != 0) return byPriority;
          return b.suggestBuy.compareTo(a.suggestBuy);
      }
    });

    final topWeekly = smart.where((e) => e.weeklyNeed > 0).toList()
      ..sort((a, b) => b.weeklyNeed.compareTo(a.weeklyNeed));
    final actionableItems = smart
        .where((e) => e.suggestBuy > 0 || e.status == 'habis' || e.status == 'kritis')
        .toList();
    final totalRecommended =
        smart.fold<double>(0, (sum, item) => sum + _safeNumber(item.suggestBuy));
    final avgSafeDays = smart.isEmpty
        ? 0.0
        : smart.fold<double>(0, (sum, item) => sum + _safeNumber(item.safeDays)) / smart.length;

    final widgets = <Widget>[
      _ConfigBar(
        windowDays: windowDays,
        horizonDays: horizonDays,
        onWindowChanged: (v) => setState(() => windowDays = v),
        onHorizonChanged: (v) => setState(() => horizonDays = v),
      ),
      const SizedBox(height: 12),
      Row(
        children: [
          Expanded(
            child: _SummaryCard(
              title: 'Stok Habis',
              value: '${emptyStock.length}',
              color: AppColors.negative,
              icon: Icons.cancel_rounded,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _SummaryCard(
              title: 'Kritis',
              value: '${criticalStock.length}',
              color: AppColors.gold,
              icon: Icons.warning_amber_rounded,
            ),
          ),
        ],
      ),
      const SizedBox(height: 10),
      Row(
        children: [
          Expanded(
            child: _SummaryCard(
              title: 'Waspada',
              value: '${warningStock.length}',
              color: AppColors.iconBlue,
              icon: Icons.error_outline_rounded,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _SummaryCard(
              title: 'Stok Mati',
              value: '${deadStock.length}',
              color: AppColors.iconPurple,
              icon: Icons.inventory_2_outlined,
            ),
          ),
        ],
      ),
      const SizedBox(height: 10),
      Row(
        children: [
          Expanded(
            child: _SummaryCard(
              title: 'Lambat',
              value: '${slowMoving.length}',
              color: AppColors.iconGreen,
              icon: Icons.timelapse_rounded,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _SummaryCard(
              title: 'Saran Beli',
              value: _fmt(totalRecommended),
              color: AppColors.primary,
              icon: Icons.shopping_bag_rounded,
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Filter prioritas', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _FilterChipItem(
                    label: 'Semua',
                    selected: statusFilter == 'semua',
                    onTap: () => setState(() => statusFilter = 'semua'),
                  ),
                  _FilterChipItem(
                    label: 'Habis',
                    selected: statusFilter == 'habis',
                    onTap: () => setState(() => statusFilter = 'habis'),
                  ),
                  _FilterChipItem(
                    label: 'Kritis',
                    selected: statusFilter == 'kritis',
                    onTap: () => setState(() => statusFilter = 'kritis'),
                  ),
                  _FilterChipItem(
                    label: 'Waspada',
                    selected: statusFilter == 'waspada',
                    onTap: () => setState(() => statusFilter = 'waspada'),
                  ),
                  _FilterChipItem(
                    label: 'Mati',
                    selected: statusFilter == 'mati',
                    onTap: () => setState(() => statusFilter = 'mati'),
                  ),
                  _FilterChipItem(
                    label: 'Lambat',
                    selected: statusFilter == 'lambat',
                    onTap: () => setState(() => statusFilter = 'lambat'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _FilterChipItem(
                    label: 'Prioritas',
                    selected: sortBy == 'prioritas',
                    onTap: () => setState(() => sortBy = 'prioritas'),
                  ),
                  _FilterChipItem(
                    label: 'Kebutuhan beli',
                    selected: sortBy == 'kebutuhan',
                    onTap: () => setState(() => sortBy = 'kebutuhan'),
                  ),
                  _FilterChipItem(
                    label: 'Hari aman',
                    selected: sortBy == 'hari_aman',
                    onTap: () => setState(() => sortBy = 'hari_aman'),
                  ),
                  _FilterChipItem(
                    label: 'Nama',
                    selected: sortBy == 'nama',
                    onTap: () => setState(() => sortBy = 'nama'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SwitchListTile.adaptive(
                value: actionableOnly,
                contentPadding: EdgeInsets.zero,
                title: const Text('Hanya tampilkan item yang perlu aksi'),
                subtitle: const Text(
                  'Fokus ke stok habis, kritis, atau yang memang perlu dibeli.',
                ),
                onChanged: (v) => setState(() => actionableOnly = v),
              ),
              Text(
                'Target otomatis dihitung dari rata-rata penjualan dan hari aman stok. Produk diurutkan dari yang paling mendesak.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 16),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _MiniMetric(
                label: 'Perlu aksi',
                value: '${actionableItems.length}',
                icon: Icons.task_alt_rounded,
              ),
              _MiniMetric(
                label: 'Hari aman rata-rata',
                value: _fmtDays(avgSafeDays),
                icon: Icons.event_available_rounded,
              ),
              _MiniMetric(
                label: 'Top mingguan',
                value: topWeekly.isEmpty ? '-' : topWeekly.first.name,
                icon: Icons.local_mall_rounded,
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 16),
    ];

    if (smart.isEmpty) {
      widgets.add(
        const EmptyState(
          title: 'Belum ada insight restock',
          subtitle:
              'Tambahkan stok minimum/target dan catat penjualan agar Smart Restock mulai bekerja.',
          icon: Icons.auto_graph_rounded,
        ),
      );
    } else {
      widgets.addAll([
        const _SectionHeader(
          title: 'Prioritas Restock',
          subtitle:
              'Status aman / waspada / kritis berdasarkan stok, hari aman, dan kebutuhan mingguan.',
        ),
        const SizedBox(height: 8),
      ]);

      if (visible.isEmpty) {
        widgets.add(
          const Card(
            child: Padding(
              padding: EdgeInsets.all(8),
              child: EmptyState(
                title: 'Tidak ada item untuk filter ini',
                subtitle:
                    'Ubah filter status atau matikan fokus aksi agar daftar restock tampil kembali.',
                icon: Icons.filter_alt_off_rounded,
                iconSize: 44,
              ),
            ),
          ),
        );
      } else {
        widgets.addAll(
          visible.take(20).map(
            (it) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Card(
                child: ListTile(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ProductDetailPage(productId: it.productId),
                    ),
                  ),
                  title: Text(it.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(
                    'Stok ${_fmt(it.stockQty)} ${it.unit} • Avg ${_fmt(it.avgPerDay)} ${it.unit}/hari\n'
                    'Hari aman ${_fmt(it.safeDays)} • Sisa ${_fmtDays(it.daysLeft)} • Mingguan ${_fmt(it.weeklyNeed)} ${it.unit}\n'
                    'Target ${_fmt(it.effectiveTargetStock)} • Saran beli ${_fmt(it.suggestBuy)} ${it.unit}',
                  ),
                  isThreeLine: true,
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _StatusBadge(
                        label: _statusLabel(it.status),
                        color: _statusColor(it.status),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Skor ${it.priorityScore}',
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      }

      widgets.addAll([
        const SizedBox(height: 12),
        const _SectionHeader(
          title: 'Rekomendasi Mingguan',
          subtitle: 'Produk dengan kebutuhan mingguan terbesar untuk bantu belanja rutin.',
        ),
        const SizedBox(height: 8),
      ]);

      widgets.addAll(
        topWeekly.take(8).map(
          (it) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Card(
              child: ListTile(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProductDetailPage(productId: it.productId),
                  ),
                ),
                leading: CircleAvatar(
                  backgroundColor: _statusColor(it.status).withOpacity(0.12),
                  foregroundColor: _statusColor(it.status),
                  child: Text(it.name.substring(0, 1).toUpperCase()),
                ),
                title: Text(it.name),
                subtitle: Text(
                  'Kebutuhan 7 hari ${_fmt(it.weeklyNeed)} ${it.unit} • Saran beli ${_fmt(it.suggestBuy)} ${it.unit}',
                ),
                trailing: Text(_statusLabel(it.status)),
              ),
            ),
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
      children: widgets,
    );
  }

  Widget _forecastTab(BuildContext context) {
    final productsRepo = ref.watch(productRepoProvider);
    final salesBox = ref.watch(salesBoxProvider);
    final products = productsRepo.all();

    final todayEpoch = _epochDay(DateTime.now());
    final startEpoch = todayEpoch - (windowDays - 1);

    final soldQty = <String, double>{};
    for (final s in salesBox.values) {
      if (s.dateEpochDay < startEpoch || s.dateEpochDay > todayEpoch) continue;
      for (final it in s.items) {
        soldQty[it.productId] = (soldQty[it.productId] ?? 0) + it.qty;
      }
    }

    final items = <_ForecastItem>[];
    for (final p in products) {
      final total = soldQty[p.id] ?? 0.0;
      if (total <= 0) continue;
      final avgPerDay = total / windowDays;
      final need = avgPerDay * horizonDays;
      final suggestBuy = need - p.stockQty;
      items.add(
        _ForecastItem(
          product: p,
          avgPerDay: avgPerDay,
          horizonNeed: need,
          suggestBuy: suggestBuy > 0 ? suggestBuy : 0,
        ),
      );
    }

    items.sort((a, b) {
      final c = b.suggestBuy.compareTo(a.suggestBuy);
      if (c != 0) return c;
      return b.horizonNeed.compareTo(a.horizonNeed);
    });

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: _ConfigBar(
            windowDays: windowDays,
            horizonDays: horizonDays,
            onWindowChanged: (v) => setState(() => windowDays = v),
            onHorizonChanged: (v) => setState(() => horizonDays = v),
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: items.isEmpty
              ? const EmptyState(
                  title: 'Belum ada prediksi',
                  subtitle:
                      'Belum ada penjualan dalam periode ini. Coba pilih 14/30 hari atau mulai catat penjualan.',
                  icon: Icons.show_chart,
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final it = items[i];
                    final p = it.product;
                    return Card(
                      child: ListTile(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ProductDetailPage(productId: p.id),
                          ),
                        ),
                        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(
                          'Rata2 ${_fmt(it.avgPerDay)} ${p.unit}/hari • Perkiraan $horizonDays hari ${_fmt(it.horizonNeed)} ${p.unit}',
                        ),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text('Saran beli', style: TextStyle(fontSize: 12)),
                            Text(
                              '${_fmt(it.suggestBuy)} ${p.unit}',
                              style: const TextStyle(fontWeight: FontWeight.w800),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'habis':
        return 'Habis';
      case 'kritis':
        return 'Kritis';
      case 'waspada':
        return 'Waspada';
      case 'mati':
        return 'Mati';
      case 'lambat':
        return 'Lambat';
      default:
        return 'Aman';
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'habis':
        return AppColors.negative;
      case 'kritis':
        return AppColors.gold;
      case 'waspada':
        return AppColors.iconBlue;
      case 'mati':
        return AppColors.iconPurple;
      case 'lambat':
        return AppColors.iconGreen;
      default:
        return AppColors.primary;
    }
  }

  double _safeNumber(num? value) {
    if (value == null) return 0;
    final asDouble = value.toDouble();
    if (asDouble.isNaN || asDouble.isInfinite) return 0;
    return asDouble;
  }

  String _fmt(double v) {
    final safe = _safeNumber(v);
    if (safe == safe.roundToDouble()) return safe.toStringAsFixed(0);
    return safe.toStringAsFixed(1);
  }

  String _fmtDays(double days) {
    final safe = _safeNumber(days);
    if (safe >= 9999) return 'belum terukur';
    if (safe <= 1) return '< 1 hari';
    if (safe == safe.roundToDouble()) return '${safe.toStringAsFixed(0)} hari';
    return '${safe.toStringAsFixed(1)} hari';
  }

  int _epochDay(DateTime dt) {
    final d = DateTime(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    final du = DateTime.utc(d.year, d.month, d.day);
    return du.difference(base).inDays;
  }
}

class _ConfigBar extends StatelessWidget {
  final int windowDays;
  final int horizonDays;
  final ValueChanged<int> onWindowChanged;
  final ValueChanged<int> onHorizonChanged;

  const _ConfigBar({
    required this.windowDays,
    required this.horizonDays,
    required this.onWindowChanged,
    required this.onHorizonChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _pillDropdown<int>(
            label: 'Data',
            value: windowDays,
            items: const [7, 14, 30],
            onChanged: onWindowChanged,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _pillDropdown<int>(
            label: 'Hari aman',
            value: horizonDays,
            items: const [3, 7],
            onChanged: onHorizonChanged,
          ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  final IconData icon;

  const _SummaryCard({
    required this.title,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 2),
                  Text(value, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterChipItem extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChipItem({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 2),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;

  const _StatusBadge({
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(color: color),
      ),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _MiniMetric({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      width: 220,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.surfaceVariant),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    label,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall?.copyWith(color: AppColors.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _pillDropdown<T>({
  required String label,
  required T value,
  required List<T> items,
  required ValueChanged<T> onChanged,
}) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 12),
    decoration: BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.surfaceVariant),
    ),
    child: DropdownButtonHideUnderline(
      child: DropdownButton<T>(
        value: value,
        isExpanded: true,
        items: items.map((e) => DropdownMenuItem<T>(value: e, child: Text('$label: $e'))).toList(),
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      ),
    ),
  );
}

class _ForecastItem {
  final Product product;
  final double avgPerDay;
  final double horizonNeed;
  final double suggestBuy;

  const _ForecastItem({
    required this.product,
    required this.avgPerDay,
    required this.horizonNeed,
    required this.suggestBuy,
  });
}
