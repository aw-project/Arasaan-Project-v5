import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/pagination_mixin.dart';
import '../../providers.dart';

class ActivityLogPage extends ConsumerStatefulWidget {
  const ActivityLogPage({super.key});

  @override
  ConsumerState<ActivityLogPage> createState() => _ActivityLogPageState();
}

class _ActivityLogPageState extends ConsumerState<ActivityLogPage>
    with PaginationMixin {
  final TextEditingController _searchC = TextEditingController();
  String _typeFilter = 'semua';
  @override
  void initState() {
    super.initState();
    initPagination(pageSize: 50, onLoadMore: () => setState(() {}));
  }

  @override
  void dispose() {
    _searchC.dispose();
    disposePagination();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final allLogs = ref.watch(activityLogRepoProvider).recent(limit: 200);
    final q = _searchC.text.trim().toLowerCase();
    final availableTypes = <String>{'semua', ...allLogs.map((e) => e.type)}.toList();
    final logs = allLogs.where((l) {
      final typeOk = _typeFilter == 'semua' || l.type == _typeFilter;
      final searchOk = q.isEmpty || _labelFor(l.type).toLowerCase().contains(q) || l.newJson.toLowerCase().contains(q) || l.oldJson.toLowerCase().contains(q);
      return typeOk && searchOk;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
          child: Column(
            children: [
              TextField(
                controller: _searchC,
                decoration: InputDecoration(
                  labelText: 'Cari log aktivitas',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _searchC.text.isEmpty
                      ? null
                      : IconButton(
                          onPressed: () {
                            _searchC.clear();
                            setState(() {});
                          },
                          icon: const Icon(Icons.close_rounded),
                        ),
                ),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 10),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: availableTypes.map((type) {
                    final selected = _typeFilter == type;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(type == 'semua' ? 'Semua' : _labelFor(type)),
                        selected: selected,
                        onSelected: (_) => setState(() => _typeFilter = type),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Menampilkan ${logs.length} dari ${allLogs.length} log terbaru',
                      style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint),
                    ),
                  ),
                  if (allLogs.isNotEmpty)
                    TextButton.icon(
                      onPressed: () async {
                        final ok = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Bersihkan log?'),
                            content: const Text('Semua log aktivitas akan dihapus. Tindakan ini tidak bisa dibatalkan.'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                            ],
                          ),
                        );
                        if (ok == true) {
                          await ref.read(activityLogRepoProvider).clear();
                          if (mounted) setState(() {});
                        }
                      },
                      icon: const Icon(Icons.delete_sweep_rounded),
                      label: const Text('Bersihkan'),
                    ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: logs.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 64, height: 64,
                        decoration: BoxDecoration(
                          color: const Color(0xFFB7EFCE),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Icon(Icons.history_rounded, color: AppColors.primary, size: 32),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        allLogs.isEmpty ? 'Belum ada log aktivitas' : 'Tidak ada log yang cocok',
                        style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.onSurface),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        allLogs.isEmpty ? 'Setiap perubahan data akan dicatat di sini.' : 'Coba ubah kata kunci atau filter jenis aktivitas.',
                        style: GoogleFonts.poppins(fontSize: 13, color: AppColors.hint),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              : Builder(builder: (context) {
                  final visible = paginate(logs);
                  final more = hasMore(logs);
                  return ListView.separated(
                    controller: paginatedScrollController,
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                    itemCount: visible.length + (more ? 1 : 0),
                    separatorBuilder: (_, __) => const SizedBox(height: 6),
                    itemBuilder: (context, i) {
                      if (i == visible.length) {
                        return Center(
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Text(
                              'Gulir untuk muat ${logs.length - visible.length} log lainnya...',
                              style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint),
                            ),
                          ),
                        );
                      }
                      final l = visible[i];
                      final (icon, color) = _iconFor(l.type);
                      return Material(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(12),
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: () => _showDetail(context, l),
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: const Color(0xFFDEEBD8), width: 1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                            child: Row(
                              children: [
                                Container(
                                  width: 36, height: 36,
                                  decoration: BoxDecoration(
                                    color: color.withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Icon(icon, color: color, size: 18),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(_labelFor(l.type), style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.onSurface)),
                                      const SizedBox(height: 2),
                                      Text(
                                        l.newJson.isEmpty ? fmtDateFromEpochDay(l.dateEpochDay) : l.newJson.split('\n').first,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                                      ),
                                    ],
                                  ),
                                ),
                                const Icon(Icons.chevron_right, color: AppColors.hint, size: 18),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                }),
        ),
      ],
    );
  }

  (IconData, Color) _iconFor(String type) {
    switch (type) {
      case 'edit_sale': return (Icons.point_of_sale_rounded, AppColors.positive);
      case 'edit_purchase': return (Icons.shopping_cart_rounded, const Color(0xFF1565C0));
      case 'add_product': return (Icons.inventory_2_rounded, AppColors.primary);
      case 'delete_product': return (Icons.delete_outline_rounded, AppColors.negative);
      case 'stock_adjustment': return (Icons.tune_rounded, AppColors.iconAmber);
      case 'debt_payment': return (Icons.payments_rounded, AppColors.iconBlue);
      case 'switch_role': return (Icons.swap_horiz_rounded, AppColors.iconPurple);
      default: return (Icons.edit_note_rounded, AppColors.hint);
    }
  }

  String _labelFor(String type) {
    switch (type) {
      case 'edit_sale': return 'Edit Penjualan';
      case 'edit_purchase': return 'Edit Pembelian';
      case 'add_product': return 'Tambah Produk';
      case 'delete_product': return 'Hapus Produk';
      case 'stock_adjustment': return 'Penyesuaian Stok';
      case 'debt_payment': return 'Pembayaran Hutang';
      case 'switch_role': return 'Ganti Role';
      default: return type.replaceAll('_', ' ').replaceAllMapped(RegExp(r'(^|\s)([a-z])'), (m) => '${m[1]}${m[2]!.toUpperCase()}');
    }
  }

  void _showDetail(BuildContext context, dynamic l) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(_labelFor(l.type),
          style: GoogleFonts.poppins(fontWeight: FontWeight.w700, fontSize: 16)),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (l.newJson.isNotEmpty) ...[
                Text('Setelah:', style: GoogleFonts.poppins(
                  fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.positive)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEBF3E6),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(l.newJson,
                    style: GoogleFonts.poppins(fontSize: 11, color: AppColors.onSurface)),
                ),
              ],
              if (l.oldJson.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text('Sebelum:', style: GoogleFonts.poppins(
                  fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.negative)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFEBEE),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(l.oldJson,
                    style: GoogleFonts.poppins(fontSize: 11, color: AppColors.onSurface)),
                ),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup')),
        ],
      ),
    );
  }
}
