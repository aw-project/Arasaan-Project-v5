import 'package:flutter/material.dart';
import '../../core/pagination_mixin.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/rejected_item.dart';
import '../../providers.dart';
import '../widgets/empty_state.dart';
import '../widgets/date_range_picker.dart';

class RejectedPage extends ConsumerStatefulWidget {
  const RejectedPage({super.key});

  @override
  ConsumerState<RejectedPage> createState() => _RejectedPageState();
}

class _RejectedPageState extends ConsumerState<RejectedPage> with PaginationMixin {
  DateTimeRange? _range;
  String _filterReason = 'Semua';

  @override
  void initState() {
    super.initState();
    initPagination(pageSize: 40, onLoadMore: () => setState(() {}));
  }

  @override
  void dispose() {
    disposePagination();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(rejectedRepoProvider);
    final allItems = repo.all();

    // Filter
    var filtered = allItems.where((r) {
      if (_range != null) {
        final d = fromEpochDay(r.dateEpochDay);
        if (d.isBefore(_range!.start) || d.isAfter(_range!.end)) return false;
      }
      if (_filterReason != 'Semua' && r.reason != _filterReason) return false;
      return true;
    }).toList();

    // Stats dari filtered
    final totalQtyFiltered = filtered.fold<double>(0.0, (s, r) => s + r.qty);
    final totalLossFiltered = filtered.fold<double>(0.0, (s, r) => s + r.estimatedLoss);

    // Stats bulan ini
    final now = DateTime.now();
    final thisMonth = allItems.where((r) {
      final d = fromEpochDay(r.dateEpochDay);
      return d.year == now.year && d.month == now.month;
    }).toList();
    final lossThisMonth = thisMonth.fold<double>(0.0, (s, r) => s + r.estimatedLoss);
    final qtyThisMonth = thisMonth.fold<double>(0.0, (s, r) => s + r.qty);

    // Breakdown alasan
    final reasonCount = <String, int>{};
    for (final r in allItems) {
      reasonCount[r.reason] = (reasonCount[r.reason] ?? 0) + 1;
    }

    return Stack(
      children: [
        CustomScrollView(
          slivers: [
            // ── Stats header ───────────────────────────────────────────────
            SliverToBoxAdapter(
              child: _StatsHeader(
                lossThisMonth: lossThisMonth,
                qtyThisMonth: qtyThisMonth,
                totalAll: allItems.length,
                reasonCount: reasonCount,
              ),
            ),

            // ── Filter bar ─────────────────────────────────────────────────
            SliverToBoxAdapter(
              child: _FilterBar(
                range: _range,
                filterReason: _filterReason,
                onPickRange: () async {
                  final picked = await pickDateRange(context, initial: _range);
                  setState(() => _range = picked);
                },
                onClearRange: () => setState(() => _range = null),
                onReasonChanged: (v) => setState(() => _filterReason = v),
              ),
            ),

            // ── Filtered summary ───────────────────────────────────────────
            if (_range != null || _filterReason != 'Semua')
              SliverToBoxAdapter(
                child: _FilterSummaryBanner(
                  count: filtered.length,
                  totalQty: totalQtyFiltered,
                  totalLoss: totalLossFiltered,
                ),
              ),

            // ── List ───────────────────────────────────────────────────────
            filtered.isEmpty
                ? SliverFillRemaining(
                    child: EmptyState(
                      icon: Icons.check_circle_outline_rounded,
                      title: allItems.isEmpty
                          ? 'Belum ada barang rejek'
                          : 'Tidak ada data yang cocok',
                      subtitle: allItems.isEmpty
                          ? 'Catat barang yang rusak, kadaluarsa, atau diretur agar stok selalu akurat.'
                          : 'Coba ubah filter tanggal atau alasan.',
                    ),
                  )
                : SliverPadding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                    sliver: SliverList.separated(
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 10),
                      itemCount: paginate(filtered).length,
                      itemBuilder: (context, i) {
                        final visible = paginate(filtered);
                        final item = visible[i];
                        final product = ref
                            .read(productRepoProvider)
                            .getById(item.productId);
                        return Dismissible(
                          key: ValueKey(item.id),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 20),
                            decoration: BoxDecoration(
                              color: AppColors.negative,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Icon(Icons.delete_rounded,
                                color: Colors.white, size: 24),
                          ),
                          confirmDismiss: (_) async {
                            return await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('Hapus Barang Rejek?'),
                                content: const Text(
                                    'Stok akan dikembalikan dan kerugian dibatalkan.'),
                                actions: [
                                  TextButton(
                                      onPressed: () =>
                                          Navigator.pop(context, false),
                                      child: const Text('Batal')),
                                  FilledButton(
                                      onPressed: () =>
                                          Navigator.pop(context, true),
                                      child: const Text('Hapus')),
                                ],
                              ),
                            ) ??
                                false;
                          },
                          onDismissed: (_) => _confirmDelete(item),
                          child: _RejectedCard(
                            item: item,
                            productName: product?.name ?? '(produk dihapus)',
                            productUnit: product?.unit ?? '',
                            onDelete: () => _confirmDelete(item),
                          ),
                        );
                      },
                    ),
                  ),
          ],
        ),

        // ── FAB ────────────────────────────────────────────────────────────
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton.extended(
            onPressed: _openForm,
            icon: const Icon(Icons.add_rounded),
            label: Text('Tambah', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );
  }

  Future<void> _openForm() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _RejectedForm(
        onSave: (item) async {
          try {
            await ref.read(rejectedRepoProvider).add(item);
            await ref
                .read(activityLogRepoProvider)
                .log('rejected_add', 'Barang rejek dicatat: ${item.id}');
            if (mounted) {
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Barang rejek berhasil dicatat.')),
              );
            }
          } catch (e) {
            if (mounted) {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('Gagal: $e')));
            }
          }
        },
      ),
    );
  }

  Future<void> _confirmDelete(RejectedItem item) async {
    final product =
        ref.read(productRepoProvider).getById(item.productId);
    final name = product?.name ?? 'produk ini';
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus catatan rejek?'),
        content: Text(
            'Stok $name akan dikembalikan sebanyak ${_fmtQty(item.qty)} ${product?.unit ?? ''}.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Batal')),
          FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: AppColors.negative),
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Hapus')),
        ],
      ),
    );
    if (ok == true) {
      await ref.read(rejectedRepoProvider).remove(item.id);
      await ref
          .read(activityLogRepoProvider)
          .log('rejected_delete', 'Catatan rejek dihapus: ${item.id}');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Catatan dihapus, stok dikembalikan.')));
      }
    }
  }
}

// ─── Stats Header ─────────────────────────────────────────────────────────────

class _StatsHeader extends StatelessWidget {
  final double lossThisMonth;
  final double qtyThisMonth;
  final int totalAll;
  final Map<String, int> reasonCount;

  const _StatsHeader({
    required this.lossThisMonth,
    required this.qtyThisMonth,
    required this.totalAll,
    required this.reasonCount,
  });

  @override
  Widget build(BuildContext context) {
    final topReason = reasonCount.entries.isNotEmpty
        ? (reasonCount.entries.toList()
              ..sort((a, b) => b.value.compareTo(a.value)))
            .first
            .key
        : '-';

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF7B1818), Color(0xFFB83232)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Barang Rejek & Rusak',
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.85),
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _HeaderStat(
                  label: 'Kerugian Bulan Ini',
                  value: fmtMoney(lossThisMonth),
                  icon: Icons.trending_down_rounded,
                ),
              ),
              Container(
                width: 1,
                height: 44,
                color: Colors.white.withOpacity(0.2),
                margin: const EdgeInsets.symmetric(horizontal: 14),
              ),
              Expanded(
                child: _HeaderStat(
                  label: 'Qty Bulan Ini',
                  value: '${_fmtQty(qtyThisMonth)} item',
                  icon: Icons.inventory_2_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _StatChip(
                label: 'Total Catatan',
                value: '$totalAll',
                icon: Icons.list_alt_rounded,
              ),
              const SizedBox(width: 8),
              _StatChip(
                label: 'Alasan Terbanyak',
                value: topReason,
                icon: Icons.flag_rounded,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeaderStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _HeaderStat(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Colors.white.withOpacity(0.7), size: 13),
            const SizedBox(width: 4),
            Text(label,
                style: GoogleFonts.poppins(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 11,
                    fontWeight: FontWeight.w500)),
          ],
        ),
        const SizedBox(height: 3),
        Text(value,
            style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3),
            maxLines: 1,
            overflow: TextOverflow.ellipsis),
      ],
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _StatChip(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white.withOpacity(0.8), size: 13),
          const SizedBox(width: 5),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: GoogleFonts.poppins(
                      color: Colors.white.withOpacity(0.65),
                      fontSize: 9,
                      fontWeight: FontWeight.w500)),
              Text(value,
                  style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Filter Bar ───────────────────────────────────────────────────────────────

class _FilterBar extends StatelessWidget {
  final DateTimeRange? range;
  final String filterReason;
  final VoidCallback onPickRange;
  final VoidCallback onClearRange;
  final ValueChanged<String> onReasonChanged;

  const _FilterBar({
    required this.range,
    required this.filterReason,
    required this.onPickRange,
    required this.onClearRange,
    required this.onReasonChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Date filter
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: onPickRange,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceDim,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: range != null
                              ? const Color(0xFFB83232)
                              : const Color(0xFFCCD9C6)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today_rounded,
                            size: 15,
                            color: range != null
                                ? const Color(0xFFB83232)
                                : AppColors.hint),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            range == null
                                ? 'Semua tanggal'
                                : '${fmtDate(range!.start)}  –  ${fmtDate(range!.end)}',
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: range != null
                                  ? const Color(0xFFB83232)
                                  : AppColors.hint,
                            ),
                          ),
                        ),
                        if (range != null)
                          GestureDetector(
                            onTap: onClearRange,
                            child: const Icon(Icons.close_rounded,
                                size: 16, color: AppColors.hint),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Reason filter chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['Semua', ...RejectedItem.reasons].map((r) {
                final sel = filterReason == r;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () => onReasonChanged(r),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: sel
                            ? const Color(0xFFB83232)
                            : AppColors.surfaceVariant,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        r,
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: sel ? Colors.white : AppColors.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Filter Summary Banner ────────────────────────────────────────────────────

class _FilterSummaryBanner extends StatelessWidget {
  final int count;
  final double totalQty;
  final double totalLoss;

  const _FilterSummaryBanner(
      {required this.count,
      required this.totalQty,
      required this.totalLoss});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3F3),
        borderRadius: BorderRadius.circular(12),
        border:
            Border.all(color: const Color(0xFFFFCDD2), width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.filter_list_rounded,
              size: 16, color: Color(0xFFB83232)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '$count catatan  •  ${_fmtQty(totalQty)} item  •  Rugi ${fmtMoney(totalLoss)}',
              style: GoogleFonts.poppins(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF7B1818),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Rejected Card ────────────────────────────────────────────────────────────

class _RejectedCard extends StatelessWidget {
  final RejectedItem item;
  final String productName;
  final String productUnit;
  final VoidCallback onDelete;

  const _RejectedCard({
    required this.item,
    required this.productName,
    required this.productUnit,
    required this.onDelete,
  });

  static const _reasonColors = <String, Color>{
    'Kadaluarsa': Color(0xFF7B1818),
    'Rusak/Cacat': Color(0xFFB83232),
    'Retur Pelanggan': Color(0xFF1565C0),
    'Retur Supplier': Color(0xFF6A1B9A),
    'Lainnya': Color(0xFF546E7A),
  };

  static const _handlingIcons = <String, IconData>{
    'Dibuang': Icons.delete_outline_rounded,
    'Dikembalikan ke Supplier': Icons.undo_rounded,
    'Dijual Diskon': Icons.sell_rounded,
    'Diproses Ulang': Icons.autorenew_rounded,
    'Lainnya': Icons.more_horiz_rounded,
  };

  @override
  Widget build(BuildContext context) {
    final rc = _reasonColors[item.reason] ?? const Color(0xFF546E7A);
    final hi = _handlingIcons[item.handling] ?? Icons.more_horiz_rounded;

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFCDD2), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          // ── Header row ─────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 8, 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: rc.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(Icons.remove_shopping_cart_rounded,
                      color: rc, size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        productName,
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.onSurface,
                        ),
                      ),
                      Text(
                        fmtDateFromEpochDay(item.dateEpochDay),
                        style: GoogleFonts.poppins(
                            fontSize: 11, color: AppColors.hint),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded,
                      size: 18),
                  color: AppColors.hint,
                  visualDensity: VisualDensity.compact,
                  onPressed: onDelete,
                ),
              ],
            ),
          ),

          // ── Badges row ─────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 0),
            child: Row(
              children: [
                _Badge(
                  label: item.reason,
                  color: rc,
                  icon: Icons.flag_rounded,
                ),
                const SizedBox(width: 6),
                _Badge(
                  label: item.handling,
                  color: const Color(0xFF37474F),
                  icon: hi,
                ),
              ],
            ),
          ),

          if (item.note.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
              child: Row(
                children: [
                  const Icon(Icons.notes_rounded,
                      size: 13, color: AppColors.hint),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      item.note,
                      style: GoogleFonts.poppins(
                          fontSize: 11, color: AppColors.hint),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 10),
          Container(
            height: 1,
            color: const Color(0xFFFFEEEE),
          ),

          // ── Bottom stats ───────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                _RejKV(
                  label: 'Jumlah Rejek',
                  value:
                      '${_fmtQty(item.qty)} $productUnit',
                ),
                _RejKV(
                  label: 'HPP Saat Itu',
                  value: fmtMoney(item.hppAtTime),
                ),
                _RejKV(
                  label: 'Est. Kerugian',
                  value: fmtMoney(item.estimatedLoss),
                  valueColor: const Color(0xFFB83232),
                  bold: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;
  const _Badge(
      {required this.label, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _RejKV extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final bool bold;
  const _RejKV(
      {required this.label,
      required this.value,
      this.valueColor,
      this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style:
                  GoogleFonts.poppins(fontSize: 10, color: AppColors.hint)),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight:
                  bold ? FontWeight.w700 : FontWeight.w600,
              color: valueColor ?? AppColors.onSurface,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ─── Rejected Form (bottom sheet) ─────────────────────────────────────────────

class _RejectedForm extends ConsumerStatefulWidget {
  final Future<void> Function(RejectedItem) onSave;
  const _RejectedForm({required this.onSave});

  @override
  ConsumerState<_RejectedForm> createState() => _RejectedFormState();
}

class _RejectedFormState extends ConsumerState<_RejectedForm> {
  final _formKey = GlobalKey<FormState>();
  DateTime _date = DateTime.now();
  String? _productId;
  final _qtyC = TextEditingController();
  String _reason = RejectedItem.reasons.first;
  String _handling = RejectedItem.handlings.first;
  final _noteC = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _qtyC.dispose();
    _noteC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productRepoProvider).all();
    final selectedProduct =
        _productId != null ? ref.read(productRepoProvider).getById(_productId!) : null;
    final estLoss = selectedProduct != null && _qtyC.text.isNotEmpty
        ? (double.tryParse(_qtyC.text) ?? 0.0) * selectedProduct.avgHpp
        : 0.0;

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 8,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: AppColors.hint.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),

              // Title
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFEBEB),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.remove_shopping_cart_rounded,
                        color: Color(0xFFB83232), size: 18),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Catat Barang Rejek',
                    style: GoogleFonts.poppins(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.onSurface,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Date
              _FormLabel('Tanggal'),
              const SizedBox(height: 6),
              InkWell(
                onTap: () async {
                  final d = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                  if (d != null) setState(() => _date = d);
                },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceDim,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: const Color(0xFFCCD9C6)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.calendar_today_rounded,
                          size: 16, color: AppColors.primary),
                      const SizedBox(width: 10),
                      Text(
                        fmtDate(_date),
                        style: GoogleFonts.poppins(
                            fontSize: 14, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Product
              _FormLabel('Produk *'),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _productId,
                decoration: const InputDecoration(
                    hintText: 'Pilih produk...'),
                items: products
                    .map((p) => DropdownMenuItem(
                          value: p.id,
                          child: Text(
                              '${p.name} (Stok: ${_fmtQty(p.stockQty)} ${p.unit})'),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _productId = v),
                validator: (v) =>
                    v == null ? 'Pilih produk terlebih dahulu.' : null,
              ),
              const SizedBox(height: 14),

              // Qty
              _FormLabel('Jumlah yang Direjek *'),
              const SizedBox(height: 6),
              TextFormField(
                controller: _qtyC,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Jumlah'),
                onChanged: (_) => setState(() {}),
                validator: (v) {
                  final n = double.tryParse(v ?? '');
                  if (n == null || n <= 0) return 'Masukkan jumlah yang valid.';
                  if (selectedProduct != null && n > selectedProduct.stockQty) {
                    return 'Melebihi stok tersedia (${_fmtQty(selectedProduct.stockQty)}).';
                  }
                  return null;
                },
              ),

              // Estimasi kerugian preview
              if (_productId != null &&
                  _qtyC.text.isNotEmpty &&
                  (double.tryParse(_qtyC.text) ?? 0.0) > 0) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF3F3),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: const Color(0xFFFFCDD2)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline_rounded,
                          size: 15,
                          color: Color(0xFFB83232)),
                      const SizedBox(width: 8),
                      Text(
                        'Estimasi Kerugian: ${fmtMoney(estLoss)}',
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFF7B1818),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 14),

              // Reason
              _FormLabel('Alasan Penolakan *'),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _reason,
                decoration:
                    const InputDecoration(hintText: 'Pilih alasan...'),
                items: RejectedItem.reasons
                    .map((r) =>
                        DropdownMenuItem(value: r, child: Text(r)))
                    .toList(),
                onChanged: (v) =>
                    setState(() => _reason = v ?? _reason),
              ),
              const SizedBox(height: 14),

              // Handling
              _FormLabel('Penanganan Barang *'),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _handling,
                decoration: const InputDecoration(
                    hintText: 'Pilih penanganan...'),
                items: RejectedItem.handlings
                    .map((h) =>
                        DropdownMenuItem(value: h, child: Text(h)))
                    .toList(),
                onChanged: (v) =>
                    setState(() => _handling = v ?? _handling),
              ),
              const SizedBox(height: 14),

              // Note
              _FormLabel('Catatan (opsional)'),
              const SizedBox(height: 6),
              TextFormField(
                controller: _noteC,
                decoration: const InputDecoration(
                  hintText: 'Misal: batch expired Jan 2025, kena air...',
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 20),

              // Save button
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFB83232),
                    padding:
                        const EdgeInsets.symmetric(vertical: 14),
                  ),
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white))
                      : const Icon(Icons.save_rounded),
                  label: Text(
                    _saving ? 'Menyimpan...' : 'Simpan Barang Rejek',
                    style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w700,
                        fontSize: 15),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final product = ref.read(productRepoProvider).getById(_productId!);
    if (product == null) return;

    final qty = double.parse(_qtyC.text);
    final loss = qty * product.avgHpp;

    if (!mounted) return;
    setState(() => _saving = true);

    final item = RejectedItem(
      id: newId('rej'),
      dateEpochDay: epochDay(_date),
      productId: _productId!,
      qty: qty,
      reason: _reason,
      handling: _handling,
      note: _noteC.text.trim(),
      hppAtTime: product.avgHpp,
      estimatedLoss: loss,
    );

    try {
      await widget.onSave(item);
    } finally {
      // onSave may pop this widget — only setState if still mounted
      if (mounted) setState(() => _saving = false);
    }
  }
}

class _FormLabel extends StatelessWidget {
  final String text;
  const _FormLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: GoogleFonts.poppins(
        fontSize: 13,
        fontWeight: FontWeight.w600,
        color: AppColors.onSurfaceVariant,
      ),
    );
  }
}

String _fmtQty(num n) {
  final s = n.toStringAsFixed(2);
  return s.replaceAll(RegExp(r'\.00$'), '').replaceAll(RegExp(r'(\.[0-9])0$'), r'$1');
}
