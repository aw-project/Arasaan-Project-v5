import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../providers.dart';
import '../widgets/empty_state.dart';

class SuppliersPage extends ConsumerStatefulWidget {
  const SuppliersPage({super.key});

  @override
  ConsumerState<SuppliersPage> createState() => _SuppliersPageState();
}

class _SuppliersPageState extends ConsumerState<SuppliersPage> {
  final searchC = TextEditingController();
  @override
  void dispose() {
    searchC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final purchases = ref.watch(purchaseRepoProvider).all();
    final debts = ref.watch(debtRepoProvider).all();
    final meta = ref.watch(metaRepoProvider);
    final q = searchC.text.trim().toLowerCase();

    final supplierMap = <String, _SupplierStats>{};
    for (final p in purchases) {
      final name = p.supplier.trim();
      if (name.isEmpty) continue;
      final entry = supplierMap.putIfAbsent(name, () => _SupplierStats(name: name));
      entry.purchaseCount += 1;
      entry.totalSpend += p.items.fold<double>(0, (sum, item) => sum + (item.qty * item.buyPrice));
      if (entry.lastEpochDay == null || p.dateEpochDay > entry.lastEpochDay!) {
        entry.lastEpochDay = p.dateEpochDay;
      }
      for (final item in p.items) {
        entry.totalItems += 1;
        entry.totalQty += item.qty;
      }
    }
    for (final d in debts) {
      final name = d.creditor.trim();
      if (name.isEmpty) continue;
      final entry = supplierMap.putIfAbsent(name, () => _SupplierStats(name: name));
      entry.outstandingDebt += d.remaining;
      entry.totalDebtPrincipal += d.principal;
    }

    final items = supplierMap.values.where((e) {
      if (q.isEmpty) return true;
      return e.name.toLowerCase().contains(q);
    }).toList()
      ..sort((a, b) {
        final favA = meta.favoriteSuppliers.any((s) => s.toLowerCase() == a.name.toLowerCase()) ? 0 : 1;
        final favB = meta.favoriteSuppliers.any((s) => s.toLowerCase() == b.name.toLowerCase()) ? 0 : 1;
        final favCmp = favA.compareTo(favB);
        if (favCmp != 0) return favCmp;
        return b.totalSpend.compareTo(a.totalSpend);
      });

    return Scaffold(
      appBar: AppBar(title: const Text('Supplier')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: Column(
              children: [
                _TopSummary(items: items),
                const SizedBox(height: 12),
                TextField(
                  controller: searchC,
                  decoration: InputDecoration(
                    labelText: 'Cari supplier',
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: searchC.text.isEmpty ? null : IconButton(
                      onPressed: () { searchC.clear(); setState(() {}); },
                      icon: const Icon(Icons.close_rounded),
                    ),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const EmptyState(title: 'Belum ada supplier', subtitle: 'Nama supplier akan muncul otomatis dari data pembelian dan hutang.')
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final s = items[i];
                      final rank = i + 1;
                      final isFav = meta.favoriteSuppliers.any((e) => e.toLowerCase() == s.name.toLowerCase());
                      return Card(
                        child: ListTile(
                          leading: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              CircleAvatar(
                                backgroundColor: isFav ? const Color(0xFFFFF3E0) : AppColors.surfaceVariant,
                                child: Icon(isFav ? Icons.star_rounded : Icons.store_mall_directory_rounded, color: isFav ? AppColors.gold : AppColors.primary),
                              ),
                              Positioned(
                                right: -4, top: -4,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                  decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(10)),
                                  child: Text('#$rank', style: GoogleFonts.poppins(fontSize: 9, fontWeight: FontWeight.w700, color: Colors.white)),
                                ),
                              ),
                            ],
                          ),
                          title: Text(s.name, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                          subtitle: Text(
                            'Pembelian: ${s.purchaseCount}x • Qty: ${s.totalQty.toStringAsFixed(2)} • Terakhir: ${s.lastEpochDay == null ? '-' : fmtDateFromEpochDay(s.lastEpochDay!)}',
                            style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                          ),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(fmtMoney(s.totalSpend), style: GoogleFonts.poppins(fontWeight: FontWeight.w700, fontSize: 12)),
                              const SizedBox(height: 2),
                              Text('Sisa hutang: ${fmtMoney(s.outstandingDebt)}', style: GoogleFonts.poppins(fontSize: 10, color: s.outstandingDebt > 0 ? AppColors.negative : AppColors.hint)),
                            ],
                          ),
                          onTap: () => showModalBottomSheet(
                            context: context,
                            isScrollControlled: true,
                            showDragHandle: true,
                            builder: (_) => _SupplierDetailSheet(stats: s, isFavorite: isFav, onToggleFavorite: () async {
                              await ref.read(metaRepoProvider).toggleFavoriteSupplier(s.name);
                              if (mounted) setState(() {});
                            }),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _SupplierStats {
  final String name;
  int purchaseCount = 0;
  int totalItems = 0;
  double totalQty = 0;
  double totalSpend = 0;
  double outstandingDebt = 0;
  double totalDebtPrincipal = 0;
  int? lastEpochDay;
  _SupplierStats({required this.name});
}

class _TopSummary extends StatelessWidget {
  final List<_SupplierStats> items;
  const _TopSummary({required this.items});

  @override
  Widget build(BuildContext context) {
    final totalSpend = items.fold<double>(0, (s, e) => s + e.totalSpend);
    final totalDebt = items.fold<double>(0, (s, e) => s + e.outstandingDebt);
    final activeDebt = items.where((e) => e.outstandingDebt > 0).length;
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.7,
      children: [
        _InfoCard(title: 'Supplier aktif', value: '${items.length}', color: AppColors.primary),
        _InfoCard(title: 'Total belanja', value: fmtMoney(totalSpend), color: AppColors.iconBlue),
        _InfoCard(title: 'Hutang supplier', value: fmtMoney(totalDebt), color: AppColors.negative),
        _InfoCard(title: 'Supplier tertagih', value: '$activeDebt', color: AppColors.gold),
      ],
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  const _InfoCard({required this.title, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(0.18))),
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(title, style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint)),
        const SizedBox(height: 6),
        Text(value, style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w700, color: color), maxLines: 2, overflow: TextOverflow.ellipsis),
      ]),
    );
  }
}

class _SupplierDetailSheet extends StatelessWidget {
  final _SupplierStats stats;
  final bool isFavorite;
  final VoidCallback onToggleFavorite;
  const _SupplierDetailSheet({required this.stats, required this.isFavorite, required this.onToggleFavorite});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text(stats.name, style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w700))),
              IconButton(onPressed: onToggleFavorite, icon: Icon(isFavorite ? Icons.star_rounded : Icons.star_border_rounded, color: isFavorite ? AppColors.gold : AppColors.hint)),
            ]),
            _detail('Jumlah pembelian', '${stats.purchaseCount} transaksi'),
            _detail('Total belanja', fmtMoney(stats.totalSpend)),
          _detail('Rata-rata per pembelian', stats.purchaseCount == 0 ? fmtMoney(0) : fmtMoney(stats.totalSpend / stats.purchaseCount)),
            _detail('Total item masuk', '${stats.totalItems} item'),
            _detail('Total qty masuk', stats.totalQty.toStringAsFixed(2)),
            _detail('Pokok hutang', fmtMoney(stats.totalDebtPrincipal)),
            _detail('Sisa hutang', fmtMoney(stats.outstandingDebt), emphasize: stats.outstandingDebt > 0),
            _detail('Pembelian terakhir', stats.lastEpochDay == null ? '-' : fmtDateFromEpochDay(stats.lastEpochDay!)),
          ],
        ),
      ),
    );
  }

  Widget _detail(String label, String value, {bool emphasize = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [
      Expanded(child: Text(label, style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint))),
      Text(value, style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: emphasize ? AppColors.negative : AppColors.onSurface)),
    ]),
  );
}
