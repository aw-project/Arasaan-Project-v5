import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/dates.dart';
import '../../core/app_theme.dart';
import '../../providers.dart';
import '../activity/activity_log_page.dart';
import '../reports/reports_page.dart';
import '../restock/restock_page.dart';
import '../products/stock_opname_page.dart';
import '../products/stock_adjustment_page.dart';
import '../products/product_detail_page.dart';
import '../sales/sale_detail_page.dart';

class OperationsToolsPage extends ConsumerStatefulWidget {
  const OperationsToolsPage({super.key});

  @override
  ConsumerState<OperationsToolsPage> createState() => _OperationsToolsPageState();
}

class _OperationsToolsPageState extends ConsumerState<OperationsToolsPage> {
  final searchC = TextEditingController();

  @override
  void dispose() {
    searchC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productRepoProvider).all()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    final sales = ref.watch(salesRepoProvider).all();
    final movements = ref.watch(movementRepoProvider).all();

    final q = searchC.text.trim().toLowerCase();
    final lowStock = products.where((p) => p.minStock > 0 && p.stockQty <= p.minStock).take(12).toList();
    final productMatches = products.where((p) {
      if (q.isEmpty) return false;
      return p.name.toLowerCase().contains(q) ||
          p.sku.toLowerCase().contains(q) ||
          p.category.toLowerCase().contains(q);
    }).take(8).toList();
    final saleMatches = sales.where((s) {
      if (q.isEmpty) return false;
      return s.id.toLowerCase().contains(q) ||
          s.customerName.toLowerCase().contains(q) ||
          s.paymentMethod.toLowerCase().contains(q);
    }).take(8).toList();
    final recentMovements = movements.take(12).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Tools Operasional')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: searchC,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              labelText: 'Cari produk, SKU, kategori, pelanggan, atau ID transaksi',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: q.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () {
                        searchC.clear();
                        setState(() {});
                      },
                      icon: const Icon(Icons.close_rounded),
                    ),
            ),
          ),
          const SizedBox(height: 16),
          _SectionTitle('Shortcut Cepat'),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.9,
            children: [
              _ActionCard(
                icon: Icons.fact_check_outlined,
                title: 'Stok Opname',
                subtitle: 'Cek stok massal',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StockOpnamePage())),
              ),
              _ActionCard(
                icon: Icons.shopping_basket_rounded,
                title: 'Saran Belanja',
                subtitle: 'Lihat restock',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RestockPage())),
              ),
              _ActionCard(
                icon: Icons.receipt_long_rounded,
                title: 'Laporan',
                subtitle: 'Audit transaksi',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const Scaffold(body: ReportsPage()))),
              ),
              _ActionCard(
                icon: Icons.history_rounded,
                title: 'Log Aktivitas',
                subtitle: 'Jejak perubahan',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ActivityLogPage())),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _SectionTitle('Produk Perlu Tindakan'),
          const SizedBox(height: 10),
          if (lowStock.isEmpty)
            const _HintCard(text: 'Tidak ada stok kritis. Semua produk masih aman.')
          else
            ...lowStock.map((p) => Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.surfaceVariant,
                      child: const Icon(Icons.inventory_2_outlined, color: AppColors.primary),
                    ),
                    title: Text(p.name),
                    subtitle: Text('Stok ${p.stockQty.toStringAsFixed(2)} ${p.unit} • Min ${p.minStock.toStringAsFixed(2)}'),
                    trailing: Wrap(
                      spacing: 8,
                      children: [
                        IconButton(
                          tooltip: 'Detail produk',
                          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id))),
                          icon: const Icon(Icons.open_in_new_rounded),
                        ),
                        IconButton(
                          tooltip: 'Adjust stok',
                          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StockAdjustmentPage(productId: p.id))),
                          icon: const Icon(Icons.tune_rounded),
                        ),
                      ],
                    ),
                  ),
                )),
          const SizedBox(height: 20),
          if (q.isNotEmpty) ...[
            _SectionTitle('Hasil Pencarian'),
            const SizedBox(height: 10),
            if (productMatches.isEmpty && saleMatches.isEmpty)
              const _HintCard(text: 'Tidak ada hasil yang cocok.')
            else ...[
              if (productMatches.isNotEmpty)
                _ResultGroup(
                  title: 'Produk',
                  child: Column(
                    children: productMatches
                        .map((p) => ListTile(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.sell_outlined),
                              title: Text(p.name),
                              subtitle: Text('${p.category.isEmpty ? 'Tanpa kategori' : p.category} • SKU ${p.sku.isEmpty ? '-' : p.sku}'),
                              trailing: Text('${p.stockQty.toStringAsFixed(2)} ${p.unit}'),
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id))),
                            ))
                        .toList(),
                  ),
                ),
              if (saleMatches.isNotEmpty)
                _ResultGroup(
                  title: 'Transaksi',
                  child: Column(
                    children: saleMatches
                        .map((s) => ListTile(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.receipt_long_rounded),
                              title: Text(s.customerName.isEmpty ? 'Transaksi ${s.id}' : s.customerName),
                              subtitle: Text('${fmtDateFromEpochDay(s.dateEpochDay)} • ${s.paymentSummary}'),
                              trailing: Text(fmtMoney(s.totalSales)),
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SaleDetailPage(saleId: s.id))),
                            ))
                        .toList(),
                  ),
                ),
            ],
            const SizedBox(height: 20),
          ],
          _SectionTitle('Riwayat Pergerakan Stok'),
          const SizedBox(height: 10),
          if (recentMovements.isEmpty)
            const _HintCard(text: 'Belum ada riwayat pergerakan stok.')
          else
            ...recentMovements.map((m) {
              final p = products.firstWhere(
                (e) => e.id == m.productId,
                orElse: () => products.isEmpty ? throw StateError('') : products.first,
              );
              final label = switch (m.type) {
                'purchase' => 'Pembelian',
                'sale' => 'Penjualan',
                'adjust' => 'Adjustment',
                _ => m.type,
              };
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: m.qtyDelta >= 0 ? Colors.green.shade50 : Colors.red.shade50,
                    child: Icon(m.qtyDelta >= 0 ? Icons.south_west_rounded : Icons.north_east_rounded,
                        color: m.qtyDelta >= 0 ? Colors.green : Colors.red),
                  ),
                  title: Text(p.name),
                  subtitle: Text('$label • ${fmtDateFromEpochDay(m.dateEpochDay)}${m.note.isEmpty ? '' : ' • ${m.note}'}'),
                  trailing: Text(
                    '${m.qtyDelta >= 0 ? '+' : ''}${m.qtyDelta.toStringAsFixed(2)} ${p.unit}',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: m.qtyDelta >= 0 ? Colors.green.shade700 : Colors.red.shade700,
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700));
  }
}

class _HintCard extends StatelessWidget {
  final String text;
  const _HintCard({required this.text});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(text),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ActionCard({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Ink(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.35)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              CircleAvatar(backgroundColor: AppColors.primaryContainer, child: Icon(icon, color: AppColors.primary)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: AppColors.hint)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ResultGroup extends StatelessWidget {
  final String title;
  final Widget child;
  const _ResultGroup({required this.title, required this.child});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            child,
          ],
        ),
      ),
    );
  }
}
