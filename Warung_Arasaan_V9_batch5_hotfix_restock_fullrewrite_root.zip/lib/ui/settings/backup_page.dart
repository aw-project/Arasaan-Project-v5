import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../activity/activity_log_page.dart';

class BackupPage extends ConsumerStatefulWidget {
  const BackupPage({super.key});

  @override
  ConsumerState<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends ConsumerState<BackupPage> {
  DateTime start = DateTime.now().subtract(const Duration(days: 6));
  DateTime end = DateTime.now();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final svc = ref.watch(backupServiceProvider);
    final settingsRepo = ref.watch(settingsRepoProvider);
    final settings = settingsRepo.get();
    final meta = ref.watch(metaRepoProvider);
    final products = ref.watch(productRepoProvider).all();
    final sales = ref.watch(salesRepoProvider).all();
    final purchases = ref.watch(purchaseRepoProvider).all();
    final debts = ref.watch(debtRepoProvider).all();
    final logs = ref.watch(activityLogRepoProvider).recent(limit: 1000);
    final lowStockCount = products.where((p) => p.minStock > 0 && p.stockQty <= p.minStock).length;
    final noSkuCount = products.where((p) => p.sku.trim().isEmpty).length;
    final activeDebtCount = debts.where((d) => !d.isSettled).length;
    final lastBackupText = meta.lastAutoBackupEpochMs > 0
        ? fmtDate(DateTime.fromMillisecondsSinceEpoch(meta.lastAutoBackupEpochMs))
        : 'Belum pernah';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Keamanan & Kesehatan Sistem', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _miniStat('Role aktif', meta.role == 'admin' ? 'Admin' : 'Kasir'),
                    _miniStat('PIN', settings.pinEnabled ? 'Aktif' : 'Off'),
                    _miniStat('Auto backup', meta.autoBackupEnabled ? '${meta.autoBackupDays} hari' : 'Off'),
                    _miniStat('Backup terakhir', lastBackupText),
                    _miniStat('Hold cart', '${meta.heldSalesCarts.length}'),
                    _miniStat('Pelanggan recent', '${meta.recentCustomers.length}'),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: _statusRow('Produk', '${products.length} item', Icons.inventory_2_outlined)),
                    const SizedBox(width: 12),
                    Expanded(child: _statusRow('Penjualan', '${sales.length} transaksi', Icons.point_of_sale_rounded)),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: _statusRow('Pembelian', '${purchases.length} transaksi', Icons.shopping_cart_outlined)),
                    const SizedBox(width: 12),
                    Expanded(child: _statusRow('Log aktivitas', '${logs.length} entri', Icons.history_rounded)),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Validasi cepat', style: Theme.of(context).textTheme.titleSmall),
                      const SizedBox(height: 8),
                      Text('• Stok menipis: $lowStockCount produk'),
                      Text('• Produk tanpa kode: $noSkuCount produk'),
                      Text('• Hutang aktif: $activeDebtCount catatan'),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ActivityLogPage()),
                      ),
                      icon: const Icon(Icons.history_rounded),
                      label: const Text('Buka Log Aktivitas'),
                    ),
                    OutlinedButton.icon(
                      onPressed: busy
                          ? null
                          : () async {
                              setState(() => busy = true);
                              try {
                                await svc.shareBackup();
                              } finally {
                                if (mounted) setState(() => busy = false);
                              }
                            },
                      icon: const Icon(Icons.backup_outlined),
                      label: const Text('Backup Sekarang'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Auto Backup', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: meta.autoBackupEnabled,
                  title: const Text('Aktifkan auto backup'),
                  subtitle: const Text('Backup otomatis disimpan di penyimpanan app.'),
                  onChanged: (v) async {
                    await ref.read(metaRepoProvider).setAutoBackupEnabled(v);
                    if (mounted) setState(() {});
                  },
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Text('Interval:'),
                    const SizedBox(width: 12),
                    DropdownButton<int>(
                      value: meta.autoBackupDays,
                      items: const [1, 3, 7, 14].map((d) => DropdownMenuItem(value: d, child: Text('$d hari'))).toList(),
                      onChanged: meta.autoBackupEnabled
                          ? (v) async {
                              if (v == null) return;
                              await ref.read(metaRepoProvider).setAutoBackupDays(v);
                              if (mounted) setState(() {});
                            }
                          : null,
                    ),
                    const Spacer(),
                    OutlinedButton(
                      onPressed: meta.autoBackupEnabled
                          ? () async {
                              setState(() => busy = true);
                              final messenger = ScaffoldMessenger.of(context);
                              try {
                                await svc.autoBackupIfDue(meta: ref.read(metaRepoProvider), logs: ref.read(activityLogRepoProvider));
                                if (!mounted) return;
                                messenger.showSnackBar(const SnackBar(content: Text('Auto backup dicek/dijalankan.')));
                              } finally {
                                if (mounted) setState(() => busy = false);
                              }
                            }
                          : null,
                      child: const Text('Jalankan sekarang'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        Card(
          child: ListTile(
            title: const Text('PIN Aplikasi'),
            subtitle: Text(settings.pinEnabled ? 'Aktif' : 'Tidak aktif'),
            trailing: const Icon(Icons.lock),
            onTap: () => _showPinDialog(context),
          ),
        ),
        Card(
          child: ListTile(
            title: const Text('Import Produk dari CSV'),
            subtitle: const Text('Ambil daftar produk dari file CSV (update jika nama sama).'),
            trailing: const Icon(Icons.upload_file),
            onTap: busy
                ? null
                : () async {
                    setState(() => busy = true);
                    final messenger = ScaffoldMessenger.of(context);
                    try {
                      final n = await svc.importProductsFromCsv();
                      if (!mounted) return;
                      messenger.showSnackBar(SnackBar(content: Text('Import selesai: $n baris')));
                    } catch (_) {
                      if (!mounted) return;
                      messenger.showSnackBar(
                        const SnackBar(content: Text('Import gagal. Pastikan format CSV benar.')),
                      );
                    } finally {
                      if (mounted) setState(() => busy = false);
                    }
                  },
          ),
        ),
        Card(
          child: ListTile(
            title: const Text('Buat Backup (.json)'),
            subtitle: const Text('Membuat backup data lalu share ke WhatsApp/Drive, dll.'),
            trailing: const Icon(Icons.share),
            onTap: busy
                ? null
                : () async {
                    setState(() => busy = true);
                    try {
                      await svc.shareBackup();
                    } finally {
                      if (mounted) setState(() => busy = false);
                    }
                  },
          ),
        ),
        Card(
          child: ListTile(
            title: const Text('Restore dari Backup (.json)'),
            subtitle: const Text('Memulihkan data dari file backup (overwrite).'),
            trailing: const Icon(Icons.restore),
            onTap: busy
                ? null
                : () async {
                    setState(() => busy = true);
                    try {
                      await svc.restoreFromPicker();
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Restore selesai')));
                      }
                    } catch (_) {
                      if (mounted) {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(const SnackBar(content: Text('Restore gagal. Pastikan file backup valid.')));
                      }
                    } finally {
                      if (mounted) setState(() => busy = false);
                    }
                  },
          ),
        ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Export Laporan Ringkas CSV', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () async {
                          final p = await showDatePicker(
                            context: context,
                            initialDate: start,
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2100),
                          );
                          if (p != null) setState(() => start = p);
                        },
                        child: InputDecorator(decoration: const InputDecoration(labelText: 'Mulai'), child: Text(fmtDate(start))),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: InkWell(
                        onTap: () async {
                          final p = await showDatePicker(
                            context: context,
                            initialDate: end,
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2100),
                          );
                          if (p != null) setState(() => end = p);
                        },
                        child: InputDecorator(decoration: const InputDecoration(labelText: 'Sampai'), child: Text(fmtDate(end))),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: busy
                      ? null
                      : () async {
                          setState(() => busy = true);
                          try {
                            await svc.shareReportCsv(start: start, end: end);
                          } finally {
                            if (mounted) setState(() => busy = false);
                          }
                        },
                  icon: const Icon(Icons.table_view),
                  label: const Text('Export & Share CSV'),
                ),
                const SizedBox(height: 8),
                Text(
                  'CSV berisi ringkasan per tanggal: omzet, HPP, laba kotor, biaya, laba bersih.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  onPressed: busy
                      ? null
                      : () async {
                          setState(() => busy = true);
                          try {
                            await svc.shareReportDetailCsv(start: start, end: end);
                          } finally {
                            if (mounted) setState(() => busy = false);
                          }
                        },
                  icon: const Icon(Icons.receipt_long),
                  label: const Text('Export & Share CSV (Detail)'),
                ),
                const SizedBox(height: 8),
                Text(
                  'CSV detail berisi baris per item: pembelian, penjualan (dengan HPP & laba), dan biaya.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _miniStat(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 2),
          Text(value, style: Theme.of(context).textTheme.labelLarge),
        ],
      ),
    );
  }

  Widget _statusRow(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 2),
                Text(value, style: Theme.of(context).textTheme.labelLarge),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showPinDialog(BuildContext context) async {
    final repo = ref.read(settingsRepoProvider);
    final s = repo.get();
    final pin1 = TextEditingController();
    final pin2 = TextEditingController();

    await showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('PIN Aplikasi'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(s.pinEnabled ? 'PIN saat ini aktif.' : 'PIN belum aktif.'),
              const SizedBox(height: 12),
              TextField(
                controller: pin1,
                keyboardType: TextInputType.number,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'PIN baru', border: OutlineInputBorder()),
                maxLength: 8,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: pin2,
                keyboardType: TextInputType.number,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Ulangi PIN', border: OutlineInputBorder()),
                maxLength: 8,
              ),
            ],
          ),
          actions: [
            if (s.pinEnabled)
              TextButton(
                onPressed: () async {
                  await repo.disablePin();
                  if (mounted) setState(() {});
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('Matikan PIN'),
              ),
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
            FilledButton(
              onPressed: () async {
                final a = pin1.text.trim();
                final b = pin2.text.trim();
                if (a.isEmpty || a.length < 4) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(const SnackBar(content: Text('PIN minimal 4 digit')));
                  return;
                }
                if (a != b) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(const SnackBar(content: Text('PIN tidak sama')));
                  return;
                }
                await repo.setPin(a);
                if (mounted) setState(() {});
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Simpan PIN'),
            ),
          ],
        );
      },
    );

    pin1.dispose();
    pin2.dispose();
  }
}
