import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/app_theme.dart';

class SplashScreen extends StatefulWidget {
  final Widget child;
  const SplashScreen({super.key, required this.child});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fade;
  late final Animation<double> _scale;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _scale = Tween<double>(begin: 0.75, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));
    _ctrl.forward();

    Future.delayed(const Duration(milliseconds: 1600), () {
      if (!mounted) return;
      setState(() => _done = true);
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_done) return widget.child;

    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: ScaleTransition(
            scale: _scale,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(32),
                  ),
                  child: const _WarungIcon(size: 120),
                ),
                const SizedBox(height: 28),
                Text(
                  'Warung Arasaan',
                  style: GoogleFonts.poppins(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Manajemen Warung Cerdas',
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    color: Colors.white.withOpacity(0.75),
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 60),
                SizedBox(
                  width: 36,
                  height: 36,
                  child: CircularProgressIndicator(
                    color: AppColors.gold.withOpacity(0.8),
                    strokeWidth: 2.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _WarungIcon extends StatelessWidget {
  final double size;
  const _WarungIcon({required this.size});

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size(size, size), painter: _WarungPainter());
}

class _WarungPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    const gold  = Color(0xFFD4870A);
    const green = Color(0xFFB7EFCE);
    const white = Colors.white;
    const brown = Color(0xFFA07830);

    // Atap
    final roofPath = Path()
      ..moveTo(w * 0.5, h * 0.15)
      ..lineTo(w * 0.08, h * 0.50)
      ..lineTo(w * 0.92, h * 0.50)
      ..close();
    canvas.drawPath(roofPath, Paint()..color = gold);

    // Garis bawah atap
    canvas.drawRect(
      Rect.fromLTWH(w * 0.08, h * 0.48, w * 0.84, h * 0.05),
      Paint()..color = brown,
    );

    // Badan warung
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(w * 0.18, h * 0.53, w * 0.64, h * 0.32),
        const Radius.circular(4),
      ),
      Paint()..color = white,
    );

    // Pintu
    canvas.drawRect(
      Rect.fromLTWH(w * 0.41, h * 0.68, w * 0.18, h * 0.17),
      Paint()..color = green,
    );

    // Jendela kiri & kanan
    for (final dx in [0.22, 0.65]) {
      canvas.drawRect(
        Rect.fromLTWH(w * dx, h * 0.57, w * 0.13, h * 0.11),
        Paint()..color = green,
      );
    }

    // Lantai
    canvas.drawRect(
      Rect.fromLTWH(w * 0.10, h * 0.85, w * 0.80, h * 0.06),
      Paint()..color = brown.withOpacity(0.6),
    );

    // Titik dekorasi atap
    for (final dx in [-0.18, 0.0, 0.18]) {
      canvas.drawCircle(
        Offset(w * (0.5 + dx), h * 0.28),
        w * 0.025,
        Paint()..color = white.withOpacity(0.8),
      );
    }
  }

  @override
  bool shouldRepaint(_) => false;
}
