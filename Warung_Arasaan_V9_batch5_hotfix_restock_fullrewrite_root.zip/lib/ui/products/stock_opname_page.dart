import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/stock_movement.dart';
import '../../providers.dart';

class StockOpnamePage extends ConsumerStatefulWidget {
  const StockOpnamePage({super.key});

  @override
  ConsumerState<StockOpnamePage> createState() => _StockOpnamePageState();
}

class _StockOpnamePageState extends ConsumerState<StockOpnamePage> {
  final noteC = TextEditingController();
  final Map<String, TextEditingController> actualControllers = {};

  @override
  void dispose() {
    noteC.dispose();
    for (final c in actualControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(productRepoProvider);
    final products = repo.all()..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

    for (final p in products) {
      actualControllers.putIfAbsent(p.id, () => TextEditingController(text: p.stockQty.toStringAsFixed(2)));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Stok Opname'),
        actions: [
          IconButton(onPressed: products.isEmpty ? null : () => _save(products), icon: const Icon(Icons.save_outlined), tooltip: 'Simpan opname'),
        ],
      ),
      body: products.isEmpty
          ? const Center(child: Text('Belum ada produk.'))
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(controller: noteC, decoration: const InputDecoration(labelText: 'Catatan opname (opsional)')),
                      const SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: const Color(0xFFF7FAF6), borderRadius: BorderRadius.circular(12)),
                        child: const Text('Masukkan stok aktual. Sistem akan menghitung selisih terhadap stok saat ini lalu membuat movement penyesuaian otomatis.'),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    itemCount: products.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final p = products[i];
                      final c = actualControllers[p.id]!;
                      final actual = double.tryParse(c.text.trim().replaceAll(',', '.')) ?? p.stockQty;
                      final delta = actual - p.stockQty;
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.name, style: Theme.of(context).textTheme.titleMedium),
                              const SizedBox(height: 4),
                              Text('Stok sistem: ${p.stockQty.toStringAsFixed(2)} ${p.unit}'),
                              const SizedBox(height: 8),
                              TextField(
                                controller: c,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                decoration: InputDecoration(labelText: 'Stok aktual (${p.unit})', helperText: 'Selisih: ${delta >= 0 ? '+' : ''}${delta.toStringAsFixed(2)} ${p.unit}'),
                                onChanged: (_) => setState(() {}),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
      floatingActionButton: products.isEmpty ? null : FloatingActionButton.extended(onPressed: () => _save(products), icon: const Icon(Icons.fact_check), label: const Text('Simpan opname')),
    );
  }

  Future<void> _save(List products) async {
    final productRepo = ref.read(productRepoProvider);
    final movementRepo = ref.read(movementRepoProvider);
    final now = DateTime.now();
    int changed = 0;
    for (final p in products) {
      final actual = double.tryParse(actualControllers[p.id]!.text.trim().replaceAll(',', '.'));
      if (actual == null) continue;
      final delta = actual - p.stockQty;
      if (delta.abs() < 0.0001) continue;
      p.stockQty = actual.clamp(0, double.infinity);
      await productRepo.upsert(p);
      await movementRepo.add(
        StockMovement(
          id: newId('mv'),
          dateEpochDay: epochDay(now),
          productId: p.id,
          type: 'adjust',
          qtyDelta: delta,
          note: 'Opname${noteC.text.trim().isNotEmpty ? ' • ${noteC.text.trim()}' : ''}',
        ),
      );
      changed++;
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(changed == 0 ? 'Tidak ada perubahan stok.' : 'Stok opname tersimpan untuk $changed produk.')));
    if (changed > 0) Navigator.pop(context);
  }
}
