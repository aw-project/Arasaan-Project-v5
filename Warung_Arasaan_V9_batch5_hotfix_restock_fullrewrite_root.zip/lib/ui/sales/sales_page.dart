import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/pagination_mixin.dart';
import '../../core/ui_debouncer.dart';
import '../../data/repositories/product_repo.dart';
import '../../data/repositories/sales_repo.dart';
import '../../domain/models/sale.dart';
import '../../providers.dart';
import '../widgets/empty_state.dart';
import 'fast_pos_page.dart';
import 'sale_detail_page.dart';
import 'sale_form.dart';

class SalesPage extends ConsumerStatefulWidget {
  const SalesPage({super.key});

  @override
  ConsumerState<SalesPage> createState() => _SalesPageState();
}

class _SalesPageState extends ConsumerState<SalesPage> with PaginationMixin {
  final qC = TextEditingController();
  final _searchDebouncer = UiDebouncer();
  String _query = '';
  DateTimeRange? range;

  @override
  void initState() {
    super.initState();
    initPagination(pageSize: 30, onLoadMore: () => setState(() {}));
  }

  @override
  void dispose() {
    _searchDebouncer.dispose();
    qC.dispose();
    disposePagination();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(salesRepoProvider);
    final itemsAll = repo.all();
    final productsRepo = ref.watch(productRepoProvider);

    final filtered = itemsAll.where((s) {
      if (range != null) {
        final d = fromEpochDay(s.dateEpochDay);
        final afterStart = !d.isBefore(DateTime(range!.start.year, range!.start.month, range!.start.day));
        final beforeEnd = !d.isAfter(DateTime(range!.end.year, range!.end.month, range!.end.day));
        if (!afterStart || !beforeEnd) return false;
      }
      if (_query.isEmpty) return true;
      if (s.paymentSummary.toLowerCase().contains(_query)) return true;
      if (s.customerName.toLowerCase().contains(_query)) return true;
      for (final it in s.items) {
        final pr = productsRepo.getById(it.productId);
        final name = (pr?.name ?? '').toLowerCase();
        if (name.contains(_query)) return true;
      }
      return false;
    }).toList();

    if (itemsAll.isEmpty) {
      return Stack(
        children: [
          const EmptyState(title: 'Belum ada penjualan', subtitle: 'Catat transaksi penjualan untuk laporan omzet & laba.'),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton.extended(
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                backgroundColor: Colors.transparent,
                builder: (_) => const SaleFormPage(showAsSheet: true),
              ),
              icon: const Icon(Icons.add_rounded),
              label: Text('Tambah', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: qC,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: 'Cari produk atau metode bayar...',
                        suffixIcon: _query.isEmpty
                            ? null
                            : IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  qC.clear();
                                  _searchDebouncer.flush(() => setState(() => _query = ''));
                                },
                              ),
                      ),
                      onChanged: (value) {
                        _searchDebouncer.run(() {
                          if (!mounted) return;
                          setState(() => _query = value.trim().toLowerCase());
                        });
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    tooltip: 'Filter tanggal',
                    icon: Icon(range == null ? Icons.filter_alt_outlined : Icons.filter_alt),
                    onPressed: () async {
                      final picked = await showDateRangePicker(
                        context: context,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                        initialDateRange: range,
                      );
                      setState(() {
                        range = picked;
                        resetPagination();
                      });
                    },
                  ),
                  IconButton(
                    tooltip: 'Fast mode kasir',
                    icon: const Icon(Icons.flash_on),
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FastPosPage())),
                  ),
                ],
              ),
            ),
            if (range != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: Row(
                  children: [
                    Expanded(child: Text('Periode: ${fmtDate(range!.start)} – ${fmtDate(range!.end)}', style: Theme.of(context).textTheme.bodySmall)),
                    TextButton.icon(onPressed: () => setState(() { range = null; resetPagination(); }), icon: const Icon(Icons.close, size: 18), label: const Text('Reset')),
                  ],
                ),
              ),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(child: Padding(padding: EdgeInsets.all(32), child: Text('Tidak ada data yang cocok.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.hint))))
                  : _buildList(filtered, repo, productsRepo),
            ),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              useSafeArea: true,
              backgroundColor: Colors.transparent,
              builder: (_) => const SaleFormPage(showAsSheet: true),
            ),
            icon: const Icon(Icons.add_rounded),
            label: Text('Tambah', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );
  }

  Widget _buildList(List<Sale> filtered, SalesRepo repo, ProductRepo productsRepo) {
    final visible = paginate(filtered);
    final more = hasMore(filtered);
    return ListView.separated(
      controller: paginatedScrollController,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
      itemCount: visible.length + (more ? 1 : 0),
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        if (i == visible.length) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text('Gulir untuk muat lebih banyak...', style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint)),
            ),
          );
        }
        final s = visible[i];
        final totalQty = s.items.fold<double>(0.0, (sum, it) => sum + it.qty);
        final summary = s.items.map((it) {
          final pr = productsRepo.getById(it.productId);
          final name = pr?.name ?? 'Produk';
          final unit = pr?.unit ?? '';
          return '$name ${it.qty.toStringAsFixed(2)} $unit';
        }).join(', ');

        return Dismissible(
          key: ValueKey(s.id),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            decoration: BoxDecoration(color: AppColors.negative, borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.delete_rounded, color: Colors.white, size: 24),
          ),
          confirmDismiss: (_) async {
            return await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Hapus Penjualan?'),
                    content: const Text('Data penjualan ini akan dihapus permanen.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                      FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                    ],
                  ),
                ) ??
                false;
          },
          onDismissed: (_) async {
            final messenger = ScaffoldMessenger.of(context);
            await repo.remove(s.id);
            messenger.showSnackBar(const SnackBar(content: Text('Penjualan dihapus')));
          },
          child: _SaleCard(
            date: fmtDateFromEpochDay(s.dateEpochDay),
            paymentMethod: s.paymentSummary,
            totalSales: s.totalSales,
            grossSales: s.grossSales,
            totalHpp: s.totalHpp,
            totalQty: totalQty,
            discount: s.discountAmount,
            summary: summary,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SaleDetailPage(saleId: s.id))),
            onDelete: () async {
              await repo.remove(s.id);
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Penjualan dihapus')));
            },
          ),
        );
      },
    );
  }
}

class _SaleCard extends StatelessWidget {
  final String date;
  final String paymentMethod;
  final double grossSales;
  final double totalSales;
  final double totalHpp;
  final double totalQty;
  final double discount;
  final String summary;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _SaleCard({
    required this.date,
    required this.paymentMethod,
    required this.grossSales,
    required this.totalSales,
    required this.totalHpp,
    required this.totalQty,
    required this.discount,
    required this.summary,
    required this.onTap,
    required this.onDelete,
  });

  Color get _payColor {
    if (paymentMethod.contains('QRIS')) return const Color(0xFF5E35B1);
    if (paymentMethod.contains('Transfer')) return const Color(0xFF1565C0);
    if (paymentMethod.contains('Hutang')) return const Color(0xFFC62828);
    return const Color(0xFF1A7A50);
  }

  @override
  Widget build(BuildContext context) {
    final laba = totalSales - totalHpp;
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFFDEEBD8), width: 1),
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(color: const Color(0xFFB7EFCE), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.point_of_sale_rounded, color: AppColors.primary, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(date, style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.onSurface)),
                        Text(summary, style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint), maxLines: 1, overflow: TextOverflow.ellipsis),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: _payColor.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                    child: Text(paymentMethod, style: GoogleFonts.poppins(fontSize: 11, fontWeight: FontWeight.w600, color: _payColor)),
                  ),
                  IconButton(icon: const Icon(Icons.delete_outline_rounded, size: 18), color: AppColors.hint, visualDensity: VisualDensity.compact, onPressed: onDelete),
                ],
              ),
              const SizedBox(height: 10),
              const Divider(height: 1),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _KV(label: 'Netto', value: fmtMoney(totalSales), bold: true)),
                  Expanded(child: _KV(label: 'HPP', value: fmtMoney(totalHpp))),
                  Expanded(child: _KV(label: 'Laba', value: fmtMoney(laba), color: laba >= 0 ? AppColors.positive : AppColors.negative)),
                ],
              ),
              if (discount > 0 || grossSales != totalSales) ...[
                const SizedBox(height: 8),
                Text('Bruto ${fmtMoney(grossSales)} • Diskon ${fmtMoney(discount)} • Qty ${totalQty.toStringAsFixed(2)}', style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _KV extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  final Color? color;
  const _KV({required this.label, required this.value, this.bold = false, this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: GoogleFonts.poppins(fontSize: 10, color: AppColors.hint)),
        Text(value, style: GoogleFonts.poppins(fontSize: 12, fontWeight: bold ? FontWeight.w700 : FontWeight.w600, color: color ?? AppColors.onSurface), maxLines: 1, overflow: TextOverflow.ellipsis),
      ],
    );
  }
}
