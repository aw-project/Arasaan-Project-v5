import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../core/unit_utils.dart';
import '../../domain/models/activity_log.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';
import '../../providers.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/money_field.dart';
import '../widgets/number_field.dart';

class SaleFormPage extends ConsumerStatefulWidget {
  final Sale? initial;
  final bool showAsSheet;
  const SaleFormPage({super.key, this.initial, this.showAsSheet = false});

  @override
  ConsumerState<SaleFormPage> createState() => _SaleFormPageState();
}

class _SaleFormPageState extends ConsumerState<SaleFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  String paymentMethod = 'Cash';
  final List<_Row> rows = [_Row()];
  final discountC = TextEditingController();
  final customerC = TextEditingController();
  bool useSplitPayment = false;
  String splitMethod2 = 'QRIS';
  final splitAmount2C = TextEditingController();

  @override
  void initState() {
    super.initState();
    final init = widget.initial;
    if (init != null) {
      date = fromEpochDay(init.dateEpochDay);
      paymentMethod = init.paymentMethod;
      discountC.text = init.discountAmount.toStringAsFixed(0);
      customerC.text = init.customerName;
      rows
        ..clear()
        ..addAll(init.items.map((it) {
          final r = _Row();
          r.productId = it.productId;
          r.qtyC.text = it.qty.toStringAsFixed(2);
          r.sellC.text = it.sellPrice.toStringAsFixed(0);
          return r;
        }));
      final splits = init.normalizedSplits;
      if (splits.length > 1) {
        useSplitPayment = true;
        paymentMethod = splits.first.method;
        splitMethod2 = splits[1].method;
        splitAmount2C.text = splits[1].amount.toStringAsFixed(0);
      }
      if (rows.isEmpty) rows.add(_Row());
    }
  }

  @override
  void dispose() {
    discountC.dispose();
    customerC.dispose();
    splitAmount2C.dispose();
    for (final row in rows) {
      row.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productRepoProvider).all();
    final recentCustomers = ref.watch(metaRepoProvider).recentCustomers;
    final gross = _grossTotal(products);
    final totalHpp = _totalHpp(products);
    final discount = (parseRupiah(discountC.text.trim()) ?? 0).toDouble();
    final net = (gross - discount).clamp(0, double.infinity);
    final splitAmount2 = (parseRupiah(splitAmount2C.text.trim()) ?? 0).toDouble();
    final splitAmount1 = useSplitPayment ? (net - splitAmount2).clamp(0, double.infinity) : net;

    final formContent = Form(
      key: _formKey,
      child: ListView(
        shrinkWrap: widget.showAsSheet,
        physics: widget.showAsSheet ? const NeverScrollableScrollPhysics() : null,
        padding: EdgeInsets.fromLTRB(16, 8, 16, widget.showAsSheet ? MediaQuery.of(context).viewInsets.bottom + 24 : 16),
        children: [
          if (widget.showAsSheet) ...[
            Center(
              child: Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: Colors.grey.withOpacity(0.3), borderRadius: BorderRadius.circular(2)),
              ),
            ),
            Row(children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(color: const Color(0xFFB7EFCE), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.point_of_sale_rounded, color: Color(0xFF0B5E38), size: 18),
              ),
              const SizedBox(width: 10),
              Text(widget.initial == null ? 'Tambah Penjualan' : 'Edit Penjualan', style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 16),
          ],
          DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
          const SizedBox(height: 12),
          TextFormField(
            controller: customerC,
            decoration: const InputDecoration(labelText: 'Pelanggan (opsional)'),
          ),
          if (recentCustomers.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: recentCustomers.take(8).map((name) => ActionChip(
                label: Text(name),
                onPressed: () => setState(() => customerC.text = name),
              )).toList(),
            ),
            const SizedBox(height: 12),
          ] else const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: paymentMethod,
            decoration: const InputDecoration(labelText: 'Metode pembayaran utama'),
            items: const [
              DropdownMenuItem(value: 'Cash', child: Text('Cash')),
              DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
              DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
              DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
            ],
            onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
          ),
          const SizedBox(height: 12),
          if (products.isEmpty) const Text('Belum ada produk. Tambahkan produk dulu di tab Produk.'),
          ...List.generate(rows.length, (i) => _buildRow(products, i)),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => setState(() => rows.add(_Row())),
            icon: const Icon(Icons.add_circle_outline_rounded),
            label: Text('Tambah item', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ),
          const SizedBox(height: 12),
          MoneyField(controller: discountC, label: 'Diskon transaksi', requiredField: false, onChanged: (_) => setState(() {})),
          const SizedBox(height: 8),
          SwitchListTile.adaptive(
            value: useSplitPayment,
            contentPadding: EdgeInsets.zero,
            title: const Text('Split payment'),
            subtitle: const Text('Pisahkan pembayaran ke 2 metode.'),
            onChanged: (v) => setState(() => useSplitPayment = v),
          ),
          if (useSplitPayment) ...[
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: splitMethod2,
                    decoration: const InputDecoration(labelText: 'Metode pembayaran ke-2'),
                    items: const [
                      DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                      DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                      DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                      DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
                    ],
                    onChanged: (v) => setState(() => splitMethod2 = v ?? 'QRIS'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: MoneyField(
                    controller: splitAmount2C,
                    label: 'Nominal metode ke-2',
                    requiredField: false,
                    onChanged: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('Sisa otomatis untuk $paymentMethod: ${fmtMoney(splitAmount1)}', style: Theme.of(context).textTheme.bodySmall),
          ],
          Builder(builder: (_) {
            final laba = net - totalHpp;
            if (gross <= 0) return const SizedBox.shrink();
            return Container(
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFEBF3E6),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFB7EFCE), width: 1),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(child: _PreviewKV(label: 'Bruto', value: fmtMoney(gross), bold: true)),
                      Expanded(child: _PreviewKV(label: 'Diskon', value: fmtMoney(discount))),
                      Expanded(child: _PreviewKV(label: 'Netto', value: fmtMoney(net), bold: true)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: _PreviewKV(label: 'HPP', value: fmtMoney(totalHpp))),
                      Expanded(child: _PreviewKV(label: 'Est. Laba', value: fmtMoney(laba), color: laba >= 0 ? AppColors.positive : AppColors.negative)),
                      Expanded(child: _PreviewKV(label: useSplitPayment ? 'Split' : 'Bayar', value: useSplitPayment ? '${paymentMethod}+${splitMethod2}' : paymentMethod)),
                    ],
                  ),
                ],
              ),
            );
          }),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: products.isEmpty ? null : _save,
            icon: const Icon(Icons.save_rounded),
            label: Text(widget.initial == null ? 'Simpan Penjualan' : 'Simpan Perubahan', style: GoogleFonts.poppins(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
        ],
      ),
    );

    if (widget.showAsSheet) {
      return Container(
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: SingleChildScrollView(child: formContent),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Tambah Penjualan' : 'Edit Penjualan')),
      body: formContent,
    );
  }

  Widget _buildRow(List<Product> products, int i) {
    final r = rows[i];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              initialValue: r.productId,
              decoration: const InputDecoration(labelText: 'Produk'),
              items: products.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(),
              onChanged: (v) {
                setState(() => r.productId = v);
                if (v != null) {
                  final pr = products.firstWhere((x) => x.id == v);
                  r.sellC.text = pr.activeSellPrice.toStringAsFixed(0);
                }
              },
              validator: (v) => (v == null || v.isEmpty) ? 'Pilih produk' : null,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: NumberField(controller: r.qtyC, label: 'Qty', requiredField: true, onChanged: (_) => setState(() {}))),
                const SizedBox(width: 12),
                Expanded(child: MoneyField(controller: r.sellC, label: 'Harga jual /unit', requiredField: true, onChanged: (_) => setState(() {}))),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: rows.length <= 1 ? null : () => setState(() { final row = rows.removeAt(i); row.dispose(); }),
                icon: const Icon(Icons.delete_outline_rounded),
                label: const Text('Hapus item'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  double _grossTotal(List<Product> products) {
    double total = 0;
    for (final r in rows) {
      final qty = normalizeQty(double.tryParse(r.qtyC.text.trim().replaceAll(',', '.')) ?? 0.0);
      final sell = (parseRupiah(r.sellC.text.trim()) ?? 0).toDouble();
      total += qty * sell;
    }
    return total;
  }

  double _totalHpp(List<Product> products) {
    double hpp = 0;
    for (final r in rows) {
      final qty = normalizeQty(double.tryParse(r.qtyC.text.trim().replaceAll(',', '.')) ?? 0.0);
      final matches = r.productId == null ? const <Product>[] : products.where((e) => e.id == r.productId).toList();
      final product = matches.isEmpty ? null : matches.first;
      hpp += qty * (product?.avgHpp ?? 0);
    }
    return hpp;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final products = ref.read(productRepoProvider).all();
    final gross = _grossTotal(products);
    final discount = (parseRupiah(discountC.text.trim()) ?? 0).toDouble();
    if (discount < 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Diskon tidak boleh negatif')));
      return;
    }
    if (discount > gross) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Diskon melebihi total bruto')));
      return;
    }

    final items = <SaleItem>[];
    for (final r in rows) {
      if (r.productId == null) continue;
      final p = products.firstWhere((x) => x.id == r.productId);
      final qty = double.tryParse(r.qtyC.text.trim().replaceAll(',', '.')) ?? 0;
      final sell = (parseRupiah(r.sellC.text.trim()) ?? 0).toDouble();
      items.add(SaleItem(productId: p.id, qty: qty, sellPrice: sell, hppAtSale: p.avgHpp));
    }
    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tambahkan minimal 1 item penjualan.')));
      return;
    }

    final totalNet = gross - discount;
    final splitAmount2 = (parseRupiah(splitAmount2C.text.trim()) ?? 0).toDouble();
    List<PaymentSplit> splits = [];
    if (useSplitPayment) {
      if (splitMethod2 == paymentMethod) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Metode split kedua harus berbeda.')));
        return;
      }
      if (splitAmount2 <= 0 || splitAmount2 >= totalNet) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nominal split kedua harus di antara 0 dan total netto.')));
        return;
      }
      splits = [
        PaymentSplit(method: paymentMethod, amount: totalNet - splitAmount2),
        PaymentSplit(method: splitMethod2, amount: splitAmount2),
      ];
    }

    final sale = Sale(
      id: widget.initial?.id ?? newId('sl'),
      dateEpochDay: epochDay(date),
      items: items,
      paymentMethod: paymentMethod,
      customerName: customerC.text.trim(),
      discountAmount: discount,
      paymentSplits: splits,
    );

    try {
      final repo = ref.read(salesRepoProvider);
      if (widget.initial != null) {
        await repo.remove(widget.initial!.id);
      }
      await repo.add(sale);
      await ref.read(metaRepoProvider).saveRecentCustomer(customerC.text.trim());
      await ref.read(activityLogRepoProvider).add(
            ActivityLog(
              id: newId('log'),
              dateEpochDay: epochDay(DateTime.now()),
              type: widget.initial == null ? 'sale_create' : 'sale_update',
              refId: sale.id,
              oldJson: widget.initial == null ? '' : jsonEncode(widget.initial!.toJson()),
              newJson: jsonEncode(sale.toJson()),
            ),
          );
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Penjualan tersimpan')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
    }
  }
}

class _Row {
  String? productId;
  final qtyC = TextEditingController();
  final sellC = TextEditingController();

  void dispose() {
    qtyC.dispose();
    sellC.dispose();
  }
}

class _PreviewKV extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  final Color? color;
  const _PreviewKV({required this.label, required this.value, this.bold = false, this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodySmall),
        Text(
          value,
          style: GoogleFonts.poppins(fontWeight: bold ? FontWeight.w700 : FontWeight.w600, color: color),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}
