import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/payment_methods.dart';
import '../../providers.dart';
import '../cash/cash_page.dart';
import '../rejected/rejected_page.dart';
import '../analytics/analytics_page.dart';
import '../reports/reports_page.dart';
import '../restock/restock_page.dart';
import '../activity/activity_log_page.dart';
import '../operations/operations_tools_page.dart';
import '../partners/suppliers_page.dart';
import '../partners/customers_page.dart';
import '../debts/debts_page.dart';
import '../expenses/expenses_page.dart';
import '../settings/backup_page.dart';

class MorePage extends ConsumerWidget {
  const MorePage({super.key});

  void _push(BuildContext context, String title, Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: Text(title)),
          body: page,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final role = ref.watch(metaRepoProvider).role;
    final isAdmin = role == 'admin';

    final cashAll = ref.watch(cashRepoProvider).all();
    final saldoKas = cashAll
        .where((e) => PaymentMethods.isCashFlow(e.method))
        .fold<double>(0, (p, e) => p + (e.direction == 'in' ? e.amount : -e.amount));

    final rejectedCount = ref.watch(rejectedRepoProvider).all().length;

    return ListView(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).padding.bottom + 100,
      ),
      children: [
        // ── Primary Hub Cards ──────────────────────────────────────
        if (isAdmin) ...[
          _PrimaryCard(
            icon: Icons.account_balance_wallet_rounded,
            color: AppColors.cardIndigo1,
            title: 'Kas',
            subtitle: 'Saldo  ${fmtMoney(saldoKas)}',
            onTap: () => _push(context, 'Kas', const CashPage()),
          ),
          const SizedBox(height: 10),
          _PrimaryCard(
            icon: Icons.remove_shopping_cart_rounded,
            color: AppColors.iconRejek,
            title: 'Barang Retur',
            subtitle: '$rejectedCount entri tercatat',
            onTap: () => _push(context, 'Barang Retur', const RejectedPage()),
          ),
        ],

        if (isAdmin) ...[
          const SizedBox(height: 28),
          _HubSection(title: 'Laporan & Analisis'),
          const SizedBox(height: 10),
          _HubGrid(
            children: [
              _HubTile(
                icon: Icons.receipt_long_rounded,
                label: 'Laporan',
                color: AppColors.iconGreen,
                onTap: () => _push(context, 'Laporan', const ReportsPage()),
              ),
              _HubTile(
                icon: Icons.insights_rounded,
                label: 'Analytics',
                color: AppColors.iconBlue,
                onTap: () => _push(context, 'Analytics', const AnalyticsPage()),
              ),
              _HubTile(
                icon: Icons.shopping_basket_rounded,
                label: 'Saran Beli',
                color: AppColors.iconRed,
                onTap: () => _push(context, 'Saran Belanja', const RestockPage()),
              ),
              _HubTile(
                icon: Icons.history_rounded,
                label: 'Log',
                color: AppColors.iconPurple,
                onTap: () => _push(context, 'Log Aktivitas', const ActivityLogPage()),
              ),
              _HubTile(
                icon: Icons.build_circle_outlined,
                label: 'Tools',
                color: AppColors.iconAmber,
                onTap: () =>
                    _push(context, 'Tools Operasional', const OperationsToolsPage()),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _HubSection(title: 'Mitra & Keuangan'),
          const SizedBox(height: 10),
          _HubGrid(
            children: [
              _HubTile(
                icon: Icons.local_shipping_rounded,
                label: 'Supplier',
                color: AppColors.iconBlue,
                onTap: () => _push(context, 'Supplier', const SuppliersPage()),
              ),
              _HubTile(
                icon: Icons.people_alt_rounded,
                label: 'Pelanggan',
                color: AppColors.iconPurple,
                onTap: () => _push(context, 'Pelanggan', const CustomersPage()),
              ),
              _HubTile(
                icon: Icons.payments_rounded,
                label: 'Hutang',
                color: AppColors.iconAmber,
                onTap: () => _push(context, 'Hutang', const DebtsPage()),
              ),
              _HubTile(
                icon: Icons.request_quote_rounded,
                label: 'Biaya',
                color: AppColors.iconCrimson,
                onTap: () => _push(context, 'Biaya', const ExpensesPage()),
              ),
              _HubTile(
                icon: Icons.backup_rounded,
                label: 'Backup',
                color: AppColors.iconSlate,
                onTap: () =>
                    _push(context, 'Backup & Restore', const BackupPage()),
              ),
            ],
          ),
        ] else ...[
          const SizedBox(height: 28),
          _HubSection(title: 'Lainnya'),
          const SizedBox(height: 10),
          _HubGrid(
            children: [
              _HubTile(
                icon: Icons.people_alt_rounded,
                label: 'Pelanggan',
                color: AppColors.iconPurple,
                onTap: () => _push(context, 'Pelanggan', const CustomersPage()),
              ),
              _HubTile(
                icon: Icons.receipt_long_rounded,
                label: 'Laporan',
                color: AppColors.iconGreen,
                onTap: () => _push(context, 'Laporan', const ReportsPage()),
              ),
            ],
          ),
        ],
      ],
    );
  }
}

// ─── Primary Card ─────────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _PrimaryCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: color.withOpacity(0.2), width: 1.5),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withOpacity(0.7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        color: AppColors.hint,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: AppColors.hint, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Hub Section Title ────────────────────────────────────────────────────────

class _HubSection extends StatelessWidget {
  final String title;
  const _HubSection({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title.toUpperCase(),
      style: GoogleFonts.poppins(
        fontSize: 10,
        fontWeight: FontWeight.w700,
        color: AppColors.hint,
        letterSpacing: 1.0,
      ),
    );
  }
}

// ─── Hub Grid ─────────────────────────────────────────────────────────────────

class _HubGrid extends StatelessWidget {
  final List<Widget> children;
  const _HubGrid({required this.children});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 4,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 0.88,
      children: children,
    );
  }
}

class _HubTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _HubTile({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(14),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDEEBD8), width: 1),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(height: 6),
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: AppColors.onSurfaceVariant,
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
