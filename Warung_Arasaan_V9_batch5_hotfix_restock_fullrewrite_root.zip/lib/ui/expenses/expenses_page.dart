import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';

import '../../core/ui_debouncer.dart';
import '../../providers.dart';
import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/activity_log.dart';
import '../widgets/empty_state.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/money_field.dart';

class ExpensesPage extends ConsumerStatefulWidget {
  const ExpensesPage({super.key});

  @override
  ConsumerState<ExpensesPage> createState() => _ExpensesPageState();
}

class _ExpensesPageState extends ConsumerState<ExpensesPage> {
  final _qC = TextEditingController();
  final _debouncer = UiDebouncer();
  String _query = '';
  String _selectedCategory = 'Semua';

  @override
  void dispose() {
    _debouncer.dispose();
    _qC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(expenseRepoProvider);
    final meta = ref.watch(metaRepoProvider);
    final all = repo.all();
    final q = _query;
    final categories = ['Semua', ...meta.expenseCategories];

    final filtered = all.where((e) {
      final matchQuery = q.isEmpty ||
          e.note.toLowerCase().contains(q) ||
          e.category.toLowerCase().contains(q);
      final matchCategory = _selectedCategory == 'Semua' || e.category == _selectedCategory;
      return matchQuery && matchCategory;
    }).toList();

    final totalFiltered = filtered.fold<double>(0.0, (s, e) => s + e.amount);
    final totalsByCategory = <String, double>{};
    for (final e in filtered) {
      totalsByCategory[e.category] = (totalsByCategory[e.category] ?? 0) + e.amount;
    }
    final topCategories = totalsByCategory.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Stack(
      children: [
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: TextField(
                controller: _qC,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: 'Cari keterangan / kategori biaya...',
                  suffixIcon: q.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () {
                            _qC.clear();
                            _debouncer.flush(() => setState(() => _query = ''));
                          },
                        ),
                ),
                onChanged: (v) => _debouncer.run(
                    () { if (mounted) setState(() => _query = v.trim().toLowerCase()); }),
              ),
            ),
            if (categories.length > 1)
              SizedBox(
                height: 52,
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (_, i) {
                    final c = categories[i];
                    final selected = c == _selectedCategory;
                    return ChoiceChip(
                      label: Text(c),
                      selected: selected,
                      onSelected: (_) => setState(() => _selectedCategory = c),
                    );
                  },
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemCount: categories.length,
                ),
              ),
            if (filtered.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: AppColors.negative.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.receipt_long_rounded,
                              color: AppColors.negative, size: 16),
                          const SizedBox(width: 8),
                          Text(
                            '${filtered.length} biaya',
                            style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint),
                          ),
                          const Spacer(),
                          Text(
                            'Total: ${fmtMoney(totalFiltered)}',
                            style: GoogleFonts.poppins(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: AppColors.negative),
                          ),
                        ],
                      ),
                      if (topCategories.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: topCategories.take(3).map((entry) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(color: AppColors.negative.withOpacity(0.15)),
                                ),
                                child: Text(
                                  '${entry.key}: ${fmtMoney(entry.value)}',
                                  style: GoogleFonts.poppins(fontSize: 11, fontWeight: FontWeight.w600),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ]
                    ],
                  ),
                ),
              ),
            Expanded(
              child: all.isEmpty
                  ? const EmptyState(
                      title: 'Belum ada biaya',
                      subtitle: 'Catat biaya harian (transport, plastik, dll).',
                    )
                  : filtered.isEmpty
                      ? const Center(
                          child: Text('Tidak ada biaya yang cocok.',
                              style: TextStyle(color: AppColors.hint)))
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(12, 8, 12, 100),
                          itemCount: filtered.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (context, i) {
                            final e = filtered[i];
                            return Dismissible(
                              key: ValueKey(e.id),
                              direction: DismissDirection.endToStart,
                              background: Container(
                                alignment: Alignment.centerRight,
                                padding: const EdgeInsets.only(right: 20),
                                decoration: BoxDecoration(
                                  color: AppColors.negative,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: const Icon(Icons.delete_rounded,
                                    color: Colors.white, size: 24),
                              ),
                              confirmDismiss: (_) => showDialog<bool>(
                                context: context,
      useRootNavigator: true,
                                builder: (_) => AlertDialog(
                                  title: const Text('Hapus Biaya?'),
                                  content: Text('Hapus "${e.note}"?'),
                                  actions: [
                                    TextButton(
                                        onPressed: () => Navigator.pop(context, false),
                                        child: const Text('Batal')),
                                    FilledButton(
                                        onPressed: () => Navigator.pop(context, true),
                                        child: const Text('Hapus')),
                                  ],
                                ),
                              ).then((v) => v ?? false),
                              onDismissed: (_) async {
                                final messenger = ScaffoldMessenger.of(context);
                                await repo.remove(e.id);
                                messenger.showSnackBar(
                                    const SnackBar(content: Text('Biaya dihapus')));
                              },
                              child: _ExpenseCard(
                                expense: e,
                                onTap: () => _openEdit(context, e),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet(
              context: context,
      useRootNavigator: true,
              isScrollControlled: true,
              useSafeArea: true,
              backgroundColor: Colors.transparent,
              builder: (_) => const ExpenseFormPage(showAsSheet: true),
            ),
            icon: const Icon(Icons.add_rounded),
            label: Text('Tambah',
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );
  }

  void _openEdit(BuildContext context, Expense e) {
    showModalBottomSheet(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ExpenseFormPage(initial: e, showAsSheet: true),
    );
  }
}

class _ExpenseCard extends StatelessWidget {
  final Expense expense;
  final VoidCallback onTap;
  const _ExpenseCard({required this.expense, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final e = expense;
    final isTransfer = e.paymentMethod == 'Transfer';
    final payColor = isTransfer ? const Color(0xFF1565C0) : const Color(0xFF1A7A50);
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFFFFCDD2), width: 1),
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: AppColors.negative.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.receipt_long_rounded,
                    color: AppColors.negative, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(e.note,
                        style: GoogleFonts.poppins(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppColors.onSurface),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 3),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(fmtDateFromEpochDay(e.dateEpochDay),
                            style: GoogleFonts.poppins(
                                fontSize: 11, color: AppColors.hint)),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(e.category,
                              style: GoogleFonts.poppins(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.primary)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(fmtMoney(e.amount),
                      style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.negative)),
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: payColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(e.paymentMethod,
                        style: GoogleFonts.poppins(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: payColor)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ExpenseFormPage extends ConsumerStatefulWidget {
  final Expense? initial;
  final bool showAsSheet;
  const ExpenseFormPage({super.key, this.initial, this.showAsSheet = false});

  @override
  ConsumerState<ExpenseFormPage> createState() => _ExpenseFormPageState();
}

class _ExpenseFormPageState extends ConsumerState<ExpenseFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  final noteC = TextEditingController();
  final amountC = TextEditingController();
  String paymentMethod = 'Cash';
  String category = 'Lainnya';

  @override
  void initState() {
    super.initState();
    final init = widget.initial;
    if (init != null) {
      date = fromEpochDay(init.dateEpochDay);
      noteC.text = init.note;
      amountC.text = init.amount.toStringAsFixed(0);
      paymentMethod = init.paymentMethod;
      category = init.category;
    }
  }

  @override
  void dispose() {
    noteC.dispose();
    amountC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final meta = ref.watch(metaRepoProvider);
    final categories = meta.expenseCategories;
    final content = Form(
      key: _formKey,
      child: ListView(
        shrinkWrap: true,
        padding: EdgeInsets.fromLTRB(16, 8, 16,
            MediaQuery.of(context).viewInsets.bottom + 24),
        children: [
          Center(
            child: Container(
              width: 40, height: 4,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFCDD2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.receipt_long_rounded,
                    color: AppColors.negative, size: 18),
              ),
              const SizedBox(width: 10),
              Text(widget.initial == null ? 'Tambah Biaya' : 'Edit Biaya',
                  style: GoogleFonts.poppins(
                      fontSize: 16, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 16),
          DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: paymentMethod,
            decoration: const InputDecoration(labelText: 'Metode pembayaran'),
            items: const [
              DropdownMenuItem(value: 'Cash', child: Text('Cash')),
              DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
            ],
            onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: categories.contains(category) ? category : (categories.isNotEmpty ? categories.first : 'Lainnya'),
            decoration: const InputDecoration(labelText: 'Kategori biaya'),
            items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => category = v ?? 'Lainnya'),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: _addCategory,
              icon: const Icon(Icons.add_circle_outline, size: 18),
              label: const Text('Tambah kategori'),
            ),
          ),
          TextFormField(
            controller: noteC,
            decoration: const InputDecoration(labelText: 'Keterangan'),
            validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
          ),
          const SizedBox(height: 12),
          MoneyField(controller: amountC, label: 'Jumlah biaya', requiredField: true),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: Text(widget.initial == null ? 'Simpan' : 'Simpan Perubahan'),
          ),
        ],
      ),
    );

    if (widget.showAsSheet) {
      return Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: content,
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Tambah Biaya' : 'Edit Biaya')),
      body: content,
    );
  }

  Future<void> _addCategory() async {
    final c = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      useRootNavigator: true,
      builder: (context) => AlertDialog(
        title: const Text('Kategori baru'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Contoh: Plastik / Listrik'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Simpan')),
        ],
      ),
    );
    c.dispose();
    final name = value?.trim() ?? '';
    if (name.isEmpty) return;
    await ref.read(metaRepoProvider).addExpenseCategory(name);
    if (!mounted) return;
    setState(() => category = name);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = (parseRupiah(amountC.text.trim()) ?? 0).toDouble();
    final isEdit = widget.initial != null;
    final id = widget.initial?.id ?? newId('exp');
    final e = Expense(
      id: id,
      dateEpochDay: epochDay(date),
      note: noteC.text.trim(),
      amount: amount,
      paymentMethod: paymentMethod,
      category: category,
    );

    if (isEdit) {
      final old = widget.initial!;
      await ref.read(expenseRepoProvider).remove(old.id);
      await ref.read(expenseRepoProvider).add(e);
      await ref.read(activityLogRepoProvider).add(
            ActivityLog(
              id: newId('log'),
              dateEpochDay: e.dateEpochDay,
              type: 'edit_expense',
              refId: old.id,
              oldJson: jsonEncode(old.toJson()),
              newJson: jsonEncode(e.toJson()),
            ),
          );
    } else {
      await ref.read(expenseRepoProvider).add(e);
    }
    if (!mounted) return;
    Navigator.pop(context);
  }
}
