import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';

import 'package:warung_arasaan/data/db/hive_adapters.dart';
import 'package:warung_arasaan/data/db/hive_boxes.dart';
import 'package:warung_arasaan/data/services/backup_service.dart';
import 'package:warung_arasaan/domain/models/activity_log.dart';
import 'package:warung_arasaan/domain/models/app_settings.dart';
import 'package:warung_arasaan/domain/models/cash_entry.dart';
import 'package:warung_arasaan/domain/models/debt.dart';
import 'package:warung_arasaan/domain/models/expense.dart';
import 'package:warung_arasaan/domain/models/product.dart';
import 'package:warung_arasaan/domain/models/purchase.dart';
import 'package:warung_arasaan/domain/models/sale.dart';
import 'package:warung_arasaan/domain/models/stock_movement.dart';

void main() {
  late HiveInterface hive;
  late Directory tempDir;
  late Box<Product> products;
  late Box<Purchase> purchases;
  late Box<Sale> sales;
  late Box<Expense> expenses;
  late Box<Debt> debts;
  late Box<StockMovement> movements;
  late Box<CashEntry> cash;
  late Box<AppSettings> settings;
  late Box<ActivityLog> activityLogs;
  late Box meta;
  late BackupService service;

  setUp(() async {
    tempDir = await Directory.systemTemp.createTemp('warung_backup_test_');
    hive = Hive..init(tempDir.path);
    registerAdapters();

    products = await hive.openBox<Product>(Boxes.products);
    purchases = await hive.openBox<Purchase>(Boxes.purchases);
    sales = await hive.openBox<Sale>(Boxes.sales);
    expenses = await hive.openBox<Expense>(Boxes.expenses);
    debts = await hive.openBox<Debt>(Boxes.debts);
    movements = await hive.openBox<StockMovement>(Boxes.movements);
    cash = await hive.openBox<CashEntry>(Boxes.cash);
    settings = await hive.openBox<AppSettings>(Boxes.settings);
    activityLogs = await hive.openBox<ActivityLog>(Boxes.activityLogs);
    meta = await hive.openBox(Boxes.meta);

    service = BackupService(
      products: products,
      purchases: purchases,
      sales: sales,
      expenses: expenses,
      debts: debts,
      movements: movements,
      cash: cash,
      settings: settings,
      activityLogs: activityLogs,
      meta: meta,
    );
  });

  tearDown(() async {
    await hive.close();
    if (tempDir.existsSync()) {
      await tempDir.delete(recursive: true);
    }
  });

  test('backup map includes meta and activity logs', () async {
    await products.put(
      'prd-1',
      Product(
        id: 'prd-1',
        name: 'Bayam',
        unit: 'ikat',
        defaultMarginPercent: 10,
        activeSellPrice: 5000,
        stockQty: 2,
        avgHpp: 4000,
        minStock: 1,
        targetStock: 5,
      ),
    );
    await activityLogs.put(
      'log-1',
      ActivityLog(
        id: 'log-1',
        dateEpochDay: 20000,
        type: 'create',
        refId: 'prd-1',
        oldJson: '',
        newJson: 'Bayam',
      ),
    );
    await meta.put('role', 'admin');

    final payload = service.buildBackupMap();

    expect((payload[Boxes.activityLogs] as List).length, 1);
    expect((payload[Boxes.meta] as Map)['role'], 'admin');
  });

  test('restoreFromJson restores new boxes only after payload parses', () async {
    final json = service.buildBackupJson();
    await meta.put('role', 'kasir');
    await service.restoreFromJson(json);
    expect(meta.get('role'), isNull);
  });
}
