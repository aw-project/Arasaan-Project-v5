import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';

import 'package:warung_arasaan/data/db/hive_adapters.dart';
import 'package:warung_arasaan/data/db/hive_boxes.dart';
import 'package:warung_arasaan/data/repositories/sales_repo.dart';
import 'package:warung_arasaan/domain/models/cash_entry.dart';
import 'package:warung_arasaan/domain/models/product.dart';
import 'package:warung_arasaan/domain/models/sale.dart';
import 'package:warung_arasaan/domain/models/stock_movement.dart';

void main() {
  late HiveInterface hive;
  late Directory tempDir;
  late Box<Sale> sales;
  late Box<Product> products;
  late Box<StockMovement> movements;
  late Box<CashEntry> cash;
  late SalesRepo repo;

  setUp(() async {
    tempDir = await Directory.systemTemp.createTemp('warung_sales_test_');
    hive = Hive..init(tempDir.path);
    registerAdapters();
    sales = await hive.openBox<Sale>(Boxes.sales);
    products = await hive.openBox<Product>(Boxes.products);
    movements = await hive.openBox<StockMovement>(Boxes.movements);
    cash = await hive.openBox<CashEntry>(Boxes.cash);
    repo = SalesRepo(sales, products, movements, cash);
  });

  tearDown(() async {
    await hive.close();
    if (tempDir.existsSync()) {
      await tempDir.delete(recursive: true);
    }
  });

  test('sales add rejects insufficient stock without side effects', () async {
    await products.put(
      'prd-1',
      Product(
        id: 'prd-1',
        name: 'Tomat',
        unit: 'kg',
        defaultMarginPercent: 10,
        activeSellPrice: 10000,
        stockQty: 1,
        avgHpp: 8000,
        minStock: 0,
        targetStock: 0,
      ),
    );

    final sale = Sale(
      id: 'sale-1',
      dateEpochDay: 20000,
      paymentMethod: 'Cash',
      items: [
        SaleItem(productId: 'prd-1', qty: 2, sellPrice: 10000, hppAtSale: 8000),
      ],
    );

    await expectLater(repo.add(sale), throwsA(isA<StateError>()));
    expect(sales.values, isEmpty);
    expect(cash.values, isEmpty);
    expect(movements.values, isEmpty);
    expect(products.get('prd-1')!.stockQty, 1);
  });
}
