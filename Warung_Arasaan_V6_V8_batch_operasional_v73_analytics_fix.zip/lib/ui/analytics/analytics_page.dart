import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../core/dates.dart';
import '../../providers.dart';
import '../../data/services/analytics_service.dart';
import '../../domain/models/product.dart';
import 'analytics_product_detail_page.dart';

class AnalyticsPage extends ConsumerStatefulWidget {
  const AnalyticsPage({super.key});

  @override
  ConsumerState<AnalyticsPage> createState() => _AnalyticsPageState();
}

class _AnalyticsPageState extends ConsumerState<AnalyticsPage> {
  DateTime start = DateTime.now().subtract(const Duration(days: 6));
  DateTime end = DateTime.now();

  String? selectedProductId;

  // Step 2 (Performa): cache hasil analitik agar tidak hitung ulang saat tab switch / rebuild kecil.
  String? _cacheKey;
  int _cacheSalesLen = -1;
  int _cacheProductsLen = -1;
  List<ProductKpi> _topSell = const [];
  List<ProductKpi> _topProfit = const [];
  List<(Product product, double marginActual)> _loss = const [];
  List<DayPoint> _globalTrend = const [];
  String? _trendProductId;
  List<DayPoint> _productTrend = const [];
  List<LossProductKpi> _lossByProduct = const [];
  List<ForecastKpi> _forecast = const [];
  List<CategoryKpi> _categories = const [];
  List<PriceTrendKpi> _priceInsights = const [];
  List<PartnerKpi> _topCustomers = const [];
  List<PartnerKpi> _topSuppliers = const [];

  Future<void> _pickRange() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDateRange: DateTimeRange(start: start, end: end),
    );
    if (r != null) {
      setState(() {
        start = DateTime(r.start.year, r.start.month, r.start.day);
        end = DateTime(r.end.year, r.end.month, r.end.day);
      });
    }
  }

  void _quickRange(int days) {
    setState(() {
      end = DateTime.now();
      start = end.subtract(Duration(days: days - 1));
    });
  }

  @override
  Widget build(BuildContext context) {
    final salesBox = ref.watch(salesBoxProvider);
    final purchasesBox = ref.watch(purchasesBoxProvider);
    final productsBox = ref.watch(productsBoxProvider);
    final service = const AnalyticsService();

    final key = '${epochDay(start)}-${epochDay(end)}';
    final salesLen = salesBox.length;
    final productsLen = productsBox.length;

    if (_cacheKey != key || _cacheSalesLen != salesLen || _cacheProductsLen != productsLen) {
      // Recompute only when data/range changes.
      _cacheKey = key;
      _cacheSalesLen = salesLen;
      _cacheProductsLen = productsLen;

      _topSell = service.topSelling(salesBox, productsBox, start, end).take(10).toList();
      _topProfit = service.topProfit(salesBox, productsBox, start, end).take(10).toList();
      _loss = service.lossProducts(productsBox);
      _globalTrend = service.revenueTrend(salesBox, start, end);
      _lossByProduct = service.lossByProduct(
        productsBox,
        ref.read(movementsBoxProvider),
        ref.read(rejectedItemsBoxProvider),
        start,
        end,
      ).take(10).toList();
      _forecast = service.restockForecast(
        salesBox,
        productsBox,
        DateTime.now(),
        windowDays: 7,
        horizonDays: 3,
      ).where((e) => e.suggestBuy > 0).take(10).toList();
      _categories = service.categoryPerformance(salesBox, productsBox, start, end).take(10).toList();
      _priceInsights = service.purchasePriceInsights(purchasesBox, productsBox, start, end, limit: 10);
      _topCustomers = service.topCustomers(salesBox, start, end, limit: 10);
      _topSuppliers = service.topSuppliers(purchasesBox, start, end, limit: 10);

      // reset cache tren per produk
      _trendProductId = null;
      _productTrend = const [];
    }

    final products = productsBox.values.toList()..sort((a, b) => a.name.compareTo(b.name));
    selectedProductId ??= products.isNotEmpty ? products.first.id : null;

    // Cache tren per produk terpilih.
    if (selectedProductId != null && _trendProductId != selectedProductId) {
      _trendProductId = selectedProductId;
      _productTrend = service.productRevenueTrend(salesBox, selectedProductId!, start, end);
    }

    return DefaultTabController(
      length: 9,
      child: Column(
        children: [
          _RangeBar(
            start: start,
            end: end,
            onPick: _pickRange,
            onQuick7: () => _quickRange(7),
            onQuick30: () => _quickRange(30),
          ),
          const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            labelPadding: EdgeInsets.symmetric(horizontal: 14),
            tabs: [
              Tab(text: 'Laku'),
              Tab(text: 'Untung'),
              Tab(text: 'Rugi'),
              Tab(text: 'Tren'),
              Tab(text: 'Susut'),
              Tab(text: 'Restock'),
              Tab(text: 'Kategori'),
              Tab(text: 'Harga'),
              Tab(text: 'Mitra'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                _KpiList(
                  title: 'Top Produk Paling Laku',
                  rows: _topSell.map((k) => _KpiRow(
                        productId: k.productId,
                        title: k.name,
                        subtitle: 'Qty: ${k.qty.toStringAsFixed(2)}',
                        trailingTop: fmtMoney(k.revenue),
                        trailingBottom: 'Laba: ${fmtMoney(k.profit)}',
                      )),
                  onTapProduct: (pid) => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => AnalyticsProductDetailPage(
                        productId: pid,
                        start: start,
                        end: end,
                      ),
                    ),
                  ),
                ),
                _KpiList(
                  title: 'Top Produk Paling Untung',
                  rows: _topProfit.map((k) => _KpiRow(
                        productId: k.productId,
                        title: k.name,
                        subtitle: 'Margin: ${k.marginPercent.toStringAsFixed(1)}%',
                        trailingTop: 'Laba: ${fmtMoney(k.profit)}',
                        trailingBottom: fmtMoney(k.revenue),
                      )),
                  onTapProduct: (pid) => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => AnalyticsProductDetailPage(
                        productId: pid,
                        start: start,
                        end: end,
                      ),
                    ),
                  ),
                ),
                _LossList(
                  loss: _loss,
                  onTapProduct: (pid) => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => AnalyticsProductDetailPage(
                        productId: pid,
                        start: start,
                        end: end,
                      ),
                    ),
                  ),
                ),
                _TrendTab(
                  products: products,
                  selectedProductId: selectedProductId,
                  onSelectProduct: (id) => setState(() => selectedProductId = id),
                  globalTrend: _globalTrend,
                  productTrend: selectedProductId == null ? const <DayPoint>[] : _productTrend,
                ),
                _LossProductTab(rows: _lossByProduct),
                _ForecastTab(rows: _forecast),
                _CategoryTab(rows: _categories),
                _PriceInsightTab(rows: _priceInsights),
                _PartnerTab(customers: _topCustomers, suppliers: _topSuppliers),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RangeBar extends StatelessWidget {
  final DateTime start;
  final DateTime end;
  final VoidCallback onPick;
  final VoidCallback onQuick7;
  final VoidCallback onQuick30;

  const _RangeBar({
    required this.start,
    required this.end,
    required this.onPick,
    required this.onQuick7,
    required this.onQuick30,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: onPick,
              icon: const Icon(Icons.date_range),
              label: Text('${fmtDate(start)}  →  ${fmtDate(end)}'),
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(onPressed: onQuick7, child: const Text('7 hari')),
          const SizedBox(width: 8),
          OutlinedButton(onPressed: onQuick30, child: const Text('30 hari')),
        ],
      ),
    );
  }
}

class _KpiRow {
  final String productId;
  final String title;
  final String subtitle;
  final String trailingTop;
  final String trailingBottom;

  const _KpiRow({
    required this.productId,
    required this.title,
    required this.subtitle,
    required this.trailingTop,
    required this.trailingBottom,
  });
}

class _KpiList extends StatelessWidget {
  final String title;
  final Iterable<_KpiRow> rows;
  final void Function(String productId)? onTapProduct;

  const _KpiList({required this.title, required this.rows, this.onTapProduct});

  @override
  Widget build(BuildContext context) {
    final list = rows.toList();
    if (list.isEmpty) {
      return const Center(child: Text('Belum ada data pada rentang ini.'));
    }
    return ListView.builder(
      itemCount: list.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Text(title, style: Theme.of(context).textTheme.titleMedium),
          );
        }
        final r = list[i - 1];
        return ListTile(
          title: Text(r.title),
          subtitle: Text(r.subtitle),
          onTap: onTapProduct == null ? null : () => onTapProduct!(r.productId),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(r.trailingTop),
              Text(r.trailingBottom, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        );
      },
    );
  }
}

class _LossList extends StatelessWidget {
  final List<(Product product, double marginActual)> loss;
  final void Function(String productId)? onTapProduct;

  const _LossList({required this.loss, this.onTapProduct});

  @override
  Widget build(BuildContext context) {
    if (loss.isEmpty) {
      return const Center(child: Text('Tidak ada produk rugi / margin turun.'));
    }
    return ListView.builder(
      itemCount: loss.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Text('Produk Rugi / Margin di bawah target', style: Theme.of(context).textTheme.titleMedium),
          );
        }
        final p = loss[i - 1].$1;
        final marginActual = loss[i - 1].$2;
        final isLoss = p.activeSellPrice < p.avgHpp;

        return ListTile(
          leading: Icon(isLoss ? Icons.error_outline : Icons.warning_amber_outlined, color: isLoss ? Colors.red : null),
          title: Text(p.name),
          subtitle: Text(
            'HPP: ${fmtMoney(p.avgHpp)} • Jual: ${fmtMoney(p.activeSellPrice)}\n'
            'Target: ${p.defaultMarginPercent.toStringAsFixed(1)}% • Aktual: ${marginActual.toStringAsFixed(1)}%',
          ),
          isThreeLine: true,
          onTap: onTapProduct == null ? null : () => onTapProduct!(p.id),
        );
      },
    );
  }
}

class _TrendTab extends StatelessWidget {
  final List<Product> products;
  final String? selectedProductId;
  final ValueChanged<String> onSelectProduct;
  final List<DayPoint> globalTrend;
  final List<DayPoint> productTrend;

  const _TrendTab({
    required this.products,
    required this.selectedProductId,
    required this.onSelectProduct,
    required this.globalTrend,
    required this.productTrend,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      children: [
        Text('Tren Omzet Global', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        _LineChart(points: globalTrend),
        const SizedBox(height: 16),
        Text('Tren Omzet Per Produk', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          initialValue: selectedProductId,
          items: products
              .map((p) => DropdownMenuItem(value: p.id, child: Text(p.name)))
              .toList(),
          onChanged: (v) {
            if (v != null) onSelectProduct(v);
          },
          decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Pilih produk'),
        ),
        const SizedBox(height: 8),
        _LineChart(points: productTrend),
      ],
    );
  }
}


class _LossProductTab extends StatelessWidget {
  final List<LossProductKpi> rows;
  const _LossProductTab({required this.rows});

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) {
      return const Center(child: Text('Belum ada kerugian produk pada rentang ini.'));
    }
    final total = rows.fold<double>(0, (p, e) => p + e.amount);
    return ListView.builder(
      itemCount: rows.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Kerugian Produk', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text('Total kerugian: ${fmtMoney(total)}'),
              ],
            ),
          );
        }
        final r = rows[i - 1];
        return ListTile(
          leading: const Icon(Icons.delete_outline),
          title: Text(r.name),
          subtitle: Text('Qty: ${r.qty.toStringAsFixed(2)} • Sumber: ${r.source}'),
          trailing: Text(fmtMoney(r.amount)),
        );
      },
    );
  }
}

class _ForecastTab extends StatelessWidget {
  final List<ForecastKpi> rows;
  const _ForecastTab({required this.rows});

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) {
      return const Center(child: Text('Belum ada forecast restock.'));
    }
    return ListView.builder(
      itemCount: rows.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Text('Prediksi Belanja 3 Hari (berdasarkan 7 hari terakhir)', style: Theme.of(context).textTheme.titleMedium),
          );
        }
        final r = rows[i - 1];
        return ListTile(
          leading: const Icon(Icons.shopping_basket_outlined),
          title: Text(r.name),
          subtitle: Text('Rata-rata ${r.avgPerDay.toStringAsFixed(2)} ${r.unit}/hari • stok ${r.stockQty.toStringAsFixed(2)} ${r.unit}'),
          trailing: Text('${r.suggestBuy.toStringAsFixed(2)} ${r.unit}'),
        );
      },
    );
  }
}


class _CategoryTab extends StatelessWidget {
  final List<CategoryKpi> rows;
  const _CategoryTab({required this.rows});

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const Center(child: Text('Belum ada data kategori.'));
    return ListView.builder(
      itemCount: rows.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Text('Performa per Kategori', style: Theme.of(context).textTheme.titleMedium),
          );
        }
        final r = rows[i - 1];
        return ListTile(
          leading: const Icon(Icons.category_outlined),
          title: Text(r.category),
          subtitle: Text('Qty: ${r.qty.toStringAsFixed(2)} • ${r.productCount} produk • Margin ${r.marginPercent.toStringAsFixed(1)}%'),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(fmtMoney(r.revenue)),
              Text('Laba ${fmtMoney(r.profit)}', style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        );
      },
    );
  }
}

class _PriceInsightTab extends StatelessWidget {
  final List<PriceTrendKpi> rows;
  const _PriceInsightTab({required this.rows});

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const Center(child: Text('Belum ada histori harga beli.'));
    return ListView.builder(
      itemCount: rows.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Text('Tren Harga Beli', style: Theme.of(context).textTheme.titleMedium),
          );
        }
        final r = rows[i - 1];
        final up = r.changePercent >= 0;
        return ListTile(
          leading: Icon(up ? Icons.trending_up : Icons.trending_down, color: up ? Colors.red : Colors.green),
          title: Text(r.name),
          subtitle: Text('Awal ${fmtMoney(r.earliestPrice)} • Kini ${fmtMoney(r.latestPrice)} • Avg ${fmtMoney(r.avgPrice)}'),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('${r.changePercent >= 0 ? '+' : ''}${r.changePercent.toStringAsFixed(1)}%'),
              Text('${r.sampleCount} sampel', style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        );
      },
    );
  }
}

class _PartnerTab extends StatelessWidget {
  final List<PartnerKpi> customers;
  final List<PartnerKpi> suppliers;
  const _PartnerTab({required this.customers, required this.suppliers});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      children: [
        Text('Pelanggan Teratas', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (customers.isEmpty)
          const ListTile(title: Text('Belum ada data pelanggan.'))
        else
          ...customers.take(5).map((e) => ListTile(
                leading: const Icon(Icons.person_outline),
                title: Text(e.name),
                subtitle: Text('${e.transactionCount} transaksi'),
                trailing: Text(fmtMoney(e.totalAmount)),
              )),
        const SizedBox(height: 16),
        Text('Supplier Teratas', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (suppliers.isEmpty)
          const ListTile(title: Text('Belum ada data supplier.'))
        else
          ...suppliers.take(5).map((e) => ListTile(
                leading: const Icon(Icons.local_shipping_outlined),
                title: Text(e.name),
                subtitle: Text('${e.transactionCount} pembelian'),
                trailing: Text(fmtMoney(e.totalAmount)),
              )),
      ],
    );
  }
}

class _LineChart extends StatelessWidget {
  final List<DayPoint> points;
  const _LineChart({required this.points});

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) {
      return const SizedBox(height: 220, child: Center(child: Text('Tidak ada data.')));
    }

    final spots = <FlSpot>[];
    for (int i = 0; i < points.length; i++) {
      spots.add(FlSpot(i.toDouble(), points[i].value));
    }

    String bottomTitle(double value) {
      final i = value.round();
      if (i < 0 || i >= points.length) return '';
      final dt = fromEpochDay(points[i].epochDayValue);
      return '${dt.day}/${dt.month}';
    }

    return SizedBox(
      height: 240,
      child: LineChart(
        LineChartData(
          gridData: const FlGridData(show: true),
          titlesData: FlTitlesData(
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 44)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: (points.length / 6).clamp(1, 999).toDouble(),
                getTitlesWidget: (v, meta) => Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(bottomTitle(v), style: const TextStyle(fontSize: 10)),
                ),
              ),
            ),
          ),
          borderData: FlBorderData(show: true),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              dotData: const FlDotData(show: false),
              barWidth: 3,
            ),
          ],
        ),
      ),
    );
  }
}
