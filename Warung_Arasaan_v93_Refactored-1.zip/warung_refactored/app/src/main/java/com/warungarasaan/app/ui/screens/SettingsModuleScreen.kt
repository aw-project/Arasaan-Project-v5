package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.AppSettings
import com.warungarasaan.app.ui.EmptyHint
import kotlinx.coroutines.launch
import com.warungarasaan.app.ui.viewmodel.SettingsViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun SettingsModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: SettingsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            if (state.settings == null) EmptyHint("Memuat settings", "Menyiapkan konfigurasi lokal.") else Text("Pengaturan aplikasi")
        }
        item {
            OutlinedTextField(role, { role = it }, label = { Text("Role") })
            TextButton(onClick = { scope.launch { vm.onEvent(SettingsEvent.SaveRole); reload() } }) { Text("Simpan role") }
        }
        item {
            ListItem(
                headlineContent = { Text("Auto backup") },
                supportingContent = { Text("Simulasi pengaturan interval backup lokal") },
                trailingContent = { Switch(checked = state.autoBackup, onCheckedChange = { checked ->
                    scope.launch { container.metaRepository.setAutoBackupEnabled(checked); reload() }
                }) },
            )
        }
        item {
            OutlinedTextField(autoBackupDays, { autoBackupDays = it }, label = { Text("Hari interval backup") })
            TextButton(onClick = {
                scope.launch {
                    vm.onEvent(SettingsEvent.SaveAutoBackupDays)(autoBackupDays.toIntOrNull() ?: 7)
                    reload()
                }
            }) { Text("Simpan interval") }
        }
        item {
            OutlinedTextField(pinInput, { pinInput = it }, label = { Text("PIN baru") })
            TextButton(onClick = {
                scope.launch {
                    vm.onEvent(SettingsEvent.SavePin) container.settingsRepository.disablePin() else container.settingsRepository.setPin(pinInput)
                    pinInput = ""
                    reload()
                }
            }) { Text("Simpan PIN") }
        }
        item {
            OutlinedTextField(verifyInput, { verifyInput = it }, label = { Text("Verifikasi PIN") })
            TextButton(onClick = {
                scope.launch {
                    vm.onEvent(SettingsEvent.VerifyPin)
                }
            }) { Text("Cek PIN") }
        }
        item { if (state.verifyResult.isNotBlank()) Text(state.verifyResult) }
        item { if (settings != null) Text("PIN aktif: ${settings!!.pinEnabled}") }
        item { Text("Jika PIN aktif, LockGate akan muncul saat aplikasi dibuka.") }
    }
}
