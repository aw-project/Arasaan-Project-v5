import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../providers.dart';
import '../products/product_detail_page.dart';
import '../purchases/purchase_form.dart';
import '../sales/sale_form.dart';
import '../sales/fast_pos_page.dart';
import '../expenses/expenses_page.dart';
import '../reports/reports_page.dart';
import '../restock/restock_page.dart';
import '../../core/payment_methods.dart';
import '../../data/services/analytics_service.dart';

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productsRepo = ref.watch(productRepoProvider);
    final salesRepo = ref.watch(salesRepoProvider);
    final expenseRepo = ref.watch(expenseRepoProvider);
    final cashRepo = ref.watch(cashRepoProvider);
    final rejectedRepo = ref.watch(rejectedRepoProvider);
    final purchaseRepo = ref.watch(purchaseRepoProvider);
    final debtRepo = ref.watch(debtRepoProvider);

    final today = epochDay(DateTime.now());

    final salesToday =
        salesRepo.all().where((s) => s.dateEpochDay == today).toList();
    final expensesToday =
        expenseRepo.all().where((e) => e.dateEpochDay == today).toList();
    final rejectedToday =
        rejectedRepo.all().where((r) => r.dateEpochDay == today).toList();
    final purchasesToday =
        purchaseRepo.all().where((p) => p.dateEpochDay == today).toList();
    final activeDebts = debtRepo.all().where((d) => !d.isSettled).toList();

    final omzetToday =
        salesToday.fold<double>(0.0, (p, s) => p + s.totalSales);
    final hppToday = salesToday.fold<double>(0.0, (p, s) => p + s.totalHpp);
    final biayaToday =
        expensesToday.fold<double>(0.0, (p, e) => p + e.amount);
    // Rugi barang rejek masuk pengurang laba (HPP sudah dibayar saat beli,
    // rejek = nilai inventory yang hilang tanpa menghasilkan omzet)
    final rugiRejekToday =
        rejectedToday.fold<double>(0.0, (p, r) => p + r.estimatedLoss);
    final labaToday = omzetToday - hppToday - biayaToday - rugiRejekToday;

    final cashAll = cashRepo.all();
    // Saldo kas hanya menghitung arus kas nyata (bukan entri Non-Cash rugi rejek)
    final saldoKas = cashAll
        .where((e) => PaymentMethods.isCashFlow(e.method))
        .fold<double>(
            0, (p, e) => p + (e.direction == 'in' ? e.amount : -e.amount));
    final outstandingDebt = activeDebts.fold<double>(0, (p, d) => p + d.remaining);

    // Top products today
    final soldByProduct = <String, double>{};
    for (final s in salesToday) {
      for (final it in s.items) {
        soldByProduct[it.productId] =
            (soldByProduct[it.productId] ?? 0) + it.qty;
      }
    }
    final topSold = soldByProduct.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final paymentMix = <String, double>{};
    for (final s in salesToday) {
      for (final split in s.normalizedSplits) {
        paymentMix[split.method] = (paymentMix[split.method] ?? 0) + split.amount;
      }
    }
    final paymentMixList = paymentMix.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    // Low stock
    final lowStock = productsRepo
        .all()
        .where((p) => p.minStock > 0 && p.stockQty <= p.minStock)
        .toList()
      ..sort((a, b) {
        final d = (a.stockQty - a.minStock)
            .compareTo(b.stockQty - b.minStock);
        if (d != 0) return d;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    final analytics = const AnalyticsService();
    final start7 = DateTime.now().subtract(const Duration(days: 6));
    final start30 = DateTime.now().subtract(const Duration(days: 29));
    final salesBox = ref.watch(salesBoxProvider);
    final productsBox = ref.watch(productsBoxProvider);
    final movementsBox = ref.watch(movementsBoxProvider);
    final rejectedBox = ref.watch(rejectedItemsBoxProvider);
    final omzet7 = analytics.revenueTrend(salesBox, start7, DateTime.now())
        .fold<double>(0, (p, e) => p + e.value);
    final omzet30 = analytics.revenueTrend(salesBox, start30, DateTime.now())
        .fold<double>(0, (p, e) => p + e.value);
    final marginAlerts = analytics.lossProducts(productsBox).take(3).toList();
    final lossProducts = analytics.lossByProduct(
      productsBox,
      movementsBox,
      rejectedBox,
      start30,
      DateTime.now(),
    ).take(3).toList();
    final forecastBuy = analytics.restockForecast(
      salesBox,
      productsBox,
      DateTime.now(),
      windowDays: 7,
      horizonDays: 3,
    ).where((e) => e.suggestBuy > 0).take(4).toList();

    final now = DateTime.now();
    final greeting = _greeting(now.hour);

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        // ── Hero header ──────────────────────────────────────────────────
        _HeroHeader(
          greeting: greeting,
          date: fmtDateFromEpochDay(today),
          omzet: omzetToday,
          laba: labaToday,
          omzet7: omzet7,
          omzet30: omzet30,
        ),

        Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Stat cards grid ────────────────────────────────────────
              _SectionLabel(label: 'Ringkasan Hari Ini'),
              const SizedBox(height: 12),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.55,
                children: [
                  _GradientStatCard(
                    title: 'Omzet',
                    value: fmtMoney(omzetToday),
                    icon: Icons.bar_chart_rounded,
                    colors: const [AppColors.cardGreen1, AppColors.cardGreen2],
                  ),
                  _GradientStatCard(
                    title: 'Laba Bersih',
                    value: fmtMoney(labaToday),
                    icon: Icons.trending_up_rounded,
                    colors: const [AppColors.cardTeal1, AppColors.cardTeal2],
                  ),
                  _GradientStatCard(
                    title: 'Saldo Kas',
                    value: fmtMoney(saldoKas),
                    icon: Icons.account_balance_wallet_rounded,
                    colors: const [AppColors.cardIndigo1, AppColors.cardIndigo2],
                  ),
                  _GradientStatCard(
                    title: 'Transaksi',
                    value: '${salesToday.length}×',
                    icon: Icons.receipt_long_rounded,
                    colors: const [AppColors.cardAmber1, AppColors.cardAmber2],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.fact_check_rounded,
                iconColor: const Color(0xFF6A1B9A),
                title: 'Kontrol Operasional',
                badge: 'Patch 4',
                child: Column(
                  children: [
                    _MiniInsightRow(
                      title: 'Pembelian hari ini',
                      value: '${purchasesToday.length}×',
                      subtitle: 'Cek apakah stok masuk sudah dicatat semua.',
                    ),
                    const Divider(height: 16),
                    _MiniInsightRow(
                      title: 'Hutang aktif',
                      value: '${activeDebts.length} akun',
                      subtitle: 'Sisa tagihan ${fmtMoney(outstandingDebt)}',
                    ),
                    const Divider(height: 16),
                    _MiniInsightRow(
                      title: 'Biaya hari ini',
                      value: fmtMoney(biayaToday),
                      subtitle: 'Pantau pengeluaran operasional harian.',
                    ),
                  ],
                ),
              ),

              // ── Quick actions ──────────────────────────────────────────
              const SizedBox(height: 24),
              _SectionLabel(label: 'Aksi Cepat'),
              const SizedBox(height: 12),
              _QuickActionsRow(
                onFastPos: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const FastPosPage())),
                onAddSale: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SaleFormPage())),
                onAddPurchase: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const PurchaseFormPage())),
                onAddExpense: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ExpenseFormPage())),
                onOpenReports: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => Scaffold(
                      appBar: AppBar(title: const Text('Laporan')),
                      body: const ReportsPage(),
                    ),
                  ),
                ),
                onOpenRestock: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const RestockPage())),
              ),

              // ── Top products ───────────────────────────────────────────
              const SizedBox(height: 24),
              _InfoCard(
                icon: Icons.local_fire_department_rounded,
                iconColor: const Color(0xFFE65100),
                title: 'Produk Terlaris Hari Ini',
                badge: '${topSold.length} produk',
                child: topSold.isEmpty
                    ? _EmptyCardContent(
                        icon: Icons.storefront_outlined,
                        message: 'Belum ada penjualan hari ini.',
                      )
                    : Column(
                        children: topSold.take(3).mapIndexed((idx, e) {
                          final pr = productsRepo.getById(e.key);
                          final name = pr?.name ?? 'Produk';
                          final unit = pr?.unit ?? '';
                          return _RankedItem(
                            rank: idx + 1,
                            title: name,
                            subtitle:
                                'Terjual: ${_fmtQty(e.value)}${unit.isNotEmpty ? ' $unit' : ''}',
                          );
                        }).toList(),
                      ),
              ),

              // ── Low stock ──────────────────────────────────────────────
              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.inventory_2_rounded,
                iconColor: const Color(0xFFC62828),
                title: 'Stok Menipis',
                badge: '${lowStock.length} item',
                badgeColor: lowStock.isEmpty
                    ? const Color(0xFF1A7A50)
                    : const Color(0xFFC62828),
                child: lowStock.isEmpty
                    ? _EmptyCardContent(
                        icon: Icons.check_circle_outline_rounded,
                        message: 'Aman! Tidak ada stok yang menipis.',
                        positive: true,
                      )
                    : Column(
                        children: lowStock.take(5).map((p) {
                          return _LowStockItem(
                            name: p.name,
                            unit: p.unit,
                            stock: p.stockQty,
                            minStock: p.minStock,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) =>
                                      ProductDetailPage(productId: p.id)),
                            ),
                          );
                        }).toList(),
                      ),
              ),

              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.payments_rounded,
                iconColor: const Color(0xFF00897B),
                title: 'Metode Pembayaran Hari Ini',
                badge: '${paymentMixList.length} metode',
                child: paymentMixList.isEmpty
                    ? _EmptyCardContent(
                        icon: Icons.point_of_sale_outlined,
                        message: 'Belum ada pembayaran yang tercatat hari ini.',
                      )
                    : Column(
                        children: paymentMixList.take(4).map((e) => _MiniInsightRow(
                              title: e.key,
                              value: fmtMoney(e.value),
                              subtitle: omzetToday <= 0
                                  ? 'Belum ada persentase'
                                  : '${(e.value / omzetToday * 100).toStringAsFixed(1)}% dari omzet hari ini',
                            )).toList(),
                      ),
              ),

              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.calendar_view_week_rounded,
                iconColor: const Color(0xFF1565C0),
                title: 'Ringkasan 7 / 30 Hari',
                badge: 'Batch 4',
                child: Column(
                  children: [
                    _MiniInsightRow(
                      title: 'Omzet 7 hari',
                      value: fmtMoney(omzet7),
                      subtitle: 'Pantau performa mingguan',
                    ),
                    const Divider(height: 16),
                    _MiniInsightRow(
                      title: 'Omzet 30 hari',
                      value: fmtMoney(omzet30),
                      subtitle: 'Melihat ritme bulanan',
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.warning_amber_rounded,
                iconColor: const Color(0xFFB26A00),
                title: 'Prioritas Margin Turun',
                badge: '${marginAlerts.length} item',
                child: marginAlerts.isEmpty
                    ? _EmptyCardContent(
                        icon: Icons.check_circle_outline_rounded,
                        message: 'Tidak ada produk dengan margin di bawah target.',
                        positive: true,
                      )
                    : Column(
                        children: marginAlerts.map((e) {
                          final p = e.$1;
                          final actual = e.$2;
                          return _MiniInsightRow(
                            title: p.name,
                            value: '${actual.toStringAsFixed(1)}%',
                            subtitle: 'Target ${p.defaultMarginPercent.toStringAsFixed(1)}% • HPP ${fmtMoney(p.avgHpp)} • Jual ${fmtMoney(p.activeSellPrice)}',
                          );
                        }).toList(),
                      ),
              ),

              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.delete_outline_rounded,
                iconColor: const Color(0xFFC62828),
                title: 'Kerugian Produk (30 Hari)',
                badge: '${lossProducts.length} produk',
                child: lossProducts.isEmpty
                    ? _EmptyCardContent(
                        icon: Icons.inventory_2_outlined,
                        message: 'Belum ada kerugian yang tercatat.',
                        positive: true,
                      )
                    : Column(
                        children: lossProducts.map((e) => _MiniInsightRow(
                              title: e.name,
                              value: fmtMoney(e.amount),
                              subtitle: '${_fmtQty(e.qty)} hilang • ${e.source}',
                            )).toList(),
                      ),
              ),

              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.shopping_basket_rounded,
                iconColor: const Color(0xFF2E7D32),
                title: 'Prediksi Belanja 3 Hari',
                badge: '${forecastBuy.length} item',
                child: forecastBuy.isEmpty
                    ? _EmptyCardContent(
                        icon: Icons.show_chart_rounded,
                        message: 'Belum ada saran belanja dari histori 7 hari.',
                      )
                    : Column(
                        children: forecastBuy.map((e) => _MiniInsightRow(
                              title: e.name,
                              value: '${_fmtQty(e.suggestBuy)} ${e.unit}',
                              subtitle: 'Rata-rata ${_fmtQty(e.avgPerDay)} ${e.unit}/hari • stok ${_fmtQty(e.stockQty)} ${e.unit}',
                            )).toList(),
                      ),
              ),

              const SizedBox(height: 32),
            ],
          ),
        ),
      ],
    );
  }
}

String _greeting(int hour) {
  if (hour < 12) return 'Selamat pagi 🌤️';
  if (hour < 15) return 'Selamat siang ☀️';
  if (hour < 18) return 'Selamat sore 🌅';
  return 'Selamat malam 🌙';
}

String _fmtQty(num n) {
  final s = n.toStringAsFixed(2);
  return s.replaceAll(RegExp(r'\.00$'), '').replaceAll(RegExp(r'(\.[0-9])0$'), r'$1');
}


class _MiniInsightRow extends StatelessWidget {
  final String title;
  final String value;
  final String subtitle;

  const _MiniInsightRow({
    required this.title,
    required this.value,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

// ─── Hero Header ─────────────────────────────────────────────────────────────

class _HeroHeader extends StatelessWidget {
  final String greeting;
  final String date;
  final double omzet;
  final double laba;
  final double omzet7;
  final double omzet30;

  const _HeroHeader({
    required this.greeting,
    required this.date,
    required this.omzet,
    required this.laba,
    required this.omzet7,
    required this.omzet30,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.drawerHeader1, AppColors.drawerHeader2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      greeting,
                      style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      date,
                      style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.55),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              // Trend pills
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _TrendPill(label: '7h', value: omzet7),
                  const SizedBox(height: 4),
                  _TrendPill(label: '30h', value: omzet30),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _HeroStat(
                  label: 'Omzet Hari Ini',
                  value: fmtMoney(omzet),
                  icon: Icons.bar_chart_rounded,
                ),
              ),
              Container(
                  width: 1,
                  height: 48,
                  color: Colors.white.withOpacity(0.2),
                  margin: const EdgeInsets.symmetric(horizontal: 16)),
              Expanded(
                child: _HeroStat(
                  label: 'Laba Bersih',
                  value: fmtMoney(laba),
                  icon: Icons.trending_up_rounded,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TrendPill extends StatelessWidget {
  final String label;
  final double value;
  const _TrendPill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border:
            Border.all(color: Colors.white.withOpacity(0.2), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.6),
              fontSize: 9,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 4),
          Text(
            fmtMoney(value),
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.9),
              fontSize: 9,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _HeroStat(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Colors.white.withOpacity(0.7), size: 14),
            const SizedBox(width: 4),
            Text(
              label,
              style: GoogleFonts.poppins(
                color: Colors.white.withOpacity(0.7),
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}

// ─── Section Label ────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: GoogleFonts.poppins(
        fontSize: 15,
        fontWeight: FontWeight.w700,
        color: AppColors.onSurface,
        letterSpacing: -0.2,
      ),
    );
  }
}

// ─── Gradient Stat Card ───────────────────────────────────────────────────────

class _GradientStatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final List<Color> colors;

  const _GradientStatCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: colors.first.withOpacity(0.35),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          const Spacer(),
          Text(
            title,
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.8),
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.4,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ─── Quick Actions ────────────────────────────────────────────────────────────

class _QuickActionsRow extends StatelessWidget {
  final VoidCallback onFastPos;
  final VoidCallback onAddSale;
  final VoidCallback onAddPurchase;
  final VoidCallback onAddExpense;
  final VoidCallback onOpenReports;
  final VoidCallback onOpenRestock;

  const _QuickActionsRow({
    required this.onFastPos,
    required this.onAddSale,
    required this.onAddPurchase,
    required this.onAddExpense,
    required this.onOpenReports,
    required this.onOpenRestock,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 92,
      child: ListView(
        scrollDirection: Axis.horizontal,
        clipBehavior: Clip.none,
        children: [
          _ActionTile(
            icon: Icons.flash_on_rounded,
            label: 'Fast POS',
            color: AppColors.gold,
            onTap: onFastPos,
          ),
          const SizedBox(width: 10),
          _ActionTile(
            icon: Icons.point_of_sale_rounded,
            label: 'Penjualan',
            color: AppColors.cardGreen1,
            onTap: onAddSale,
          ),
          const SizedBox(width: 10),
          _ActionTile(
            icon: Icons.shopping_cart_rounded,
            label: 'Pembelian',
            color: AppColors.cardIndigo1,
            onTap: onAddPurchase,
          ),
          const SizedBox(width: 10),
          _ActionTile(
            icon: Icons.request_quote_rounded,
            label: 'Biaya',
            color: AppColors.cardAmber1,
            onTap: onAddExpense,
          ),
          const SizedBox(width: 10),
          _ActionTile(
            icon: Icons.bar_chart_rounded,
            label: 'Laporan',
            color: AppColors.cardTeal1,
            onTap: onOpenReports,
          ),
          const SizedBox(width: 10),
          _ActionTile(
            icon: Icons.shopping_basket_rounded,
            label: 'Saran Beli',
            color: AppColors.iconPurple,
            onTap: onOpenRestock,
          ),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 76,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFDEEBD8), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(height: 7),
            Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: AppColors.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Info Card ────────────────────────────────────────────────────────────────

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String badge;
  final Color? badgeColor;
  final Widget child;

  const _InfoCard({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.badge,
    this.badgeColor,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final bc = badgeColor ?? AppColors.hint;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Left accent bar + header row
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xFFE8F0E3), width: 1),
                left: BorderSide(color: AppColors.primary, width: 4),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: iconColor, size: 16),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: AppColors.onSurface,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: bc.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    badge,
                    style: GoogleFonts.poppins(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: bc,
                    ),
                  ),
                ),
              ],
            ),
          ),
          child,
        ],
      ),
    );
  }
}

// ─── Ranked Item ──────────────────────────────────────────────────────────────

class _RankedItem extends StatelessWidget {
  final int rank;
  final String title;
  final String subtitle;

  const _RankedItem(
      {required this.rank, required this.title, required this.subtitle});

  static const _rankColors = [
    Color(0xFFD4A017),
    Color(0xFF9E9E9E),
    Color(0xFFBF7D43),
  ];

  @override
  Widget build(BuildContext context) {
    final rankColor = rank <= 3 ? _rankColors[rank - 1] : AppColors.hint;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              color: rankColor.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              '$rank',
              style: GoogleFonts.poppins(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: rankColor,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.onSurface,
                  ),
                ),
                Text(
                  subtitle,
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    color: AppColors.hint,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Low Stock Item ───────────────────────────────────────────────────────────

class _LowStockItem extends StatelessWidget {
  final String name;
  final String unit;
  final double stock;
  final double minStock;
  final VoidCallback onTap;

  const _LowStockItem({
    required this.name,
    required this.unit,
    required this.stock,
    required this.minStock,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final pct = minStock > 0 ? (stock / minStock).clamp(0.0, 1.0) : 0.0;
    final barColor = pct < 0.3
        ? const Color(0xFFC62828)
        : pct < 0.7
            ? const Color(0xFFE65100)
            : const Color(0xFF1A7A50);

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: barColor,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    name,
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.onSurface,
                    ),
                  ),
                ),
                Text(
                  '${_fmtQty(stock)} / ${_fmtQty(minStock)} ${unit.isNotEmpty ? unit : ''}',
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    color: AppColors.hint,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: pct,
                backgroundColor: barColor.withOpacity(0.15),
                color: barColor,
                minHeight: 4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Empty Card Content ───────────────────────────────────────────────────────

class _EmptyCardContent extends StatelessWidget {
  final IconData icon;
  final String message;
  final bool positive;

  const _EmptyCardContent({
    required this.icon,
    required this.message,
    this.positive = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = positive ? AppColors.positive : AppColors.hint;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Text(
            message,
            style: GoogleFonts.poppins(
              fontSize: 13,
              color: color,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Iterable mapIndexed helper ───────────────────────────────────────────────

extension _IndexedMap<T> on Iterable<T> {
  Iterable<R> mapIndexed<R>(R Function(int idx, T item) fn) sync* {
    int i = 0;
    for (final item in this) {
      yield fn(i++, item);
    }
  }
}
