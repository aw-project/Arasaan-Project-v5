package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.viewmodel.SettingsEvent
import com.warungarasaan.app.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: SettingsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            if (state.settings == null)
                EmptyHint("Memuat settings", "Menyiapkan konfigurasi lokal.")
            else
                Text("Pengaturan aplikasi")
        }

        // Role
        item {
            OutlinedTextField(
                value = state.role,
                onValueChange = { vm.onEvent(SettingsEvent.RoleChanged(it)) },
                label = { Text("Role") },
            )
            TextButton(onClick = { vm.onEvent(SettingsEvent.SaveRole) }) {
                Text("Simpan role")
            }
        }

        // Auto Backup
        item {
            ListItem(
                headlineContent = { Text("Auto backup") },
                supportingContent = { Text("Simulasi pengaturan interval backup lokal") },
                trailingContent = {
                    Switch(
                        checked = state.autoBackup,
                        onCheckedChange = { vm.onEvent(SettingsEvent.AutoBackupChanged(it)) },
                    )
                },
            )
        }
        item {
            OutlinedTextField(
                value = state.autoBackupDays,
                onValueChange = { vm.onEvent(SettingsEvent.AutoBackupDaysChanged(it)) },
                label = { Text("Hari interval backup") },
            )
            TextButton(onClick = { vm.onEvent(SettingsEvent.SaveAutoBackupDays) }) {
                Text("Simpan interval")
            }
        }

        // PIN
        item {
            OutlinedTextField(
                value = state.pinInput,
                onValueChange = { vm.onEvent(SettingsEvent.PinInputChanged(it)) },
                label = { Text("PIN baru (kosongkan untuk nonaktifkan)") },
            )
            TextButton(onClick = { vm.onEvent(SettingsEvent.SavePin) }) {
                Text("Simpan PIN")
            }
        }
        item {
            OutlinedTextField(
                value = state.verifyInput,
                onValueChange = { vm.onEvent(SettingsEvent.VerifyInputChanged(it)) },
                label = { Text("Verifikasi PIN") },
            )
            TextButton(onClick = { vm.onEvent(SettingsEvent.VerifyPin) }) {
                Text("Cek PIN")
            }
        }
        item { if (state.verifyResult.isNotBlank()) Text(state.verifyResult) }
        item { if (state.message.isNotBlank()) Text(state.message) }
        item {
            val pinEnabled = state.settings?.pinEnabled
            if (pinEnabled != null) Text("PIN aktif: $pinEnabled")
        }
        item { Text("Jika PIN aktif, LockGate akan muncul saat aplikasi dibuka.") }
    }
}
