package com.warungarasaan.app.data.repository

import com.warungarasaan.app.core.AppUtils.epochDayNow
import com.warungarasaan.app.core.AppUtils.hppWeightedAverage
import com.warungarasaan.app.core.AppUtils.newId
import com.warungarasaan.app.core.AppUtils.normalizeMoney
import com.warungarasaan.app.core.AppUtils.normalizeQty
import com.warungarasaan.app.core.AppUtils.sha256
import com.warungarasaan.app.data.local.*
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.domain.model.*
import kotlin.math.abs

private fun ProductEntity.toDomain() = Product(id, name, unit, defaultMarginPercent, activeSellPrice, stockQty, avgHpp, minStock, targetStock, sku, category, imagePath)
private fun Product.toEntity() = ProductEntity(id, name, unit, defaultMarginPercent, activeSellPrice, stockQty, avgHpp, minStock, targetStock, sku, category, imagePath)
private fun ExpenseEntity.toDomain() = Expense(id, dateEpochDay, note, amount, paymentMethod, category)
private fun Expense.toEntity() = ExpenseEntity(id, dateEpochDay, note, amount, paymentMethod, category)
private fun DebtEntity.toDomain() = Debt(id, dateEpochDay, creditor, note, principal, paid)
private fun Debt.toEntity() = DebtEntity(id, dateEpochDay, creditor, note, principal, paid)
private fun CashEntry.toEntity() = CashEntryEntity(id, dateEpochDay, direction, source, method, note, amount, refId)
private fun CashEntryEntity.toDomain() = CashEntry(id, dateEpochDay, direction, source, method, note, amount, refId)
private fun StockMovementEntity.toDomain() = StockMovement(id, dateEpochDay, productId, type, qtyDelta, note, lossType, lossAmount)
private fun StockMovement.toEntity() = StockMovementEntity(id, dateEpochDay, productId, type, qtyDelta, note, lossType, lossAmount)
private fun RejectedItemEntity.toDomain() = RejectedItem(id, dateEpochDay, productId, qty, reason, handling, note, hppAtTime, estimatedLoss)
private fun RejectedItem.toEntity() = RejectedItemEntity(id, dateEpochDay, productId, qty, reason, handling, note, hppAtTime, estimatedLoss)
private fun ActivityLogEntity.toDomain() = ActivityLog(id, dateEpochDay, type, refId, oldJson, newJson)
private fun ActivityLog.toEntity() = ActivityLogEntity(id, dateEpochDay, type, refId, oldJson, newJson)
private fun AppSettingsEntity.toDomain() = AppSettings(id, pinEnabled, pinHash)
private fun AppSettings.toEntity() = AppSettingsEntity(id, pinEnabled, pinHash)
private fun PurchaseEntity.toDomain(items: List<PurchaseItem>) = Purchase(id, dateEpochDay, supplier, paymentMethod, items)
private fun Purchase.toEntity() = PurchaseEntity(id, dateEpochDay, supplier, paymentMethod)
private fun PurchaseItemEntity.toDomain() = PurchaseItem(productId, qty, buyPrice)
private fun PurchaseItem.toEntity(purchaseId: String) = PurchaseItemEntity(purchaseId, productId, qty, buyPrice)
private fun SaleEntity.toDomain(items: List<SaleItem>, splits: List<PaymentSplit>) = Sale(id, dateEpochDay, items, paymentMethod, customerName, discountAmount, splits)
private fun Sale.toEntity() = SaleEntity(id, dateEpochDay, paymentMethod, customerName, discountAmount)
private fun SaleItemEntity.toDomain() = SaleItem(productId, qty, sellPrice, hppAtSale)
private fun SaleItem.toEntity(saleId: String) = SaleItemEntity(saleId, productId, qty, sellPrice, hppAtSale)
private fun PaymentSplitEntity.toDomain() = PaymentSplit(method, amount)
private fun PaymentSplit.toEntity(saleId: String) = PaymentSplitEntity(saleId, method, amount)

private suspend fun requireAdmin(metaRepository: MetaRepository?, actionLabel: String) {
    if (metaRepository?.role()?.trim()?.lowercase() == "kasir") {
        throw IllegalStateException("Aksi $actionLabel hanya tersedia untuk admin.")
    }
}

private fun requireValidCashEntry(entry: CashEntry) {
    require(entry.amount > 0) { "Nominal kas harus lebih dari 0." }
    require(entry.direction.trim().lowercase() in setOf("in", "out")) { "Arah kas harus in atau out." }
    require(entry.method.trim().isNotBlank()) { "Metode kas wajib diisi." }
    require(entry.note.trim().isNotBlank()) { "Catatan kas wajib diisi." }
}

private fun requireValidExpense(expense: Expense) {
    require(expense.amount > 0) { "Nominal biaya harus lebih dari 0." }
    require(expense.note.trim().isNotBlank()) { "Catatan biaya wajib diisi." }
    require(expense.paymentMethod.trim().isNotBlank()) { "Metode pembayaran biaya wajib diisi." }
}

private fun requireValidDebt(debt: Debt) {
    require(debt.creditor.trim().isNotBlank()) { "Nama kreditur/supplier hutang wajib diisi." }
    require(debt.principal > 0) { "Nilai pokok hutang harus lebih dari 0." }
    require(debt.paid >= 0) { "Nilai pembayaran hutang tidak boleh negatif." }
    require(debt.paid <= debt.principal + 0.000001) { "Nilai pembayaran hutang tidak boleh melebihi pokok hutang." }
}

private fun requireValidMovement(movement: StockMovement) {
    require(movement.productId.trim().isNotBlank()) { "Produk movement wajib diisi." }
    require(movement.qtyDelta != 0.0) { "Qty movement tidak boleh 0." }
    require(movement.type.trim().isNotBlank()) { "Jenis movement wajib diisi." }
}

private fun requireValidProduct(product: Product) {
    require(product.name.trim().isNotBlank()) { "Nama produk wajib diisi." }
    require(product.unit.trim().isNotBlank()) { "Satuan produk wajib diisi." }
    require(product.defaultMarginPercent >= 0.0) { "Margin default tidak boleh negatif." }
    require(product.activeSellPrice >= 0.0) { "Harga jual tidak boleh negatif." }
    require(product.stockQty >= 0.0) { "Stok produk tidak boleh negatif." }
    require(product.avgHpp >= 0.0) { "HPP rata-rata tidak boleh negatif." }
    require(product.minStock >= 0.0) { "Stok minimum tidak boleh negatif." }
    require(product.targetStock >= 0.0) { "Target stok tidak boleh negatif." }
}

private fun requireValidPurchase(purchase: Purchase) {
    require(purchase.items.isNotEmpty()) { "Transaksi pembelian tidak boleh kosong." }
    require(purchase.paymentMethod.trim().isNotBlank()) { "Metode pembayaran pembelian wajib diisi." }
    if (purchase.paymentMethod.equals(PaymentMethods.HUTANG, true)) {
        require(purchase.supplier.trim().isNotBlank()) { "Supplier wajib diisi untuk pembelian hutang." }
    }
}

private fun requireValidSale(sale: Sale) {
    require(sale.items.isNotEmpty()) { "Transaksi penjualan tidak boleh kosong." }
    require(sale.paymentMethod.trim().isNotBlank()) { "Metode pembayaran penjualan wajib diisi." }
    require(sale.discountAmount >= 0) { "Diskon tidak boleh negatif." }
    require(sale.discountAmount <= sale.grossSales) { "Diskon melebihi total bruto penjualan." }
    if (sale.paymentMethod.equals("Tempo", ignoreCase = true) || sale.paymentMethod.equals(PaymentMethods.HUTANG, ignoreCase = true)) {
        require(sale.customerName.trim().isNotBlank()) { "Nama customer wajib diisi untuk transaksi tempo." }
    }
}


class ProductRepository(private val dao: ProductDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<Product> = dao.getAll().map { it.toDomain() }
    suspend fun getById(id: String): Product? = dao.getById(id)?.toDomain()
    suspend fun upsert(product: Product) {
        requireAdmin(metaRepository, "ubah produk")
        requireValidProduct(product)
        dao.upsert(product.toEntity())
    }
    suspend fun remove(id: String) {
        requireAdmin(metaRepository, "hapus produk")
        dao.delete(id)
    }
}

class CashRepository(private val dao: CashDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<CashEntry> = dao.getAll().map { it.toDomain() }
    suspend fun add(entry: CashEntry) {
        requireAdmin(metaRepository, "input kas manual")
        requireValidCashEntry(entry)
        dao.upsert(entry.toEntity())
    }
    suspend fun remove(id: String) {
        requireAdmin(metaRepository, "hapus entri kas")
        dao.delete(id)
    }
    suspend fun removeByRef(source: String, refId: String) = dao.deleteByRef(source, refId)
}

class ExpenseRepository(private val expenseDao: ExpenseDao, private val cashDao: CashDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<Expense> = expenseDao.getAll().map { it.toDomain() }
    suspend fun add(expense: Expense) {
        requireAdmin(metaRepository, "tambah biaya")
        requireValidExpense(expense)
        expenseDao.upsert(expense.toEntity())
        cashDao.upsert(CashEntry(newId("cash"), expense.dateEpochDay, "out", "expense", expense.paymentMethod, expense.note, expense.amount, expense.id).toEntity())
    }
    suspend fun remove(id: String) {
        requireAdmin(metaRepository, "hapus biaya")
        expenseDao.delete(id)
        cashDao.deleteByRef("expense", id)
    }
}

class DebtRepository(private val debtDao: DebtDao, private val cashDao: CashDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<Debt> = debtDao.getAll().map { it.toDomain() }
    suspend fun add(debt: Debt) {
        requireAdmin(metaRepository, "tambah hutang")
        requireValidDebt(debt)
        debtDao.upsert(debt.toEntity())
    }
    suspend fun remove(id: String) {
        requireAdmin(metaRepository, "hapus hutang")
        cashDao.deleteByRef("debt_payment", id)
        debtDao.delete(id)
    }
    suspend fun addPayment(id: String, amount: Double, dateEpochDay: Int, method: String = "Cash") {
        requireAdmin(metaRepository, "bayar hutang")
        require(amount > 0) { "Nominal pembayaran hutang harus lebih dari 0." }
        require(method.trim().isNotBlank()) { "Metode pembayaran hutang wajib diisi." }
        val debt = debtDao.getById(id) ?: return
        debtDao.upsert(debt.copy(paid = (debt.paid + amount).coerceAtMost(debt.principal)))
        cashDao.upsert(CashEntry(newId("cash"), dateEpochDay, "out", "debt_payment", method, "Bayar hutang: ${debt.creditor}", amount, debt.id).toEntity())
    }
}

class MovementRepository(private val dao: StockMovementDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<StockMovement> = dao.getAll().map { it.toDomain() }
    suspend fun byProduct(productId: String): List<StockMovement> = dao.byProduct(productId).map { it.toDomain() }
    suspend fun add(movement: StockMovement) {
        requireAdmin(metaRepository, "stok adjustment")
        requireValidMovement(movement)
        dao.upsert(movement.toEntity())
    }
    suspend fun clear() {
        requireAdmin(metaRepository, "hapus movement stok")
        dao.clear()
    }
}

class RejectedRepository(private val rejectedItemDao: RejectedItemDao, private val productDao: ProductDao, private val stockMovementDao: StockMovementDao, private val cashDao: CashDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<RejectedItem> = rejectedItemDao.getAll().map { it.toDomain() }
    suspend fun add(item: RejectedItem) {
        requireAdmin(metaRepository, "catat rejek")
        require(item.qty > 0) { "Jumlah barang rejek harus lebih dari 0." }
        val product = productDao.getById(item.productId) ?: error("Produk tidak ditemukan.")
        require(product.stockQty >= item.qty) { "Stok tidak cukup. Stok tersedia: ${product.stockQty} ${product.unit}." }
        rejectedItemDao.upsert(item.toEntity())
        productDao.upsert(product.copy(stockQty = product.stockQty - item.qty))
        stockMovementDao.upsert(StockMovement(newId("mv"), item.dateEpochDay, item.productId, "reject", -item.qty, "Rejek: ${item.reason} — ${item.note}", item.reason, item.estimatedLoss).toEntity())
        if (item.estimatedLoss > 0) {
            cashDao.upsert(CashEntry(newId("cash"), item.dateEpochDay, "out", "reject", PaymentMethods.NON_CASH, "Kerugian Rejek: ${item.reason}", item.estimatedLoss, item.id).toEntity())
        }
    }
    suspend fun remove(id: String) {
        requireAdmin(metaRepository, "hapus rejek")
        val item = rejectedItemDao.getById(id)?.toDomain() ?: return
        productDao.getById(item.productId)?.let { productDao.upsert(it.copy(stockQty = it.stockQty + item.qty)) }
        stockMovementDao.getAllByProduct(item.productId).filter { it.type == "reject" && it.dateEpochDay == item.dateEpochDay && abs(it.qtyDelta + item.qty) < 0.001 }.forEach { stockMovementDao.delete(it.id) }
        cashDao.deleteByRef("reject", id)
        rejectedItemDao.delete(id)
    }
}

class ActivityLogRepository(private val dao: ActivityLogDao, private val metaRepository: MetaRepository? = null) {
    private val maxLogs = 500
    suspend fun all(): List<ActivityLog> = dao.getAll().map { it.toDomain() }
    suspend fun recent(limit: Int = 100): List<ActivityLog> = all().take(limit)
    suspend fun add(log: ActivityLog) {
        dao.upsert(log.toEntity())
        all().drop(maxLogs).forEach { dao.delete(it.id) }
    }
    suspend fun log(type: String, message: String) = add(ActivityLog(newId("log"), epochDayNow(), type, "", "", message))
    suspend fun clear() {
        requireAdmin(metaRepository, "hapus log aktivitas")
        dao.clear()
    }
}

class SettingsRepository(
    private val dao: AppSettingsDao,
    private val metaRepository: MetaRepository? = null,
) {
    suspend fun get(): AppSettings = dao.get()?.toDomain() ?: AppSettings(pinEnabled = false, pinHash = "")
    suspend fun setPin(pin: String) {
        requireAdmin(metaRepository, "ubah PIN aplikasi")
        require(pin.trim().length >= 4) { "PIN minimal 4 digit." }
        dao.upsert(AppSettings(pinEnabled = true, pinHash = sha256(pin)).toEntity())
    }
    suspend fun disablePin() {
        requireAdmin(metaRepository, "nonaktifkan PIN aplikasi")
        dao.upsert(AppSettings(pinEnabled = false, pinHash = "").toEntity())
    }
    suspend fun verifyPin(pin: String): Boolean {
        val settings = get()
        return !settings.pinEnabled || sha256(pin) == settings.pinHash
    }
}

class MetaRepository(private val store: MetaStore) {
    suspend fun role(): String = store.role()
    fun roleFlow(): kotlinx.coroutines.flow.Flow<String> = store.roleFlow()
    private suspend fun requireAdmin(actionLabel: String) {
        if (store.role().trim().lowercase() == "kasir") {
            throw IllegalStateException("Aksi $actionLabel hanya tersedia untuk admin.")
        }
    }
    suspend fun setRole(value: String) {
        requireAdmin("ubah role")
        store.setRole(value)
    }
    suspend fun autoBackupEnabled(): Boolean = store.autoBackupEnabled()
    suspend fun setAutoBackupEnabled(value: Boolean) {
        requireAdmin("ubah auto backup")
        store.setAutoBackupEnabled(value)
    }
    suspend fun autoBackupDays(): Int = store.autoBackupDays()
    suspend fun setAutoBackupDays(value: Int) {
        requireAdmin("ubah interval backup")
        store.setAutoBackupDays(value)
    }
    suspend fun lastAutoBackupEpochMs(): Long = store.lastAutoBackupEpochMs()
    suspend fun setLastAutoBackupEpochMs(value: Long) {
        requireAdmin("ubah metadata backup")
        store.setLastAutoBackupEpochMs(value)
    }
    suspend fun lastAutoBackupMillis(): Long = lastAutoBackupEpochMs()
    suspend fun setLastAutoBackupMillis(value: Long) = setLastAutoBackupEpochMs(value)
    suspend fun getString(key: String, defaultValue: String = ""): String = store.getString(key, defaultValue)
    private suspend fun requireAdminForSensitiveMetaKey(key: String) {
        val lowered = key.trim().lowercase()
        val sensitive = lowered.contains("role") || lowered.contains("backup") || lowered.contains("pin")
        if (sensitive) requireAdmin("ubah konfigurasi sistem")
    }

    suspend fun setString(key: String, value: String) {
        requireAdminForSensitiveMetaKey(key)
        store.setString(key, value)
    }
    suspend fun getBoolean(key: String, defaultValue: Boolean = false): Boolean = store.getBoolean(key, defaultValue)
    suspend fun setBoolean(key: String, value: Boolean) {
        requireAdminForSensitiveMetaKey(key)
        store.setBoolean(key, value)
    }
}

class PurchaseRepository(private val purchaseDao: PurchaseDao, private val purchaseItemDao: PurchaseItemDao, private val productDao: ProductDao, private val stockMovementDao: StockMovementDao, private val cashDao: CashDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<Purchase> = purchaseDao.getAll().map { it.toDomain(purchaseItemDao.getByPurchaseId(it.id).map { item -> item.toDomain() }) }
    suspend fun getById(id: String): Purchase? = purchaseDao.getById(id)?.toDomain(purchaseItemDao.getByPurchaseId(id).map { it.toDomain() })

    suspend fun add(purchase: Purchase) {
        requireAdmin(metaRepository, "tambah pembelian")
        requireValidPurchase(purchase)
        purchase.items.forEach {
            require(it.qty > 0) { "Qty pembelian harus lebih dari 0 untuk ${it.productId}." }
            require(it.buyPrice >= 0) { "Harga beli tidak boleh negatif untuk ${it.productId}." }
            requireNotNull(productDao.getById(it.productId)) { "Produk tidak ditemukan: ${it.productId}" }
        }
        if (!purchase.paymentMethod.equals(PaymentMethods.HUTANG, true)) {
            val total = purchase.items.sumOf { it.qty * it.buyPrice }
            cashDao.upsert(CashEntry(newId("cash"), purchase.dateEpochDay, "out", "purchase", purchase.paymentMethod, if (purchase.supplier.isBlank()) "Pembelian" else "Pembelian (${purchase.supplier})", total, purchase.id).toEntity())
        }
        purchase.items.forEach { item ->
            stockMovementDao.upsert(StockMovement(newId("mv"), purchase.dateEpochDay, item.productId, "purchase", item.qty, "Pembelian#${purchase.id}").toEntity())
            val product = productDao.getById(item.productId)!!
            val oldCost = product.stockQty * product.avgHpp
            val incomingCost = item.qty * item.buyPrice
            val newQty = product.stockQty + item.qty
            productDao.upsert(product.copy(stockQty = normalizeQty(newQty), avgHpp = hppWeightedAverage(newQty, oldCost + incomingCost)))
        }
        purchaseDao.upsert(purchase.toEntity())
        purchaseItemDao.deleteByPurchaseId(purchase.id)
        purchaseItemDao.upsertAll(purchase.items.map { it.toEntity(purchase.id) })
    }

    suspend fun replace(purchase: Purchase) {
        requireAdmin(metaRepository, "ubah pembelian")
        if (purchaseDao.getById(purchase.id) != null) {
            remove(purchase.id)
        }
        add(purchase)
    }

    suspend fun remove(id: String) {
        requireAdmin(metaRepository, "hapus pembelian")
        val purchase = purchaseDao.getById(id)?.toDomain(purchaseItemDao.getByPurchaseId(id).map { it.toDomain() }) ?: run { purchaseDao.delete(id); return }
        stockMovementDao.getByTypeAndNote("purchase", "Pembelian#$id").forEach { stockMovementDao.delete(it.id) }
        purchaseDao.delete(id)
        purchaseItemDao.deleteByPurchaseId(id)
        cashDao.deleteByRef("purchase", id)
        purchase.items.map { it.productId }.toSet().forEach { productId ->
            val product = productDao.getById(productId) ?: return@forEach
            val stock = stockMovementDao.getAllByProduct(productId).sumOf { it.qtyDelta }
            var totalQty = 0.0
            var totalCost = 0.0
            all().forEach { existing ->
                existing.items.filter { it.productId == productId }.forEach { item ->
                    totalQty += item.qty
                    totalCost += item.qty * item.buyPrice
                }
            }
            productDao.upsert(product.copy(stockQty = normalizeQty(stock.coerceAtLeast(0.0)), avgHpp = if (totalQty <= 0.0) 0.0 else hppWeightedAverage(totalQty, totalCost)))
        }
    }
}

class SalesRepository(private val saleDao: SaleDao, private val saleItemDao: SaleItemDao, private val paymentSplitDao: PaymentSplitDao, private val productDao: ProductDao, private val stockMovementDao: StockMovementDao, private val cashDao: CashDao, private val metaRepository: MetaRepository? = null) {
    suspend fun all(): List<Sale> = saleDao.getAll().map { it.toDomain(saleItemDao.getBySaleId(it.id).map { item -> item.toDomain() }, paymentSplitDao.getBySaleId(it.id).map { split -> split.toDomain() }) }
    suspend fun getById(id: String): Sale? = saleDao.getById(id)?.toDomain(saleItemDao.getBySaleId(id).map { it.toDomain() }, paymentSplitDao.getBySaleId(id).map { it.toDomain() })

    suspend fun add(sale: Sale) {
        requireValidSale(sale)
        sale.items.forEach { item ->
            require(item.qty > 0) { "Qty penjualan harus lebih dari 0 untuk ${item.productId}." }
            val product = productDao.getById(item.productId) ?: error("Produk tidak ditemukan: ${item.productId}")
            require(item.qty <= product.stockQty) { "Stok tidak cukup untuk ${product.name}. Stok: ${"%.2f".format(product.stockQty)}" }
        }
        val normalizedSplits = sale.normalizedSplits
        normalizedSplits.forEach { split ->
            require(split.amount >= 0.0) { "Nominal split pembayaran tidak boleh negatif." }
            require(split.method.trim().isNotBlank()) { "Metode split pembayaran wajib diisi." }
        }
        val splitTotal = normalizedSplits.sumOf { it.amount }
        require(abs(normalizeMoney(splitTotal) - normalizeMoney(sale.totalSales)) <= 0.51) { "Pembagian pembayaran tidak sama dengan total akhir." }
        normalizedSplits.filterNot { it.method.equals(PaymentMethods.HUTANG, true) }.forEach { split ->
            cashDao.upsert(CashEntry(newId("cash"), sale.dateEpochDay, "in", "sale", split.method, if (sale.isSplitPayment) "Penjualan (${sale.paymentSummary})" else "Penjualan", split.amount, sale.id).toEntity())
        }
        sale.items.forEach { item ->
            val product = productDao.getById(item.productId)!!
            productDao.upsert(product.copy(stockQty = normalizeQty((product.stockQty - item.qty).coerceAtLeast(0.0))))
            stockMovementDao.upsert(StockMovement(newId("mv"), sale.dateEpochDay, item.productId, "sale", -item.qty, "Penjualan#${sale.id}").toEntity())
        }
        saleDao.upsert(sale.toEntity())
        saleItemDao.deleteBySaleId(sale.id)
        saleItemDao.upsertAll(sale.items.map { it.toEntity(sale.id) })
        paymentSplitDao.deleteBySaleId(sale.id)
        paymentSplitDao.upsertAll(sale.paymentSplits.map { it.toEntity(sale.id) })
    }

    suspend fun replace(sale: Sale) {
        requireAdmin(metaRepository, "ubah penjualan")
        if (saleDao.getById(sale.id) != null) {
            remove(sale.id)
        }
        add(sale)
    }

    suspend fun remove(id: String) {
        requireAdmin(metaRepository, "hapus penjualan")
        val sale = saleDao.getById(id)?.toDomain(saleItemDao.getBySaleId(id).map { it.toDomain() }, paymentSplitDao.getBySaleId(id).map { it.toDomain() }) ?: run { saleDao.delete(id); return }
        stockMovementDao.getByTypeAndNote("sale", "Penjualan#$id").forEach { stockMovementDao.delete(it.id) }
        saleDao.delete(id)
        saleItemDao.deleteBySaleId(id)
        paymentSplitDao.deleteBySaleId(id)
        cashDao.deleteByRef("sale", id)
        sale.items.map { it.productId }.toSet().forEach { productId ->
            val product = productDao.getById(productId) ?: return@forEach
            val stock = stockMovementDao.getAllByProduct(productId).sumOf { it.qtyDelta }
            productDao.upsert(product.copy(stockQty = normalizeQty(stock.coerceAtLeast(0.0))))
        }
    }
}