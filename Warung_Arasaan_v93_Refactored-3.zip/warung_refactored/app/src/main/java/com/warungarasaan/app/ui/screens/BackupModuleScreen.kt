package com.warungarasaan.app.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.viewmodel.BackupEvent
import com.warungarasaan.app.ui.viewmodel.BackupViewModel

@Composable
fun BackupModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: BackupViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // SAF launchers — must live in @Composable scope
    val exportBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null && state.exportJson.isNotBlank()) {
            context.contentResolver.openOutputStream(uri)?.use { it.write(state.exportJson.toByteArray()) }
            Toast.makeText(context, "Backup disimpan.", Toast.LENGTH_SHORT).show()
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
            vm.onEvent(BackupEvent.ImportJsonChanged(json))
        }
    }

    val exportReportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null && state.exportJson.isNotBlank()) {
            // exportJson is reused as CSV preview in this simple implementation
            Toast.makeText(context, "Laporan diekspor.", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) { vm.onEvent(BackupEvent.LoadExport) }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // Status
        item {
            SectionCard(title = "Status backup") {
                InlineLabelValue("Auto backup", if (state.autoBackup) "Aktif" else "Nonaktif")
                InlineLabelValue("Interval", "${state.backupDays} hari")
                InlineLabelValue("Backup terakhir", state.lastBackupText)
            }
        }

        // Pengaturan
        item {
            SectionCard(title = "Pengaturan backup") {
                ListItem(
                    headlineContent = { Text("Aktifkan auto backup") },
                    trailingContent = {
                        Switch(
                            checked = state.autoBackup,
                            onCheckedChange = { vm.onEvent(BackupEvent.AutoBackupChanged(it)) },
                        )
                    },
                )
                OutlinedTextField(
                    value = state.backupDays,
                    onValueChange = { vm.onEvent(BackupEvent.BackupDaysChanged(it)) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Interval backup (hari)") },
                )
                TextButton(onClick = { vm.onEvent(BackupEvent.AutoBackupChanged(state.autoBackup)) }) {
                    Text("Simpan interval")
                }
            }
        }

        // File backup
        item {
            SectionCard(title = "Backup file", subtitle = "Gunakan Storage Access Framework Android") {
                TextButton(onClick = { exportBackupLauncher.launch("warung_arasaan_backup.json") }) {
                    Text("Export backup ke file JSON")
                }
                TextButton(onClick = { importBackupLauncher.launch("application/json") }) {
                    Text("Import backup dari file")
                }
                TextButton(onClick = { exportReportLauncher.launch("laporan_stok.csv") }) {
                    Text("Export laporan stok CSV")
                }
            }
        }

        // JSON payload
        item {
            SectionCard(title = "Payload backup", subtitle = "Tersedia untuk copy-paste manual") {
                if (state.exportJson.isBlank()) {
                    EmptyHint("Belum ada payload", "Tekan export atau tunggu data ter-load.")
                } else {
                    OutlinedTextField(
                        value = state.exportJson,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 180.dp),
                        label = { Text("JSON backup") },
                    )
                }
            }
        }

        // Restore manual
        item {
            SectionCard(title = "Restore manual") {
                OutlinedTextField(
                    value = state.importJson,
                    onValueChange = { vm.onEvent(BackupEvent.ImportJsonChanged(it)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp),
                    label = { Text("Tempel JSON di sini") },
                )
                TextButton(onClick = { vm.onEvent(BackupEvent.DoRestore(context)) }) {
                    Text("Restore JSON manual")
                }
            }
        }

        // Status pesan
        item {
            if (state.resultMessage.isNotBlank()) {
                Text(state.resultMessage)
            }
        }
    }
}
