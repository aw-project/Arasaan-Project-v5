package com.warungarasaan.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.domain.model.ActivityLog
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.theme.WarungColors
import com.warungarasaan.app.ui.viewmodel.HomeViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

// ─── Data ──────────────────────────────────────────────────────────────────────
private data class QuickBtn(
    val label: String,
    val icon: ImageVector,
    val route: String,
    val primary: Boolean = false,
)

@Composable
fun HomeHubScreen(
    container: AppContainer,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
    vm: HomeViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val greeting = _greeting()
    var insightExpanded by remember { mutableStateOf(false) }

    // Refresh on every compose (tab revisit)
    LaunchedEffect(Unit) { vm.load() }

    val quickBtns = listOf(
        QuickBtn("Kasir Cepat", Icons.Rounded.FlashOn,      "fast_pos",  primary = true),
        QuickBtn("Jual Biasa",  Icons.Rounded.PointOfSale,  "sales"),
        QuickBtn("Belanja Stok",  Icons.Rounded.ShoppingCart, "purchases"),
        QuickBtn("Pengeluaran",       Icons.Rounded.RequestQuote, "expenses"),
    )

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(bottom = 100.dp),
    ) {
        // ── Zone 1: Hero ──────────────────────────────────────────────────
        item {
            _HeroHeader(
                greeting   = greeting,
                role       = state.activeRole,
                omzet      = state.omzetToday,
                laba       = state.labaToday,
                omzet7     = state.omzet7,
                omzet30    = state.omzet30,
            )
        }

        // ── Zone 2: Compact Stat Row ──────────────────────────────────────
        item {
            Spacer(Modifier.height(16.dp))
            _StatRow(
                saldoKas    = state.saldoKas,
                txCount     = state.txCount,
                activeDebts = state.activeDebts,
                lowStock    = state.lowStockCount,
                modifier    = Modifier.padding(horizontal = 16.dp),
            )
        }

        // ── Zone 3: Quick Actions 2×2 ─────────────────────────────────────
        item {
            Spacer(Modifier.height(20.dp))
            _SectionLabel("Aksi Cepat", Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(10.dp))
            _QuickActions2x2(
                buttons    = quickBtns,
                onNavigate = onNavigate,
                modifier   = Modifier.padding(horizontal = 16.dp),
            )
        }

        item {
            Spacer(Modifier.height(12.dp))
            _SmartCard(
                icon = Icons.Rounded.TipsAndUpdates,
                iconColor = WarungColors.Primary,
                title = "Panduan Singkat",
                badge = "Mode mudah",
                modifier = Modifier.padding(horizontal = 16.dp),
            ) {
                Text("1. Tekan Kasir Cepat untuk jualan harian.")
                Text("2. Tekan Belanja Stok saat menambah barang masuk.")
                Text("3. Tekan Pengeluaran untuk catat uang keluar.")
                Text("4. Cek Stok Menipis agar tidak kehabisan barang.")
            }
        }

        // ── Zone 4A: Stok Menipis ─────────────────────────────────────────
        item {
            Spacer(Modifier.height(20.dp))
            _SmartCard(
                icon       = Icons.Rounded.Inventory2,
                iconColor  = if (state.lowStockCount == 0) WarungColors.Positive else Color(0xFFC62828),
                title      = "Stok Menipis",
                badge      = if (state.lowStockCount == 0) "Aman" else "${state.lowStockCount} item",
                badgeColor = if (state.lowStockCount == 0) WarungColors.Positive else Color(0xFFC62828),
                modifier   = Modifier.padding(horizontal = 16.dp),
            ) {
                if (state.lowStockCount == 0) {
                    _EmptyCardState(Icons.Rounded.CheckCircle, "Semua stok aman.", positive = true)
                } else {
                    state.lowStockItems.forEach { (name, qty) ->
                        ListItem(
                            headlineContent   = { Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text(qty,  style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                            leadingContent = {
                                Box(
                                    modifier = Modifier.size(8.dp).clip(CircleShape)
                                        .background(Color(0xFFC62828))
                                )
                            },
                            modifier = Modifier.padding(horizontal = 2.dp),
                        )
                    }
                }
            }
        }

        // ── Zone 4B: Terlaris Hari Ini ────────────────────────────────────
        item {
            Spacer(Modifier.height(12.dp))
            _SmartCard(
                icon      = Icons.Rounded.LocalFireDepartment,
                iconColor = Color(0xFFE65100),
                title     = "Terlaris Hari Ini",
                badge     = "${state.topSold.size} produk",
                modifier  = Modifier.padding(horizontal = 16.dp),
            ) {
                if (state.topSold.isEmpty()) {
                    _EmptyCardState(Icons.Rounded.Storefront, "Belum ada penjualan hari ini.")
                } else {
                    state.topSold.forEach { (rank, name, qty) ->
                        val rankColor = when (rank) {
                            "1" -> Color(0xFFD4A017); "2" -> Color(0xFF9E9E9E); else -> Color(0xFFBF7D43)
                        }
                        ListItem(
                            headlineContent   = { Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Terjual: $qty", style = MaterialTheme.typography.bodySmall) },
                            leadingContent = {
                                Box(
                                    modifier = Modifier.size(22.dp).clip(CircleShape)
                                        .background(rankColor.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center,
                                ) { Text(rank, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = rankColor) }
                            },
                            modifier = Modifier.padding(horizontal = 2.dp),
                        )
                    }
                }
            }
        }

        // ── Zone 4C: Tren & Prediksi ─────────────────────────────────────
        item {
            Spacer(Modifier.height(12.dp))
            _SmartCard(
                icon      = Icons.Rounded.ShowChart,
                iconColor = WarungColors.Primary,
                title     = "Tren Omzet",
                badge     = "7 & 30 Hari",
                modifier  = Modifier.padding(horizontal = 16.dp),
            ) {
                _TrendRow("Omzet 7 hari",  UiFormat.money(state.omzet7))
                Divider(modifier = Modifier.padding(horizontal = 14.dp), thickness = 0.5.dp)
                _TrendRow("Omzet 30 hari", UiFormat.money(state.omzet30))
            }
        }

        // ── Zone 5: Expandable Detail ─────────────────────────────────────
        item {
            Spacer(Modifier.height(12.dp))
            _ExpandToggle(
                expanded = state.isLoading.not(),  // use local state for expand
                onToggle = { insightExpanded = !insightExpanded },
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        item {
            AnimatedVisibility(
                visible = true,
                enter = expandVertically(animationSpec = tween(260)),
                exit  = shrinkVertically(animationSpec = tween(200)),
            ) {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(12.dp))
                    // Prioritas Bisnis
                    if (state.decisionText.isNotBlank()) {
                        _SmartCard(
                            icon = Icons.Rounded.TipsAndUpdates,
                            iconColor = WarungColors.Gold,
                            title = "Prioritas Bisnis",
                            badge = "AI Insight",
                        ) {
                            Padding14 { Text(state.decisionText, style = MaterialTheme.typography.bodyMedium) }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                    // Aktivitas terbaru
                    _SmartCard(
                        icon = Icons.Rounded.History,
                        iconColor = WarungColors.PrimaryLight,
                        title = "Aktivitas Terbaru",
                        badge = "${state.recentLogs.size} entri",
                    ) {
                        if (state.recentLogs.isEmpty()) {
                            _EmptyCardState(Icons.Rounded.Info, "Belum ada aktivitas tercatat.")
                        } else {
                            state.recentLogs.forEach { log ->
                                ListItem(
                                    headlineContent = { Text(log.type.ifBlank { "Aktivitas" }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = { Text(UiFormat.date(log.dateEpochDay), style = MaterialTheme.typography.bodySmall) },
                                    leadingContent = {
                                        Box(
                                            modifier = Modifier.size(6.dp).clip(CircleShape)
                                                .background(WarungColors.PrimaryLight)
                                        )
                                    },
                                    modifier = Modifier.padding(horizontal = 2.dp),
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ─── Private helpers ──────────────────────────────────────────────────────────

@Composable
private fun Padding14(content: @Composable () -> Unit) {
    Box(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) { content() }
}

private fun _greeting(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when {
        h < 12 -> "Selamat pagi"
        h < 15 -> "Selamat siang"
        h < 18 -> "Selamat sore"
        else   -> "Selamat malam"
    }
}

// ─── Hero Header ──────────────────────────────────────────────────────────────
@Composable
private fun _HeroHeader(
    greeting: String,
    role: String,
    omzet: Double,
    laba: Double,
    omzet7: Double,
    omzet30: Double,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0xFF073D25), Color(0xFF0F6040))
                )
            )
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        greeting,
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(
                        UiFormat.dateToday(),
                        color = Color.White.copy(alpha = 0.5f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                // Trend pills + role badge
                Column(horizontalAlignment = Alignment.End) {
                    _TrendPill("7h",  omzet7)
                    Spacer(Modifier.height(4.dp))
                    _TrendPill("30h", omzet30)
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.15f),
                    ) {
                        Text(
                            role.replaceFirstChar { it.uppercase() },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            color = Color.White.copy(alpha = 0.9f),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth()) {
                _HeroStat("Omzet Hari Ini", UiFormat.money(omzet), Icons.Rounded.BarChart, Modifier.weight(1f))
                Box(
                    Modifier
                        .width(1.dp).height(44.dp)
                        .background(Color.White.copy(alpha = 0.18f))
                        .padding(horizontal = 16.dp)
                )
                Spacer(Modifier.width(16.dp))
                _HeroStat("Laba Bersih", UiFormat.money(laba), Icons.Rounded.TrendingUp, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun _TrendPill(label: String, value: Double) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.1f),
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, color = Color.White.copy(alpha = 0.55f), fontSize = 9.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(4.dp))
            Text(UiFormat.money(value), color = Color.White.copy(alpha = 0.9f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun _HeroStat(label: String, value: String, icon: ImageVector, modifier: Modifier) {
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, color = Color.White.copy(alpha = 0.65f), fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.5).sp,
            maxLines = 1,
        )
    }
}

// ─── Compact Stat Row ─────────────────────────────────────────────────────────
@Composable
private fun _StatRow(
    saldoKas: Double,
    txCount: Int,
    activeDebts: Int,
    lowStock: Int,
    modifier: Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(
            Modifier.padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            _StatChip(Icons.Rounded.AccountBalanceWallet, "Kas",        UiFormat.money(saldoKas), WarungColors.Primary)
            _VDivider()
            _StatChip(Icons.Rounded.ReceiptLong,         "Transaksi",   "${txCount}×",             Color(0xFFC05300))
            _VDivider()
            _StatChip(Icons.Rounded.Payments,            "Hutang",      "$activeDebts",            if (activeDebts > 0) WarungColors.Warning else WarungColors.Positive)
            _VDivider()
            _StatChip(Icons.Rounded.Inventory2,          "Stok Kritis", "$lowStock",               if (lowStock > 0) Color(0xFFC62828) else WarungColors.Positive)
        }
    }
}

@Composable
private fun _VDivider() {
    Divider(modifier = Modifier.height(32.dp).width(1.dp), color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun _StatChip(icon: ImageVector, label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        Spacer(Modifier.height(3.dp))
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, maxLines = 1)
        Text(label, fontSize = 9.sp,  fontWeight = FontWeight.Medium,    color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ─── Quick Actions 2×2 ────────────────────────────────────────────────────────
@Composable
private fun _QuickActions2x2(
    buttons: List<QuickBtn>,
    onNavigate: (String) -> Unit,
    modifier: Modifier,
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        buttons.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { btn ->
                    _QBtn(btn = btn, onClick = { onNavigate(btn.route) }, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun _QBtn(btn: QuickBtn, onClick: () -> Unit, modifier: Modifier) {
    Surface(
        modifier  = modifier.height(48.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        shape     = RoundedCornerShape(14.dp),
        color     = if (btn.primary) WarungColors.Gold else MaterialTheme.colorScheme.surface,
        border    = if (btn.primary) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        tonalElevation = if (btn.primary) 4.dp else 0.dp,
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start,
        ) {
            Icon(
                btn.icon,
                contentDescription = null,
                tint = if (btn.primary) Color.White else WarungColors.Primary,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                btn.label,
                style = MaterialTheme.typography.labelLarge,
                color = if (btn.primary) Color.White else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

// ─── Smart Card ───────────────────────────────────────────────────────────────
@Composable
private fun _SmartCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    badge: String,
    badgeColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column {
            // Header with left accent
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                // Left accent bar
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(44.dp)
                        .background(WarungColors.Primary)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier.size(28.dp).clip(RoundedCornerShape(8.dp))
                            .background(iconColor.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(15.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = badgeColor.copy(alpha = 0.1f),
                    ) {
                        Text(
                            badge,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = badgeColor,
                        )
                    }
                }
            }
            Divider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            content()
        }
    }
}

@Composable
private fun _EmptyCardState(icon: ImageVector, message: String, positive: Boolean = false) {
    val color = if (positive) WarungColors.Positive else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(message, style = MaterialTheme.typography.bodySmall, color = color, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun _TrendRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

// ─── Expand Toggle ────────────────────────────────────────────────────────────
@Composable
private fun _ExpandToggle(expanded: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    Surface(
        modifier  = modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onToggle),
        shape     = RoundedCornerShape(14.dp),
        color     = MaterialTheme.colorScheme.surface,
        border    = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier.size(26.dp).clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    contentDescription = null,
                    tint = WarungColors.Primary,
                    modifier = Modifier.size(16.dp),
                )
            }
            Spacer(Modifier.width(10.dp))
            Text(
                if (expanded) "Sembunyikan Detail" else "Lihat Detail & Aktivitas",
                style = MaterialTheme.typography.labelLarge,
                color = WarungColors.Primary,
                modifier = Modifier.weight(1f),
            )
            Text(
                "Insight • Log",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun _SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text, modifier = modifier,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
    )
}
