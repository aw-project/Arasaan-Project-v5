package com.warungarasaan.app.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.local.AppDatabase
import com.warungarasaan.app.data.repository.*
import com.warungarasaan.app.data.service.*
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ─────────────────────────────────────────────────────────────────────────────
// ANALYTICS
// ─────────────────────────────────────────────────────────────────────────────

data class AnalyticsState(
    val rangeDays: Int = 30,
    val horizonDays: Int = 14,
    val topSelling: List<ProductKpi> = emptyList(),
    val topProfit: List<ProductKpi> = emptyList(),
    val lowMargin: List<Pair<Product, Double>> = emptyList(),
    val forecast: List<ForecastKpi> = emptyList(),
    val supplierSpend: List<Pair<String, Double>> = emptyList(),
    val customerRevenue: List<Pair<String, Double>> = emptyList(),
    val supplierInsights: List<SupplierInsight> = emptyList(),
    val purchaseTrends: List<PurchasePriceTrend> = emptyList(),
    val profitAlerts: List<ProfitAlert> = emptyList(),
    val supplierScorecards: List<SupplierScorecard> = emptyList(),
    val salePriceRecommendations: List<SalePriceRecommendation> = emptyList(),
    val marginDropAlerts: List<MarginDropAlert> = emptyList(),
    val smartRestock: List<SmartRestockKpi> = emptyList(),
    val decisionSummary: BusinessDecisionSummary? = null,
    val businessActions: List<BusinessActionItem> = emptyList(),
    val supplierRestockPriorities: List<SupplierRestockPriority> = emptyList(),
    val isLoading: Boolean = false,
)

sealed interface AnalyticsEvent {
    data class RangeDaysChanged(val days: Int) : AnalyticsEvent
    data class HorizonDaysChanged(val days: Int) : AnalyticsEvent
}

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val salesRepo: SalesRepository,
    private val purchaseRepo: PurchaseRepository,
    private val productRepo: ProductRepository,
    private val expenseRepo: ExpenseRepository,
    private val rejectedRepo: RejectedRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(AnalyticsState())
    val state: StateFlow<AnalyticsState> = _state.asStateFlow()

    init { load(30, 14) }

    fun onEvent(event: AnalyticsEvent) {
        when (event) {
            is AnalyticsEvent.RangeDaysChanged -> {
                _state.update { it.copy(rangeDays = event.days) }
                load(event.days, _state.value.horizonDays)
            }
            is AnalyticsEvent.HorizonDaysChanged -> {
                _state.update { it.copy(horizonDays = event.days) }
                load(_state.value.rangeDays, event.days)
            }
        }
    }

    private fun load(rangeDays: Int, horizonDays: Int) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching {
                val sales = salesRepo.all()
                val purchases = purchaseRepo.all()
                val products = productRepo.all()
                val expenses = expenseRepo.all()
                val rejected = rejectedRepo.all()
                val service = AnalyticsService()
                _state.update {
                    it.copy(
                        topSelling = service.topSelling(sales, products, rangeDays).take(10),
                        topProfit = service.topProfit(sales, products, rangeDays).take(10),
                        lowMargin = service.lowMarginProducts(products),
                        forecast = service.restockForecast(sales, products, horizonDays),
                        supplierSpend = service.supplierSpend(purchases),
                        customerRevenue = service.customerRevenue(sales),
                        supplierInsights = service.supplierInsights(purchases),
                        purchaseTrends = service.purchasePriceTrends(purchases, products),
                        profitAlerts = service.profitAlerts(products),
                        supplierScorecards = service.supplierScorecards(purchases),
                        salePriceRecommendations = service.salePriceRecommendations(products),
                        marginDropAlerts = service.marginDropAlerts(purchases, products),
                        smartRestock = service.smartRestock(sales, products, horizonDays),
                        decisionSummary = service.businessDecisionSummary(sales, purchases, products),
                        businessActions = service.businessActionItems(sales, purchases, products),
                        supplierRestockPriorities = service.supplierRestockPriorities(sales, purchases, products),
                        isLoading = false,
                    )
                }
            }.onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SEARCH
// ─────────────────────────────────────────────────────────────────────────────

data class SearchHit(
    val kind: String,
    val title: String,
    val subtitle: String,
    val trailing: String,
    val score: Int,
    val routeTarget: String,
)

data class SearchState(
    val query: String = "",
    val moduleFilter: String = "Semua",
    val hits: List<SearchHit> = emptyList(),
    val recentQueries: List<String> = emptyList(),
    val isLoading: Boolean = false,
)

sealed interface SearchEvent {
    data class QueryChanged(val q: String) : SearchEvent
    data class ModuleFilterChanged(val filter: String) : SearchEvent
    data object ClearQuery : SearchEvent
}

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val productRepo: ProductRepository,
    private val salesRepo: SalesRepository,
    private val purchaseRepo: PurchaseRepository,
    private val debtRepo: DebtRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(SearchState())
    val state: StateFlow<SearchState> = _state.asStateFlow()

    fun onEvent(event: SearchEvent) {
        when (event) {
            is SearchEvent.QueryChanged -> {
                _state.update { it.copy(query = event.q) }
                if (event.q.trim().length >= 2) search(event.q, _state.value.moduleFilter)
                else _state.update { it.copy(hits = emptyList()) }
            }
            is SearchEvent.ModuleFilterChanged -> {
                _state.update { it.copy(moduleFilter = event.filter) }
                search(_state.value.query, event.filter)
            }
            is SearchEvent.ClearQuery -> _state.update { it.copy(query = "", hits = emptyList()) }
        }
    }

    private fun search(query: String, filter: String) {
        val q = query.trim().lowercase()
        if (q.length < 2) return
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching {
                val hits = mutableListOf<SearchHit>()
                if (filter == "Semua" || filter == "Produk") {
                    productRepo.all().filter {
                        it.name.lowercase().contains(q) || it.sku.lowercase().contains(q) || it.category.lowercase().contains(q)
                    }.take(10).forEach {
                        hits += SearchHit("Produk", it.name, "${it.category} • stok ${it.stockQty} ${it.unit}", "Rp${it.activeSellPrice.toLong()}", 50, "products")
                    }
                }
                if (filter == "Semua" || filter == "Penjualan") {
                    salesRepo.all().filter {
                        it.customerName.lowercase().contains(q) || it.id.lowercase().contains(q)
                    }.take(10).forEach {
                        hits += SearchHit("Penjualan", it.id, it.customerName.ifBlank { "Tanpa nama" }, "Rp${it.totalSales.toLong()}", 40, "sales")
                    }
                }
                if (filter == "Semua" || filter == "Pembelian") {
                    purchaseRepo.all().filter {
                        it.supplier.lowercase().contains(q) || it.id.lowercase().contains(q)
                    }.take(10).forEach {
                        hits += SearchHit("Pembelian", it.id, it.supplier.ifBlank { "Tanpa supplier" }, it.paymentMethod, 35, "purchases")
                    }
                }
                if (filter == "Semua" || filter == "Hutang") {
                    debtRepo.all().filter {
                        it.creditor.lowercase().contains(q) || it.note.lowercase().contains(q)
                    }.take(10).forEach {
                        hits += SearchHit("Hutang", it.creditor, it.note, "Sisa Rp${it.remaining.toLong()}", 30, "finance")
                    }
                }
                _state.update { it.copy(hits = hits.sortedByDescending { h -> h.score }, isLoading = false) }
            }.onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// BACKUP
// ─────────────────────────────────────────────────────────────────────────────

data class BackupState(
    val exportJson: String = "",
    val importJson: String = "",
    val resultMessage: String = "",
    val autoBackup: Boolean = false,
    val backupDays: String = "7",
    val lastBackupText: String = "Belum pernah",
    val isLoading: Boolean = false,
)

sealed interface BackupEvent {
    data object LoadExport : BackupEvent
    data class ImportJsonChanged(val json: String) : BackupEvent
    data class BackupDaysChanged(val days: String) : BackupEvent
    data class AutoBackupChanged(val enabled: Boolean) : BackupEvent
    data class DoRestore(val context: Context) : BackupEvent
    data object ClearMessage : BackupEvent
}

@HiltViewModel
class BackupViewModel @Inject constructor(
    private val productRepo: ProductRepository,
    private val purchaseRepo: PurchaseRepository,
    private val salesRepo: SalesRepository,
    private val expenseRepo: ExpenseRepository,
    private val debtRepo: DebtRepository,
    private val movementRepo: MovementRepository,
    private val cashRepo: CashRepository,
    private val rejectedRepo: RejectedRepository,
    private val activityLogRepo: ActivityLogRepository,
    private val settingsRepo: SettingsRepository,
    private val metaRepo: MetaRepository,
    private val database: AppDatabase,
) : ViewModel() {

    private val _state = MutableStateFlow(BackupState())
    val state: StateFlow<BackupState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val autoBackup = metaRepo.autoBackupEnabled()
            val days = metaRepo.autoBackupDays()
            val lastMs = metaRepo.lastAutoBackupEpochMs()
            val lastText = if (lastMs == 0L) "Belum pernah"
            else java.text.SimpleDateFormat("dd MMM yyyy HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date(lastMs))
            _state.update { it.copy(autoBackup = autoBackup, backupDays = days.toString(), lastBackupText = lastText) }
        }
    }

    fun onEvent(event: BackupEvent) {
        when (event) {
            is BackupEvent.LoadExport -> viewModelScope.launch {
                _state.update { it.copy(isLoading = true) }
                runCatching {
                    val json = BackupService.exportJson(
                        products = productRepo.all(),
                        purchases = purchaseRepo.all(),
                        sales = salesRepo.all(),
                        expenses = expenseRepo.all(),
                        debts = debtRepo.all(),
                        movements = movementRepo.all(),
                        cash = cashRepo.all(),
                        rejectedItems = rejectedRepo.all(),
                        activityLogs = activityLogRepo.all(),
                        settings = settingsRepo.get(),
                    )
                    _state.update { it.copy(exportJson = json, isLoading = false) }
                }.onFailure { e -> _state.update { it.copy(resultMessage = "Gagal export: ${e.message}", isLoading = false) } }
            }
            is BackupEvent.ImportJsonChanged -> _state.update { it.copy(importJson = event.json) }
            is BackupEvent.BackupDaysChanged -> _state.update { it.copy(backupDays = event.days) }
            is BackupEvent.AutoBackupChanged -> viewModelScope.launch {
                metaRepo.setAutoBackupEnabled(event.enabled)
                metaRepo.setAutoBackupDays(_state.value.backupDays.toIntOrNull() ?: 7)
                _state.update { it.copy(autoBackup = event.enabled, resultMessage = "Pengaturan backup disimpan.") }
            }
            is BackupEvent.DoRestore -> viewModelScope.launch {
                val json = _state.value.importJson.trim()
                if (json.isBlank()) { _state.update { it.copy(resultMessage = "JSON kosong.") }; return@launch }
                _state.update { it.copy(isLoading = true) }
                runCatching {
                    BackupService.restoreJson(database, json)
                    _state.update { it.copy(resultMessage = "Restore berhasil!", isLoading = false) }
                }.onFailure { e -> _state.update { it.copy(resultMessage = "Gagal restore: ${e.message}", isLoading = false) } }
            }
            is BackupEvent.ClearMessage -> _state.update { it.copy(resultMessage = "") }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FAST POS
// ─────────────────────────────────────────────────────────────────────────────

data class FastPosState(
    val products: List<Product> = emptyList(),
    val query: String = "",
    val selected: Map<String, Int> = emptyMap(),
    val paymentMethod: String = "Cash",
    val customerName: String = "",
    val discountText: String = "0",
    val cashReceivedText: String = "0",
    val message: String = "",
    val isLoading: Boolean = false,
    val showCheckout: Boolean = false,
    val lastSale: Sale? = null,
) {
    val filteredProducts: List<Product> get() {
        val q = query.trim().lowercase()
        return if (q.isBlank()) products
        else products.filter {
            it.name.lowercase().contains(q) ||
            it.sku.lowercase().contains(q) ||
            it.category.lowercase().contains(q)
        }
    }
    val cartTotal: Double get() = selected.entries.sumOf { (id, qty) ->
        (products.firstOrNull { it.id == id }?.activeSellPrice ?: 0.0) * qty
    }
    val discountAmount: Double get() = discountText.toDoubleOrNull() ?: 0.0
    val grandTotal: Double get() = (cartTotal - discountAmount).coerceAtLeast(0.0)
    val cashReceived: Double get() = cashReceivedText.toDoubleOrNull() ?: 0.0
    val kembalian: Double get() = (cashReceived - grandTotal).coerceAtLeast(0.0)
}

sealed interface FastPosEvent {
    data class QueryChanged(val q: String) : FastPosEvent
    data class AddToCart(val productId: String) : FastPosEvent
    data class RemoveFromCart(val productId: String) : FastPosEvent
    data class SetQty(val productId: String, val qty: Int) : FastPosEvent
    data object ClearCart : FastPosEvent
    data class PaymentMethodChanged(val method: String) : FastPosEvent
    data class CustomerNameChanged(val name: String) : FastPosEvent
    data class DiscountChanged(val text: String) : FastPosEvent
    data class CashReceivedChanged(val text: String) : FastPosEvent
    data object ShowCheckout : FastPosEvent
    data object DismissCheckout : FastPosEvent
    data object Checkout : FastPosEvent
    data object ClearMessage : FastPosEvent
}

@HiltViewModel
class FastPosViewModel @Inject constructor(
    private val productRepo: ProductRepository,
    private val salesRepo: SalesRepository,
    private val activityLogRepo: ActivityLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(FastPosState())
    val state: StateFlow<FastPosState> = _state.asStateFlow()

    init { loadProducts() }

    private fun loadProducts() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            runCatching { productRepo.all() }
                .onSuccess { list -> _state.update { it.copy(products = list, isLoading = false) } }
                .onFailure { _state.update { it.copy(isLoading = false) } }
        }
    }

    fun onEvent(event: FastPosEvent) {
        when (event) {
            is FastPosEvent.QueryChanged -> _state.update { it.copy(query = event.q) }
            is FastPosEvent.AddToCart -> _state.update {
                val current = it.selected[event.productId] ?: 0
                it.copy(selected = it.selected + (event.productId to current + 1))
            }
            is FastPosEvent.RemoveFromCart -> _state.update {
                val current = it.selected[event.productId] ?: 0
                val newMap = if (current <= 1) it.selected - event.productId
                else it.selected + (event.productId to current - 1)
                it.copy(selected = newMap)
            }
            is FastPosEvent.SetQty -> _state.update {
                val newMap = if (event.qty <= 0) it.selected - event.productId
                else it.selected + (event.productId to event.qty)
                it.copy(selected = newMap)
            }
            is FastPosEvent.ClearCart -> _state.update { it.copy(selected = emptyMap(), discountText = "0", cashReceivedText = "0") }
            is FastPosEvent.PaymentMethodChanged -> _state.update { it.copy(paymentMethod = event.method) }
            is FastPosEvent.CustomerNameChanged -> _state.update { it.copy(customerName = event.name) }
            is FastPosEvent.DiscountChanged -> _state.update { it.copy(discountText = event.text) }
            is FastPosEvent.CashReceivedChanged -> _state.update { it.copy(cashReceivedText = event.text) }
            is FastPosEvent.ShowCheckout -> _state.update { it.copy(showCheckout = true) }
            is FastPosEvent.DismissCheckout -> _state.update { it.copy(showCheckout = false) }
            is FastPosEvent.ClearMessage -> _state.update { it.copy(message = "") }
            is FastPosEvent.Checkout -> viewModelScope.launch {
                val s = _state.value
                if (s.selected.isEmpty()) { _state.update { it.copy(message = "Keranjang kosong.") }; return@launch }
                _state.update { it.copy(isLoading = true) }
                runCatching {
                    val items = s.selected.mapNotNull { (id, qty) ->
                        val p = s.products.firstOrNull { it.id == id } ?: return@mapNotNull null
                        SaleItem(p.id, qty.toDouble(), p.activeSellPrice, p.avgHpp)
                    }
                    val sale = Sale(
                        id = AppUtils.newId("sale"),
                        dateEpochDay = AppUtils.epochDayNow(),
                        items = items,
                        paymentMethod = s.paymentMethod,
                        customerName = s.customerName,
                        discountAmount = s.discountAmount,
                    )
                    salesRepo.add(sale)
                    activityLogRepo.log("fastpos_sale", "FastPOS sale ${sale.id} total Rp${sale.totalSales.toLong()}")
                    _state.update {
                        it.copy(
                            selected = emptyMap(), discountText = "0", cashReceivedText = "0",
                            customerName = "", showCheckout = false, lastSale = sale,
                            message = "Transaksi berhasil! Kembalian Rp${it.kembalian.toLong()}",
                            isLoading = false,
                        )
                    }
                    loadProducts()
                }.onFailure { e -> _state.update { it.copy(message = e.message ?: "Gagal checkout.", isLoading = false) } }
            }
        }
    }
}
