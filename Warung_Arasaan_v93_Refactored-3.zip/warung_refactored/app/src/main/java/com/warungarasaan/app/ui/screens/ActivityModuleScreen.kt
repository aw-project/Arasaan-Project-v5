package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.viewmodel.ActivityViewModel

@Composable
fun ActivityModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: ActivityViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    Scaffold(modifier = modifier) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier,
        ) {
            if (state.activities.isEmpty()) {
                item { EmptyHint("Belum ada log", "Tambahkan data di modul lain untuk melihat audit trail.") }
            } else {
                items(state.activities, key = { it.id }) { log ->
                    ListItem(
                        headlineContent = { Text(log.type) },
                        supportingContent = { Text(log.newJson.ifBlank { log.oldJson }.ifBlank { "-" }) },
                        overlineContent = { Text(UiFormat.date(log.dateEpochDay)) },
                    )
                }
                item {
                    TextButton(onClick = { vm.load() }) { Text("Refresh") }
                }
            }
        }
    }
}
