package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.ui.UiFormat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.warungarasaan.app.ui.viewmodel.CashViewModel
import com.warungarasaan.app.ui.viewmodel.CashEvent
import com.warungarasaan.app.ui.redesign.CashRowUi
import com.warungarasaan.app.ui.redesign.NativeCashScreen

@Composable
fun NativeCashModuleScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    vm: CashViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()

    val rows = state.entries.map {
        CashRowUi(
            id = it.id,
            title = it.note.ifBlank { it.source.ifBlank { "Kas" } },
            subtitle = "${UiFormat.date(it.dateEpochDay)} • ${it.method} • ${it.source}",
            amount = UiFormat.money(it.amount),
            isInflow = it.direction.equals("in", true),
        )
    }
    val cashOnly = state.entries.filter { PaymentMethods.isCashFlow(it.method) }
    val inAmount = cashOnly.filter { it.direction.equals("in", true) }.sumOf { it.amount }
    val outAmount = cashOnly.filter { it.direction.equals("out", true) }.sumOf { it.amount }

    NativeCashScreen(
        rows = rows,
        balance = UiFormat.money(inAmount - outAmount),
        totalIn = UiFormat.money(inAmount),
        totalOut = UiFormat.money(outAmount),
        modifier = modifier,
    )
}