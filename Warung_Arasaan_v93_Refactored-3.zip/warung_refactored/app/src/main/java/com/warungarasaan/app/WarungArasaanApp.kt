package com.warungarasaan.app

import android.app.Application
import com.warungarasaan.app.data.local.AppDatabase
import com.warungarasaan.app.data.local.MetaStore
import com.warungarasaan.app.data.repository.*
import com.warungarasaan.app.data.service.UnitMigrationService
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@HiltAndroidApp
class WarungArasaanApp : Application() {
    lateinit var container: AppContainer
        private set

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.create(this)
        val metaStore = MetaStore(this)
        val metaRepository = MetaRepository(metaStore)
        container = AppContainer(
            database = database,
            productRepository = ProductRepository(database.productDao(), metaRepository),
            purchaseRepository = PurchaseRepository(
                purchaseDao = database.purchaseDao(),
                purchaseItemDao = database.purchaseItemDao(),
                productDao = database.productDao(),
                stockMovementDao = database.stockMovementDao(),
                cashDao = database.cashDao(),
                metaRepository = metaRepository,
            ),
            salesRepository = SalesRepository(
                saleDao = database.saleDao(),
                saleItemDao = database.saleItemDao(),
                paymentSplitDao = database.paymentSplitDao(),
                productDao = database.productDao(),
                stockMovementDao = database.stockMovementDao(),
                cashDao = database.cashDao(),
                metaRepository = metaRepository,
            ),
            expenseRepository = ExpenseRepository(
                expenseDao = database.expenseDao(),
                cashDao = database.cashDao(),
                metaRepository = metaRepository,
            ),
            debtRepository = DebtRepository(
                debtDao = database.debtDao(),
                cashDao = database.cashDao(),
                metaRepository = metaRepository,
            ),
            cashRepository = CashRepository(database.cashDao(), metaRepository),
            movementRepository = MovementRepository(database.stockMovementDao(), metaRepository),
            rejectedRepository = RejectedRepository(
                rejectedItemDao = database.rejectedItemDao(),
                productDao = database.productDao(),
                stockMovementDao = database.stockMovementDao(),
                cashDao = database.cashDao(),
                metaRepository = metaRepository,
            ),
            activityLogRepository = ActivityLogRepository(database.activityLogDao(), metaRepository),
            settingsRepository = SettingsRepository(database.appSettingsDao(), metaRepository),
            metaRepository = metaRepository,
        )

        applicationScope.launch {
            UnitMigrationService(
                productRepository = container.productRepository,
                purchaseRepository = container.purchaseRepository,
                salesRepository = container.salesRepository,
                movementRepository = container.movementRepository,
                metaRepository = container.metaRepository,
            ).migrateKgToGramOnce()
        }
    }
}

data class AppContainer(
    val database: AppDatabase,
    val productRepository: ProductRepository,
    val purchaseRepository: PurchaseRepository,
    val salesRepository: SalesRepository,
    val expenseRepository: ExpenseRepository,
    val debtRepository: DebtRepository,
    val cashRepository: CashRepository,
    val movementRepository: MovementRepository,
    val rejectedRepository: RejectedRepository,
    val activityLogRepository: ActivityLogRepository,
    val settingsRepository: SettingsRepository,
    val metaRepository: MetaRepository,
)
