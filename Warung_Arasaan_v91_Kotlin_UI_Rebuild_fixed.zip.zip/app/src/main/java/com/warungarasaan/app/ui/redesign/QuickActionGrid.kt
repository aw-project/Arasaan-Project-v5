package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.warungarasaan.app.ui.theme.WarungColors

data class QuickAction(
    val label: String,
    val icon: ImageVector,
    val route: String,
    val primary: Boolean = false,
)

fun defaultQuickActions(): List<QuickAction> = listOf(
    QuickAction("Fast POS",   Icons.Rounded.PointOfSale,  "fast_pos",   primary = true),
    QuickAction("Catat Jual", Icons.Rounded.ArrowUpward,  "sales"),
    QuickAction("Catat Beli", Icons.Rounded.ArrowDownward,"purchases"),
    QuickAction("Biaya",      Icons.Rounded.Payments,     "expenses"),
)

@Composable
fun QuickActionGrid(
    actions: List<QuickAction> = defaultQuickActions(),
    onAction: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        actions.forEach { action ->
            _QaTile(
                action  = action,
                onClick = { onAction(action.route) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun _QaTile(
    action: QuickAction,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val bgColor  = if (action.primary) WarungColors.Green800 else MaterialTheme.colorScheme.surface
    val iconTint = if (action.primary) Color.White else MaterialTheme.colorScheme.primary
    val textColor= if (action.primary) Color.White else MaterialTheme.colorScheme.onSurface

    Box(
        modifier = modifier
            .height(64.dp)
            .then(
                if (action.primary) Modifier.shadow(
                    8.dp, RoundedCornerShape(14.dp),
                    ambientColor = WarungColors.Green800.copy(0.35f),
                    spotColor = WarungColors.Green800.copy(0.45f),
                ) else Modifier
            )
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .then(
                if (!action.primary) Modifier.border(
                    1.dp,
                    MaterialTheme.colorScheme.outlineVariant,
                    RoundedCornerShape(14.dp),
                ) else Modifier
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(action.icon, contentDescription = action.label, tint = iconTint, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(
                text = action.label,
                fontSize = 10.sp,
                fontWeight = FontWeight.W600,
                color = textColor,
                maxLines = 1,
            )
        }
    }
}
