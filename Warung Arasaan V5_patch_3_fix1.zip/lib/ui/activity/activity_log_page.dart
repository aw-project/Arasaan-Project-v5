import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/pagination_mixin.dart';
import '../../providers.dart';

class ActivityLogPage extends ConsumerStatefulWidget {
  const ActivityLogPage({super.key});

  @override
  ConsumerState<ActivityLogPage> createState() => _ActivityLogPageState();
}

class _ActivityLogPageState extends ConsumerState<ActivityLogPage>
    with PaginationMixin {
  @override
  void initState() {
    super.initState();
    initPagination(pageSize: 50, onLoadMore: () => setState(() {}));
  }

  @override
  void dispose() {
    disposePagination();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final logs = ref.watch(activityLogRepoProvider).recent(limit: 200);

    if (logs.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 64, height: 64,
              decoration: BoxDecoration(
                color: const Color(0xFFB7EFCE),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(Icons.history_rounded,
                  color: AppColors.primary, size: 32),
            ),
            const SizedBox(height: 16),
            Text('Belum ada log aktivitas',
              style: GoogleFonts.poppins(
                fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.onSurface)),
            const SizedBox(height: 6),
            Text('Setiap perubahan data akan dicatat di sini.',
              style: GoogleFonts.poppins(fontSize: 13, color: AppColors.hint),
              textAlign: TextAlign.center),
          ],
        ),
      );
    }

    final visible = paginate(logs);
    final more = hasMore(logs);

    return ListView.separated(
      controller: paginatedScrollController,
      padding: const EdgeInsets.all(12),
      itemCount: visible.length + (more ? 1 : 0),
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (context, i) {
        if (i == visible.length) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'Gulir untuk muat ${logs.length - visible.length} log lainnya...',
                style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint),
              ),
            ),
          );
        }
        final l = visible[i];
        final (icon, color) = _iconFor(l.type);
        return Material(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => _showDetail(context, l),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFDEEBD8), width: 1),
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(icon, color: color, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_labelFor(l.type),
                          style: GoogleFonts.poppins(
                            fontSize: 13, fontWeight: FontWeight.w600,
                            color: AppColors.onSurface)),
                        Text(fmtDateFromEpochDay(l.dateEpochDay),
                          style: GoogleFonts.poppins(
                            fontSize: 11, color: AppColors.hint)),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: AppColors.hint, size: 18),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  (IconData, Color) _iconFor(String type) {
    switch (type) {
      case 'edit_sale': return (Icons.point_of_sale_rounded, AppColors.positive);
      case 'edit_purchase': return (Icons.shopping_cart_rounded, const Color(0xFF1565C0));
      default: return (Icons.edit_note_rounded, AppColors.hint);
    }
  }

  String _labelFor(String type) {
    switch (type) {
      case 'edit_sale': return 'Edit Penjualan';
      case 'edit_purchase': return 'Edit Pembelian';
      default: return type.replaceAll('_', ' ').toUpperCase();
    }
  }

  void _showDetail(BuildContext context, dynamic l) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(_labelFor(l.type),
          style: GoogleFonts.poppins(fontWeight: FontWeight.w700, fontSize: 16)),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (l.newJson.isNotEmpty) ...[
                Text('Setelah:', style: GoogleFonts.poppins(
                  fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.positive)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEBF3E6),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(l.newJson,
                    style: GoogleFonts.poppins(fontSize: 11, color: AppColors.onSurface)),
                ),
              ],
              if (l.oldJson.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text('Sebelum:', style: GoogleFonts.poppins(
                  fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.negative)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFEBEE),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(l.oldJson,
                    style: GoogleFonts.poppins(fontSize: 11, color: AppColors.onSurface)),
                ),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup')),
        ],
      ),
    );
  }
}
