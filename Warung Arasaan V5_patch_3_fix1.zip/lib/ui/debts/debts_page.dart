import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/debt.dart';
import '../widgets/empty_state.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/money_field.dart';

class DebtsPage extends ConsumerWidget {
  const DebtsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(debtRepoProvider);
    final items = repo.all();

    return Stack(
      children: [
        items.isEmpty
            ? const EmptyState(title: 'Belum ada hutang', subtitle: 'Catat hutang supplier/pinjaman dan pembayarannya.')
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) {
                  final d = items[i];
                  final pct = d.principal > 0
                      ? (d.paid / d.principal).clamp(0.0, 1.0)
                      : 0.0;
                  final isLunas = d.remaining <= 0;
                  return Dismissible(
                    key: ValueKey(d.id),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      decoration: BoxDecoration(
                        color: AppColors.negative,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(Icons.delete_rounded, color: Colors.white, size: 24),
                    ),
                    confirmDismiss: (_) async {
                      return await showDialog<bool>(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text('Hapus Hutang?'),
                          content: const Text('Data hutang dan riwayat pembayaran akan dihapus.'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                          ],
                        ),
                      ) ?? false;
                    },
                    onDismissed: (_) async {
                      final messenger = ScaffoldMessenger.of(context);
                      await repo.remove(d.id);
                      messenger.showSnackBar(const SnackBar(content: Text('Hutang dihapus')));
                    },
                    child: Material(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(16),
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => DebtPaymentPage(debtId: d.id))),
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isLunas
                                  ? const Color(0xFFB7EFCE)
                                  : const Color(0xFFFFCDD2),
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 34, height: 34,
                                    decoration: BoxDecoration(
                                      color: isLunas
                                          ? const Color(0xFFB7EFCE)
                                          : const Color(0xFFFFEBEE),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Icon(
                                      isLunas ? Icons.check_circle_rounded : Icons.account_balance_wallet_rounded,
                                      color: isLunas ? AppColors.positive : AppColors.negative,
                                      size: 18,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(d.creditor,
                                          style: GoogleFonts.poppins(
                                            fontSize: 14, fontWeight: FontWeight.w600,
                                            color: AppColors.onSurface)),
                                        Text(fmtDateFromEpochDay(d.dateEpochDay),
                                          style: GoogleFonts.poppins(
                                            fontSize: 11, color: AppColors.hint)),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: (isLunas ? AppColors.positive : AppColors.negative).withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      isLunas ? 'LUNAS' : 'BELUM LUNAS',
                                      style: GoogleFonts.poppins(
                                        fontSize: 10, fontWeight: FontWeight.w700,
                                        color: isLunas ? AppColors.positive : AppColors.negative),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              const Divider(height: 1),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Expanded(child: _DKV(label: 'Pokok', value: fmtMoney(d.principal))),
                                  Expanded(child: _DKV(label: 'Terbayar', value: fmtMoney(d.paid))),
                                  Expanded(child: _DKV(
                                    label: 'Sisa',
                                    value: fmtMoney(d.remaining),
                                    color: isLunas ? AppColors.positive : AppColors.negative,
                                  )),
                                ],
                              ),
                              const SizedBox(height: 8),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: pct,
                                  backgroundColor: AppColors.negative.withOpacity(0.12),
                                  color: isLunas ? AppColors.positive : AppColors.primary,
                                  minHeight: 4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DebtFormPage())),
            child: Image.asset('assets/icons/ic_add.png', width: 24, height: 24),
          ),
        ),
      ],
    );
  }
}

class DebtFormPage extends ConsumerStatefulWidget {
  const DebtFormPage({super.key});

  @override
  ConsumerState<DebtFormPage> createState() => _DebtFormPageState();
}

class _DebtFormPageState extends ConsumerState<DebtFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  final creditorC = TextEditingController();
  final noteC = TextEditingController();
  final principalC = TextEditingController();

  @override
  void dispose() {
    creditorC.dispose();
    noteC.dispose();
    principalC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Hutang')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            TextFormField(
              controller: creditorC,
              decoration: const InputDecoration(labelText: 'Kreditur (supplier/nama)'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(controller: noteC, decoration: const InputDecoration(labelText: 'Catatan (opsional)')),
            const SizedBox(height: 12),
            MoneyField(controller: principalC, label: 'Jumlah hutang', requiredField: true),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan')),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final d = Debt(
      id: newId('debt'),
      dateEpochDay: epochDay(date),
      creditor: creditorC.text.trim(),
      note: noteC.text.trim(),
      principal: (parseRupiah(principalC.text.trim()) ?? 0).toDouble(),
      paid: 0,
    );
    await ref.read(debtRepoProvider).add(d);
    if (!mounted) return;
    Navigator.pop(context);
  }
}

class DebtPaymentPage extends ConsumerStatefulWidget {
  final String debtId;
  const DebtPaymentPage({super.key, required this.debtId});

  @override
  ConsumerState<DebtPaymentPage> createState() => _DebtPaymentPageState();
}

class _DebtPaymentPageState extends ConsumerState<DebtPaymentPage> {
  final _formKey = GlobalKey<FormState>();
  final payC = TextEditingController();
  DateTime date = DateTime.now();
  String method = 'Cash';

  @override
  void dispose() {
    payC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final box = ref.watch(debtsBoxProvider);
    final debt = box.get(widget.debtId);
    if (debt == null) {
      return const Scaffold(body: Center(child: Text('Data hutang tidak ditemukan')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Pembayaran Hutang')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: Text(debt.creditor),
              subtitle: Text('Total: ${fmtMoney(debt.principal)}\nTerbayar: ${fmtMoney(debt.paid)}\nSisa: ${fmtMoney(debt.remaining)}'),
              isThreeLine: true,
            ),
          ),
          const SizedBox(height: 12),
          Form(
            key: _formKey,
            child: Column(
              children: [
                DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal bayar'),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: method,
                  decoration: const InputDecoration(labelText: 'Metode pembayaran'),
                  items: const [
                    DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                    DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                  ],
                  onChanged: (v) => setState(() => method = v ?? 'Cash'),
                ),
                const SizedBox(height: 12),
                MoneyField(controller: payC, label: 'Tambah pembayaran', requiredField: true),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: debt.isSettled ? null : _pay,
                  icon: const Icon(Icons.payments),
                  label: const Text('Simpan Pembayaran'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _pay() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = (parseRupiah(payC.text.trim()) ?? 0).toDouble();
    if (amount <= 0) return;
    await ref.read(debtRepoProvider).addPayment(
          widget.debtId,
          amount,
          dateEpochDay: epochDay(date),
          method: method,
        );
    if (!mounted) return;
    payC.clear();
    setState(() {});
  }
}

class _DKV extends StatelessWidget {
  final String label;
  final String value;
  final Color? color;
  const _DKV({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: GoogleFonts.poppins(fontSize: 10, color: AppColors.hint)),
        Text(value,
          style: GoogleFonts.poppins(
            fontSize: 12, fontWeight: FontWeight.w600,
            color: color ?? AppColors.onSurface),
          maxLines: 1, overflow: TextOverflow.ellipsis),
      ],
    );
  }
}
