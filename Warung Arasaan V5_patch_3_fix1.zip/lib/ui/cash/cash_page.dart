import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/payment_methods.dart';
import '../../providers.dart';
import '../../core/app_theme.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../widgets/date_range_picker.dart';
import '../widgets/money_field.dart';

class CashPage extends ConsumerStatefulWidget {
  const CashPage({super.key});

  @override
  ConsumerState<CashPage> createState() => _CashPageState();
}

class _CashPageState extends ConsumerState<CashPage> {
  DateTimeRange? range;

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(cashRepoProvider);
    final all = repo.all();
    final filtered = range == null
        ? all
        : all.where((e) {
            final d = fromEpochDay(e.dateEpochDay);
            return !d.isBefore(range!.start) && !d.isAfter(range!.end);
          }).toList();

    double cashIn = 0;
    double cashOut = 0;
    for (final e in filtered) {
      // Hanya hitung arus kas nyata (exclude Non-Cash seperti rugi rejek/adjust)
      if (!PaymentMethods.isCashFlow(e.method)) continue;
      if (e.direction == 'in') cashIn += e.amount;
      if (e.direction == 'out') cashOut += e.amount;
    }

    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.all(12),
          children: [
            _CashSummaryCard(
              cashIn: cashIn,
              cashOut: cashOut,
              saldo: cashIn - cashOut,
              range: range,
              onPickRange: () async {
                final picked = await pickDateRange(context, initial: range);
                setState(() => range = picked);
              },
              onClearRange: () => setState(() => range = null),
            ),
            const SizedBox(height: 8),
            if (filtered.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('Belum ada catatan kas di periode ini.')),
              ),
            ...filtered.asMap().entries.map((entry) {
              final e = entry.value;
              final isIn = e.direction == 'in';
              final isManual = e.source == 'manual';
              final dirIcon = isIn ? Icons.arrow_downward : Icons.arrow_upward;
              final dirColor = isIn ? AppColors.positive : AppColors.negative;

              final card = Material(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                clipBehavior: Clip.antiAlias,
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: const Color(0xFFDEEBD8), width: 1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          color: dirColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(dirIcon, color: dirColor, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(e.note.isEmpty ? _sourceLabel(e.source) : e.note,
                              style: GoogleFonts.poppins(
                                fontSize: 13, fontWeight: FontWeight.w600,
                                color: AppColors.onSurface),
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                            Text('${fmtDateFromEpochDay(e.dateEpochDay)} • ${e.method} • ${_sourceLabel(e.source)}',
                              style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint)),
                          ],
                        ),
                      ),
                      Text(
                        '${isIn ? '+' : '-'}${fmtMoney(e.amount)}',
                        style: GoogleFonts.poppins(
                          fontSize: 13, fontWeight: FontWeight.w700, color: dirColor),
                      ),
                    ],
                  ),
                ),
              );

              // Hanya entry manual yang bisa di-swipe hapus
              if (!isManual) return Padding(padding: const EdgeInsets.only(bottom: 8), child: card);

              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Dismissible(
                  key: ValueKey(e.id),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    decoration: BoxDecoration(
                      color: AppColors.negative,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.delete_rounded, color: Colors.white, size: 24),
                  ),
                  confirmDismiss: (_) async {
                    return await showDialog<bool>(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Hapus Entri Kas?'),
                        content: const Text('Entri kas manual ini akan dihapus permanen.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                        ],
                      ),
                    ) ?? false;
                  },
                  onDismissed: (_) async {
                    final cashRepo = ref.read(cashRepoProvider);
                    await cashRepo.remove(e.id);
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Entri kas dihapus')));
                  },
                  child: card,
                ),
              );
            }),
            const SizedBox(height: 80),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ManualCashFormPage())),
            child: Image.asset('assets/icons/ic_add.png', width: 24, height: 24),
          ),
        ),
      ],
    );
  }

  Widget _kv(String k, String v, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w400);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Expanded(child: Text(k, style: style)),
          Text(v, style: style),
        ],
      ),
    );
  }
}

class ManualCashFormPage extends ConsumerStatefulWidget {
  const ManualCashFormPage({super.key});

  @override
  ConsumerState<ManualCashFormPage> createState() => _ManualCashFormPageState();
}

class _ManualCashFormPageState extends ConsumerState<ManualCashFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  String direction = 'in';
  String method = 'Cash';
  final noteC = TextEditingController();
  final amountC = TextEditingController();

  @override
  void dispose() {
    noteC.dispose();
    amountC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Kas Manual')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ListTile(
              title: const Text('Tanggal'),
              subtitle: Text(fmtDate(date)),
              trailing: const Icon(Icons.date_range),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: date,
                  firstDate: DateTime(2020),
                  lastDate: DateTime(2100),
                );
                if (picked != null) setState(() => date = picked);
              },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: direction,
              decoration: const InputDecoration(labelText: 'Arah kas'),
              items: const [
                DropdownMenuItem(value: 'in', child: Text('Uang masuk')),
                DropdownMenuItem(value: 'out', child: Text('Uang keluar')),
              ],
              onChanged: (v) => setState(() => direction = v ?? 'in'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: method,
              decoration: const InputDecoration(labelText: 'Metode'),
              items: const [
                DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
              ],
              onChanged: (v) => setState(() => method = v ?? 'Cash'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: noteC,
              decoration: const InputDecoration(labelText: 'Catatan (opsional)'),
            ),
            const SizedBox(height: 12),
            MoneyField(controller: amountC, label: 'Jumlah', requiredField: true),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = (parseRupiah(amountC.text.trim()) ?? 0).toDouble();
    final id = newId('cash');
    await ref.read(cashRepoProvider).add(
          CashEntry(
            id: id,
            dateEpochDay: epochDay(date),
            direction: direction,
            source: 'manual',
            method: method,
            note: noteC.text.trim(),
            amount: amount,
            refId: '',
          ),
        );
    if (!mounted) return;
    Navigator.pop(context);
  }
}

// ─── Cash Summary Card ────────────────────────────────────────────────────────

class _CashSummaryCard extends StatelessWidget {
  final double cashIn;
  final double cashOut;
  final double saldo;
  final DateTimeRange? range;
  final VoidCallback onPickRange;
  final VoidCallback onClearRange;

  const _CashSummaryCard({
    required this.cashIn,
    required this.cashOut,
    required this.saldo,
    required this.range,
    required this.onPickRange,
    required this.onClearRange,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0B5E38), Color(0xFF1A7A50)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0B5E38).withOpacity(0.3),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Kas',
                style: GoogleFonts.poppins(
                  color: Colors.white.withOpacity(0.85),
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: onPickRange,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.calendar_today_rounded, size: 12, color: Colors.white),
                      const SizedBox(width: 5),
                      Text(
                        range == null ? 'Semua' : '${fmtDate(range!.start)} - ${fmtDate(range!.end)}',
                        style: GoogleFonts.poppins(fontSize: 11, color: Colors.white, fontWeight: FontWeight.w500),
                      ),
                      if (range != null) ...[
                        const SizedBox(width: 5),
                        GestureDetector(
                          onTap: onClearRange,
                          child: const Icon(Icons.close_rounded, size: 12, color: Colors.white),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            fmtMoney(saldo),
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),
          Text(
            'Saldo Bersih',
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.7),
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _CashStatChip(
                label: 'Masuk',
                value: fmtMoney(cashIn),
                icon: Icons.arrow_downward_rounded,
                color: const Color(0xFF81C784),
              ),
              const SizedBox(width: 12),
              _CashStatChip(
                label: 'Keluar',
                value: fmtMoney(cashOut),
                icon: Icons.arrow_upward_rounded,
                color: const Color(0xFFEF9A9A),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CashStatChip extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const _CashStatChip({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 6),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: GoogleFonts.poppins(fontSize: 10, color: Colors.white.withOpacity(0.7))),
                  Text(value, style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white), overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String _sourceLabel(String source) {
  switch (source) {
    case 'sale': return 'Penjualan';
    case 'purchase': return 'Pembelian';
    case 'expense': return 'Biaya';
    case 'debt_payment': return 'Bayar Hutang';
    case 'reject': return 'Rugi Rejek';
    case 'loss': return 'Kerugian Stok'; // dari penyesuaian stok
    case 'manual': return 'Manual';
    default: return source;
  }
}
