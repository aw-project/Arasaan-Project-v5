import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';
import '../../data/repositories/meta_repo.dart';
import '../../providers.dart';
import '../widgets/money_field.dart';

class FastPosPage extends ConsumerStatefulWidget {
  const FastPosPage({super.key});

  @override
  ConsumerState<FastPosPage> createState() => _FastPosPageState();
}

class _FastPosPageState extends ConsumerState<FastPosPage> {
  final qC = TextEditingController();
  final Map<String, double> cart = {};
  String paymentMethod = 'Cash';
  double discountAmount = 0;
  List<PaymentSplit> paymentSplits = const [];
  String selectedCategory = 'Semua';

  @override
  void dispose() {
    qC.dispose();
    super.dispose();
  }

  void _add(String productId) {
    setState(() => cart[productId] = (cart[productId] ?? 0) + 1.0);
  }

  void _remove(String productId) {
    setState(() {
      final v = (cart[productId] ?? 0) - 1.0;
      if (v <= 0) {
        cart.remove(productId);
      } else {
        cart[productId] = v;
      }
    });
  }

  double _grossTotal(List<Product> products) {
    double sum = 0;
    for (final e in cart.entries) {
      final p = products.firstWhere((x) => x.id == e.key);
      sum += e.value * p.activeSellPrice;
    }
    return sum;
  }

  double _netTotal(List<Product> products) => (_grossTotal(products) - discountAmount).clamp(0, double.infinity);

  Future<void> _checkout(List<Product> products) async {
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Keranjang kosong.')));
      return;
    }

    final res = await showModalBottomSheet<_CheckoutResult>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _CartSheet(
        products: products,
        cart: Map<String, double>.from(cart),
        paymentMethod: paymentMethod,
        discountAmount: discountAmount,
        paymentSplits: paymentSplits,
      ),
    );

    if (res == null) return;

    setState(() {
      cart
        ..clear()
        ..addAll(res.cart);
      paymentMethod = res.paymentMethod;
      discountAmount = res.discountAmount;
      paymentSplits = res.paymentSplits;
    });

    final salesRepo = ref.read(salesRepoProvider);
    final prodRepo = ref.read(productRepoProvider);

    final items = <SaleItem>[];
    for (final e in res.cart.entries) {
      final p = prodRepo.getById(e.key);
      if (p == null) continue;
      items.add(SaleItem(productId: p.id, qty: e.value, sellPrice: p.activeSellPrice, hppAtSale: p.avgHpp));
    }
    final sale = Sale(
      id: newId('sl'),
      dateEpochDay: epochDay(DateTime.now()),
      items: items,
      paymentMethod: res.paymentMethod,
      discountAmount: res.discountAmount,
      paymentSplits: res.paymentSplits,
    );

    try {
      await salesRepo.add(sale);
      if (!mounted) return;
      setState(() {
        cart.clear();
        discountAmount = 0;
        paymentSplits = const [];
      });
      final paid = res.paidAmount;
      final change = res.paymentMethod == 'Cash' && paid > 0 ? (paid - sale.totalSales).clamp(0, double.infinity) : 0.0;
      final msg = change > 0 ? 'Transaksi tersimpan. Kembalian: ${fmtMoney(change)}' : 'Transaksi tersimpan.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
    }
  }

  Future<void> _saveHoldCart(List<Product> products) async {
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Keranjang kosong.')));
      return;
    }
    final labelC = TextEditingController(text: 'Hold ${DateTime.now().hour}:${DateTime.now().minute.toString().padLeft(2, '0')}');
    final label = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Simpan hold cart'),
        content: TextField(controller: labelC, decoration: const InputDecoration(labelText: 'Nama hold')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, labelC.text.trim()), child: const Text('Simpan')),
        ],
      ),
    );
    if (label == null || label.trim().isEmpty) return;
    await ref.read(metaRepoProvider).saveHeldSalesCart(
          HeldCart(
            id: newId('hold'),
            label: label,
            savedAtMs: DateTime.now().millisecondsSinceEpoch,
            cart: Map<String, double>.from(cart),
            paymentMethod: paymentMethod,
            discountAmount: discountAmount,
            paymentSplits: paymentSplits,
          ),
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Hold cart disimpan')));
    setState(() {});
  }

  Future<void> _openHeldCarts(List<Product> products) async {
    final holds = ref.read(metaRepoProvider).heldSalesCarts;
    if (holds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Belum ada hold cart.')));
      return;
    }
    final selected = await showModalBottomSheet<HeldCart>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('Hold Cart')),
            ...holds.map((hold) => ListTile(
                  title: Text(hold.label),
                  subtitle: Text('${hold.cart.length} item • ${fmtDate(DateTime.fromMillisecondsSinceEpoch(hold.savedAtMs))}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      await ref.read(metaRepoProvider).deleteHeldSalesCart(hold.id);
                      if (mounted) {
                        Navigator.pop(context);
                        _openHeldCarts(products);
                      }
                    },
                  ),
                  onTap: () => Navigator.pop(context, hold),
                )),
          ],
        ),
      ),
    );
    if (selected == null) return;
    setState(() {
      cart
        ..clear()
        ..addAll(selected.cart);
      paymentMethod = selected.paymentMethod;
      discountAmount = selected.discountAmount;
      paymentSplits = selected.paymentSplits;
    });
    await ref.read(metaRepoProvider).deleteHeldSalesCart(selected.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Hold cart "${selected.label}" dimuat')));
  }

  @override
  Widget build(BuildContext context) {
    final productsBox = ref.watch(productsBoxProvider);
    final products = productsBox.values.toList()..sort((a, b) => a.name.compareTo(b.name));
    final q = qC.text.trim().toLowerCase();
    final categories = <String>{'Semua'}..addAll(products.map((p) => p.category.trim().isEmpty ? 'Lainnya' : p.category).toSet());
    final filtered = products.where((p) {
      final matchCategory = selectedCategory == 'Semua' || p.category == selectedCategory;
      final matchQuery = q.isEmpty || p.name.toLowerCase().contains(q) || p.sku.toLowerCase().contains(q) || p.category.toLowerCase().contains(q);
      return matchCategory && matchQuery;
    }).toList();

    final gross = cart.isEmpty ? 0.0 : _grossTotal(products);
    final total = cart.isEmpty ? 0.0 : _netTotal(products);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Fast Mode Kasir'),
        actions: [
          IconButton(onPressed: () => _saveHoldCart(products), icon: const Icon(Icons.pause_circle_outline), tooltip: 'Simpan hold cart'),
          IconButton(onPressed: () => _openHeldCarts(products), icon: const Icon(Icons.shopping_bag_outlined), tooltip: 'Buka hold cart'),
          PopupMenuButton<String>(
            tooltip: 'Metode pembayaran',
            onSelected: (v) => setState(() => paymentMethod = v),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'Cash', child: Text('Cash')),
              PopupMenuItem(value: 'QRIS', child: Text('QRIS')),
              PopupMenuItem(value: 'Transfer', child: Text('Transfer')),
              PopupMenuItem(value: 'Hutang', child: Text('Hutang')),
            ],
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  const Icon(Icons.payments_outlined),
                  const SizedBox(width: 6),
                  Text(paymentMethod),
                ],
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: Column(
              children: [
                TextField(
                  controller: qC,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: 'Cari produk / kategori / SKU...',
                    suffixIcon: q.isEmpty ? null : IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() => qC.clear())),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    DropdownButton<String>(
                      value: categories.contains(selectedCategory) ? selectedCategory : 'Semua',
                      items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                      onChanged: (v) => setState(() => selectedCategory = v ?? 'Semua'),
                    ),
                    Text('Tampil: ${filtered.length}', style: Theme.of(context).textTheme.bodySmall),
                    if (cart.isNotEmpty)
                      Text('Keranjang: ${cart.length} item', style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 1.05,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: filtered.length,
              itemBuilder: (_, i) {
                final p = filtered[i];
                final qty = cart[p.id] ?? 0;
                final lowStock = p.minStock > 0 && p.stockQty <= p.minStock;
                return InkWell(
                  onTap: () => _add(p.id),
                  onLongPress: qty > 0 ? () => _remove(p.id) : null,
                  borderRadius: BorderRadius.circular(14),
                  child: Stack(
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: SizedBox(
                                  height: 52,
                                  width: double.infinity,
                                  child: (p.imagePath != null && p.imagePath!.isNotEmpty)
                                      ? Image.file(
                                          File(p.imagePath!),
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Container(
                                            color: Theme.of(context).colorScheme.surfaceContainerHighest,
                                            alignment: Alignment.center,
                                            child: const Icon(Icons.inventory_2_outlined),
                                          ),
                                        )
                                      : Container(
                                          color: Theme.of(context).colorScheme.surfaceContainerHighest,
                                          alignment: Alignment.center,
                                          child: const Icon(Icons.inventory_2_outlined),
                                        ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(
                                  p.category,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ),
                              const Spacer(),
                              Text(fmtMoney(p.activeSellPrice), style: Theme.of(context).textTheme.titleSmall),
                              const SizedBox(height: 2),
                              Text(
                                'Stok: ${p.stockQty.toStringAsFixed(0)} ${p.unit}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                      ),
                      if (qty > 0)
                        Positioned(
                          right: 8,
                          top: 8,
                          child: CircleAvatar(
                            radius: 12,
                            child: Text(qty.toStringAsFixed(0), style: const TextStyle(fontSize: 11)),
                          ),
                        ),
                      if (lowStock)
                        Positioned(
                          left: 8,
                          top: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                            decoration: BoxDecoration(
                              color: Colors.red.shade50,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text('Menipis', style: Theme.of(context).textTheme.labelSmall?.copyWith(color: Colors.red.shade700)),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(border: Border(top: BorderSide(color: Theme.of(context).dividerColor))),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(child: Text('Bruto: ${fmtMoney(gross)}', style: Theme.of(context).textTheme.bodyMedium)),
                      if (discountAmount > 0) Text('Diskon: ${fmtMoney(discountAmount)}'),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(child: Text('Total: ${fmtMoney(total)}', style: Theme.of(context).textTheme.titleMedium)),
                      ElevatedButton.icon(onPressed: () => _checkout(products), icon: const Icon(Icons.check_circle_outline), label: const Text('Bayar')),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CheckoutResult {
  final Map<String, double> cart;
  final String paymentMethod;
  final double discountAmount;
  final List<PaymentSplit> paymentSplits;
  final double paidAmount;
  const _CheckoutResult(this.cart, this.paymentMethod, this.discountAmount, this.paymentSplits, {this.paidAmount = 0});
}

class _CartSheet extends StatefulWidget {
  final List<Product> products;
  final Map<String, double> cart;
  final String paymentMethod;
  final double discountAmount;
  final List<PaymentSplit> paymentSplits;

  const _CartSheet({required this.products, required this.cart, required this.paymentMethod, required this.discountAmount, required this.paymentSplits});

  @override
  State<_CartSheet> createState() => _CartSheetState();
}

class _CartSheetState extends State<_CartSheet> {
  late Map<String, double> cart;
  late String paymentMethod;
  late final TextEditingController discountC;
  bool useSplitPayment = false;
  String splitMethod2 = 'QRIS';
  late final TextEditingController splitAmount2C;
  late final TextEditingController paidAmountC;

  @override
  void initState() {
    super.initState();
    cart = Map<String, double>.from(widget.cart);
    paymentMethod = widget.paymentMethod;
    discountC = TextEditingController(text: widget.discountAmount.toStringAsFixed(0));
    final splits = widget.paymentSplits;
    useSplitPayment = splits.length > 1;
    splitMethod2 = splits.length > 1 ? splits[1].method : 'QRIS';
    splitAmount2C = TextEditingController(text: splits.length > 1 ? splits[1].amount.toStringAsFixed(0) : '0');
    paidAmountC = TextEditingController();
  }

  @override
  void dispose() {
    discountC.dispose();
    splitAmount2C.dispose();
    paidAmountC.dispose();
    super.dispose();
  }

  double get grossTotal {
    double sum = 0;
    for (final e in cart.entries) {
      final p = widget.products.firstWhere((x) => x.id == e.key);
      sum += e.value * p.activeSellPrice;
    }
    return sum;
  }

  double get discountAmount => (parseRupiah(discountC.text.trim()) ?? 0).toDouble();
  double get netTotal => (grossTotal - discountAmount).clamp(0, double.infinity);
  double get paidAmount => (parseRupiah(paidAmountC.text.trim()) ?? 0).toDouble();
  double get changeAmount => (paidAmount - netTotal).clamp(0, double.infinity);

  @override
  Widget build(BuildContext context) {
    final entries = cart.entries.toList();
    final splitAmount2 = (parseRupiah(splitAmount2C.text.trim()) ?? 0).toDouble();
    final splitAmount1 = (netTotal - splitAmount2).clamp(0, double.infinity);

    return Padding(
      padding: EdgeInsets.only(left: 12, right: 12, top: 12, bottom: 12 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Keranjang', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Row(
            children: [
              const Text('Pembayaran:'),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: paymentMethod,
                items: const [
                  DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                  DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                  DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                  DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
                ],
                onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
              ),
            ],
          ),
          MoneyField(controller: discountC, label: 'Diskon transaksi', requiredField: false, onChanged: (_) => setState(() {})),
          SwitchListTile.adaptive(
            value: useSplitPayment,
            title: const Text('Split payment'),
            contentPadding: EdgeInsets.zero,
            onChanged: (v) => setState(() => useSplitPayment = v),
          ),
          if (paymentMethod == 'Cash' && !useSplitPayment) ...[
            MoneyField(controller: paidAmountC, label: 'Uang dibayar', requiredField: false, onChanged: (_) => setState(() {})),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ActionChip(label: const Text('Pas'), onPressed: () => setState(() => paidAmountC.text = netTotal.round().toString())),
                ActionChip(label: const Text('20rb'), onPressed: () => setState(() => paidAmountC.text = '20000')),
                ActionChip(label: const Text('50rb'), onPressed: () => setState(() => paidAmountC.text = '50000')),
                ActionChip(label: const Text('100rb'), onPressed: () => setState(() => paidAmountC.text = '100000')),
              ],
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                paidAmount <= 0
                    ? 'Masukkan uang dibayar untuk hitung kembalian'
                    : 'Kembalian: ${fmtMoney(changeAmount)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
          if (useSplitPayment) ...[
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: splitMethod2,
                    decoration: const InputDecoration(labelText: 'Metode ke-2'),
                    items: const [
                      DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                      DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                      DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                      DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
                    ],
                    onChanged: (v) => setState(() => splitMethod2 = v ?? 'QRIS'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(child: MoneyField(controller: splitAmount2C, label: 'Nominal ke-2', requiredField: false, onChanged: (_) => setState(() {}))),
              ],
            ),
            const SizedBox(height: 6),
            Text('Sisa untuk $paymentMethod: ${fmtMoney(splitAmount1)}', style: Theme.of(context).textTheme.bodySmall),
          ],
          const SizedBox(height: 8),
          if (entries.isEmpty)
            const Padding(padding: EdgeInsets.all(12), child: Text('Keranjang kosong.'))
          else
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: entries.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final pid = entries[i].key;
                  final qty = entries[i].value;
                  final p = widget.products.firstWhere((x) => x.id == pid);
                  return ListTile(
                    title: Text(p.name),
                    subtitle: Text(fmtMoney(p.activeSellPrice)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline),
                          onPressed: () => setState(() {
                            final v = (cart[pid] ?? 0) - 1.0;
                            if (v <= 0) {
                              cart.remove(pid);
                            } else {
                              cart[pid] = v;
                            }
                          }),
                        ),
                        Text(qty.toStringAsFixed(0)),
                        IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => setState(() => cart[pid] = (cart[pid] ?? 0) + 1.0)),
                      ],
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Bruto: ${fmtMoney(grossTotal)}'),
                    if (discountAmount > 0) Text('Diskon: ${fmtMoney(discountAmount)}'),
                    Text('Total: ${fmtMoney(netTotal)}', style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
              ),
              ElevatedButton(
                onPressed: entries.isEmpty
                    ? null
                    : () {
                        if (discountAmount > grossTotal) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Diskon melebihi total bruto')));
                          return;
                        }
                        final splits = <PaymentSplit>[];
                        if (!useSplitPayment && paymentMethod == 'Cash' && paidAmount > 0 && paidAmount < netTotal) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Uang dibayar kurang dari total belanja')));
                          return;
                        }
                        if (useSplitPayment) {
                          if (splitMethod2 == paymentMethod) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Metode split kedua harus berbeda')));
                            return;
                          }
                          if (splitAmount2 <= 0 || splitAmount2 >= netTotal) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nominal split kedua tidak valid')));
                            return;
                          }
                          splits.add(PaymentSplit(method: paymentMethod, amount: netTotal - splitAmount2));
                          splits.add(PaymentSplit(method: splitMethod2, amount: splitAmount2));
                        }
                        Navigator.pop(context, _CheckoutResult(cart, paymentMethod, discountAmount, splits, paidAmount: paidAmount));
                      },
                child: const Text('Simpan'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
