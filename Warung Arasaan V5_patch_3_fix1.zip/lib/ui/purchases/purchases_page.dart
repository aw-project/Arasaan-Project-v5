import 'package:flutter/material.dart';
import '../../core/ui_debouncer.dart';
import '../../core/pagination_mixin.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/app_theme.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/dates.dart';
import '../widgets/empty_state.dart';
import 'purchase_form.dart';
import 'purchase_detail_page.dart';
import '../../domain/models/purchase.dart';
import '../../data/repositories/purchase_repo.dart';
import '../../data/repositories/product_repo.dart';

class PurchasesPage extends ConsumerStatefulWidget {
  const PurchasesPage({super.key});

  @override
  ConsumerState<PurchasesPage> createState() => _PurchasesPageState();
}

class _PurchasesPageState extends ConsumerState<PurchasesPage> with PaginationMixin {
  final qC = TextEditingController();
  final _searchDebouncer = UiDebouncer();
  String _query = '';
  DateTimeRange? range;

  @override
  void initState() {
    super.initState();
    initPagination(pageSize: 30, onLoadMore: () => setState(() {}));
  }

  @override
  void dispose() {
    _searchDebouncer.dispose();
    qC.dispose();
    disposePagination();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(purchaseRepoProvider);
    final itemsAll = repo.all();
    final productsRepo = ref.watch(productRepoProvider);

    final q = _query;

    final filtered = itemsAll.where((p) {
      if (range != null) {
        final d = fromEpochDay(p.dateEpochDay);
        final afterStart = !d.isBefore(DateTime(range!.start.year, range!.start.month, range!.start.day));
        final beforeEnd = !d.isAfter(DateTime(range!.end.year, range!.end.month, range!.end.day));
        if (!afterStart || !beforeEnd) return false;
      }
      if (q.isEmpty) return true;

      final supplier = p.supplier.toLowerCase();
      if (supplier.contains(q)) return true;
      for (final it in p.items) {
        final pr = productsRepo.getById(it.productId);
        final name = (pr?.name ?? '').toLowerCase();
        if (name.contains(q)) return true;
      }
      return false;
    }).toList();

    if (itemsAll.isEmpty) {
      return Stack(
        children: [
          const EmptyState(
            title: 'Belum ada pembelian',
            subtitle: 'Catat pembelian untuk mengisi stok dan menghitung HPP.',
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton.extended(
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                backgroundColor: Colors.transparent,
                builder: (_) => const PurchaseFormPage(showAsSheet: true),
              ),
              icon: const Icon(Icons.add_rounded),
              label: Text('Tambah', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: qC,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: 'Cari supplier / produk...',
                        suffixIcon: q.isEmpty
                            ? null
                            : IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  qC.clear();
                                  _searchDebouncer.flush(() => setState(() => _query = ''));
                                },
                              ),
                      ),
                      onChanged: (value) {
                        _searchDebouncer.run(() {
                          if (!mounted) return;
                          setState(() => _query = value.trim().toLowerCase());
                        });
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    tooltip: 'Filter tanggal',
                    icon: Icon(range == null ? Icons.filter_alt_outlined : Icons.filter_alt),
                    onPressed: () async {
                      final picked = await showDateRangePicker(
                        context: context,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                        initialDateRange: range,
                      );
                      setState(() { range = picked; resetPagination(); });
                    },
                  ),
                ],
              ),
            ),
            if (range != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Periode: ${fmtDate(range!.start)} – ${fmtDate(range!.end)}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => setState(() { range = null; resetPagination(); }),
                      icon: const Icon(Icons.close, size: 18),
                      label: const Text('Reset'),
                    ),
                  ],
                ),
              ),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(child: Text('Tidak ada data yang cocok.'))
                  : _buildList(filtered, repo, productsRepo),
            ),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              useSafeArea: true,
              backgroundColor: Colors.transparent,
              builder: (_) => PurchaseFormPage(showAsSheet: true),
            ),
            icon: const Icon(Icons.add_rounded),
            label: Text('Tambah', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );
  }

  Widget _buildList(List<Purchase> filtered, PurchaseRepo repo, ProductRepo productsRepo) {
    final visible = paginate(filtered);
    final more = hasMore(filtered);
    return ListView.separated(
      controller: paginatedScrollController,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
      itemCount: visible.length + (more ? 1 : 0),
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        if (i == visible.length) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'Gulir untuk muat lebih banyak...',
                style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint),
              ),
            ),
          );
        }
        final p = visible[i];
        final totalQty = p.items.fold<double>(0.0, (sum, it) => sum + it.qty);
        final total = p.items.fold<double>(0.0, (sum, it) => sum + it.qty * it.buyPrice);
        final summary = p.items.map((it) {
          final pr = productsRepo.getById(it.productId);
          final name = pr?.name ?? 'Produk';
          final unit = pr?.unit ?? '';
          return '$name ${it.qty.toStringAsFixed(2)} $unit';
        }).join(', ');

        return Dismissible(
          key: ValueKey(p.id),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            decoration: BoxDecoration(
              color: AppColors.negative,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.delete_rounded, color: Colors.white, size: 24),
          ),
          confirmDismiss: (_) async {
            return await showDialog<bool>(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text('Hapus Pembelian?'),
                content: const Text('Data pembelian dan stok terkait akan dikembalikan.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                  FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                ],
              ),
            ) ?? false;
          },
          onDismissed: (_) async {
            final messenger = ScaffoldMessenger.of(context);
            await repo.remove(p.id);
            messenger.showSnackBar(const SnackBar(content: Text('Pembelian dihapus')));
          },
          child: _PurchaseCard(
            date: fmtDateFromEpochDay(p.dateEpochDay),
            supplier: p.supplier.trim(),
            paymentMethod: p.paymentMethod,
            total: total,
            totalQty: totalQty,
            summary: summary,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => PurchaseDetailPage(purchaseId: p.id)),
            ),
            onDelete: () async {
              final messenger = ScaffoldMessenger.of(context);
              await repo.remove(p.id);
              if (!mounted) return;
              messenger.showSnackBar(const SnackBar(content: Text('Pembelian dihapus')));
            },
          ),
        );
      },
    );
  }

}

// ─── Purchase Card ────────────────────────────────────────────────────────────

class _PurchaseCard extends StatelessWidget {
  final String date;
  final String supplier;
  final String paymentMethod;
  final double total;
  final double totalQty;
  final String summary;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _PurchaseCard({
    required this.date,
    required this.supplier,
    required this.paymentMethod,
    required this.total,
    required this.totalQty,
    required this.summary,
    required this.onTap,
    required this.onDelete,
  });

  Color get _payColor {
    switch (paymentMethod) {
      case 'Transfer': return const Color(0xFF1565C0);
      case 'Hutang': return const Color(0xFFC62828);
      default: return const Color(0xFF1A7A50);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFFDEEBD8), width: 1),
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(
                      color: const Color(0xFFB7EFCE),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.shopping_cart_rounded,
                        color: AppColors.primary, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(date,
                          style: GoogleFonts.poppins(fontSize: 13,
                              fontWeight: FontWeight.w600, color: AppColors.onSurface)),
                        Text(
                          supplier.isEmpty ? summary : '$supplier • $summary',
                          style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _payColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(paymentMethod,
                      style: GoogleFonts.poppins(fontSize: 11,
                          fontWeight: FontWeight.w600, color: _payColor)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline_rounded, size: 18),
                    color: AppColors.hint,
                    visualDensity: VisualDensity.compact,
                    onPressed: onDelete,
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Divider(height: 1),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _PKV(label: 'Total Bayar', value: fmtMoney(total), bold: true)),
                  Expanded(child: _PKV(label: 'Qty Total', value: totalQty.toStringAsFixed(2))),
                  Expanded(child: _PKV(label: 'Produk', value: '${summary.split(',').length} item')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PKV extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  const _PKV({required this.label, required this.value, this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: GoogleFonts.poppins(fontSize: 10, color: AppColors.hint)),
        Text(value,
          style: GoogleFonts.poppins(
            fontSize: 12,
            fontWeight: bold ? FontWeight.w700 : FontWeight.w600,
            color: AppColors.onSurface,
          ),
          maxLines: 1, overflow: TextOverflow.ellipsis),
      ],
    );
  }
}
