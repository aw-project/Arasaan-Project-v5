import '../../core/payment_methods.dart';
import 'package:hive/hive.dart';

import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/stock_movement.dart';

class SalesRepo {
  final Box<Sale> salesBox;
  final Box<Product> productsBox;
  final Box<StockMovement> movementsBox;
  final Box<CashEntry> cashBox;

  SalesRepo(this.salesBox, this.productsBox, this.movementsBox, this.cashBox);

  List<Sale> all() => salesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Sale sale) async {
    if (sale.items.isEmpty) {
      throw const FormatException('Transaksi penjualan tidak boleh kosong.');
    }
    if (sale.discountAmount < 0) {
      throw const FormatException('Diskon tidak boleh negatif.');
    }
    if (sale.discountAmount > sale.grossSales) {
      throw const FormatException('Diskon melebihi total bruto penjualan.');
    }

    final touchedProducts = <String, ({double stockQty, double avgHpp})>{};
    final createdMovementIds = <String>[];
    final createdCashIds = <String>[];
    var saleSaved = false;

    try {
      for (final item in sale.items) {
        if (item.qty <= 0) {
          throw FormatException('Qty penjualan harus lebih dari 0 untuk ${item.productId}.');
        }
        final p = productsBox.get(item.productId);
        if (p == null) {
          throw StateError('Produk tidak ditemukan: ${item.productId}');
        }
        touchedProducts[p.id] = (stockQty: p.stockQty, avgHpp: p.avgHpp);
        if (item.qty > p.stockQty) {
          throw StateError('Stok tidak cukup untuk ${p.name}. Stok: ${p.stockQty.toStringAsFixed(2)}');
        }
      }

      final normalizedSplits = sale.normalizedSplits;
      final splitTotal = normalizedSplits.fold<double>(0.0, (sum, e) => sum + e.amount);
      if ((splitTotal - sale.totalSales).abs() > 0.51) {
        throw const FormatException('Pembagian pembayaran tidak sama dengan total akhir.');
      }

      for (final split in normalizedSplits) {
        if (split.method.toLowerCase() == PaymentMethods.hutang.toLowerCase()) continue;
        final cashId = newId('cash');
        createdCashIds.add(cashId);
        await cashBox.put(
          cashId,
          CashEntry(
            id: cashId,
            dateEpochDay: sale.dateEpochDay,
            direction: 'in',
            source: 'sale',
            method: split.method,
            note: sale.isSplitPayment ? 'Penjualan (${sale.paymentSummary})' : 'Penjualan',
            amount: split.amount,
            refId: sale.id,
          ),
        );
      }

      for (final item in sale.items) {
        final p = productsBox.get(item.productId)!;
        p.stockQty = (p.stockQty - item.qty).clamp(0, double.infinity);
        await productsBox.put(p.id, p);

        final mvId = newId('mv');
        createdMovementIds.add(mvId);
        await movementsBox.put(
          mvId,
          StockMovement(
            id: mvId,
            dateEpochDay: sale.dateEpochDay,
            productId: item.productId,
            type: 'sale',
            qtyDelta: -item.qty,
            note: 'Penjualan#${sale.id}',
          ),
        );
      }

      await salesBox.put(sale.id, sale);
      saleSaved = true;
    } catch (e) {
      if (saleSaved) {
        await salesBox.delete(sale.id);
      }
      for (final cashId in createdCashIds) {
        await cashBox.delete(cashId);
      }
      for (final mvId in createdMovementIds) {
        await movementsBox.delete(mvId);
      }
      for (final entry in touchedProducts.entries) {
        final p = productsBox.get(entry.key);
        if (p == null) continue;
        p
          ..stockQty = entry.value.stockQty
          ..avgHpp = entry.value.avgHpp;
        await productsBox.put(p.id, p);
      }
      rethrow;
    }
  }

  Future<void> remove(String id) async {
    final sale = salesBox.get(id);
    if (sale == null) {
      await salesBox.delete(id);
      return;
    }

    final mvKeysToDelete = <dynamic>[];
    for (final entry in movementsBox.toMap().entries) {
      final mv = entry.value;
      if (mv.type == 'sale' && mv.note == 'Penjualan#$id') {
        mvKeysToDelete.add(entry.key);
      }
    }
    for (final k in mvKeysToDelete) {
      await movementsBox.delete(k);
    }

    await salesBox.delete(id);

    final cashKeys = <dynamic>[];
    for (final entry in cashBox.toMap().entries) {
      final c = entry.value;
      if (c.source == 'sale' && c.refId == id) cashKeys.add(entry.key);
    }
    for (final k in cashKeys) {
      await cashBox.delete(k);
    }

    final affectedProductIds = sale.items.map((e) => e.productId).toSet();
    for (final productId in affectedProductIds) {
      final product = productsBox.get(productId);
      if (product == null) continue;

      final stock = movementsBox.values.where((m) => m.productId == productId).fold<double>(0.0, (sum, m) => sum + m.qtyDelta);
      product.stockQty = stock.clamp(0, double.infinity);
      await productsBox.put(product.id, product);
    }
  }
}
