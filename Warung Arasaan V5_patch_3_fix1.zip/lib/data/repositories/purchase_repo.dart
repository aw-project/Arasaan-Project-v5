import '../../core/payment_methods.dart';
import 'package:hive/hive.dart';

import '../../core/calc.dart';
import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/stock_movement.dart';

class PurchaseRepo {
  final Box<Purchase> purchasesBox;
  final Box<Product> productsBox;
  final Box<StockMovement> movementsBox;
  final Box<CashEntry> cashBox;

  PurchaseRepo(this.purchasesBox, this.productsBox, this.movementsBox, this.cashBox);

  List<Purchase> all() => purchasesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Purchase purchase) async {
    if (purchase.items.isEmpty) {
      throw const FormatException('Transaksi pembelian tidak boleh kosong.');
    }

    final touchedProducts = <String, ({double stockQty, double avgHpp})>{};
    final createdMovementIds = <String>[];
    String? createdCashId;
    var purchaseSaved = false;

    try {
      for (final item in purchase.items) {
        if (item.qty <= 0) {
          throw FormatException('Qty pembelian harus lebih dari 0 untuk ${item.productId}.');
        }
        if (item.buyPrice < 0) {
          throw FormatException('Harga beli tidak boleh negatif untuk ${item.productId}.');
        }
        final product = productsBox.get(item.productId);
        if (product == null) {
          throw StateError('Produk tidak ditemukan: ${item.productId}');
        }
        touchedProducts[product.id] = (stockQty: product.stockQty, avgHpp: product.avgHpp);
      }

      if (purchase.paymentMethod.toLowerCase() != PaymentMethods.hutang.toLowerCase()) {
        createdCashId = newId('cash');
        final total = purchase.items.fold<double>(0.0, (s, it) => s + it.qty * it.buyPrice);
        await cashBox.put(
          createdCashId,
          CashEntry(
            id: createdCashId,
            dateEpochDay: purchase.dateEpochDay,
            direction: 'out',
            source: 'purchase',
            method: purchase.paymentMethod,
            note: purchase.supplier.isEmpty ? 'Pembelian' : 'Pembelian (${purchase.supplier})',
            amount: total,
            refId: purchase.id,
          ),
        );
      }

      for (final item in purchase.items) {
        final mvId = newId('mv');
        createdMovementIds.add(mvId);
        await movementsBox.put(
          mvId,
          StockMovement(
            id: mvId,
            dateEpochDay: purchase.dateEpochDay,
            productId: item.productId,
            type: 'purchase',
            qtyDelta: item.qty,
            note: 'Pembelian#${purchase.id}',
          ),
        );
      }

      for (final item in purchase.items) {
        final product = productsBox.get(item.productId)!;

        final oldQty = product.stockQty;
        final oldHpp = product.avgHpp;
        final incomingQty = item.qty;
        final incomingCost = item.qty * item.buyPrice;
        final oldCost = oldQty * oldHpp;
        final newTotalQty = oldQty + incomingQty;
        final newTotalCost = oldCost + incomingCost;

        product.stockQty = newTotalQty;
        product.avgHpp = hppWeightedAverage(totalQty: newTotalQty, totalCost: newTotalCost);

        await productsBox.put(product.id, product);
      }

      await purchasesBox.put(purchase.id, purchase);
      purchaseSaved = true;
    } catch (e) {
      if (purchaseSaved) {
        await purchasesBox.delete(purchase.id);
      }
      if (createdCashId != null) {
        await cashBox.delete(createdCashId);
      }
      for (final mvId in createdMovementIds) {
        await movementsBox.delete(mvId);
      }
      for (final entry in touchedProducts.entries) {
        final p = productsBox.get(entry.key);
        if (p == null) continue;
        p
          ..stockQty = entry.value.stockQty
          ..avgHpp = entry.value.avgHpp;
        await productsBox.put(p.id, p);
      }
      rethrow;
    }
  }

  Future<void> remove(String id) async {
    final purchase = purchasesBox.get(id);
    if (purchase == null) {
      await purchasesBox.delete(id);
      return;
    }

    final mvKeysToDelete = <dynamic>[];
    for (final entry in movementsBox.toMap().entries) {
      final mv = entry.value;
      if (mv.type == 'purchase' && mv.note == 'Pembelian#$id') {
        mvKeysToDelete.add(entry.key);
      }
    }
    for (final k in mvKeysToDelete) {
      await movementsBox.delete(k);
    }

    await purchasesBox.delete(id);

    final cashKeys = <dynamic>[];
    for (final entry in cashBox.toMap().entries) {
      final c = entry.value;
      if (c.source == 'purchase' && c.refId == id) cashKeys.add(entry.key);
    }
    for (final k in cashKeys) {
      await cashBox.delete(k);
    }

    final affectedProductIds = purchase.items.map((e) => e.productId).toSet();
    for (final productId in affectedProductIds) {
      final product = productsBox.get(productId);
      if (product == null) continue;

      final stock = movementsBox.values
          .where((m) => m.productId == productId)
          .fold<double>(0.0, (sum, m) => sum + m.qtyDelta);
      product.stockQty = stock.clamp(0, double.infinity);

      double totalQty = 0;
      double totalCost = 0;
      for (final p in purchasesBox.values) {
        for (final it in p.items) {
          if (it.productId != productId) continue;
          totalQty += it.qty;
          totalCost += it.qty * it.buyPrice;
        }
      }
      product.avgHpp = totalQty <= 0 ? 0 : hppWeightedAverage(totalQty: totalQty, totalCost: totalCost);

      await productsBox.put(product.id, product);
    }
  }
}
