import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../providers.dart';
import '../products/product_detail_page.dart';
import '../purchases/purchase_form.dart';
import '../sales/sale_form.dart';
import '../sales/fast_pos_page.dart';
import '../expenses/expenses_page.dart';
import '../restock/restock_page.dart';
import '../search/global_search_page.dart';
import '../../core/payment_methods.dart';
import '../../data/services/analytics_service.dart';

class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> {
  bool _insightExpanded = false;

  @override
  Widget build(BuildContext context) {
    final productsRepo = ref.watch(productRepoProvider);
    final salesRepo    = ref.watch(salesRepoProvider);
    final purchaseRepo = ref.watch(purchaseRepoProvider);
    final expenseRepo  = ref.watch(expenseRepoProvider);
    final debtRepo     = ref.watch(debtRepoProvider);
    final cashRepo     = ref.watch(cashRepoProvider);
    final rejectedRepo = ref.watch(rejectedRepoProvider);

    final today = epochDay(DateTime.now());

    final salesToday    = salesRepo.all().where((s) => s.dateEpochDay == today).toList();
    final expensesToday = expenseRepo.all().where((e) => e.dateEpochDay == today).toList();
    final rejectedToday = rejectedRepo.all().where((r) => r.dateEpochDay == today).toList();

    final omzetToday  = salesToday.fold<double>(0.0, (p, s) => p + s.totalSales);
    final hppToday    = salesToday.fold<double>(0.0, (p, s) => p + s.totalHpp);
    final biayaToday  = expensesToday.fold<double>(0.0, (p, e) => p + e.amount);
    final rugiRejek   = rejectedToday.fold<double>(0.0, (p, r) => p + r.estimatedLoss);
    final labaToday   = omzetToday - hppToday - biayaToday - rugiRejek;
    final activeDebts = debtRepo.all().where((d) => !d.isSettled).length;

    final cashAll  = cashRepo.all();
    final saldoKas = cashAll
        .where((e) => PaymentMethods.isCashFlow(e.method))
        .fold<double>(0, (p, e) => p + (e.direction == 'in' ? e.amount : -e.amount));

    // Top products today
    final soldByProduct = <String, double>{};
    for (final s in salesToday) {
      for (final it in s.items) {
        soldByProduct[it.productId] = (soldByProduct[it.productId] ?? 0) + it.qty;
      }
    }
    final topSold = soldByProduct.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    // Low stock
    final lowStock = productsRepo
        .all()
        .where((p) => p.minStock > 0 && p.stockQty <= p.minStock)
        .toList()
      ..sort((a, b) {
        final d = (a.stockQty - a.minStock).compareTo(b.stockQty - b.minStock);
        if (d != 0) return d;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    // Analytics
    final analytics  = const AnalyticsService();
    final start7     = DateTime.now().subtract(const Duration(days: 6));
    final start30    = DateTime.now().subtract(const Duration(days: 29));
    final salesBox    = ref.watch(salesBoxProvider);
    final productsBox = ref.watch(productsBoxProvider);
    final movementsBox = ref.watch(movementsBoxProvider);
    final rejectedBox  = ref.watch(rejectedItemsBoxProvider);

    final omzet7 = analytics
        .revenueTrend(salesBox, start7, DateTime.now())
        .fold<double>(0, (p, e) => p + e.value);
    final omzet30 = analytics
        .revenueTrend(salesBox, start30, DateTime.now())
        .fold<double>(0, (p, e) => p + e.value);
    final marginAlerts = analytics.lossProducts(productsBox).take(3).toList();
    final lossProducts = analytics.lossByProduct(
      productsBox, movementsBox, rejectedBox, start30, DateTime.now(),
    ).take(3).toList();
    final forecastBuy = analytics.restockForecast(
      salesBox, productsBox, DateTime.now(), windowDays: 7, horizonDays: 3,
    ).where((e) => e.suggestBuy > 0).take(4).toList();

    final now      = DateTime.now();
    final greeting = _greeting(now.hour);

    return ListView(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).padding.bottom + 100,
      ),
      children: [
        // ── Hero ──────────────────────────────────────────────────────
        _HeroHeader(
          greeting: greeting,
          date: fmtDateFromEpochDay(today),
          omzet: omzetToday,
          laba: labaToday,
          omzet7: omzet7,
          omzet30: omzet30,
        ),

        Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Stat Row (compact chips) ───────────────────────────
              _StatChipRow(
                saldoKas: saldoKas,
                txCount: salesToday.length,
                activeDebts: activeDebts,
                lowStockCount: lowStock.length,
              ),

              // ── Quick Actions 2×2 ──────────────────────────────────
              const SizedBox(height: 22),
              _SectionLabel(label: 'Aksi Cepat'),
              const SizedBox(height: 10),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 2.45,
                children: [
                  _ActionTile(
                    icon: Icons.flash_on_rounded,
                    label: 'Fast POS',
                    color: AppColors.gold,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const FastPosPage())),
                  ),
                  _ActionTile(
                    icon: Icons.search_rounded,
                    label: 'Global Search',
                    color: AppColors.cardTeal1,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const GlobalSearchPage())),
                  ),
                  _ActionTile(
                    icon: Icons.point_of_sale_rounded,
                    label: 'Catat Jual',
                    color: AppColors.cardGreen1,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const SaleFormPage())),
                  ),
                  _ActionTile(
                    icon: Icons.shopping_cart_rounded,
                    label: 'Catat Beli',
                    color: AppColors.cardIndigo1,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(
                            builder: (_) => const PurchaseFormPage())),
                  ),
                  _ActionTile(
                    icon: Icons.auto_graph_rounded,
                    label: 'Restock Cerdas',
                    color: AppColors.cardTeal2,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const RestockPage())),
                  ),
                  _ActionTile(
                    icon: Icons.request_quote_rounded,
                    label: 'Catat Biaya',
                    color: AppColors.cardAmber1,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(
                            builder: (_) => const ExpenseFormPage())),
                  ),
                ],
              ),

              // ── Stok Menipis ────────────────────────────────────────
              const SizedBox(height: 20),
              _InfoCard(
                icon: Icons.inventory_2_rounded,
                iconColor: lowStock.isEmpty
                    ? AppColors.positive
                    : const Color(0xFFC62828),
                title: 'Stok Menipis',
                badge: '${lowStock.length} item',
                badgeColor: lowStock.isEmpty
                    ? AppColors.positive
                    : const Color(0xFFC62828),
                child: lowStock.isEmpty
                    ? _EmptyCard(
                        icon: Icons.check_circle_outline_rounded,
                        message: 'Semua stok aman.',
                        positive: true,
                      )
                    : Column(
                        children: lowStock.take(5).map((p) {
                          return _LowStockItem(
                            name: p.name,
                            unit: p.unit,
                            stock: p.stockQty,
                            minStock: p.minStock,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) =>
                                      ProductDetailPage(productId: p.id)),
                            ),
                          );
                        }).toList(),
                      ),
              ),

              // ── Produk Terlaris ────────────────────────────────────
              const SizedBox(height: 10),
              _InfoCard(
                icon: Icons.local_fire_department_rounded,
                iconColor: const Color(0xFFE65100),
                title: 'Terlaris Hari Ini',
                badge: '${topSold.length} produk',
                child: topSold.isEmpty
                    ? _EmptyCard(
                        icon: Icons.storefront_outlined,
                        message: 'Belum ada penjualan hari ini.',
                      )
                    : Column(
                        children: topSold.take(3).mapIndexed((idx, e) {
                          final pr   = productsRepo.getById(e.key);
                          final name = pr?.name ?? 'Produk';
                          final unit = pr?.unit ?? '';
                          return _RankedItem(
                            rank: idx + 1,
                            title: name,
                            subtitle:
                                'Terjual: ${_fmtQty(e.value)}${unit.isNotEmpty ? ' $unit' : ''}',
                          );
                        }).toList(),
                      ),
              ),

              // ── Insight Mingguan (expandable) ──────────────────────
              const SizedBox(height: 10),
              _InsightCard(
                expanded: _insightExpanded,
                onToggle: () =>
                    setState(() => _insightExpanded = !_insightExpanded),
                omzet7: omzet7,
                omzet30: omzet30,
                marginAlerts: marginAlerts,
                lossProducts: lossProducts,
                forecastBuy: forecastBuy,
              ),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Greeting ─────────────────────────────────────────────────────────────────
String _greeting(int hour) {
  if (hour < 12) return 'Selamat pagi 🌤️';
  if (hour < 15) return 'Selamat siang ☀️';
  if (hour < 18) return 'Selamat sore 🌅';
  return 'Selamat malam 🌙';
}

String _fmtQty(num n) {
  final s = n.toStringAsFixed(2);
  return s
      .replaceAll(RegExp(r'\.00$'), '')
      .replaceAll(RegExp(r'(\.[0-9])0$'), r'$1');
}

// ─── Hero Header ──────────────────────────────────────────────────────────────
class _HeroHeader extends StatelessWidget {
  final String greeting;
  final String date;
  final double omzet;
  final double laba;
  final double omzet7;
  final double omzet30;

  const _HeroHeader({
    required this.greeting,
    required this.date,
    required this.omzet,
    required this.laba,
    required this.omzet7,
    required this.omzet30,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.drawerHeader1, AppColors.drawerHeader2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      greeting,
                      style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      date,
                      style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _TrendPill(label: '7h', value: omzet7),
                  const SizedBox(height: 4),
                  _TrendPill(label: '30h', value: omzet30),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _HeroStat(
                  label: 'Omzet Hari Ini',
                  value: fmtMoney(omzet),
                  icon: Icons.bar_chart_rounded,
                ),
              ),
              Container(
                width: 1,
                height: 44,
                color: Colors.white.withOpacity(0.2),
                margin: const EdgeInsets.symmetric(horizontal: 16),
              ),
              Expanded(
                child: _HeroStat(
                  label: 'Laba Bersih',
                  value: fmtMoney(laba),
                  icon: Icons.trending_up_rounded,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TrendPill extends StatelessWidget {
  final String label;
  final double value;
  const _TrendPill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.18), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label,
              style: GoogleFonts.poppins(
                  color: Colors.white.withOpacity(0.55),
                  fontSize: 9,
                  fontWeight: FontWeight.w500)),
          const SizedBox(width: 4),
          Text(fmtMoney(value),
              style: GoogleFonts.poppins(
                  color: Colors.white.withOpacity(0.88),
                  fontSize: 9,
                  fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _HeroStat({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Colors.white.withOpacity(0.6), size: 12),
            const SizedBox(width: 4),
            Text(label,
                style: GoogleFonts.poppins(
                    color: Colors.white.withOpacity(0.65),
                    fontSize: 10,
                    fontWeight: FontWeight.w500)),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.3,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}

// ─── Stat Chip Row ────────────────────────────────────────────────────────────
class _StatChipRow extends StatelessWidget {
  final double saldoKas;
  final int txCount;
  final int activeDebts;
  final int lowStockCount;

  const _StatChipRow({
    required this.saldoKas,
    required this.txCount,
    required this.activeDebts,
    required this.lowStockCount,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _StatChip(
            icon: Icons.account_balance_wallet_rounded,
            label: 'Kas',
            value: fmtMoney(saldoKas),
            color: AppColors.cardIndigo1,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _StatChip(
            icon: Icons.receipt_long_rounded,
            label: 'Transaksi',
            value: '$txCount×',
            color: AppColors.cardAmber1,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _StatChip(
            icon: Icons.payments_rounded,
            label: 'Hutang',
            value: '$activeDebts aktif',
            color: activeDebts > 0
                ? const Color(0xFFC05300)
                : AppColors.positive,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _StatChip(
            icon: Icons.inventory_2_rounded,
            label: 'Stok Kritis',
            value: '$lowStockCount item',
            color: lowStockCount > 0
                ? const Color(0xFFC62828)
                : AppColors.positive,
          ),
        ),
      ],
    );
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatChip({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(height: 5),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: AppColors.onSurface,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 9,
              fontWeight: FontWeight.w500,
              color: AppColors.hint,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Section Label ────────────────────────────────────────────────────────────
class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: GoogleFonts.poppins(
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: AppColors.onSurface,
        letterSpacing: -0.2,
      ),
    );
  }
}

// ─── Action Tile (2×2 horizontal) ────────────────────────────────────────────
class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(14),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.2), width: 1.5),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 17),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.onSurface,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Info Card ────────────────────────────────────────────────────────────────
class _InfoCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String badge;
  final Color? badgeColor;
  final Widget child;

  const _InfoCard({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.badge,
    this.badgeColor,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final bc = badgeColor ?? AppColors.hint;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE4EEE0), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xFFEEF4EA), width: 1),
                left: BorderSide(color: AppColors.primary, width: 3),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: iconColor, size: 14),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.onSurface,
                    ),
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: bc.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    badge,
                    style: GoogleFonts.poppins(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: bc,
                    ),
                  ),
                ),
              ],
            ),
          ),
          child,
        ],
      ),
    );
  }
}

// ─── Insight Card (expandable) ────────────────────────────────────────────────
class _InsightCard extends StatelessWidget {
  final bool expanded;
  final VoidCallback onToggle;
  final double omzet7;
  final double omzet30;
  final List<dynamic> marginAlerts;
  final List<dynamic> lossProducts;
  final List<dynamic> forecastBuy;

  const _InsightCard({
    required this.expanded,
    required this.onToggle,
    required this.omzet7,
    required this.omzet30,
    required this.marginAlerts,
    required this.lossProducts,
    required this.forecastBuy,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE4EEE0), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header — tappable to expand
          GestureDetector(
            onTap: onToggle,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Color(0xFFEEF4EA), width: 1),
                  left: BorderSide(color: AppColors.primary, width: 3),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1565C0).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.insights_rounded,
                        color: Color(0xFF1565C0), size: 14),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Insight Mingguan',
                          style: GoogleFonts.poppins(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: AppColors.onSurface,
                          ),
                        ),
                        Text(
                          '7h: ${fmtMoney(omzet7)}  •  30h: ${fmtMoney(omzet30)}',
                          style: GoogleFonts.poppins(
                            fontSize: 10,
                            color: AppColors.hint,
                          ),
                        ),
                      ],
                    ),
                  ),
                  AnimatedRotation(
                    turns: expanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 220),
                    child: const Icon(Icons.keyboard_arrow_down_rounded,
                        color: AppColors.hint, size: 20),
                  ),
                ],
              ),
            ),
          ),

          // Expandable body
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 250),
            crossFadeState: expanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Prediksi Belanja
                  _InsightSubHeader(title: 'Prediksi Belanja 3 Hari'),
                  const SizedBox(height: 6),
                  if (forecastBuy.isEmpty)
                    _InsightEmpty(message: 'Belum ada saran dari histori 7 hari.')
                  else
                    ...forecastBuy.map((e) => _InsightRow(
                          title: e.name,
                          value: '${_fmtQty(e.suggestBuy)} ${e.unit}',
                          subtitle:
                              'Rata-rata ${_fmtQty(e.avgPerDay)} ${e.unit}/hari • stok ${_fmtQty(e.stockQty)}',
                        )),

                  const SizedBox(height: 12),
                  // Margin Alerts
                  _InsightSubHeader(title: 'Margin Turun'),
                  const SizedBox(height: 6),
                  if (marginAlerts.isEmpty)
                    _InsightEmpty(message: 'Tidak ada produk di bawah target margin.', positive: true)
                  else
                    ...marginAlerts.map((e) {
                      final p      = e.$1;
                      final actual = e.$2 as double;
                      return _InsightRow(
                        title: p.name,
                        value: '${actual.toStringAsFixed(1)}%',
                        subtitle:
                            'Target ${p.defaultMarginPercent.toStringAsFixed(1)}% • HPP ${fmtMoney(p.avgHpp)}',
                      );
                    }),

                  const SizedBox(height: 12),
                  // Kerugian Produk
                  _InsightSubHeader(title: 'Kerugian Produk (30 Hari)'),
                  const SizedBox(height: 6),
                  if (lossProducts.isEmpty)
                    _InsightEmpty(message: 'Tidak ada kerugian tercatat.', positive: true)
                  else
                    ...lossProducts.map((e) => _InsightRow(
                          title: e.name,
                          value: fmtMoney(e.amount),
                          subtitle: '${_fmtQty(e.qty)} hilang • ${e.source}',
                        )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InsightSubHeader extends StatelessWidget {
  final String title;
  const _InsightSubHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: GoogleFonts.poppins(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: AppColors.hint,
        letterSpacing: 0.3,
      ),
    );
  }
}

class _InsightRow extends StatelessWidget {
  final String title;
  final String value;
  final String subtitle;

  const _InsightRow({
    required this.title,
    required this.value,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.poppins(
                        fontSize: 12, fontWeight: FontWeight.w600)),
                Text(subtitle,
                    style: GoogleFonts.poppins(
                        fontSize: 10, color: AppColors.hint)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(value,
              style: GoogleFonts.poppins(
                  fontSize: 12, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _InsightEmpty extends StatelessWidget {
  final String message;
  final bool positive;

  const _InsightEmpty({required this.message, this.positive = false});

  @override
  Widget build(BuildContext context) {
    final color = positive ? AppColors.positive : AppColors.hint;
    return Row(
      children: [
        Icon(
          positive
              ? Icons.check_circle_outline_rounded
              : Icons.info_outline_rounded,
          color: color,
          size: 14,
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            message,
            style: GoogleFonts.poppins(fontSize: 11, color: color),
          ),
        ),
      ],
    );
  }
}

// ─── Ranked Item ──────────────────────────────────────────────────────────────
class _RankedItem extends StatelessWidget {
  final int rank;
  final String title;
  final String subtitle;

  const _RankedItem(
      {required this.rank, required this.title, required this.subtitle});

  static const _rankColors = [
    Color(0xFFD4A017),
    Color(0xFF9E9E9E),
    Color(0xFFBF7D43),
  ];

  @override
  Widget build(BuildContext context) {
    final rankColor = rank <= 3 ? _rankColors[rank - 1] : AppColors.hint;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: rankColor.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              '$rank',
              style: GoogleFonts.poppins(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: rankColor,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.poppins(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.onSurface)),
                Text(subtitle,
                    style: GoogleFonts.poppins(
                        fontSize: 10, color: AppColors.hint)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Low Stock Item ───────────────────────────────────────────────────────────
class _LowStockItem extends StatelessWidget {
  final String name;
  final String unit;
  final double stock;
  final double minStock;
  final VoidCallback onTap;

  const _LowStockItem({
    required this.name,
    required this.unit,
    required this.stock,
    required this.minStock,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final pct      = minStock > 0 ? (stock / minStock).clamp(0.0, 1.0) : 0.0;
    final barColor = pct < 0.3
        ? const Color(0xFFC62828)
        : pct < 0.7
            ? const Color(0xFFE65100)
            : const Color(0xFF1A7A50);

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration:
                      BoxDecoration(color: barColor, shape: BoxShape.circle),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(name,
                      style: GoogleFonts.poppins(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: AppColors.onSurface)),
                ),
                Text(
                  '${_fmtQty(stock)} / ${_fmtQty(minStock)}${unit.isNotEmpty ? ' $unit' : ''}',
                  style: GoogleFonts.poppins(
                      fontSize: 10, color: AppColors.hint),
                ),
              ],
            ),
            const SizedBox(height: 5),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: pct,
                backgroundColor: barColor.withOpacity(0.15),
                color: barColor,
                minHeight: 3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Empty Card ───────────────────────────────────────────────────────────────
class _EmptyCard extends StatelessWidget {
  final IconData icon;
  final String message;
  final bool positive;

  const _EmptyCard({
    required this.icon,
    required this.message,
    this.positive = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = positive ? AppColors.positive : AppColors.hint;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Text(message,
              style: GoogleFonts.poppins(
                  fontSize: 12, color: color, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

// ─── Iterable helper ──────────────────────────────────────────────────────────
extension _IndexedMap<T> on Iterable<T> {
  Iterable<R> mapIndexed<R>(R Function(int idx, T item) fn) sync* {
    int i = 0;
    for (final item in this) {
      yield fn(i++, item);
    }
  }
}
