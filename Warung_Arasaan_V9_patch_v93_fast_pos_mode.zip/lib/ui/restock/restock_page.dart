import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/app_theme.dart';
import '../../providers.dart';
import '../../domain/models/product.dart';
import '../../data/services/analytics_service.dart';
import '../products/product_detail_page.dart';
import '../widgets/empty_state.dart';

class RestockPage extends ConsumerStatefulWidget {
  const RestockPage({super.key});

  @override
  ConsumerState<RestockPage> createState() => _RestockPageState();
}

class _RestockPageState extends ConsumerState<RestockPage> {
  int windowDays = 7;
  int horizonDays = 3;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Smart Restock'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'Restock Cerdas'),
              Tab(text: 'Prediksi'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _restockTab(context),
            _forecastTab(context),
          ],
        ),
      ),
    );
  }

  Widget _restockTab(BuildContext context) {
    final productsBox = ref.watch(productsBoxProvider);
    final salesBox = ref.watch(salesBoxProvider);
    final products = ref.watch(productRepoProvider).all();
    final analytics = const AnalyticsService();
    final smart = analytics.stockIntelligence(
      salesBox,
      productsBox,
      DateTime.now(),
      windowDays: windowDays,
      horizonDays: horizonDays,
      deadStockDays: windowDays,
    );

    final lowStock = smart.where((e) => e.stockQty > 0 && e.stockQty <= e.minStock && e.minStock > 0).toList();
    final emptyStock = smart.where((e) => e.stockQty <= 0.0001).toList();
    final deadStock = smart.where((e) => e.isDeadStock).toList();
    final slowMoving = smart.where((e) => e.isSlowMoving).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
      children: [
        _ConfigBar(
          windowDays: windowDays,
          horizonDays: horizonDays,
          onWindowChanged: (v) => setState(() => windowDays = v),
          onHorizonChanged: (v) => setState(() => horizonDays = v),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _SummaryCard(title: 'Stok Habis', value: '${emptyStock.length}', color: AppColors.negative, icon: Icons.cancel_rounded)),
            const SizedBox(width: 10),
            Expanded(child: _SummaryCard(title: 'Stok Kritis', value: '${lowStock.length}', color: AppColors.gold, icon: Icons.warning_amber_rounded)),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _SummaryCard(title: 'Stok Mati', value: '${deadStock.length}', color: AppColors.iconPurple, icon: Icons.inventory_2_outlined)),
            const SizedBox(width: 10),
            Expanded(child: _SummaryCard(title: 'Lambat', value: '${slowMoving.length}', color: AppColors.iconBlue, icon: Icons.timelapse_rounded)),
          ],
        ),
        const SizedBox(height: 16),
        if (smart.isEmpty)
          const EmptyState(
            title: 'Belum ada insight restock',
            subtitle: 'Tambahkan stok minimum/target dan catat penjualan agar Smart Restock mulai bekerja.',
            icon: Icons.auto_graph_rounded,
          )
        else ...[
          _SectionHeader(
            title: 'Prioritas Restock',
            subtitle: 'Urut berdasarkan kondisi stok dan saran beli.',
          ),
          const SizedBox(height: 8),
          ...smart.take(12).map((it) {
            final match = products.where((e) => e.id == it.productId);
            final p = match.isEmpty ? null : match.first;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Card(
                child: ListTile(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ProductDetailPage(productId: it.productId)),
                  ),
                  title: Text(it.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(
                    'Stok ${_fmt(it.stockQty)} ${it.unit} • Avg ${_fmt(it.avgPerDay)} ${it.unit}/hari\n'
                    'Habis ${_fmtDays(it.daysLeft)} • Saran beli ${_fmt(it.suggestBuy)} ${it.unit}',
                  ),
                  isThreeLine: true,
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _StatusBadge(
                        label: _statusLabel(it),
                        color: _statusColor(it),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        p == null ? '-' : 'Target ${_fmt(p.targetStock > 0 ? p.targetStock : p.minStock)}',
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ],
      ],
    );
  }

  Widget _forecastTab(BuildContext context) {
    final productsRepo = ref.watch(productRepoProvider);
    final salesBox = ref.watch(salesBoxProvider);
    final products = productsRepo.all();

    final todayEpoch = _epochDay(DateTime.now());
    final startEpoch = todayEpoch - (windowDays - 1);

    final soldQty = <String, double>{};
    for (final s in salesBox.values) {
      if (s.dateEpochDay < startEpoch || s.dateEpochDay > todayEpoch) continue;
      for (final it in s.items) {
        soldQty[it.productId] = (soldQty[it.productId] ?? 0) + it.qty;
      }
    }

    final items = <_ForecastItem>[];
    for (final p in products) {
      final total = soldQty[p.id] ?? 0.0;
      if (total <= 0) continue;
      final avgPerDay = total / windowDays;
      final need = avgPerDay * horizonDays;
      final suggestBuy = (need - p.stockQty);
      items.add(_ForecastItem(
        product: p,
        avgPerDay: avgPerDay,
        horizonNeed: need,
        suggestBuy: suggestBuy > 0 ? suggestBuy : 0,
      ));
    }

    items.sort((a, b) {
      final c = b.suggestBuy.compareTo(a.suggestBuy);
      if (c != 0) return c;
      return b.horizonNeed.compareTo(a.horizonNeed);
    });

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: _ConfigBar(
            windowDays: windowDays,
            horizonDays: horizonDays,
            onWindowChanged: (v) => setState(() => windowDays = v),
            onHorizonChanged: (v) => setState(() => horizonDays = v),
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: items.isEmpty
              ? const EmptyState(
                  title: 'Belum ada prediksi',
                  subtitle: 'Belum ada penjualan dalam periode ini. Coba pilih 14/30 hari atau mulai catat penjualan.',
                  icon: Icons.show_chart,
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final it = items[i];
                    final p = it.product;
                    return Card(
                      child: ListTile(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id)),
                        ),
                        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(
                          'Rata2: ${_fmt(it.avgPerDay)} ${p.unit}/hari • Perkiraan $horizonDays hari: ${_fmt(it.horizonNeed)} ${p.unit}',
                        ),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text('Saran beli', style: TextStyle(fontSize: 12)),
                            Text('${_fmt(it.suggestBuy)} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.w800)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  String _statusLabel(StockInsightKpi it) {
    if (it.stockQty <= 0.0001) return 'Habis';
    if (it.stockQty <= it.minStock && it.minStock > 0) return 'Kritis';
    if (it.isDeadStock) return 'Mati';
    if (it.isSlowMoving) return 'Lambat';
    if (it.suggestBuy > 0) return 'Restock';
    return 'Aman';
  }

  Color _statusColor(StockInsightKpi it) {
    if (it.stockQty <= 0.0001) return AppColors.negative;
    if (it.stockQty <= it.minStock && it.minStock > 0) return AppColors.gold;
    if (it.isDeadStock) return AppColors.iconPurple;
    if (it.isSlowMoving) return AppColors.iconBlue;
    return AppColors.primary;
  }

  String _fmt(double v) {
    if (v == v.roundToDouble()) return v.toStringAsFixed(0);
    return v.toStringAsFixed(2);
  }

  String _fmtDays(double days) {
    if (days >= 9999) return 'belum terukur';
    if (days <= 1) return '< 1 hari';
    if (days == days.roundToDouble()) return '${days.toStringAsFixed(0)} hari';
    return '${days.toStringAsFixed(1)} hari';
  }

  int _epochDay(DateTime dt) {
    final d = DateTime(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    final du = DateTime.utc(d.year, d.month, d.day);
    return du.difference(base).inDays;
  }
}

class _ConfigBar extends StatelessWidget {
  final int windowDays;
  final int horizonDays;
  final ValueChanged<int> onWindowChanged;
  final ValueChanged<int> onHorizonChanged;

  const _ConfigBar({
    required this.windowDays,
    required this.horizonDays,
    required this.onWindowChanged,
    required this.onHorizonChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _pillDropdown<int>(
            label: 'Data',
            value: windowDays,
            items: const [7, 14, 30],
            onChanged: onWindowChanged,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _pillDropdown<int>(
            label: 'Prediksi',
            value: horizonDays,
            items: const [3, 7],
            onChanged: onHorizonChanged,
          ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  final IconData icon;

  const _SummaryCard({required this.title, required this.value, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 2),
                  Text(value, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionHeader({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 2),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  const _StatusBadge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 11)),
    );
  }
}

Widget _pillDropdown<T>({
  required String label,
  required T value,
  required List<T> items,
  required void Function(T v) onChanged,
}) {
  return InputDecorator(
    decoration: InputDecoration(
      labelText: label,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    ),
    child: DropdownButtonHideUnderline(
      child: DropdownButton<T>(
        value: value,
        isExpanded: true,
        items: items
            .map((e) => DropdownMenuItem<T>(
                  value: e,
                  child: Text(e.toString()),
                ))
            .toList(),
        onChanged: (v) {
          if (v == null) return;
          onChanged(v);
        },
      ),
    ),
  );
}

class _ForecastItem {
  final Product product;
  final double avgPerDay;
  final double horizonNeed;
  final double suggestBuy;
  _ForecastItem({required this.product, required this.avgPerDay, required this.horizonNeed, required this.suggestBuy});
}
