import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../providers.dart';
import '../debts/debts_page.dart';
import '../partners/customers_page.dart';
import '../partners/suppliers_page.dart';
import '../products/product_detail_page.dart';
import '../purchases/purchase_detail_page.dart';
import '../sales/sale_detail_page.dart';

class GlobalSearchPage extends ConsumerStatefulWidget {
  const GlobalSearchPage({super.key});

  @override
  ConsumerState<GlobalSearchPage> createState() => _GlobalSearchPageState();
}

class _GlobalSearchPageState extends ConsumerState<GlobalSearchPage> {
  final _controller = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toLowerCase();
    final products = ref.watch(productRepoProvider).all();
    final sales = ref.watch(salesRepoProvider).all();
    final purchases = ref.watch(purchaseRepoProvider).all();
    final debts = ref.watch(debtRepoProvider).all();

    final productHits = q.isEmpty
        ? products.take(8).toList()
        : products.where((p) {
            return p.name.toLowerCase().contains(q) ||
                p.sku.toLowerCase().contains(q) ||
                p.category.toLowerCase().contains(q);
          }).take(20).toList();

    final saleHits = q.isEmpty
        ? sales.take(8).toList()
        : sales.where((s) {
            final idText = s.id.toLowerCase();
            final customer = s.customerName.toLowerCase();
            final payment = s.paymentMethod.toLowerCase();
            final productNames = s.items
                .map((it) => products.where((p) => p.id == it.productId).isNotEmpty
                    ? products.firstWhere((p) => p.id == it.productId).name.toLowerCase()
                    : '')
                .join(' ');
            return idText.contains(q) || customer.contains(q) || payment.contains(q) || productNames.contains(q);
          }).take(20).toList();

    final purchaseHits = q.isEmpty
        ? purchases.take(8).toList()
        : purchases.where((p) {
            final supplier = p.supplier.toLowerCase();
            final idText = p.id.toLowerCase();
            final productNames = p.items
                .map((it) => products.where((e) => e.id == it.productId).isNotEmpty
                    ? products.firstWhere((e) => e.id == it.productId).name.toLowerCase()
                    : '')
                .join(' ');
            return supplier.contains(q) || idText.contains(q) || productNames.contains(q);
          }).take(20).toList();

    final debtHits = q.isEmpty
        ? debts.take(8).toList()
        : debts.where((d) {
            return d.creditor.toLowerCase().contains(q) ||
                d.note.toLowerCase().contains(q) ||
                d.id.toLowerCase().contains(q);
          }).take(20).toList();

    final customerMap = <String, ({int count, double total})>{};
    for (final sale in sales) {
      final name = sale.customerName.trim();
      if (name.isEmpty) continue;
      final cur = customerMap[name] ?? (count: 0, total: 0.0);
      customerMap[name] = (count: cur.count + 1, total: cur.total + sale.totalSales);
    }
    var customerHits = customerMap.entries.toList();
    if (q.isNotEmpty) {
      customerHits = customerHits.where((e) => e.key.toLowerCase().contains(q)).toList();
    }
    customerHits.sort((a, b) => b.value.total.compareTo(a.value.total));

    final supplierMap = <String, ({int count, double total})>{};
    for (final p in purchases) {
      final name = p.supplier.trim();
      if (name.isEmpty) continue;
      final total = p.items.fold<double>(0, (sum, it) => sum + (it.qty * it.buyPrice));
      final cur = supplierMap[name] ?? (count: 0, total: 0.0);
      supplierMap[name] = (count: cur.count + 1, total: cur.total + total);
    }
    var supplierHits = supplierMap.entries.toList();
    if (q.isNotEmpty) {
      supplierHits = supplierHits.where((e) => e.key.toLowerCase().contains(q)).toList();
    }
    supplierHits.sort((a, b) => b.value.total.compareTo(a.value.total));

    final totalHits = productHits.length + saleHits.length + purchaseHits.length + debtHits.length + customerHits.length + supplierHits.length;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Global Search')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
        children: [
          TextField(
            controller: _controller,
            autofocus: true,
            decoration: InputDecoration(
              hintText: 'Cari produk, SKU, transaksi, supplier, pelanggan, hutang...',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () {
                        _controller.clear();
                        setState(() => _query = '');
                      },
                      icon: const Icon(Icons.close_rounded),
                    ),
            ),
            onChanged: (v) => setState(() => _query = v),
          ),
          const SizedBox(height: 12),
          _SearchSummaryCard(query: _query, totalHits: totalHits),
          const SizedBox(height: 16),
          _SectionCard(
            title: 'Produk',
            badge: '${productHits.length}',
            child: productHits.isEmpty
                ? const _NoResult(text: 'Tidak ada produk yang cocok.')
                : Column(
                    children: productHits.map((p) => ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: AppColors.primaryContainer,
                        child: Text((p.name.isNotEmpty ? p.name[0] : '?').toUpperCase()),
                      ),
                      title: Text(p.name),
                      subtitle: Text('${p.category} • SKU ${p.sku.isEmpty ? '-' : p.sku}'),
                      trailing: Text(_fmtQty(p.stockQty, p.unit)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id))),
                    )).toList(),
                  ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Penjualan',
            badge: '${saleHits.length}',
            child: saleHits.isEmpty
                ? const _NoResult(text: 'Tidak ada transaksi penjualan yang cocok.')
                : Column(
                    children: saleHits.map((s) => ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.point_of_sale_rounded, color: AppColors.iconGreen),
                      title: Text(s.customerName.trim().isEmpty ? 'Transaksi ${s.id}' : s.customerName),
                      subtitle: Text('${fmtDateFromEpochDay(s.dateEpochDay)} • ${s.paymentSummary}'),
                      trailing: Text(fmtMoney(s.totalSales)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SaleDetailPage(saleId: s.id))),
                    )).toList(),
                  ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Pembelian',
            badge: '${purchaseHits.length}',
            child: purchaseHits.isEmpty
                ? const _NoResult(text: 'Tidak ada transaksi pembelian yang cocok.')
                : Column(
                    children: purchaseHits.map((p) {
                      final total = p.items.fold<double>(0, (sum, it) => sum + (it.qty * it.buyPrice));
                      return ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.shopping_cart_rounded, color: AppColors.iconBlue),
                        title: Text(p.supplier.trim().isEmpty ? 'Pembelian ${p.id}' : p.supplier),
                        subtitle: Text('${fmtDateFromEpochDay(p.dateEpochDay)} • ${p.items.length} item'),
                        trailing: Text(fmtMoney(total)),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PurchaseDetailPage(purchaseId: p.id))),
                      );
                    }).toList(),
                  ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Hutang',
            badge: '${debtHits.length}',
            child: debtHits.isEmpty
                ? const _NoResult(text: 'Tidak ada hutang yang cocok.')
                : Column(
                    children: debtHits.map((d) => ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.payments_rounded, color: AppColors.iconAmber),
                      title: Text(d.creditor),
                      subtitle: Text('${fmtDateFromEpochDay(d.dateEpochDay)} • ${d.note.isEmpty ? 'Tanpa catatan' : d.note}'),
                      trailing: Text(fmtMoney(d.remaining)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DebtsPage())),
                    )).toList(),
                  ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _SectionCard(
                  title: 'Pelanggan',
                  badge: '${customerHits.length}',
                  child: customerHits.isEmpty
                      ? const _NoResult(text: 'Tidak ada pelanggan.')
                      : Column(
                          children: customerHits.take(6).map((e) => ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            leading: const Icon(Icons.people_alt_rounded, color: AppColors.iconPurple),
                            title: Text(e.key),
                            subtitle: Text('${e.value.count} transaksi'),
                            trailing: Text(fmtMoney(e.value.total)),
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomersPage())),
                          )).toList(),
                        ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Supplier',
            badge: '${supplierHits.length}',
            child: supplierHits.isEmpty
                ? const _NoResult(text: 'Tidak ada supplier.')
                : Column(
                    children: supplierHits.take(6).map((e) => ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.local_shipping_rounded, color: AppColors.iconBlue),
                      title: Text(e.key),
                      subtitle: Text('${e.value.count} pembelian'),
                      trailing: Text(fmtMoney(e.value.total)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SuppliersPage())),
                    )).toList(),
                  ),
          ),
        ],
      ),
    );
  }

  String _fmtQty(double qty, String unit) {
    if (qty == qty.roundToDouble()) return '${qty.toStringAsFixed(0)} $unit';
    return '${qty.toStringAsFixed(2)} $unit';
  }
}

class _SearchSummaryCard extends StatelessWidget {
  final String query;
  final int totalHits;

  const _SearchSummaryCard({required this.query, required this.totalHits});

  @override
  Widget build(BuildContext context) {
    final hasQuery = query.trim().isNotEmpty;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.primaryContainer,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(Icons.travel_explore_rounded, color: AppColors.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasQuery ? 'Hasil untuk "$query"' : 'Pencarian terpadu Warung Arasaan',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    hasQuery ? '$totalHits hasil ditemukan di seluruh modul.' : 'Cari data produk, transaksi, pembelian, supplier, pelanggan, dan hutang dalam satu tempat.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final String badge;
  final Widget child;

  const _SectionCard({required this.title, required this.badge, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(badge, style: Theme.of(context).textTheme.labelSmall),
                ),
              ],
            ),
            const SizedBox(height: 8),
            child,
          ],
        ),
      ),
    );
  }
}

class _NoResult extends StatelessWidget {
  final String text;
  const _NoResult({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(text, style: Theme.of(context).textTheme.bodySmall),
    );
  }
}
