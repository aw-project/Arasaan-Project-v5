import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/cash_entry.dart';
import '../widgets/empty_state.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/money_field.dart';

class DebtsPage extends ConsumerStatefulWidget {
  const DebtsPage({super.key});

  @override
  ConsumerState<DebtsPage> createState() => _DebtsPageState();
}

class _DebtsPageState extends ConsumerState<DebtsPage> {
  final searchC = TextEditingController();
  String filter = 'aktif';

  @override
  void dispose() {
    searchC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(debtRepoProvider);
    final items = repo.all();
    final cashEntries = ref.watch(cashBoxProvider).values.toList();

    final q = searchC.text.trim().toLowerCase();
    final filtered = items.where((d) {
      final matchesQuery = q.isEmpty ||
          d.creditor.toLowerCase().contains(q) ||
          d.note.toLowerCase().contains(q);
      final matchesFilter = switch (filter) {
        'aktif' => !d.isSettled,
        'lunas' => d.isSettled,
        _ => true,
      };
      return matchesQuery && matchesFilter;
    }).toList()
      ..sort((a, b) {
        final activeCmp = (a.isSettled ? 1 : 0).compareTo(b.isSettled ? 1 : 0);
        if (activeCmp != 0) return activeCmp;
        return b.remaining.compareTo(a.remaining);
      });

    final activeDebts = items.where((d) => !d.isSettled).toList();
    final settledDebts = items.where((d) => d.isSettled).toList();
    final totalPrincipal = items.fold<double>(0.0, (s, d) => s + d.principal);
    final totalPaid = items.fold<double>(0.0, (s, d) => s + d.paid);
    final totalRemaining = items.fold<double>(0.0, (s, d) => s + d.remaining);
    final paidThisMonth = cashEntries
        .where((e) => e.source == 'debt_payment')
        .where((e) {
          final dt = fromEpochDay(e.dateEpochDay);
          final now = DateTime.now();
          return dt.year == now.year && dt.month == now.month;
        })
        .fold<double>(0.0, (s, e) => s + e.amount);

    return Stack(
      children: [
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              child: Column(
                children: [
                  _SummaryGrid(
                    totalPrincipal: totalPrincipal,
                    totalPaid: totalPaid,
                    totalRemaining: totalRemaining,
                    activeCount: activeDebts.length,
                    settledCount: settledDebts.length,
                    paidThisMonth: paidThisMonth,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: searchC,
                    decoration: InputDecoration(
                      labelText: 'Cari kreditur / catatan',
                      prefixIcon: const Icon(Icons.search_rounded),
                      suffixIcon: searchC.text.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                searchC.clear();
                                setState(() {});
                              },
                              icon: const Icon(Icons.close_rounded),
                            ),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: _FilterChip(label: 'Aktif', selected: filter == 'aktif', onTap: () => setState(() => filter = 'aktif'))),
                      const SizedBox(width: 8),
                      Expanded(child: _FilterChip(label: 'Lunas', selected: filter == 'lunas', onTap: () => setState(() => filter = 'lunas'))),
                      const SizedBox(width: 8),
                      Expanded(child: _FilterChip(label: 'Semua', selected: filter == 'semua', onTap: () => setState(() => filter = 'semua'))),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                  ? const EmptyState(
                      title: 'Tidak ada data yang cocok',
                      subtitle: 'Coba ubah pencarian atau filter hutang.',
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 100),
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (context, i) {
                        final d = filtered[i];
                        final pct = d.principal > 0 ? (d.paid / d.principal).clamp(0.0, 1.0) : 0.0;
                        final isLunas = d.isSettled;
                        final lastPayment = _lastPaymentFor(cashEntries, d.id);
                        return Dismissible(
                          key: ValueKey(d.id),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 20),
                            decoration: BoxDecoration(
                              color: AppColors.negative,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Icon(Icons.delete_rounded, color: Colors.white, size: 24),
                          ),
                          confirmDismiss: (_) async {
                            return await showDialog<bool>(
                                  context: context,
                                  builder: (_) => AlertDialog(
                                    title: const Text('Hapus Hutang?'),
                                    content: const Text('Data hutang dan riwayat pembayaran kas akan ikut dihapus.'),
                                    actions: [
                                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                                      FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                                    ],
                                  ),
                                ) ??
                                false;
                          },
                          onDismissed: (_) async {
                            final messenger = ScaffoldMessenger.of(context);
                            await repo.remove(d.id);
                            messenger.showSnackBar(const SnackBar(content: Text('Hutang dihapus')));
                          },
                          child: Material(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(16),
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DebtPaymentPage(debtId: d.id))),
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: isLunas ? const Color(0xFFB7EFCE) : const Color(0xFFFFCDD2),
                                    width: 1,
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                padding: const EdgeInsets.all(14),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          width: 36,
                                          height: 36,
                                          decoration: BoxDecoration(
                                            color: isLunas ? const Color(0xFFB7EFCE) : const Color(0xFFFFEBEE),
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          child: Icon(
                                            isLunas ? Icons.check_circle_rounded : Icons.account_balance_wallet_rounded,
                                            color: isLunas ? AppColors.positive : AppColors.negative,
                                            size: 18,
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(d.creditor,
                                                  style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.onSurface)),
                                              Text(
                                                '${fmtDateFromEpochDay(d.dateEpochDay)}${d.note.trim().isEmpty ? '' : ' • ${d.note.trim()}'}',
                                                style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                          decoration: BoxDecoration(
                                            color: (isLunas ? AppColors.positive : AppColors.negative).withOpacity(0.1),
                                            borderRadius: BorderRadius.circular(20),
                                          ),
                                          child: Text(
                                            isLunas ? 'LUNAS' : 'AKTIF',
                                            style: GoogleFonts.poppins(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: isLunas ? AppColors.positive : AppColors.negative,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 10),
                                    Row(
                                      children: [
                                        Expanded(child: _DKV(label: 'Pokok', value: fmtMoney(d.principal))),
                                        Expanded(child: _DKV(label: 'Terbayar', value: fmtMoney(d.paid))),
                                        Expanded(
                                          child: _DKV(
                                            label: 'Sisa',
                                            value: fmtMoney(d.remaining),
                                            color: isLunas ? AppColors.positive : AppColors.negative,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(99),
                                      child: LinearProgressIndicator(
                                        value: pct,
                                        backgroundColor: AppColors.negative.withOpacity(0.12),
                                        color: isLunas ? AppColors.positive : AppColors.primary,
                                        minHeight: 6,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            isLunas
                                                ? 'Sudah lunas'
                                                : 'Progress ${((pct) * 100).toStringAsFixed(1)}% • Ketuk untuk bayar',
                                            style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                                          ),
                                        ),
                                        if (lastPayment != null)
                                          Text(
                                            'Bayar terakhir ${fmtDateFromEpochDay(lastPayment.dateEpochDay)}',
                                            style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DebtFormPage())),
            child: Image.asset('assets/icons/ic_add.png', width: 24, height: 24),
          ),
        ),
      ],
    );
  }

  CashEntry? _lastPaymentFor(List<CashEntry> entries, String debtId) {
    final list = entries.where((e) => e.source == 'debt_payment' && e.refId == debtId).toList()
      ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));
    return list.isEmpty ? null : list.first;
  }
}

class DebtFormPage extends ConsumerStatefulWidget {
  const DebtFormPage({super.key});

  @override
  ConsumerState<DebtFormPage> createState() => _DebtFormPageState();
}

class _DebtFormPageState extends ConsumerState<DebtFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  final creditorC = TextEditingController();
  final noteC = TextEditingController();
  final principalC = TextEditingController();

  @override
  void dispose() {
    creditorC.dispose();
    noteC.dispose();
    principalC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Hutang')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            TextFormField(
              controller: creditorC,
              decoration: const InputDecoration(labelText: 'Kreditur (supplier/nama)'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(controller: noteC, decoration: const InputDecoration(labelText: 'Catatan (opsional)')),
            const SizedBox(height: 12),
            MoneyField(controller: principalC, label: 'Jumlah hutang', requiredField: true),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan')),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final d = Debt(
      id: newId('debt'),
      dateEpochDay: epochDay(date),
      creditor: creditorC.text.trim(),
      note: noteC.text.trim(),
      principal: (parseRupiah(principalC.text.trim()) ?? 0).toDouble(),
      paid: 0,
    );
    await ref.read(debtRepoProvider).add(d);
    if (!mounted) return;
    Navigator.pop(context);
  }
}

class DebtPaymentPage extends ConsumerStatefulWidget {
  final String debtId;
  const DebtPaymentPage({super.key, required this.debtId});

  @override
  ConsumerState<DebtPaymentPage> createState() => _DebtPaymentPageState();
}

class _DebtPaymentPageState extends ConsumerState<DebtPaymentPage> {
  final _formKey = GlobalKey<FormState>();
  final payC = TextEditingController();
  DateTime date = DateTime.now();
  String method = 'Cash';

  @override
  void dispose() {
    payC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final box = ref.watch(debtsBoxProvider);
    final debt = box.get(widget.debtId);
    final payments = ref
        .watch(cashBoxProvider)
        .values
        .where((e) => e.source == 'debt_payment' && e.refId == widget.debtId)
        .toList()
      ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

    if (debt == null) {
      return const Scaffold(body: Center(child: Text('Data hutang tidak ditemukan')));
    }

    final pct = debt.principal > 0 ? (debt.paid / debt.principal).clamp(0.0, 1.0) : 0.0;

    return Scaffold(
      appBar: AppBar(title: const Text('Pembayaran Hutang')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(debt.creditor, style: Theme.of(context).textTheme.titleMedium),
                      ),
                      Text(
                        debt.isSettled ? 'LUNAS' : 'AKTIF',
                        style: TextStyle(
                          color: debt.isSettled ? AppColors.positive : AppColors.negative,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  if (debt.note.trim().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(debt.note, style: Theme.of(context).textTheme.bodySmall),
                  ],
                  const SizedBox(height: 12),
                  _payRow('Pokok hutang', fmtMoney(debt.principal)),
                  _payRow('Sudah dibayar', fmtMoney(debt.paid)),
                  _payRow('Sisa tagihan', fmtMoney(debt.remaining), emphasize: true),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      value: pct,
                      minHeight: 8,
                      backgroundColor: AppColors.negative.withOpacity(0.12),
                      color: debt.isSettled ? AppColors.positive : AppColors.primary,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text('Progress ${((pct) * 100).toStringAsFixed(1)}%', style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Form(
            key: _formKey,
            child: Column(
              children: [
                DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal bayar'),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: method,
                  decoration: const InputDecoration(labelText: 'Metode pembayaran'),
                  items: const [
                    DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                    DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                  ],
                  onChanged: (v) => setState(() => method = v ?? 'Cash'),
                ),
                const SizedBox(height: 12),
                MoneyField(controller: payC, label: 'Tambah pembayaran', requiredField: true),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton(
                      onPressed: debt.remaining <= 0 ? null : () => _setQuickAmount(debt.remaining),
                      child: const Text('Bayar sisa'),
                    ),
                    OutlinedButton(
                      onPressed: debt.remaining <= 0 ? null : () => _setQuickAmount(debt.remaining / 2),
                      child: const Text('50% sisa'),
                    ),
                    OutlinedButton(
                      onPressed: debt.remaining <= 0 ? null : () => _setQuickAmount(100000),
                      child: const Text('100rb'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: debt.isSettled ? null : _pay,
                  icon: const Icon(Icons.payments_rounded),
                  label: const Text('Simpan Pembayaran'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text('Riwayat Pembayaran', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (payments.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('Belum ada pembayaran untuk hutang ini.'),
              ),
            )
          else
            ...payments.map(
              (p) => Card(
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: AppColors.surfaceVariant,
                    child: Icon(Icons.payments_rounded, color: AppColors.primary),
                  ),
                  title: Text(fmtMoney(p.amount)),
                  subtitle: Text('${fmtDateFromEpochDay(p.dateEpochDay)} • ${p.method}'),
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _setQuickAmount(double value) {
    final rounded = value <= 0 ? 0 : value.round();
    payC.text = _formatThousands(rounded.toString());
    setState(() {});
  }

  String _formatThousands(String digits) {
    final chars = digits.split('');
    final buf = StringBuffer();
    for (int i = 0; i < chars.length; i++) {
      final idxFromEnd = chars.length - i;
      buf.write(chars[i]);
      if (idxFromEnd > 1 && idxFromEnd % 3 == 1) {
        buf.write('.');
      }
    }
    return buf.toString();
  }

  Future<void> _pay() async {
    if (!_formKey.currentState!.validate()) return;
    final debt = ref.read(debtsBoxProvider).get(widget.debtId);
    if (debt == null) return;

    var amount = (parseRupiah(payC.text.trim()) ?? 0).toDouble();
    if (amount <= 0) return;
    if (amount > debt.remaining) {
      amount = debt.remaining;
    }

    await ref.read(debtRepoProvider).addPayment(
          widget.debtId,
          amount,
          dateEpochDay: epochDay(date),
          method: method,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Pembayaran tersimpan: ${fmtMoney(amount)}')),
    );
    payC.clear();
    setState(() {});
  }

  Widget _payRow(String label, String value, {bool emphasize = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.hint))),
          Text(
            value,
            style: TextStyle(
              fontWeight: emphasize ? FontWeight.w700 : FontWeight.w600,
              color: emphasize ? AppColors.negative : null,
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryGrid extends StatelessWidget {
  final double totalPrincipal;
  final double totalPaid;
  final double totalRemaining;
  final int activeCount;
  final int settledCount;
  final double paidThisMonth;

  const _SummaryGrid({
    required this.totalPrincipal,
    required this.totalPaid,
    required this.totalRemaining,
    required this.activeCount,
    required this.settledCount,
    required this.paidThisMonth,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.55,
      children: [
        _SummaryCard(title: 'Sisa Hutang', value: fmtMoney(totalRemaining), color: AppColors.negative),
        _SummaryCard(title: 'Terbayar', value: fmtMoney(totalPaid), color: AppColors.positive),
        _SummaryCard(title: 'Hutang Aktif', value: '$activeCount akun', color: AppColors.primary),
        _SummaryCard(title: 'Bayar Bulan Ini', value: fmtMoney(paidThisMonth), color: AppColors.gold),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  const _SummaryCard({required this.title, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.18)),
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(title, style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint, fontWeight: FontWeight.w500)),
          const SizedBox(height: 6),
          Text(value, style: GoogleFonts.poppins(fontSize: 14, color: color, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryContainer : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : const Color(0xFFDEEBD8)),
        ),
        child: Center(
          child: Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: selected ? AppColors.primary : AppColors.onSurface,
            ),
          ),
        ),
      ),
    );
  }
}

class _DKV extends StatelessWidget {
  final String label;
  final String value;
  final Color? color;
  const _DKV({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: GoogleFonts.poppins(fontSize: 10, color: AppColors.hint)),
        Text(
          value,
          style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: color ?? AppColors.onSurface),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}
