import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../../core/ui_debouncer.dart';
import '../../core/pagination_mixin.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/app_theme.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/ids.dart';
import '../../core/calc.dart';
import '../../core/unit_utils.dart';
import '../../core/dates.dart';
import '../../domain/models/product.dart';
import '../widgets/empty_state.dart';
import '../widgets/number_field.dart';
import '../widgets/money_field.dart';
import 'product_detail_page.dart';
import 'stock_opname_page.dart';

enum _SortMode { nameAsc, stockAsc, stockDesc, lowFirst }

class ProductsPage extends ConsumerStatefulWidget {
  const ProductsPage({super.key});

  @override
  ConsumerState<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends ConsumerState<ProductsPage> with PaginationMixin {
  final qC = TextEditingController();
  final _searchDebouncer = UiDebouncer();
  String _query = '';
  bool onlyLow = false;
  bool onlyMarginDown = false;
  String selectedCategory = 'Semua';
  _SortMode sortMode = _SortMode.nameAsc;

  @override
  void initState() {
    super.initState();
    initPagination(pageSize: 30, onLoadMore: () => setState(() {}));
  }

  @override
  void dispose() {
    _searchDebouncer.dispose();
    qC.dispose();
    disposePagination();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(productRepoProvider);
    final itemsAll = repo.all();

    if (itemsAll.isEmpty) {
      return Stack(
        children: [
          const EmptyState(
            title: 'Belum ada produk',
            subtitle: 'Tambahkan produk dulu, lalu kamu bisa input pembelian & penjualan.',
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton.extended(
              onPressed: () => _openForm(context, ref),
              icon: const Icon(Icons.add_rounded),
              label: Text('Tambah', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      );
    }

    final q = _query;
    final categories = <String>{'Semua'}..addAll(itemsAll.map((p) => p.category.trim().isEmpty ? 'Lainnya' : p.category).toSet());
    final lowCount = itemsAll.where((p) => p.minStock > 0 && p.stockQty <= p.minStock).length;
    final marginDownCount = itemsAll.where((p) {
      final sell = p.activeSellPrice;
      final hpp = p.avgHpp;
      if (sell <= 0) return false;
      final m = actualMarginPercent(sellPrice: sell, hpp: hpp);
      return (sell < hpp) || (m + 1e-9 < p.defaultMarginPercent);
    }).length;

    final items = itemsAll.where((p) {
      if (onlyLow && !(p.minStock > 0 && p.stockQty <= p.minStock)) return false;
      if (onlyMarginDown) {
        final sell = p.activeSellPrice;
        final hpp = p.avgHpp;
        if (sell <= 0) return false;
        final m = actualMarginPercent(sellPrice: sell, hpp: hpp);
        if (!((sell < hpp) || (m + 1e-9 < p.defaultMarginPercent))) return false;
      }
      if (selectedCategory != 'Semua' && p.category != selectedCategory) return false;
      if (q.isEmpty) return true;
      return p.name.toLowerCase().contains(q) || p.sku.toLowerCase().contains(q) || p.category.toLowerCase().contains(q);
    }).toList();

    items.sort((a, b) {
      switch (sortMode) {
        case _SortMode.nameAsc:
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
        case _SortMode.stockAsc:
          return a.stockQty.compareTo(b.stockQty);
        case _SortMode.stockDesc:
          return b.stockQty.compareTo(a.stockQty);
        case _SortMode.lowFirst:
          final al = (a.minStock > 0 && a.stockQty <= a.minStock) ? 0 : 1;
          final bl = (b.minStock > 0 && b.stockQty <= b.minStock) ? 0 : 1;
          final c = al.compareTo(bl);
          if (c != 0) return c;
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      }
    });

    return Stack(
      children: [
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: qC,
                          decoration: InputDecoration(
                            prefixIcon: const Icon(Icons.search),
                            hintText: 'Cari produk...',
                            suffixIcon: q.isEmpty
                                ? null
                                : IconButton(
                                    icon: const Icon(Icons.clear),
                                    onPressed: () {
                                      qC.clear();
                                      _searchDebouncer.flush(() => setState(() => _query = ''));
                                    },
                                  ),
                          ),
                          onChanged: (value) {
                            _searchDebouncer.run(() {
                              if (!mounted) return;
                              setState(() => _query = value.trim().toLowerCase());
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      PopupMenuButton<_SortMode>(
                        tooltip: 'Sort',
                        initialValue: sortMode,
                        onSelected: (v) => setState(() => sortMode = v),
                        itemBuilder: (context) => const [
                          PopupMenuItem(value: _SortMode.nameAsc, child: Text('Nama A–Z')),
                          PopupMenuItem(value: _SortMode.lowFirst, child: Text('Stok menipis dulu')),
                          PopupMenuItem(value: _SortMode.stockDesc, child: Text('Stok terbanyak')),
                          PopupMenuItem(value: _SortMode.stockAsc, child: Text('Stok tersedikit')),
                        ],
                        child: const Padding(
                          padding: EdgeInsets.all(8),
                          child: Icon(Icons.sort),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Stok opname',
                        icon: const Icon(Icons.fact_check_outlined),
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const StockOpnamePage()),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      FilterChip(
                        label: Text('Stok menipis ($lowCount)'),
                        selected: onlyLow,
                        onSelected: (v) => setState(() => onlyLow = v),
                      ),
                      FilterChip(
                        label: Text('Margin turun ($marginDownCount)'),
                        selected: onlyMarginDown,
                        onSelected: (v) => setState(() => onlyMarginDown = v),
                      ),
                      DropdownButton<String>(
                        value: categories.contains(selectedCategory) ? selectedCategory : 'Semua',
                        items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                        onChanged: (v) => setState(() => selectedCategory = v ?? 'Semua'),
                      ),
                      Text(
                        'Total: ${items.length}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: items.isEmpty
                  ? const Center(child: Text('Tidak ada produk yang cocok.'))
                  : _buildProductList(context, ref, items, repo),
            ),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton.extended(
            onPressed: () => _openForm(context, ref),
            icon: const Icon(Icons.add_rounded),
            label: Text('Tambah', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );
  }

  Widget _buildProductList(BuildContext context, WidgetRef ref, List items, dynamic repo) {
    final visible = paginate(items);
    final more = hasMore(items);
    return ListView.separated(
      controller: paginatedScrollController,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
      itemCount: visible.length + (more ? 1 : 0),
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        if (i == visible.length) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'Gulir untuk lihat ${items.length - visible.length} produk lainnya...',
                style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint),
              ),
            ),
          );
        }
        final p = visible[i];
        final rec = recommendedSellPrice(hpp: p.avgHpp, marginPercent: p.defaultMarginPercent);
        final low = p.minStock > 0 && p.stockQty <= p.minStock;
        final sell = p.activeSellPrice;
        final hpp = p.avgHpp;
        final actual = actualMarginPercent(sellPrice: sell, hpp: hpp);
        final marginDown = sell > 0 && ((sell < hpp) || (actual + 1e-9 < p.defaultMarginPercent));
        final loss = sell > 0 && (sell < hpp);

        return Dismissible(
          key: ValueKey(p.id),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            decoration: BoxDecoration(
              color: AppColors.negative,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.delete_rounded, color: Colors.white, size: 24),
          ),
          confirmDismiss: (_) => showDialog<bool>(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Hapus produk?'),
              content: Text('Produk "${p.name}" akan dihapus permanen.'),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Batal')),
                FilledButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Hapus')),
              ],
            ),
          ).then((v) => v ?? false),
          onDismissed: (_) async {
            final messenger = ScaffoldMessenger.of(context);
            await repo.remove(p.id);
            messenger.showSnackBar(const SnackBar(content: Text('Produk dihapus')));
          },
          child: _ProductCard(
            product: p,
            isLow: low,
            isMarginDown: marginDown,
            isLoss: loss,
            recPrice: rec,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id)),
            ),
            onEdit: () => _openForm(context, ref, product: p),
            onDelete: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Hapus produk?'),
                  content: Text('Produk "${p.name}" akan dihapus.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                    FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                  ],
                ),
              );
              if (ok == true) {
                await repo.remove(p.id);
                if (mounted) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(const SnackBar(content: Text('Produk dihapus')));
                }
              }
            },
          ),
        );
      },
    );
  }

  Future<void> _openForm(BuildContext context, WidgetRef ref, {Product? product}) async {
    if (product == null) {
      // ADD: open as bottom sheet
      await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (_) => const ProductFormPage(showAsSheet: true),
      );
    } else {
      // EDIT: navigate to full page
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ProductFormPage(product: product)),
      );
    }
  }
}

class ProductFormPage extends ConsumerStatefulWidget {
  final Product? product;
  final bool showAsSheet;
  const ProductFormPage({super.key, this.product, this.showAsSheet = false});

  @override
  ConsumerState<ProductFormPage> createState() => _ProductFormPageState();
}

class _ProductFormPageState extends ConsumerState<ProductFormPage> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController nameC;
  late final TextEditingController unitC;
  late final TextEditingController marginC;
  late final TextEditingController sellC;
  late final TextEditingController minStockC;
  late final TextEditingController targetStockC;
  late final TextEditingController skuC;
  late final TextEditingController categoryC;
  String? imagePath;

  static const List<String> _categoryOptions = [
    'Sayur',
    'Buah',
    'Bumbu',
    'Sembako',
    'Minuman',
    'Snack',
    'Lainnya',
  ];

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    nameC = TextEditingController(text: p?.name ?? '');
    unitC = TextEditingController(text: p?.unit ?? 'gram');
    marginC = TextEditingController(text: (p?.defaultMarginPercent ?? 20).toStringAsFixed(0));
    sellC = TextEditingController(text: (p?.activeSellPrice ?? 0).toStringAsFixed(0));
    minStockC = TextEditingController(text: (p?.minStock ?? 0).toStringAsFixed(2));
    targetStockC = TextEditingController(text: (p?.targetStock ?? 0).toStringAsFixed(2));
    skuC = TextEditingController(text: p?.sku ?? '');
    categoryC = TextEditingController(text: p?.category ?? 'Lainnya');
    imagePath = p?.imagePath;
  }

  @override
  void dispose() {
    nameC.dispose();
    unitC.dispose();
    marginC.dispose();
    sellC.dispose();
    minStockC.dispose();
    targetStockC.dispose();
    skuC.dispose();
    categoryC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.product != null;
        final formContent = Form(
      key: _formKey,
      child: ListView(
        shrinkWrap: widget.showAsSheet,
        physics: widget.showAsSheet ? const NeverScrollableScrollPhysics() : null,
        padding: EdgeInsets.fromLTRB(16, 8, 16,
            widget.showAsSheet ? MediaQuery.of(context).viewInsets.bottom + 24 : 16),
        children: [
          if (widget.showAsSheet) ...[
            Center(
              child: Container(
                width: 36, height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: Colors.grey.withOpacity(0.3), borderRadius: BorderRadius.circular(2)),
              ),
            ),
            Row(children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(color: const Color(0xFFB7EFCE), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.inventory_2_rounded, color: Color(0xFF0B5E38), size: 18),
              ),
              const SizedBox(width: 10),
              Text(isEdit ? 'Edit Produk' : 'Tambah Produk', style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 16),
          ],
          TextFormField(
            controller: nameC,
            decoration: const InputDecoration(labelText: 'Nama Produk'),
            validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: unitC,
            decoration: const InputDecoration(labelText: 'Satuan (gram/ikat/pcs)', helperText: 'Gunakan gram untuk produk timbang.'),
            validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: skuC,
            decoration: const InputDecoration(labelText: 'Kode produk / barcode manual (opsional)'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _categoryOptions.contains(categoryC.text) ? categoryC.text : 'Lainnya',
            decoration: const InputDecoration(labelText: 'Kategori'),
            items: _categoryOptions.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => categoryC.text = v ?? 'Lainnya',
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickImage,
            icon: const Icon(Icons.photo_library_outlined),
            label: Text(imagePath == null ? 'Pilih foto produk (opsional)' : 'Ganti foto produk'),
          ),
          if (imagePath != null) ...[
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                height: 120,
                width: double.infinity,
                child: Image.file(File(imagePath!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Text('Foto tidak bisa dibuka'))),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: () => setState(() => imagePath = null),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Hapus foto'),
              ),
            ),
          ],
          const SizedBox(height: 12),
          NumberField(controller: marginC, label: 'Margin default (%)', requiredField: true),
          const SizedBox(height: 12),
          MoneyField(controller: sellC, label: 'Harga jual aktif', requiredField: true),
          const SizedBox(height: 12),
          NumberField(controller: minStockC, label: 'Stok minimum (peringatan)', requiredField: false),
          const SizedBox(height: 12),
          NumberField(controller: targetStockC, label: 'Target stok (saran belanja)', requiredField: false),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save_rounded),
            label: Text('Simpan', style: GoogleFonts.poppins(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
          const SizedBox(height: 8),
          Text(
            'Jika stok minimum > 0 dan stok saat ini <= minimum, produk akan ditandai "stok menipis".',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );

    if (widget.showAsSheet) {
      return Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: SingleChildScrollView(child: formContent),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Produk' : 'Tambah Produk')),
      body: formContent,
    );
  } // end build()

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image, allowMultiple: false, withData: false);
    final path = result?.files.single.path;
    if (path == null || path.isEmpty) return;
    if (!mounted) return;
    setState(() => imagePath = path);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final repo = ref.read(productRepoProvider);

    final name = nameC.text.trim();
    var unit = normalizeUnitLabel(unitC.text.trim());
    final margin = double.parse(marginC.text.trim());
    final sell = (parseRupiah(sellC.text.trim()) ?? 0).toDouble();
    final minStock = double.tryParse(minStockC.text.trim().replaceAll(',', '.')) ?? 0.0;
    final targetStock = double.tryParse(targetStockC.text.trim().replaceAll(',', '.')) ?? 0.0;
    final sku = skuC.text.trim();
    final category = categoryC.text.trim().isEmpty ? 'Lainnya' : categoryC.text.trim();

    if (margin < 0 || margin > 95) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Margin harus 0–95%')));
      return;
    }
    if (minStock < 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Stok minimum tidak boleh negatif')));
      return;
    }

    final p = widget.product;
    if (p == null) {
      final np = Product(
        id: newId('prd'),
        name: name,
        unit: unit,
        defaultMarginPercent: margin,
        activeSellPrice: sell,
        stockQty: 0,
        avgHpp: 0,
        minStock: minStock,
        targetStock: targetStock,
        sku: sku,
        category: category,
        imagePath: imagePath,
      );
      await repo.upsert(np);
    } else {
      p.name = name;
      p.unit = unit;
      p.defaultMarginPercent = margin;
      p.activeSellPrice = sell;
      p.minStock = minStock;
      p.targetStock = targetStock;
      p.sku = sku;
      p.category = category;
      p.imagePath = imagePath;
      await repo.upsert(p);
    }

    if (!mounted) return;
    Navigator.pop(context);
  }
} // end _ProductFormPageState

// ─── Product Card ─────────────────────────────────────────────────────────────

class _ProductCard extends StatelessWidget {
  final dynamic product;
  final bool isLow;
  final bool isMarginDown;
  final bool isLoss;
  final double recPrice;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _ProductCard({
    required this.product,
    required this.isLow,
    required this.isMarginDown,
    required this.isLoss,
    required this.recPrice,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: isLow
                  ? const Color(0xFFFFCDD2)
                  : isMarginDown
                      ? const Color(0xFFFFE0B2)
                      : const Color(0xFFDEEBD8),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: SizedBox(
                      width: 44,
                      height: 44,
                      child: (product.imagePath != null && (product.imagePath as String).isNotEmpty)
                          ? Image.file(
                              File(product.imagePath as String),
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: isLow ? const Color(0xFFFFEBEE) : const Color(0xFFB7EFCE),
                                alignment: Alignment.center,
                                child: Icon(
                                  Icons.inventory_2_rounded,
                                  color: isLow ? AppColors.negative : AppColors.primary,
                                  size: 18,
                                ),
                              ),
                            )
                          : Container(
                              color: isLow ? const Color(0xFFFFEBEE) : const Color(0xFFB7EFCE),
                              alignment: Alignment.center,
                              child: Icon(
                                Icons.inventory_2_rounded,
                                color: isLow ? AppColors.negative : AppColors.primary,
                                size: 18,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                product.name,
                                style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.onSurface,
                                ),
                              ),
                            ),
                            if (isLow)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFEBEE),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.warning_amber_rounded, size: 11, color: AppColors.negative),
                                    const SizedBox(width: 2),
                                    Text('Menipis', style: GoogleFonts.poppins(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.negative)),
                                  ],
                                ),
                              ),
                            if (!isLow && isMarginDown)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFF3E0),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(isLoss ? Icons.error_outline : Icons.trending_down, size: 11, color: const Color(0xFFE65100)),
                                    const SizedBox(width: 2),
                                    Text(isLoss ? 'Rugi' : 'Margin↓', style: GoogleFonts.poppins(fontSize: 10, fontWeight: FontWeight.w600, color: const Color(0xFFE65100))),
                                  ],
                                ),
                              ),
                          ],
                        ),
                        Text(
                          'Stok: ${product.stockQty.toStringAsFixed(2)} ${product.unit}'
                          '${product.minStock > 0 ? "  •  Min: ${product.minStock.toStringAsFixed(2)}" : ""}',
                          style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                        ),
                        const SizedBox(height: 4),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            _MiniTag(label: product.category.isEmpty ? 'Lainnya' : product.category),
                            if ((product.sku as String).trim().isNotEmpty) _MiniTag(label: 'SKU: ${product.sku}'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'edit') onEdit();
                      if (v == 'delete') onDelete();
                    },
                    itemBuilder: (context) => [
                      PopupMenuItem(
                        value: 'edit',
                        child: Row(children: [const Icon(Icons.edit_outlined, size: 18), const SizedBox(width: 8), Text('Edit', style: GoogleFonts.poppins(fontSize: 13))]),
                      ),
                      PopupMenuItem(
                        value: 'delete',
                        child: Row(children: [Icon(Icons.delete_outline, size: 18, color: AppColors.negative), const SizedBox(width: 8), Text('Hapus', style: GoogleFonts.poppins(fontSize: 13, color: AppColors.negative))]),
                      ),
                    ],
                    icon: const Icon(Icons.more_vert_rounded, color: AppColors.hint, size: 20),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Divider(height: 1),
              const SizedBox(height: 10),
              Row(
                children: [
                  _ProdKV(label: 'HPP', value: fmtMoney(product.avgHpp)),
                  const SizedBox(width: 16),
                  _ProdKV(label: 'Harga Jual', value: fmtMoney(product.activeSellPrice), bold: true),
                  const SizedBox(width: 16),
                  _ProdKV(label: 'Rekomendasi', value: fmtMoney(recPrice)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _MiniTag extends StatelessWidget {
  final String label;
  const _MiniTag({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(label, style: GoogleFonts.poppins(fontSize: 10, color: AppColors.hint)),
    );
  }
}

class _ProdKV extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  const _ProdKV({required this.label, required this.value, this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: GoogleFonts.poppins(fontSize: 10, color: AppColors.hint)),
          Text(value,
              style: GoogleFonts.poppins(
                fontSize: 12,
                fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
                color: AppColors.onSurface,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}
