# Batch 2 — Produk dan Stok

- products page shell
- product detail shell
- stock adjustment mapping
- stock opname mapping
