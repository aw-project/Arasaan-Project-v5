# Warung Arasaan Kotlin Continued V8

Batch lanjutan ini fokus pada area yang masih tertinggal dibanding source Flutter:
- splash / lifecycle
- low stock notification
- customer dan supplier page parity
- dashboard insight
- more hub dan operations hub

Catatan:
- ini tetap best-effort conversion.
- belum ada build verification Gradle/Android Studio di environment ini.
- file progress report ada di `CONVERSION_PROGRESS_REPORT_V8.md`.
