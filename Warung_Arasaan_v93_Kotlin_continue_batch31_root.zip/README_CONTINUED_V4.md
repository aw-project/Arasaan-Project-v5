# CONTINUED V4

Batch lanjutan ini fokus ke hardening dan verifikasi dasar.

## Tambahan utama
- `ReceiptShareService` untuk share struk sebagai teks atau file `.txt`
- `FileProvider` + `res/xml/file_paths.xml`
- unit test:
  - `ReceiptServiceTest`
  - `BackupServiceTest`
  - `ReportingServiceTest`
- instrumented test:
  - `PurchaseRepositoryInstrumentedTest`
- dependency test di `app/build.gradle.kts`

## Dampak
- alur receipt sekarang bisa lanjut ke share intent Android
- backup/report/receipt punya coverage awal
- repository purchase punya smoke test untuk update stok + HPP

## Yang masih layak dikerjakan sesudah ini
- test untuk `SalesRepository.replace(...)`
- compile pass verification di Android Studio / Gradle wrapper
- print Bluetooth / thermal printer
- migration Room bila skema berubah