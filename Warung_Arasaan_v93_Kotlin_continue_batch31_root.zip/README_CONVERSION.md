# Warung Arasaan Flutter -> Kotlin Android Native

Batch ini mengonversi pondasi aplikasi ke Kotlin Android native:
- model domain
- database lokal Room
- repository bisnis inti
- shell Jetpack Compose

Paritas yang sudah dibawa:
- Product
- Purchase
- Sale
- Payment split
- Expense
- Debt
- Cash entry
- Rejected item
- Stock movement
- Activity log
- PIN settings
- Meta preferences dasar

Belum selesai pada batch ini:
- semua layar Flutter detail
- export PDF/CSV
- backup/import
- notification/local receipt
- analytics page dan report UI penuh

Ini sengaja dibuat sebagai batch foundation supaya fungsi inti bisnis bisa dipakai ulang saat layar Compose dikonversi.
