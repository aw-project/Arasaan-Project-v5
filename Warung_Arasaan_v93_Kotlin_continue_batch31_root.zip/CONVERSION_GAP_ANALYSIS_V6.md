# Conversion Gap Analysis V6

Analisis ini membandingkan area Flutter terbesar yang sebelumnya paling tertinggal.

## Halaman Flutter terbesar yang menjadi prioritas
1. `lib/ui/dashboard/dashboard_page.dart` ~1333 LOC
2. `lib/ui/rejected/rejected_page.dart` ~1099 LOC
3. `lib/ui/sales/fast_pos_page.dart` ~1005 LOC
4. `lib/ui/analytics/analytics_page.dart` ~867 LOC
5. `lib/ui/products/products_page.dart` ~821 LOC
6. `lib/ui/restock/restock_page.dart` ~779 LOC
7. `lib/ui/search/global_search_page.dart` ~700 LOC
8. `lib/ui/debts/debts_page.dart` ~673 LOC
9. `lib/ui/reports/reports_page.dart` ~639 LOC
10. `lib/ui/home/home_page.dart` ~643 LOC

## Perubahan V6
- `fast_pos_page.dart` kini punya padanan screen khusus.
- `rejected_page.dart` kini punya padanan screen khusus.
- `operations_tools_page.dart` kini punya padanan screen khusus.
- root navigation Kotlin mulai lebih dekat ke struktur fungsional Flutter.

## Gap terbesar yang tersisa
- Dashboard/Home/More masih belum setara kedalaman UI dan action density-nya.
- Analytics detail per produk masih lebih ringan dari Flutter.
- Reports filter/range/export parity belum penuh.
- Notification/unit migration belum punya padanan native.
- Build verification nyata masih belum ada.
