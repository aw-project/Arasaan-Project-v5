package com.warungarasaan.app.data.repository

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.warungarasaan.app.data.local.AppDatabase
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SalesRepositoryInstrumentedTest {
    private lateinit var database: AppDatabase
    private lateinit var productRepository: ProductRepository
    private lateinit var salesRepository: SalesRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        productRepository = ProductRepository(database.productDao())
        salesRepository = SalesRepository(
            saleDao = database.saleDao(),
            saleItemDao = database.saleItemDao(),
            paymentSplitDao = database.paymentSplitDao(),
            productDao = database.productDao(),
            stockMovementDao = database.stockMovementDao(),
            cashDao = database.cashDao(),
        )
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun addSale_reducesStockAndCreatesCashEntry() = runBlocking {
        productRepository.upsert(
            Product(
                id = "p1",
                name = "Beras",
                unit = "kg",
                defaultMarginPercent = 10.0,
                activeSellPrice = 15000.0,
                stockQty = 20.0,
                avgHpp = 12000.0,
            ),
        )

        salesRepository.add(
            Sale(
                id = "sale-1",
                dateEpochDay = 20001,
                customer = "Pelanggan A",
                paymentMethod = PaymentMethods.CASH,
                items = listOf(SaleItem(productId = "p1", qty = 3.0, sellPrice = 15000.0, hppAtTime = 12000.0)),
            ),
        )

        val product = productRepository.getById("p1") ?: error("missing product")
        assertEquals(17.0, product.stockQty, 0.001)

        val cashEntries = database.cashDao().getAll()
        assertEquals(1, cashEntries.size)
        assertEquals("in", cashEntries.first().direction)
        assertEquals("sale", cashEntries.first().source)
        assertEquals(45000.0, cashEntries.first().amount, 0.001)
    }
}
