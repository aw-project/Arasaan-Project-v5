package com.warungarasaan.app.data.repository

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.warungarasaan.app.data.local.AppDatabase
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.PurchaseItem
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PurchaseRepositoryInstrumentedTest {
    private lateinit var database: AppDatabase
    private lateinit var productRepository: ProductRepository
    private lateinit var purchaseRepository: PurchaseRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        productRepository = ProductRepository(database.productDao())
        purchaseRepository = PurchaseRepository(
            purchaseDao = database.purchaseDao(),
            purchaseItemDao = database.purchaseItemDao(),
            productDao = database.productDao(),
            stockMovementDao = database.stockMovementDao(),
            cashDao = database.cashDao(),
        )
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun createPurchase_updatesProductStockAndHpp() = runBlocking {
        productRepository.upsert(
            Product(
                id = "p1",
                name = "Minyak",
                unit = "ltr",
                defaultMarginPercent = 10.0,
                activeSellPrice = 17000.0,
                stockQty = 0.0,
                avgHpp = 0.0,
            ),
        )

        purchaseRepository.create(
            Purchase(
                id = "buy-1",
                dateEpochDay = 20000,
                supplier = "Supplier A",
                paymentMethod = "Cash",
                items = listOf(PurchaseItem("p1", 10.0, 12000.0)),
            ),
        )

        val product = productRepository.getById("p1") ?: error("missing product")
        assertEquals(10.0, product.stockQty, 0.001)
        assertEquals(12000.0, product.avgHpp, 0.001)
    }
}