package com.warungarasaan.app.core

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FormStateGuardsTest {
    @Test
    fun merge_returns_invalid_when_any_guard_fails() {
        val result = FormStateGuards.merge(
            FormStateGuards.requiredText("Nama produk", ""),
            FormStateGuards.positiveNumber("Harga jual", 1000.0)
        )
        assertFalse(result.isValid)
        assertTrue(result.issues.isNotEmpty())
    }

    @Test
    fun merge_returns_valid_when_all_guards_pass() {
        val result = FormStateGuards.merge(
            FormStateGuards.requiredText("Nama produk", "Gula"),
            FormStateGuards.positiveNumber("Harga jual", 1000.0)
        )
        assertTrue(result.isValid)
    }
}
