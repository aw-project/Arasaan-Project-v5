package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.AppSettings
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.PurchaseItem
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupServiceTest {
    @Test
    fun json_roundTrip_keepsCoreCounts() {
        val json = BackupService.toJson(
            products = listOf(Product("p1", "Gula", "kg", 15.0, 18000.0, 3.0, 12000.0)),
            purchases = listOf(Purchase("buy-1", 20000, "Supplier A", "Cash", listOf(PurchaseItem("p1", 2.0, 12000.0)))),
            sales = listOf(Sale("sale-1", 20001, listOf(SaleItem("p1", 1.0, 18000.0, 12000.0)), "Cash")),
            expenses = listOf(Expense("exp-1", 20001, "Transport", 5000.0)),
            debts = emptyList(),
            movements = emptyList(),
            cash = emptyList(),
            rejectedItems = emptyList(),
            activityLogs = emptyList(),
            settings = AppSettings(pinEnabled = true, pinHash = "abc"),
        )

        val payload = BackupService.fromJson(json)

        assertEquals(1, payload.products.size)
        assertEquals(1, payload.purchases.size)
        assertEquals(1, payload.sales.size)
        assertEquals(1, payload.expenses.size)
        assertTrue(payload.settings?.pinEnabled == true)
    }
}