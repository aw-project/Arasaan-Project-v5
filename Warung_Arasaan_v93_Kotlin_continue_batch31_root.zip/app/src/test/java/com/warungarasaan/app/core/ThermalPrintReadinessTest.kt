package com.warungarasaan.app.core

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ThermalPrintReadinessTest {
    @Test
    fun can_attempt_print_when_core_requirements_met() {
        val state = ThermalPrintReadiness.fromPermissions(
            bluetoothEnabled = true,
            permissions = setOf("BLUETOOTH_CONNECT", "BLUETOOTH_SCAN"),
            pairedPrinterAvailable = true,
        )

        assertTrue(state.canAttemptPrint)
        assertTrue(state.warnings.isEmpty())
    }

    @Test
    fun warnings_cover_missing_state() {
        val state = ThermalPrintReadiness.fromPermissions(
            bluetoothEnabled = false,
            permissions = emptySet(),
            pairedPrinterAvailable = false,
        )

        assertFalse(state.canAttemptPrint)
        assertTrue(state.warnings.size >= 3)
    }
}
