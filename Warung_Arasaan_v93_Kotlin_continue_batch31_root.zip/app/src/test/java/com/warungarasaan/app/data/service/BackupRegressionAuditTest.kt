package com.warungarasaan.app.data.service

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class BackupRegressionAuditTest {
    @Test
    fun `backup audit should pass for complete payload markers`() {
        val result = BackupRegressionAudit.validate(
            BackupRegressionInput(
                payloadNotBlank = true,
                looksLikeJson = true,
                hasVersionMarker = true,
                hasProductsSection = true,
                hasTransactionsSection = true,
            )
        )

        assertTrue(result.valid)
    }

    @Test
    fun `backup audit should fail when critical sections are missing`() {
        val result = BackupRegressionAudit.validate(
            BackupRegressionInput(
                payloadNotBlank = true,
                looksLikeJson = true,
                hasVersionMarker = false,
                hasProductsSection = true,
                hasTransactionsSection = false,
            )
        )

        assertFalse(result.valid)
        assertTrue(result.reasons.isNotEmpty())
    }
}
