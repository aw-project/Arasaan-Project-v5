package com.warungarasaan.app.core

import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionCenterTest {
    @Test
    fun required_permissions_are_unique() {
        val permissions = PermissionCenter.requiredRuntimePermissions()
        assertTrue(permissions.distinct().size == permissions.size)
    }
}
