package com.warungarasaan.app.ui.redesign

import kotlin.test.Test
import kotlin.test.assertTrue

class ReportFilterStateTest {
    @Test
    fun summary_includes_active_chips_only() {
        val state = ReportFilterState(
            paymentMethod = "Tunai",
            category = "Makanan",
            searchQuery = "nasi",
            onlyCriticalStock = true
        )

        val summary = state.summary()

        assertTrue(summary.contains("30 hari"))
        assertTrue(summary.contains("Tunai"))
        assertTrue(summary.contains("Makanan"))
        assertTrue(summary.contains("Cari: nasi"))
        assertTrue(summary.contains("Stok kritis"))
    }
}
