package com.warungarasaan.app.ui.redesign

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class RouteCoverageAuditTest {
    @Test
    fun `audit should report missing routes`() {
        val audit = RouteCoverageAuditor.audit(
            available = listOf(
                NativeModuleRoutes.Home,
                NativeModuleRoutes.Dashboard,
                NativeModuleRoutes.Products,
            )
        )

        assertTrue(audit.missing().contains(NativeModuleRoutes.Purchases))
        assertEquals(16, audit.coveragePercent())
    }
}
