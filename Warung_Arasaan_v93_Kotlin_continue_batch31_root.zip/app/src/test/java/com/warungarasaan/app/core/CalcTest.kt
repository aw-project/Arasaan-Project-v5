package com.warungarasaan.app.core

import kotlin.test.Test
import kotlin.test.assertEquals

class CalcTest {
    @Test
    fun grandTotal_respects_discount_and_extra_charge() {
        assertEquals(9500.0, Calc.grandTotal(subtotal = 10000.0, discount = 1000.0, extraCharge = 500.0))
    }

    @Test
    fun change_never_negative() {
        assertEquals(0.0, Calc.change(received = 5000.0, total = 7000.0))
    }

    @Test
    fun weightedAverageHpp_combines_existing_and_incoming_stock() {
        assertEquals(
            11666.67,
            Calc.weightedAverageHpp(
                currentQty = 10.0,
                currentHpp = 10000.0,
                incomingQty = 5.0,
                incomingUnitCost = 15000.0,
            ),
        )
    }
}
