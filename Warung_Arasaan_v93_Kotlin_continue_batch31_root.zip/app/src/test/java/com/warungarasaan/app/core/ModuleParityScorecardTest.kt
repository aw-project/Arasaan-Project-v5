package com.warungarasaan.app.core

import org.junit.Assert.assertEquals
import org.junit.Test

class ModuleParityScorecardTest {
    @Test
    fun summarize_returns_average() {
        val avg = ModuleParityScorecard.summarize(
            listOf(
                ModuleParityScore("sales", 96),
                ModuleParityScore("reports", 91),
                ModuleParityScore("backup", 88),
            )
        )

        assertEquals(91, avg)
    }

    @Test
    fun weakest_modules_sorted_ascending() {
        val weakest = ModuleParityScorecard.weakestModules(
            listOf(
                ModuleParityScore("sales", 96),
                ModuleParityScore("reports", 91),
                ModuleParityScore("backup", 88),
            ),
            limit = 2,
        )

        assertEquals(listOf("backup", "reports"), weakest.map { it.name })
    }
}
