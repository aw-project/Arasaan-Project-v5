package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import org.junit.Assert.assertTrue
import org.junit.Test

class ReceiptServiceTest {
    @Test
    fun buildSaleText_containsKeyFields() {
        val sale = Sale(
            id = "sale-1",
            dateEpochDay = 20000,
            items = listOf(SaleItem("p1", 2.0, 15000.0, 10000.0)),
            paymentMethod = "Cash",
            customerName = "Budi",
            discountAmount = 1000.0,
            paymentSplits = listOf(PaymentSplit("Cash", 29000.0)),
        )
        val text = ReceiptService.buildSaleText(
            sale = sale,
            productsById = mapOf(
                "p1" to Product(
                    id = "p1",
                    name = "Kopi",
                    unit = "pcs",
                    defaultMarginPercent = 20.0,
                    activeSellPrice = 15000.0,
                    stockQty = 10.0,
                    avgHpp = 10000.0,
                ),
            ),
        )

        assertTrue(text.contains("Struk Penjualan"))
        assertTrue(text.contains("Budi"))
        assertTrue(text.contains("Kopi"))
        assertTrue(text.contains("TOTAL"))
    }
}