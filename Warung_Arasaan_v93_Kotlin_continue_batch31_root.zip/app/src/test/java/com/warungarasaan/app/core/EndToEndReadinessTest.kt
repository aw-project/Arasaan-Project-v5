package com.warungarasaan.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EndToEndReadinessTest {
    @Test
    fun evaluate_computes_percentage() {
        val result = EndToEndReadiness.evaluate(
            transactionsReady = true,
            reportingReady = true,
            backupReady = false,
            printReady = true,
            blockers = listOf(" minor "),
        )

        assertEquals(75, result.readyPercentage)
        assertTrue(result.isReadyForPilot)
    }

    @Test
    fun critical_blocker_disables_pilot() {
        val result = EndToEndReadiness.evaluate(
            transactionsReady = true,
            reportingReady = true,
            backupReady = true,
            printReady = true,
            blockers = listOf("critical: backup restore belum lolos"),
        )

        assertFalse(result.isReadyForPilot)
    }
}
