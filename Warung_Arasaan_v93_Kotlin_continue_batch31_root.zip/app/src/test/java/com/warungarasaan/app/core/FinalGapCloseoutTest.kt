package com.warungarasaan.app.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class FinalGapCloseoutTest {
    @Test
    fun `completion percent should combine readiness and route coverage`() {
        val closeout = FinalGapCloseoutFactory.create(
            compileReady = true,
            regressionReady = true,
            backupReady = false,
            printReady = false,
            routeCoverage = 80,
            weakestModules = listOf("reports", "analytics"),
        )

        assertEquals(56, closeout.completionPercent)
        assertTrue(closeout.remainingPriorities().contains("backup_restore_regression"))
    }
}
