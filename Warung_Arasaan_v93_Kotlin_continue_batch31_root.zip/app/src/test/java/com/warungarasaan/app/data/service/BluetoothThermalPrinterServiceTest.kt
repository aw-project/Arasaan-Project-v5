package com.warungarasaan.app.data.service

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BluetoothThermalPrinterServiceTest {
    @Test
    fun sanitize_replaces_non_ascii() {
        val sanitized = BluetoothThermalPrinterService.sanitize("Warung\nArasaan ✓")
        assertTrue(sanitized.contains("Warung"))
        assertFalse(sanitized.contains("✓"))
    }

    @Test
    fun buildEscPosPayload_contains_init_and_cut() {
        val payload = BluetoothThermalPrinterService.buildEscPosPayload("Hello")
        assertTrue(payload.size > 8)
        assertTrue(payload[0] == 0x1B.toByte())
        assertTrue(payload[1] == 0x40.toByte())
        assertTrue(payload.takeLast(4).toByteArray().contentEquals(byteArrayOf(0x1D, 0x56, 0x41, 0x10)))
    }
}
