package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.domain.model.RejectedItem
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportExportServiceTest {
    @Test
    fun exportSummaryCsv_contains_expected_headers() {
        val sales = listOf(
            Sale(
                id = "s1",
                dateEpochDay = 20000,
                items = listOf(SaleItem("p1", 2.0, 10000.0, 7000.0)),
                paymentMethod = "Cash",
            )
        )
        val expenses = listOf(
            Expense("e1", 20000, "Listrik", 5000.0)
        )
        val rejected = listOf(
            RejectedItem("r1", 20000, "p1", 1.0, "Rusak", "Buang", "", 7000.0, 7000.0)
        )

        val csv = ReportExportService.exportSummaryCsv(
            ReportingService.summarize(sales, expenses, rejected)
        )

        assertTrue(csv.contains("omzet"))
        assertTrue(csv.contains("laba_bersih"))
    }
}
