package com.warungarasaan.app.data.service

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupRestoreValidatorTest {
    @Test
    fun valid_payload_passes() {
        val payload = BackupPayload(
            products = listOf(
                ProductSnapshot(
                    id = "p1",
                    name = "Produk A",
                    unit = "pcs",
                    defaultMarginPercent = 20.0,
                    activeSellPrice = 10000.0,
                    stockQty = 10.0,
                    avgHpp = 7000.0,
                    minStock = 2.0,
                    targetStock = 10.0,
                    sku = "SKU-1",
                    category = "Umum",
                )
            ),
            purchases = listOf(
                PurchaseSnapshot(
                    id = "pur-1",
                    dateEpochDay = 20000,
                    supplier = "Supplier A",
                    paymentMethod = "Cash",
                    items = listOf(PurchaseItemSnapshot(productId = "p1", qty = 1.0, buyPrice = 7000.0))
                )
            )
        )

        val result = BackupRestoreValidator.validate(payload)
        assertTrue(result.ok)
    }

    @Test
    fun invalid_reference_fails() {
        val payload = BackupPayload(
            products = emptyList(),
            sales = listOf(
                SaleSnapshot(
                    id = "sale-1",
                    dateEpochDay = 20000,
                    customer = "Pelanggan",
                    paymentMethod = "Cash",
                    totalSales = 10000.0,
                    totalHpp = 7000.0,
                    discount = 0.0,
                    paidAmount = 10000.0,
                    changeAmount = 0.0,
                    notes = "",
                    items = listOf(SaleItemSnapshot(productId = "missing", qty = 1.0, sellPrice = 10000.0, hppAtSale = 7000.0)),
                    splits = emptyList(),
                )
            )
        )

        val result = BackupRestoreValidator.validate(payload)
        assertFalse(result.ok)
    }
}
