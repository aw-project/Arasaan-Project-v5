package com.warungarasaan.app.core

import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import org.junit.Test

class TransactionValidationTest {
    @Test(expected = IllegalArgumentException::class)
    fun split_payment_must_match_sale_total() {
        val sale = Sale(
            id = "sale-1",
            dateEpochDay = 20000,
            paymentMethod = "Split",
            items = listOf(SaleItem("p1", 2.0, 10000.0, 7000.0)),
            paymentSplits = listOf(
                PaymentSplit("Cash", 10000.0),
                PaymentSplit("QRIS", 5000.0),
            ),
        )
        TransactionValidation.validateSale(sale)
    }
}
