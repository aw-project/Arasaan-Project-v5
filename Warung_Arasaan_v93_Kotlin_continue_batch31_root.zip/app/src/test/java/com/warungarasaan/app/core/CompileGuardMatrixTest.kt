package com.warungarasaan.app.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class CompileGuardMatrixTest {
    @Test
    fun `matrix should report build ready when all guards pass`() {
        val matrix = CompileGuardMatrixFactory.create(
            roomReady = true,
            composeReady = true,
            navigationReady = true,
            permissionsReady = true,
            backupReady = true,
            receiptReady = true,
            testsReady = true,
        )

        assertTrue(matrix.isReadyToAttemptBuild())
        assertEquals(7, matrix.readyCount())
        assertEquals("7/7 compile guards ready", matrix.summary())
    }

    @Test
    fun `matrix should report blocked guards`() {
        val matrix = CompileGuardMatrixFactory.create(
            roomReady = true,
            composeReady = false,
            navigationReady = false,
            permissionsReady = true,
            backupReady = true,
            receiptReady = true,
            testsReady = false,
        )

        assertFalse(matrix.isReadyToAttemptBuild())
        assertEquals(3, matrix.blockedCount())
    }
}
