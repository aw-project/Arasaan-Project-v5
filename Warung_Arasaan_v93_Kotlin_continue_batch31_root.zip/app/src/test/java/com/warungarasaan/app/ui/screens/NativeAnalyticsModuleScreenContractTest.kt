package com.warungarasaan.app.ui.screens

import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.ui.redesign.AnalyticsBreakdownCalculator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class NativeAnalyticsModuleScreenContractTest {
    @Test
    fun breakdownHandlesEmptyData() {
        val result = AnalyticsBreakdownCalculator.build(
            sales = emptyList(),
            products = emptyList<Product>(),
            purchases = emptyList()
        )

        assertEquals(0.0, result.totalRevenue)
        assertEquals(0, result.totalTransactions)
        assertTrue(result.topProductNames.isEmpty())
    }
}
