package com.warungarasaan.app.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class RegressionScenarioMatrixTest {
    @Test
    fun `matrix should expose critical blockers`() {
        val matrix = RegressionScenarioMatrixFactory.createDefault(
            saleCreate = true,
            saleEdit = false,
            purchaseCreate = true,
            purchaseEdit = true,
            stockAdjustment = true,
            stockOpname = true,
            reportExport = true,
            backupRestore = false,
            receiptShare = true,
            thermalPrint = false,
        )

        assertEquals(listOf("sale_edit", "backup_restore"), matrix.criticalBlockers())
        assertFalse(matrix.isPilotSafe())
    }

    @Test
    fun `matrix should be pilot safe when critical scenarios are covered`() {
        val matrix = RegressionScenarioMatrixFactory.createDefault(
            saleCreate = true,
            saleEdit = true,
            purchaseCreate = true,
            purchaseEdit = true,
            stockAdjustment = true,
            stockOpname = true,
            reportExport = false,
            backupRestore = true,
            receiptShare = false,
            thermalPrint = false,
        )

        assertTrue(matrix.isPilotSafe())
        assertEquals(80, matrix.coveragePercent())
    }
}
