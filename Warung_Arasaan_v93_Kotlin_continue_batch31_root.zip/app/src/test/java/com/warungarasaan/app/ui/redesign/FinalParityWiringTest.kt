package com.warungarasaan.app.ui.redesign

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class FinalParityWiringTest {
    @Test
    fun `coverage should count enabled required routes`() {
        val routes = listOf(
            ModuleWiringState(NativeModuleRoutes.Home, true),
            ModuleWiringState(NativeModuleRoutes.Dashboard, true),
            ModuleWiringState(NativeModuleRoutes.Products, true),
            ModuleWiringState(NativeModuleRoutes.Purchases, true),
            ModuleWiringState("custom_route", true),
        )

        val coverage = FinalParityWiring.coverage(routes)
        assertTrue(coverage > 0)
    }

    @Test
    fun `missing routes should include print center when absent`() {
        val routes = listOf(
            ModuleWiringState(NativeModuleRoutes.Home, true),
            ModuleWiringState(NativeModuleRoutes.Dashboard, true),
        )

        val missing = FinalParityWiring.missingRoutes(routes)
        assertTrue(NativeModuleRoutes.PrintCenter in missing)
        assertEquals(false, missing.isEmpty() && missing.contains(NativeModuleRoutes.PrintCenter))
    }
}
