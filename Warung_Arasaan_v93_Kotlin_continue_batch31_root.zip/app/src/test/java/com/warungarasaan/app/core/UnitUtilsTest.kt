package com.warungarasaan.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UnitUtilsTest {
    @Test
    fun normalize_weight_units_to_gram() {
        assertEquals("gram", UnitUtils.normalizeUnitLabel("kg"))
        assertEquals("gram", UnitUtils.normalizeUnitLabel("gr"))
        assertTrue(UnitUtils.usesKgPriceInput("kilogram"))
    }

    @Test
    fun convert_purchase_price_between_input_and_storage() {
        val stored = UnitUtils.purchaseInputPriceToStored("kg", 32000.0)
        val input = UnitUtils.purchaseStoredPriceToInput("gram", stored)
        assertEquals(32.0, stored, 0.000001)
        assertEquals(32000.0, input, 0.01)
    }
}
