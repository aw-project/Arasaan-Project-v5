package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnalyticsServiceTest {
    private val analytics = AnalyticsService()

    @Test
    fun topSelling_aggregates_qty_and_profit() {
        val products = listOf(
            Product("p1", "Beras", "kg", 20.0, 15000.0, 10.0, 12000.0),
            Product("p2", "Gula", "kg", 15.0, 18000.0, 8.0, 14000.0),
        )
        val sales = listOf(
            Sale(
                id = "s1",
                dateEpochDay = 20000,
                items = listOf(
                    SaleItem("p1", 2.0, 15000.0, 12000.0),
                    SaleItem("p2", 1.0, 18000.0, 14000.0),
                ),
                paymentMethod = "Cash",
            ),
            Sale(
                id = "s2",
                dateEpochDay = 20001,
                items = listOf(
                    SaleItem("p1", 1.0, 15000.0, 12000.0),
                ),
                paymentMethod = "Cash",
            ),
        )

        val result = analytics.topSelling(sales, products, 30)

        assertEquals("p1", result.first().productId)
        assertEquals(3.0, result.first().qty, 0.0001)
        assertTrue(result.first().profit > 0.0)
    }
}
