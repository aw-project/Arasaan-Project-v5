package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import org.junit.Assert.assertTrue
import org.junit.Test

class ThermalReceiptServiceTest {
    @Test
    fun escPosText_contains_core_sale_data() {
        val sale = Sale(
            id = "sale-1",
            dateEpochDay = 20000,
            items = listOf(SaleItem("p1", 2.0, 5000.0, 3000.0)),
            paymentMethod = "Cash",
            customerName = "Budi",
            discountAmount = 1000.0,
            paymentSplits = listOf(PaymentSplit("Cash", 9000.0)),
        )

        val output = ThermalReceiptService.toEscPosText(sale, mapOf("p1" to "Kopi"))

        assertTrue(output.contains("WARUNG ARASAAN"))
        assertTrue(output.contains("sale-1"))
        assertTrue(output.contains("Kopi"))
        assertTrue(output.contains("9000"))
    }
}
