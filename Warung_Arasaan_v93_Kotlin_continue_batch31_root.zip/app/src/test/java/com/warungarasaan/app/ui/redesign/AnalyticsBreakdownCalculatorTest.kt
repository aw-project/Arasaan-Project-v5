package com.warungarasaan.app.ui.redesign

import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class AnalyticsBreakdownCalculatorTest {
    @Test
    fun build_calculates_totals_and_top_products() {
        val products = listOf(
            Product("p1", "Beras", "kg", 10.0, 15000.0, 10.0, 12000.0),
            Product("p2", "Gula", "kg", 8.0, 14000.0, 10.0, 13000.0)
        )
        val sales = listOf(
            Sale(
                id = "s1",
                dateEpochDay = 1,
                items = listOf(
                    SaleItem("p1", 2.0, 15000.0, 12000.0),
                    SaleItem("p2", 1.0, 14000.0, 13000.0)
                ),
                paymentMethod = "Cash"
            )
        )

        val result = AnalyticsBreakdownCalculator.build(sales = sales, products = products)
        assertEquals(44000.0, result.totalRevenue)
        assertEquals(7000.0, result.totalProfit)
        assertEquals(1, result.totalTransactions)
        assertTrue(result.topProductNames.first() == "Beras")
    }
}
