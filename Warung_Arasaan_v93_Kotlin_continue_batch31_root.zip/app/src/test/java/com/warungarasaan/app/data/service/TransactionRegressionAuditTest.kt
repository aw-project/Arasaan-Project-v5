
package com.warungarasaan.app.data.service

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class TransactionRegressionAuditTest {
    @Test
    fun valid_input_passes() {
        val result = TransactionRegressionAudit.validate(
            RegressionAuditInput(
                itemCount = 2,
                transactionTotal = 50000.0,
                projectedStock = 5.0,
                debtPrincipal = 100000.0,
                debtPaid = 20000.0,
                cashBefore = 300000.0,
                cashDelta = -50000.0,
            )
        )
        assertTrue(result.valid)
    }

    @Test
    fun invalid_input_collects_reasons() {
        val result = TransactionRegressionAudit.validate(
            RegressionAuditInput(
                itemCount = 0,
                transactionTotal = 0.0,
                projectedStock = -1.0,
                debtPrincipal = 100000.0,
                debtPaid = 120000.0,
                cashBefore = 20000.0,
                cashDelta = -50000.0,
            )
        )
        assertFalse(result.valid)
        assertTrue(result.reasons.isNotEmpty())
    }
}
