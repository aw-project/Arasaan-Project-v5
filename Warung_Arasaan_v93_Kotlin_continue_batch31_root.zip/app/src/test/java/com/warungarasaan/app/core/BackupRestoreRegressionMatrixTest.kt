package com.warungarasaan.app.core

import com.warungarasaan.app.data.service.AppSettingsSnapshot
import com.warungarasaan.app.data.service.BackupPayload
import com.warungarasaan.app.data.service.ProductSnapshot
import kotlin.test.Test
import kotlin.test.assertEquals

class BackupRestoreRegressionMatrixTest {
    @Test
    fun completionRatioCountsCoveredSections() {
        val payload = BackupPayload(
            products = listOf(
                ProductSnapshot(
                    id = "p1",
                    name = "Beras",
                    unit = "kg",
                    defaultMarginPercent = 10.0,
                    activeSellPrice = 12000.0,
                    stockQty = 5.0,
                    avgHpp = 10000.0,
                    minStock = 1.0,
                    targetStock = 8.0,
                    sku = "BRS-1",
                    category = "Pokok"
                )
            ),
            settings = AppSettingsSnapshot(
                id = "default",
                shopName = "Warung",
                currencySymbol = "Rp",
                lowStockThreshold = 3.0,
                backupEnabled = true,
                backupIntervalHours = 24,
                lockPinEnabled = false,
                lockPin = null
            )
        )

        val ratio = BackupRestoreRegressionAudit.fromPayload(payload).completionRatio()
        assertEquals(0.2, ratio)
    }
}
