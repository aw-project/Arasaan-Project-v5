package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.domain.model.RejectedItem
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import org.junit.Assert.assertEquals
import org.junit.Test

class ReportingServiceTest {
    @Test
    fun summarize_calculatesNetProfit() {
        val sales = listOf(
            Sale(
                id = "s1",
                dateEpochDay = 20000,
                items = listOf(
                    SaleItem("p1", 2.0, 15000.0, 10000.0),
                    SaleItem("p2", 1.0, 10000.0, 6000.0),
                ),
                paymentMethod = "Cash",
                discountAmount = 2000.0,
            ),
        )
        val expenses = listOf(Expense("e1", 20000, "Listrik", 3000.0))
        val rejected = listOf(
            RejectedItem("r1", 20000, "p1", 1.0, "Rusak", "Buang", hppAtTime = 5000.0, estimatedLoss = 5000.0),
        )

        val summary = ReportingService.summarize(sales, expenses, rejected)

        assertEquals(38000.0, summary.omzet, 0.001)
        assertEquals(26000.0, summary.totalHpp, 0.001)
        assertEquals(12000.0, summary.labaKotor, 0.001)
        assertEquals(3000.0, summary.totalBiaya, 0.001)
        assertEquals(5000.0, summary.rugiRejek, 0.001)
        assertEquals(4000.0, summary.labaBersih, 0.001)
    }
}