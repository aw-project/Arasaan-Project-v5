package com.warungarasaan.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals

class SafeCollectorsTest {
    @Test
    fun collectSafely_collects_values() = runBlocking {
        var received = 0
        val job = collectSafely(
            flow = flowOf(1, 2, 3),
            onValue = { received += it }
        )
        job.join()
        assertEquals(6, received)
        cancel()
    }
}
