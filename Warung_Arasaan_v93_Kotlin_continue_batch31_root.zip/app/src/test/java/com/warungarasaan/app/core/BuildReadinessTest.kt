
package com.warungarasaan.app.core

import kotlin.test.Test
import kotlin.test.assertEquals

class BuildReadinessTest {
    @Test
    fun completion_percent_reflects_ratio() {
        val report = BuildReadiness.evaluate(
            hasRootWiring = true,
            hasReportParity = true,
            hasAnalyticsParity = true,
            hasBackupValidation = true,
            hasReceiptTransport = false,
            hasPermissionCenter = false,
            hasRegressionCoverage = true,
        )
        assertEquals(5, report.passedCount)
        assertEquals(2, report.failedCount)
        assertEquals(71, report.completionPercent())
    }
}
