
package com.warungarasaan.app.core

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class RegressionGuardsTest {
    @Test
    fun prevents_negative_stock() {
        assertTrue(RegressionGuards.preventNegativeStock(0.0))
        assertFalse(RegressionGuards.preventNegativeStock(-1.0))
    }

    @Test
    fun prevents_overpayment() {
        assertTrue(RegressionGuards.preventOverpayment(100.0, 80.0))
        assertFalse(RegressionGuards.preventOverpayment(100.0, 120.0))
    }

    @Test
    fun prevents_empty_transaction() {
        assertTrue(RegressionGuards.preventEmptyTransaction(1, 12000.0))
        assertFalse(RegressionGuards.preventEmptyTransaction(0, 0.0))
    }
}
