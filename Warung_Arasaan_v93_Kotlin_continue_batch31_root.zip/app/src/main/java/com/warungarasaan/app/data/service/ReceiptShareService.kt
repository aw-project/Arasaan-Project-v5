package com.warungarasaan.app.data.service

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

object ReceiptShareService {
    fun sharePlainText(
        context: Context,
        title: String,
        content: String,
    ) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, content)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    fun shareTextFile(
        context: Context,
        title: String,
        fileName: String,
        content: String,
    ) {
        val exportDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val file = File(exportDir, fileName).apply { writeText(content) }
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }
}