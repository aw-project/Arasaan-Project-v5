package com.warungarasaan.app.core

data class CompileGuardItem(
    val key: String,
    val ready: Boolean,
    val note: String,
)

data class CompileGuardMatrix(
    val items: List<CompileGuardItem>,
) {
    fun readyCount(): Int = items.count { it.ready }
    fun blockedCount(): Int = items.count { !it.ready }
    fun isReadyToAttemptBuild(): Boolean = items.all { it.ready }
    fun summary(): String = "${readyCount()}/${items.size} compile guards ready"
}

object CompileGuardMatrixFactory {
    fun create(
        roomReady: Boolean,
        composeReady: Boolean,
        navigationReady: Boolean,
        permissionsReady: Boolean,
        backupReady: Boolean,
        receiptReady: Boolean,
        testsReady: Boolean,
    ): CompileGuardMatrix = CompileGuardMatrix(
        items = listOf(
            CompileGuardItem("room", roomReady, "Room entities/DAO/schema wiring should be stable."),
            CompileGuardItem("compose", composeReady, "Compose wrappers and redesign screens should resolve."),
            CompileGuardItem("navigation", navigationReady, "Root routes should map to active module wrappers."),
            CompileGuardItem("permissions", permissionsReady, "Notification/Bluetooth permissions should be guarded."),
            CompileGuardItem("backup", backupReady, "Backup import/export should validate payload before restore."),
            CompileGuardItem("receipt", receiptReady, "Share and thermal receipt path should be available."),
            CompileGuardItem("tests", testsReady, "Core regression tests should exist for critical flows."),
        )
    )
}
