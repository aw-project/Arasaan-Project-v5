package com.warungarasaan.app.ui.redesign

data class ReportPeriodUi(
    val label: String,
    val fromEpochDay: Long? = null,
    val toEpochDay: Long? = null
)

data class ReportFilterState(
    val period: ReportPeriodUi = ReportPeriodUi(label = "30 hari"),
    val paymentMethod: String = "Semua",
    val category: String = "Semua",
    val searchQuery: String = "",
    val onlyCriticalStock: Boolean = false
) {
    fun summary(): String {
        val chips = buildList {
            add(period.label)
            if (paymentMethod != "Semua") add(paymentMethod)
            if (category != "Semua") add(category)
            if (searchQuery.isNotBlank()) add("Cari: $searchQuery")
            if (onlyCriticalStock) add("Stok kritis")
        }
        return chips.joinToString(" • ")
    }
}
