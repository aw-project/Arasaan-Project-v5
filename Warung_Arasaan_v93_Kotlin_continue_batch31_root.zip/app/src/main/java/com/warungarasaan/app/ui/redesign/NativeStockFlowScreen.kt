package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class StockFlowItem(
    val label: String,
    val type: String,
    val qtyDelta: String,
    val createdAt: String
)

@Composable
fun NativeStockFlowScreen(
    items: List<StockFlowItem> = emptyList()
) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionHeader(
            title = "Riwayat Stok",
            subtitle = "Gabungan adjustment, opname, pembelian, dan penjualan"
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { item ->
                Card {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(item.label)
                        AssistChip(onClick = {}, label = { Text(item.type) })
                        Text("Perubahan: ${item.qtyDelta}")
                        Text(item.createdAt)
                    }
                }
            }
        }
    }
}
