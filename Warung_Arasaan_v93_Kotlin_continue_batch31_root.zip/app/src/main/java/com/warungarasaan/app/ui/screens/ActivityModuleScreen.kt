package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.ActivityLog
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun ActivityModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var activities by remember { mutableStateOf<List<ActivityLog>>(emptyList()) }

    suspend fun reload() { activities = container.activityLogRepository.all() }

    LaunchedEffect(Unit) { reload() }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = {
                scope.launch {
                    container.activityLogRepository.log("manual", "Log dibuat manual dari modul aktivitas")
                    reload()
                }
            }) { Text("+") }
        },
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier,
        ) {
            if (activities.isEmpty()) {
                item { EmptyHint("Belum ada log", "Tambahkan data di modul lain untuk melihat audit trail.") }
            } else {
                items(activities, key = { it.id }) { log ->
                    ListItem(
                        headlineContent = { Text(log.type) },
                        supportingContent = { Text(log.newJson.ifBlank { log.oldJson }.ifBlank { "-" }) },
                        overlineContent = { Text(UiFormat.date(log.dateEpochDay)) },
                    )
                }
                item {
                    TextButton(onClick = {
                        scope.launch {
                            container.activityLogRepository.clear()
                            reload()
                        }
                    }) { Text("Bersihkan log") }
                }
            }
        }
    }
}
