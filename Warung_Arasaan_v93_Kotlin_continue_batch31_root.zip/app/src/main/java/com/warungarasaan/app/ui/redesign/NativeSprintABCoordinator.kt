package com.warungarasaan.app.ui.redesign

data class SprintABProgress(
    val transactionParity: Double,
    val rejectedParity: Double,
    val reportsParity: Double,
    val analyticsParity: Double,
    val financeParity: Double
)

object NativeSprintABCoordinator {
    fun currentProgress(): SprintABProgress = SprintABProgress(
        transactionParity = 0.9,
        rejectedParity = 0.72,
        reportsParity = 0.83,
        analyticsParity = 0.81,
        financeParity = 0.86
    )
}
