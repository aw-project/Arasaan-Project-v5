package com.warungarasaan.app.data.service

data class BackupValidationResult(
    val ok: Boolean,
    val errors: List<String>,
)

object BackupRestoreValidator {
    fun validate(payload: BackupPayload): BackupValidationResult {
        val errors = buildList {
            val productIds = payload.products.map { it.id }.toSet()
            payload.products
                .groupBy { it.id }
                .filterValues { it.size > 1 }
                .keys
                .forEach { add("Duplicate product id: $it") }

            payload.purchases.forEach { purchase ->
                if (purchase.items.isEmpty()) add("Purchase ${purchase.id} has no items")
                purchase.items
                    .filterNot { it.productId in productIds }
                    .forEach { add("Purchase ${purchase.id} references missing product ${it.productId}") }
            }

            payload.sales.forEach { sale ->
                if (sale.items.isEmpty()) add("Sale ${sale.id} has no items")
                sale.items
                    .filterNot { it.productId in productIds }
                    .forEach { add("Sale ${sale.id} references missing product ${it.productId}") }
            }

            payload.rejectedItems
                .filterNot { it.productId in productIds }
                .forEach { add("Rejected item ${it.id} references missing product ${it.productId}") }
        }

        return BackupValidationResult(ok = errors.isEmpty(), errors = errors)
    }
}
