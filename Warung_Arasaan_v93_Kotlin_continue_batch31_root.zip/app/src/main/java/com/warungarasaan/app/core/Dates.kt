package com.warungarasaan.app.core

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object Dates {
    private val dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy")
    private val shortFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    fun today(): LocalDate = LocalDate.now()
    fun epochDay(date: LocalDate): Int = date.toEpochDay().toInt()
    fun fromEpochDay(value: Int): LocalDate = LocalDate.ofEpochDay(value.toLong())

    fun formatEpochDay(value: Int): String = format(fromEpochDay(value))
    fun format(date: LocalDate): String = date.format(dateFormatter)
    fun formatShort(date: LocalDate): String = date.format(shortFormatter)

    fun epochMillisToLocalDate(value: Long): LocalDate =
        Instant.ofEpochMilli(value).atZone(ZoneId.systemDefault()).toLocalDate()

    fun rangeLabel(startEpochDay: Int, endEpochDay: Int): String =
        "${formatShort(fromEpochDay(startEpochDay))} - ${formatShort(fromEpochDay(endEpochDay))}"

    fun lastDaysRange(days: Long): IntRange {
        val end = today()
        val start = end.minusDays(days - 1)
        return epochDay(start)..epochDay(end)
    }
}
