package com.warungarasaan.app.ui

import androidx.compose.runtime.Composable
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.di.ProvideAppContainer

@Composable
fun AppEntry(container: AppContainer) {
    ProvideAppContainer(container) {
        WarungArasaanRoot(container)
    }
}
