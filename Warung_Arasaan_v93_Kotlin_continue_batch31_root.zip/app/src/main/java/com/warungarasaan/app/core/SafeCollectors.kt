package com.warungarasaan.app.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

fun <T> CoroutineScope.collectSafely(
    flow: Flow<T>,
    onValue: (T) -> Unit,
    onError: (Throwable) -> Unit = {}
): Job {
    return launch {
        flow
            .catch { onError(it) }
            .collect { onValue(it) }
    }
}
