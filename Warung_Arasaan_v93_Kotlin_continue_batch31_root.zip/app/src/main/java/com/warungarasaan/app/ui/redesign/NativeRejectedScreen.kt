package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

data class RejectedItemUi(
    val productName: String,
    val qtyLabel: String,
    val reason: String,
    val handling: String,
    val lossLabel: String
)

@Composable
fun NativeRejectedScreen(
    activeReason: String,
    activeHandling: String,
    reasons: List<String>,
    handlings: List<String>,
    items: List<RejectedItemUi>,
    onReasonChange: (String) -> Unit,
    onHandlingChange: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Barang Reject") }
        item {
            reasons.forEach { reason ->
                FilterChip(
                    selected = reason == activeReason,
                    onClick = { onReasonChange(reason) },
                    label = { Text(reason) }
                )
            }
        }
        item {
            handlings.forEach { handling ->
                FilterChip(
                    selected = handling == activeHandling,
                    onClick = { onHandlingChange(handling) },
                    label = { Text(handling) }
                )
            }
        }
        items(items) { item ->
            Card {
                ListItem(
                    headlineContent = { Text(item.productName) },
                    supportingContent = { Text("${item.qtyLabel} • ${item.reason} • ${item.handling}") },
                    overlineContent = { Text(item.lossLabel) }
                )
            }
        }
    }
}
