package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

object ReceiptService {
    private val moneyFormatter = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
        maximumFractionDigits = 0
    }

    private fun money(value: Double): String = moneyFormatter.format(value)

    private fun epochDayToText(epochDay: Int): String =
        LocalDate.ofEpochDay(epochDay.toLong()).toString()

    fun buildSaleText(sale: Sale, productsById: Map<String, Product>): String {
        return buildString {
            appendLine("Warung Arasaan")
            appendLine("Struk Penjualan")
            appendLine("Tanggal: ${epochDayToText(sale.dateEpochDay)}")
            appendLine("Pembayaran: ${sale.paymentSummary}")
            if (sale.customerName.isNotBlank()) appendLine("Pelanggan: ${sale.customerName}")
            appendLine("------------------------------")
            sale.items.forEach { item ->
                val product = productsById[item.productId]
                appendLine(product?.name ?: item.productId)
                appendLine("  ${item.qty} ${product?.unit.orEmpty()} x ${money(item.sellPrice)} = ${money(item.total)}")
            }
            appendLine("------------------------------")
            appendLine("BRUTO : ${money(sale.grossSales)}")
            if (sale.discountAmount > 0) appendLine("DISKON: ${money(sale.discountAmount)}")
            appendLine("TOTAL : ${money(sale.totalSales)}")
            appendLine("Terima kasih")
        }
    }
}
