package com.warungarasaan.app.core

data class EndToEndReadiness(
    val transactionsReady: Boolean,
    val reportingReady: Boolean,
    val backupReady: Boolean,
    val printReady: Boolean,
    val blockers: List<String>,
) {
    val readyPercentage: Int =
        listOf(transactionsReady, reportingReady, backupReady, printReady)
            .count { it } * 25

    val isReadyForPilot: Boolean =
        readyPercentage >= 75 && blockers.none { it.contains("critical", ignoreCase = true) }

    companion object {
        fun evaluate(
            transactionsReady: Boolean,
            reportingReady: Boolean,
            backupReady: Boolean,
            printReady: Boolean,
            blockers: List<String>,
        ): EndToEndReadiness {
            val normalized = blockers.map { it.trim() }.filter { it.isNotEmpty() }
            return EndToEndReadiness(
                transactionsReady = transactionsReady,
                reportingReady = reportingReady,
                backupReady = backupReady,
                printReady = printReady,
                blockers = normalized,
            )
        }
    }
}
