package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.ui.redesign.NativeExpensesScreen

@Composable
fun NativeExpensesModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var expenses by remember { mutableStateOf(emptyList<Expense>()) }

    LaunchedEffect(Unit) {
        expenses = container.expenseRepository.all().sortedByDescending { it.dateEpochDay }
    }

    NativeExpensesScreen(
        expenses = expenses,
        onCreateExpense = {},
    )
}
