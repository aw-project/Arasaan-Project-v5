package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer

@Composable
fun ActivityLogPageScreen(container: AppContainer, modifier: Modifier = Modifier) {
    ActivityModuleScreen(container = container, modifier = modifier)
}
