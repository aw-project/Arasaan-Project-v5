package com.warungarasaan.app.ui.redesign

data class RouteCoverageAudit(
    val required: List<String>,
    val available: List<String>,
) {
    fun missing(): List<String> = required.filterNot { it in available.toSet() }
    fun extra(): List<String> = available.filterNot { it in required.toSet() }
    fun coveragePercent(): Int {
        if (required.isEmpty()) return 0
        return (((required.size - missing().size).toDouble() / required.size.toDouble()) * 100.0).toInt()
    }
}

object RouteCoverageAuditor {
    fun audit(available: List<String>): RouteCoverageAudit =
        RouteCoverageAudit(
            required = FinalParityWiring.requiredRoutes(),
            available = available.distinct(),
        )
}
