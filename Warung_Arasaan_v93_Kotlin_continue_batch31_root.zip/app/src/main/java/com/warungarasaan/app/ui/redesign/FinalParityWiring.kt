package com.warungarasaan.app.ui.redesign

data class ModuleWiringState(
    val route: String,
    val enabled: Boolean,
)

object FinalParityWiring {
    fun requiredRoutes(): List<String> = listOf(
        NativeModuleRoutes.Home,
        NativeModuleRoutes.Dashboard,
        NativeModuleRoutes.Products,
        NativeModuleRoutes.Purchases,
        NativeModuleRoutes.Sales,
        NativeModuleRoutes.FastPos,
        NativeModuleRoutes.Finance,
        NativeModuleRoutes.Cash,
        NativeModuleRoutes.Expenses,
        NativeModuleRoutes.Debts,
        NativeModuleRoutes.Rejected,
        NativeModuleRoutes.Reports,
        NativeModuleRoutes.Analytics,
        NativeModuleRoutes.Customers,
        NativeModuleRoutes.Suppliers,
        NativeModuleRoutes.Settings,
        NativeModuleRoutes.Backup,
        NativeModuleRoutes.PrintCenter,
    )

    fun coverage(routes: List<ModuleWiringState>): Int {
        if (routes.isEmpty()) return 0
        val enabled = routes.count { it.enabled && it.route in requiredRoutes() }
        return ((enabled.toDouble() / requiredRoutes().size.toDouble()) * 100.0).toInt()
    }

    fun missingRoutes(routes: List<ModuleWiringState>): List<String> {
        val enabled = routes.filter { it.enabled }.map { it.route }.toSet()
        return requiredRoutes().filterNot(enabled::contains)
    }
}
