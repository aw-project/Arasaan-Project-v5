package com.warungarasaan.app.core

data class PaginationState(
    val page: Int = 1,
    val pageSize: Int = 20,
) {
    fun next(): PaginationState = copy(page = page + 1)
    fun reset(): PaginationState = copy(page = 1)
}
