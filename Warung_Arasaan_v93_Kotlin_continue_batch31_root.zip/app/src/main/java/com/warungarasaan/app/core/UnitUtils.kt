package com.warungarasaan.app.core

object UnitUtils {
    const val UNIT_MIGRATION_V5_FINAL = "unit_migration_v5_final_gram"

    fun normalizeUnitLabel(unit: String): String {
        val normalized = unit.trim().lowercase()
        return when (normalized) {
            "kg", "kilogram", "kilograms" -> "gram"
            "gr" -> "gram"
            "" -> "pcs"
            else -> unit.trim()
        }
    }

    fun isWeightUnit(unit: String): Boolean {
        return when (unit.trim().lowercase()) {
            "kg", "kilogram", "kilograms", "gram", "gr" -> true
            else -> false
        }
    }

    fun normalizeQty(value: Double): Double = "%.3f".format(value).toDouble()
    fun normalizeMoney(value: Double): Double = "%.2f".format(value).toDouble()
    fun normalizeRate(value: Double): Double = "%.6f".format(value).toDouble()

    fun usesKgPriceInput(unit: String): Boolean = isWeightUnit(unit)
    fun purchaseQtyLabel(unit: String): String = if (usesKgPriceInput(unit)) "Qty (gram)" else "Qty"
    fun purchasePriceLabel(unit: String): String = if (usesKgPriceInput(unit)) "Harga beli / kg" else "Harga beli / unit"

    fun purchaseInputPriceToStored(unit: String, inputPrice: Double): Double {
        return if (usesKgPriceInput(unit)) normalizeRate(inputPrice / 1000.0) else normalizeRate(inputPrice)
    }

    fun purchaseStoredPriceToInput(unit: String, storedPrice: Double): Double {
        return if (usesKgPriceInput(unit)) normalizeMoney(storedPrice * 1000.0) else normalizeRate(storedPrice)
    }

    fun purchasePriceHint(unit: String): String {
        return if (usesKgPriceInput(unit)) {
            "Masukkan harga per kg. Sistem akan hitung otomatis ke gram."
        } else {
            "Masukkan harga per unit item."
        }
    }
}
