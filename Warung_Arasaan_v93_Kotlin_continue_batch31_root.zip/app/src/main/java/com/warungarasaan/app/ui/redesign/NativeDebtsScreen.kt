package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CreditScore
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.domain.model.Debt
import com.warungarasaan.app.ui.UiFormat

@Composable
fun NativeDebtsScreen(
    debts: List<Debt>,
    onCreateDebt: () -> Unit = {},
    onPayDebt: (Debt) -> Unit = {},
) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SectionHeader("Hutang", "Fokus ke sisa kewajiban dan aksi bayar yang cepat.")
        FilledTonalButton(onClick = onCreateDebt, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.CreditScore, contentDescription = null)
            Text("  Catat Hutang")
        }
        if (debts.isEmpty()) {
            NativeEmptyBlock(
                title = "Tidak ada hutang aktif",
                subtitle = "Semua kewajiban sudah lunas atau belum ada data baru.",
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
                items(debts, key = { it.id }) { debt ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Rounded.Person, contentDescription = null)
                                    Text(debt.creditor, style = MaterialTheme.typography.titleMedium)
                                }
                                Text(UiFormat.date(debt.dateEpochDay), style = MaterialTheme.typography.bodySmall)
                            }
                            Text(debt.note.ifBlank { "Tanpa catatan" }, style = MaterialTheme.typography.bodySmall)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Sisa")
                                Text(UiFormat.money(debt.remaining), style = MaterialTheme.typography.titleMedium)
                            }
                            FilledTonalButton(onClick = { onPayDebt(debt) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Rounded.Payments, contentDescription = null)
                                Text("  Bayar")
                            }
                        }
                    }
                }
            }
        }
    }
}
