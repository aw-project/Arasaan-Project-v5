package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.AppSettings
import com.warungarasaan.app.ui.EmptyHint
import kotlinx.coroutines.launch

@Composable
fun SettingsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf<AppSettings?>(null) }
    var role by remember { mutableStateOf("") }
    var autoBackup by remember { mutableStateOf(false) }
    var autoBackupDays by remember { mutableStateOf("7") }
    var pinInput by remember { mutableStateOf("") }
    var verifyInput by remember { mutableStateOf("") }
    var verifyResult by remember { mutableStateOf("") }

    suspend fun reload() {
        settings = container.settingsRepository.get()
        role = container.metaRepository.role()
        autoBackup = container.metaRepository.autoBackupEnabled()
        autoBackupDays = container.metaRepository.autoBackupDays().toString()
    }

    LaunchedEffect(Unit) { reload() }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            if (settings == null) EmptyHint("Memuat settings", "Menyiapkan konfigurasi lokal.") else Text("Pengaturan aplikasi")
        }
        item {
            OutlinedTextField(role, { role = it }, label = { Text("Role") })
            TextButton(onClick = { scope.launch { container.metaRepository.setRole(role); reload() } }) { Text("Simpan role") }
        }
        item {
            ListItem(
                headlineContent = { Text("Auto backup") },
                supportingContent = { Text("Simulasi pengaturan interval backup lokal") },
                trailingContent = { Switch(checked = autoBackup, onCheckedChange = { checked ->
                    scope.launch { container.metaRepository.setAutoBackupEnabled(checked); reload() }
                }) },
            )
        }
        item {
            OutlinedTextField(autoBackupDays, { autoBackupDays = it }, label = { Text("Hari interval backup") })
            TextButton(onClick = {
                scope.launch {
                    container.metaRepository.setAutoBackupDays(autoBackupDays.toIntOrNull() ?: 7)
                    reload()
                }
            }) { Text("Simpan interval") }
        }
        item {
            OutlinedTextField(pinInput, { pinInput = it }, label = { Text("PIN baru") })
            TextButton(onClick = {
                scope.launch {
                    if (pinInput.isBlank()) container.settingsRepository.disablePin() else container.settingsRepository.setPin(pinInput)
                    pinInput = ""
                    reload()
                }
            }) { Text("Simpan PIN") }
        }
        item {
            OutlinedTextField(verifyInput, { verifyInput = it }, label = { Text("Verifikasi PIN") })
            TextButton(onClick = {
                scope.launch {
                    verifyResult = if (container.settingsRepository.verifyPin(verifyInput)) "PIN valid" else "PIN salah"
                }
            }) { Text("Cek PIN") }
        }
        item { if (verifyResult.isNotBlank()) Text(verifyResult) }
        item { if (settings != null) Text("PIN aktif: ${settings!!.pinEnabled}") }
        item { Text("Jika PIN aktif, LockGate akan muncul saat aplikasi dibuka.") }
    }
}
