package com.warungarasaan.app.domain.model

data class ActivityLog(val id: String, val dateEpochDay: Int, val type: String, val refId: String, val oldJson: String, val newJson: String)
data class AppSettings(val id: String = "app", val pinEnabled: Boolean, val pinHash: String)
data class CashEntry(val id: String, val dateEpochDay: Int, val direction: String, val source: String, val method: String, val note: String, val amount: Double, val refId: String)
data class Debt(val id: String, val dateEpochDay: Int, val creditor: String, val note: String, val principal: Double, val paid: Double) {
    val remaining: Double get() = (principal - paid).coerceAtLeast(0.0)
    val isSettled: Boolean get() = remaining <= 0.000001
}
data class Expense(val id: String, val dateEpochDay: Int, val note: String, val amount: Double, val paymentMethod: String = "Cash", val category: String = "Lainnya")
data class Product(val id: String, val name: String, val unit: String, val defaultMarginPercent: Double, val activeSellPrice: Double, val stockQty: Double, val avgHpp: Double, val minStock: Double = 0.0, val targetStock: Double = 0.0, val sku: String = "", val category: String = "Lainnya", val imagePath: String? = null)
data class PurchaseItem(val productId: String, val qty: Double, val buyPrice: Double)
data class Purchase(val id: String, val dateEpochDay: Int, val supplier: String = "", val paymentMethod: String = "Cash", val items: List<PurchaseItem>)
data class PaymentSplit(val method: String, val amount: Double)
data class SaleItem(val productId: String, val qty: Double, val sellPrice: Double, val hppAtSale: Double) {
    val total: Double get() = qty * sellPrice
    val totalHpp: Double get() = qty * hppAtSale
}
data class Sale(val id: String, val dateEpochDay: Int, val items: List<SaleItem>, val paymentMethod: String, val customerName: String = "", val discountAmount: Double = 0.0, val paymentSplits: List<PaymentSplit> = emptyList()) {
    val grossSales: Double get() = items.sumOf { it.total }
    val totalSales: Double get() = (grossSales - discountAmount).coerceAtLeast(0.0)
    val totalHpp: Double get() = items.sumOf { it.totalHpp }
    val totalProfit: Double get() = totalSales - totalHpp
    val hasDiscount: Boolean get() = discountAmount > 0.0001
    val isSplitPayment: Boolean get() = paymentSplits.size > 1
    val normalizedSplits: List<PaymentSplit> get() = if (paymentSplits.isNotEmpty()) paymentSplits.filter { it.amount > 0.0 } else listOf(PaymentSplit(paymentMethod, totalSales))
    val paymentSummary: String get() = normalizedSplits.joinToString(" + ") { "${it.method} ${"%.0f".format(it.amount)}" }
}
data class RejectedItem(val id: String, val dateEpochDay: Int, val productId: String, val qty: Double, val reason: String, val handling: String, val note: String = "", val hppAtTime: Double, val estimatedLoss: Double)
data class StockMovement(val id: String, val dateEpochDay: Int, val productId: String, val type: String, val qtyDelta: Double, val note: String, val lossType: String? = null, val lossAmount: Double = 0.0)
