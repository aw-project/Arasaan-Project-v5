package com.warungarasaan.app.ui.widgets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.core.Dates

@Composable
fun DateRangePicker(
    startEpochDay: Int,
    endEpochDay: Int,
    onLast7Days: () -> Unit,
    onLast30Days: () -> Unit,
    onThisMonth: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        AssistChip(
            onClick = onLast7Days,
            label = { Text("7 Hari") },
        )
        AssistChip(
            onClick = onLast30Days,
            label = { Text("30 Hari") },
        )
        AssistChip(
            onClick = onThisMonth,
            label = { Text(Dates.rangeLabel(startEpochDay, endEpochDay)) },
        )
    }
}
