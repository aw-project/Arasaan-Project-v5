
package com.warungarasaan.app.ui.redesign

data class FastPosParityState(
    val cartCount: Int = 0,
    val subtotal: Double = 0.0,
    val discountAmount: Double = 0.0,
    val paymentReceived: Double = 0.0,
    val paymentMethod: String = "Cash",
) {
    fun total(): Double = (subtotal - discountAmount).coerceAtLeast(0.0)
    fun change(): Double = (paymentReceived - total()).coerceAtLeast(0.0)
    fun canCheckout(): Boolean = cartCount > 0 && total() > 0.0 && paymentReceived >= total()
}
