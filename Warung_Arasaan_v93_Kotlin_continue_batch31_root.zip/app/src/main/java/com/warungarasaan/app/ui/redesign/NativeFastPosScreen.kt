package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun NativeFastPosScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    products: List<FastPosProductUi>,
    cartItems: List<FastPosCartRowUi>,
    subtotal: String,
    paymentMethod: String,
    onPaymentMethodChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    onTapProduct: (String) -> Unit = {},
    onCheckout: () -> Unit = {}
) {
    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = onCheckout) {
                Text("Bayar")
            }
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp,
                top = padding.calculateTopPadding() + 16.dp,
                end = 16.dp,
                bottom = padding.calculateBottomPadding() + 88.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SmartSearchBar(
                    value = query,
                    placeholder = "Cari produk atau barcode",
                    onValueChange = onQueryChange
                )
            }
            item {
                CompactFilterRow(
                    selected = paymentMethod,
                    options = listOf("Cash", "QRIS", "Transfer", "Tempo"),
                    onChange = onPaymentMethodChange
                )
            }
            item {
                SectionHeader("Keranjang", trailing = subtotal)
            }
            if (cartItems.isEmpty()) {
                item {
                    Card {
                        ListItem(
                            headlineContent = { Text("Belum ada item") },
                            supportingContent = { Text("Tambahkan produk dari daftar di bawah") }
                        )
                    }
                }
            } else {
                items(cartItems) { row ->
                    Card {
                        ListItem(
                            headlineContent = { Text(row.title) },
                            supportingContent = { Text("${row.qty} • ${row.subtotal}") }
                        )
                    }
                }
            }
            item {
                SectionHeader("Produk")
            }
            items(products) { product ->
                Card(onClick = { onTapProduct(product.id) }) {
                    ListItem(
                        headlineContent = { Text(product.title) },
                        supportingContent = { Text("${product.price} • ${product.subtitle}") }
                    )
                }
            }
        }
    }
}
