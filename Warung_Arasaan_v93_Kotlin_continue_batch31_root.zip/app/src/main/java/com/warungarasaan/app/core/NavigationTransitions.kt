package com.warungarasaan.app.core

object NavigationTransitions {
    const val Default = "default"
    const val Fade = "fade"
    const val Slide = "slide"
}
