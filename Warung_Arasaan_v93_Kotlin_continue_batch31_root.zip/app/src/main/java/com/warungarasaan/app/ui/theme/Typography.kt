package com.warungarasaan.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Fallback ke sans-serif default Android (mirip Poppins feel)
// Jika ada font file di assets/fonts/ bisa di-swap di sini
val WarungFontFamily = FontFamily.Default

val WarungTypography = Typography(
    displayLarge  = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W700, fontSize = 57.sp, lineHeight = 64.sp, letterSpacing = (-0.25).sp),
    displayMedium = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W700, fontSize = 45.sp, lineHeight = 52.sp),
    displaySmall  = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W700, fontSize = 36.sp, lineHeight = 44.sp),
    headlineLarge = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W700, fontSize = 32.sp, lineHeight = 40.sp, letterSpacing = (-0.3).sp),
    headlineMedium= TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W700, fontSize = 28.sp, lineHeight = 36.sp, letterSpacing = (-0.2).sp),
    headlineSmall = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W700, fontSize = 24.sp, lineHeight = 32.sp),
    titleLarge    = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W700, fontSize = 20.sp, lineHeight = 28.sp, letterSpacing = (-0.2).sp),
    titleMedium   = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W600, fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = (-0.1).sp),
    titleSmall    = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W600, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge     = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W400, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium    = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W400, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall     = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W400, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge    = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W600, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    labelMedium   = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W600, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.3.sp),
    labelSmall    = TextStyle(fontFamily = WarungFontFamily, fontWeight = FontWeight.W600, fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 0.4.sp),
)
