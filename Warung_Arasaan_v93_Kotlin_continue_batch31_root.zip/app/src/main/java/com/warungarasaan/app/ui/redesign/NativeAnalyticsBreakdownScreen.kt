package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

@Composable
fun NativeAnalyticsBreakdownScreen(
    rangeLabel: String,
    summary: AnalyticsBreakdownUi
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionHeader("Analytics Breakdown") }
        item { Text("Rentang: $rangeLabel") }
        item { Card { ListItem(headlineContent = { Text("Revenue") }, trailingContent = { Text(summary.totalRevenue.toString()) }) } }
        item { Card { ListItem(headlineContent = { Text("Profit") }, trailingContent = { Text(summary.totalProfit.toString()) }) } }
        item { Card { ListItem(headlineContent = { Text("Transaksi") }, trailingContent = { Text(summary.totalTransactions.toString()) }) } }
        item { Card { ListItem(headlineContent = { Text("Rata-rata keranjang") }, trailingContent = { Text(summary.averageBasket.toString()) }) } }
        item { SectionHeader("Top Produk") }
        items(summary.topProductNames.size) { index ->
            Card { ListItem(headlineContent = { Text(summary.topProductNames[index]) }) }
        }
        item { SectionHeader("Margin Rendah") }
        items(summary.lowMarginProductNames.size) { index ->
            Card { ListItem(headlineContent = { Text(summary.lowMarginProductNames[index]) }) }
        }
    }
}
