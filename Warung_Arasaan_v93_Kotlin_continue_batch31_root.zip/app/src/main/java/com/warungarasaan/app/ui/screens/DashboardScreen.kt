package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.data.service.BusinessActionItem
import com.warungarasaan.app.data.service.BusinessDecisionSummary
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.domain.model.*
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun DashboardScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var easyMode by remember { mutableStateOf(true) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var purchases by remember { mutableStateOf<List<Purchase>>(emptyList()) }
    var debts by remember { mutableStateOf<List<Debt>>(emptyList()) }
    var cashEntries by remember { mutableStateOf<List<CashEntry>>(emptyList()) }
    var rejected by remember { mutableStateOf<List<RejectedItem>>(emptyList()) }
    var activities by remember { mutableStateOf<List<ActivityLog>>(emptyList()) }

    LaunchedEffect(Unit) {
        products = container.productRepository.all()
        sales = container.salesRepository.all()
        expenses = container.expenseRepository.all()
        purchases = container.purchaseRepository.all()
        debts = container.debtRepository.all()
        cashEntries = container.cashRepository.all()
        rejected = container.rejectedRepository.all()
        activities = container.activityLogRepository.recent(20)
    }

    val today = AppUtils.epochDayNow()
    val salesToday = sales.filter { it.dateEpochDay == today }
    val expensesToday = expenses.filter { it.dateEpochDay == today }
    val rejectedToday = rejected.filter { it.dateEpochDay == today }
    val omzetToday = salesToday.sumOf { it.totalSales }
    val hppToday = salesToday.sumOf { it.totalHpp }
    val biayaToday = expensesToday.sumOf { it.amount }
    val rugiRejekToday = rejectedToday.sumOf { it.estimatedLoss }
    val labaToday = omzetToday - hppToday - biayaToday - rugiRejekToday
    val activeDebts = debts.count { !it.isSettled }
    val analyticsService = AnalyticsService()
    val businessSummary = analyticsService.businessDecisionSummary(sales, purchases, products)
    val businessActions = analyticsService.businessActionItems(sales, purchases, products, limit = 6)
    val ownerCapital = cashEntries
        .filter { it.direction.equals("in", true) && (it.source.equals("owner_capital", true) || it.note.contains("modal", true)) }
        .sumOf { it.amount }
    val stockAsset = products.sumOf { it.stockQty.coerceAtLeast(0.0) * it.avgHpp.coerceAtLeast(0.0) }
    val cashBalance = cashEntries
        .filter { PaymentMethods.isCashFlow(it.method) }
        .sumOf { if (it.direction == "in") it.amount else -it.amount }
    val lowStocks = products.filter { it.minStock > 0 && it.stockQty <= it.minStock }

    val soldByProduct = salesToday
        .flatMap { it.items }
        .groupBy { it.productId }
        .mapValues { (_, items) -> items.sumOf { it.qty } }

    val productMap = products.associateBy { it.id }
    val topProducts = soldByProduct.entries
        .sortedByDescending { it.value }
        .take(8)

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(
                title = if (easyMode) "Yang perlu dilihat cepat" else "Ringkasan hari ini",
                subtitle = if (easyMode) "Lihat uang masuk, laba, dan barang yang perlu diperhatikan." else "Ringkasan KPI utama hari ini."
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { easyMode = true }) { Text("Mode Mudah") }
                    TextButton(onClick = { easyMode = false }) { Text("Mode Lengkap") }
                }
            }
        }
        if (easyMode) {
            item {
                SectionCard(
                    title = "Mulai dari sini",
                    subtitle = "Urutan paling aman untuk dipakai setiap hari.",
                ) {
                    Text("1. Cek uang masuk dan laba hari ini.")
                    Text("2. Lihat barang yang perlu dibeli atau dihabiskan.")
                    Text("3. Kerjakan aksi yang disarankan satu per satu.")
                }
            }
        }
        item { StatCard("Omzet hari ini", UiFormat.money(omzetToday), "${salesToday.size} transaksi penjualan") }
        item { StatCard("Laba estimasi", UiFormat.money(labaToday), "Omzet - HPP - biaya - rugi rejek hari ini") }
        item { StatCard("Saldo kas", UiFormat.money(cashBalance), "Arus kas cash / tunai") }
        item { StatCard("Hutang aktif", activeDebts.toString(), "Hutang supplier yang belum lunas") }

        item {
            SectionCard(if (easyMode) "Yang perlu dikerjakan hari ini" else "Insight cepat", subtitle = if (easyMode) "Hal penting yang perlu dicek hari ini." else "Padanan dashboard_page.dart dengan KPI inti dan insight harian.") {
                Text("HPP hari ini: ${UiFormat.money(hppToday)}")
                Text("Biaya hari ini: ${UiFormat.money(biayaToday)}")
                Text("Rugi rejek hari ini: ${UiFormat.money(rugiRejekToday)}")
                Text("Produk kritis: ${lowStocks.size}")
            }
        }

        item {
            SectionCard(if (easyMode) "Aksi yang disarankan" else "Aksi bisnis utama", subtitle = if (easyMode) "Urutan kerja yang paling penting lebih dulu." else "Rekomendasi cepat dari restock, margin, dan evaluasi harga.") {
                if (businessActions.isEmpty()) {
                    EmptyHint("Belum ada tindakan prioritas.", "")
                } else {
                    businessActions.forEachIndexed { index, item ->
                        Text("${index + 1}. ${item.label}", modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }

        item {
            SectionCard(if (easyMode) "Peringatan usaha" else "Prioritas bisnis", subtitle = if (easyMode) "Tanda bahaya dan peluang yang perlu diperhatikan." else "Ringkasan BI utama untuk tindakan hari ini.") {
                Text("Restock kritis: ${businessSummary.criticalRestockCount} item")
                Text("Total saran beli kritis: ${UiFormat.qty(businessSummary.criticalRestockBuyQty)}")
                Text("Stok mati: ${businessSummary.deadStockCount} • stok lambat: ${businessSummary.slowStockCount}")
                Text("Alert margin turun: ${businessSummary.marginAlertCount}")
                Text("Produk perlu review harga jual: ${businessSummary.priceReviewCount}")
                Text("Supplier terbaik: ${businessSummary.bestSupplierName} (${UiFormat.qty(businessSummary.bestSupplierScore)})")
            }
        }

        item {
            SectionCard(if (easyMode) "Uang & stok usaha" else "Posisi modal & aset", subtitle = if (easyMode) "Membantu melihat uang usaha dan nilai barang yang tersedia." else "Membantu membaca modal owner, kas aktif, dan nilai stok saat ini.") {
                Text("Modal owner tercatat: ${UiFormat.money(ownerCapital)}")
                Text("Kas aktif: ${UiFormat.money(cashBalance)}")
                Text("Nilai stok saat ini: ${UiFormat.money(stockAsset)}")
                Text("Aset lancar sederhana: ${UiFormat.money(cashBalance + stockAsset)}")
            }
        }

        item {
            HorizontalDivider()
            Text("Top produk hari ini", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        }
        if (topProducts.isEmpty()) {
            item { EmptyHint("Belum ada penjualan hari ini", "Top produk akan tampil setelah ada transaksi.") }
        } else {
            items(topProducts, key = { it.key }) { entry ->
                val product = productMap[entry.key]
                ListItem(
                    modifier = Modifier.fillMaxWidth(),
                    headlineContent = { Text(product?.name ?: entry.key) },
                    supportingContent = {
                        Text("Terjual ${UiFormat.qty(entry.value)} ${product?.unit ?: "unit"}")
                    },
                    trailingContent = {
                        Text(UiFormat.money(product?.activeSellPrice ?: 0.0))
                    },
                )
            }
        }

        item {
            HorizontalDivider()
            Text("Stok kritis", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        }
        if (lowStocks.isEmpty()) {
            item { EmptyHint("Tidak ada stok kritis", "Semua produk masih di atas batas minimal.") }
        } else {
            items(lowStocks.take(10), key = { it.id }) { product ->
                ListItem(
                    modifier = Modifier.fillMaxWidth(),
                    headlineContent = { Text(product.name) },
                    supportingContent = {
                        Text("Stok ${UiFormat.qty(product.stockQty)} ${product.unit} • Min ${UiFormat.qty(product.minStock)}")
                    },
                    trailingContent = { Text(UiFormat.money(product.activeSellPrice)) },
                )
            }
        }

        item {
            HorizontalDivider()
            Text("Aktivitas terbaru", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        }
        if (activities.isEmpty()) {
            item { EmptyHint("Belum ada aktivitas", "Aktivitas terbaru akan muncul setelah data berubah.") }
        } else {
            items(activities.take(12), key = { it.id }) { log ->
                ListItem(
                    headlineContent = { Text(log.newJson.ifBlank { log.refId }) },
                    supportingContent = { Text("${log.type} • ${UiFormat.date(log.dateEpochDay)}") },
                )
            }
        }
    }
}
