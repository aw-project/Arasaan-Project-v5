package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoneyOff
import androidx.compose.material.icons.rounded.Receipt
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.ui.UiFormat

@Composable
fun NativeExpensesScreen(
    expenses: List<Expense>,
    onCreateExpense: () -> Unit = {},
) {
    val grouped = expenses.groupBy { it.category }
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SectionHeader("Biaya", "Biaya rutin lebih mudah dipantau per kategori dan metode bayar.")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryMiniCard("Total", UiFormat.money(expenses.sumOf { it.amount }), Icons.Rounded.MoneyOff, Modifier.weight(1f))
            SummaryMiniCard("Kategori", grouped.keys.size.toString(), Icons.Rounded.Tune, Modifier.weight(1f))
        }
        FilledTonalButton(onClick = onCreateExpense, modifier = Modifier.fillMaxWidth()) {
            Text("Tambah Biaya")
        }
        if (expenses.isEmpty()) {
            NativeEmptyBlock("Belum ada biaya", "Catat biaya operasional supaya laba bersih lebih akurat.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
                items(expenses, key = { it.id }) { expense ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(expense.note, style = MaterialTheme.typography.titleMedium)
                                AssistChip(onClick = {}, label = { Text(expense.category) })
                            }
                            Text(UiFormat.date(expense.dateEpochDay), style = MaterialTheme.typography.bodySmall)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(expense.paymentMethod)
                                Text(UiFormat.money(expense.amount), style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
