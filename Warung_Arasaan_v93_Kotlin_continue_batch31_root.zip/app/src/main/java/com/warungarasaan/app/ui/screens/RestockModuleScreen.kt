package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.data.service.SmartRestockKpi
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

private fun Double.daysLeftLabel(): String = if (this.isInfinite()) "Aman / tidak aktif" else "${UiFormat.qty(this)} hari"

private fun applyRestockFilter(rows: List<SmartRestockKpi>, filter: String): List<SmartRestockKpi> {
    return when (filter) {
        "Perlu Aksi" -> rows.filter { it.status in setOf("HABIS", "KRITIS", "WASPADA") }
        "Habis" -> rows.filter { it.status == "HABIS" }
        "Kritis" -> rows.filter { it.status == "KRITIS" }
        "Lambat" -> rows.filter { it.status == "LAMBAT" }
        "Mati" -> rows.filter { it.status == "MATI" }
        "Aman" -> rows.filter { it.status == "AMAN" }
        else -> rows
    }
}

private fun applyRestockSort(rows: List<SmartRestockKpi>, sort: String): List<SmartRestockKpi> {
    return when (sort) {
        "Nama" -> rows.sortedBy { it.name.lowercase() }
        "Hari Aman" -> rows.sortedBy { if (it.daysLeft.isInfinite()) Double.MAX_VALUE else it.daysLeft }
        "Saran Beli" -> rows.sortedByDescending { it.suggestBuy }
        else -> rows.sortedByDescending { it.priorityScore }
    }
}

@Composable
fun RestockModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var rows by remember { mutableStateOf(emptyList<SmartRestockKpi>()) }
    var filter by remember { mutableStateOf("Perlu Aksi") }
    var sort by remember { mutableStateOf("Prioritas") }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Semua Kategori") }
    var actionOnly by remember { mutableStateOf(true) }
    var simpleMode by remember { mutableStateOf(true) }

    suspend fun reload() {
        val sales = container.salesRepository.all()
        val products = container.productRepository.all()
        val purchases = container.purchaseRepository.all()
        rows = AnalyticsService().smartRestock(sales, products, purchases = purchases)
    }

    LaunchedEffect(Unit) { reload() }

    val categoryOptions = remember(rows) {
        listOf("Semua Kategori") + rows.map { it.category.trim().ifBlank { "Tanpa Kategori" } }.distinct().sorted()
    }
    val visibleRows = remember(rows, actionOnly) {
        if (actionOnly) rows.filter { it.status in setOf("HABIS", "KRITIS", "WASPADA") } else rows
    }
    val filteredRows = remember(visibleRows, filter, sort, query, category) {
        val filtered = applyRestockFilter(visibleRows, filter)
            .filter {
                val categoryLabel = it.category.trim().ifBlank { "Tanpa Kategori" }
                val matchesCategory = category == "Semua Kategori" || categoryLabel == category
                val normalizedQuery = query.trim().lowercase()
                val matchesQuery = normalizedQuery.isBlank() ||
                    it.name.lowercase().contains(normalizedQuery) ||
                    it.category.lowercase().contains(normalizedQuery) ||
                    it.productId.lowercase().contains(normalizedQuery)
                matchesCategory && matchesQuery
            }
        applyRestockSort(filtered, sort)
    }
    val criticalCount = remember(rows) { rows.count { it.status == "KRITIS" || it.status == "HABIS" } }
    val warningCount = remember(rows) { rows.count { it.status == "WASPADA" } }
    val slowCount = remember(rows) { rows.count { it.status == "LAMBAT" || it.status == "MATI" } }
    val buyTotal = remember(filteredRows) { filteredRows.sumOf { it.suggestBuy } }
    val actionRows = remember(rows) { rows.filter { it.status in setOf("HABIS", "KRITIS", "WASPADA") } }
    val weeklyActionNeed = remember(actionRows) { actionRows.sumOf { it.weeklyNeed } }
    val topPriorityRows = remember(actionRows) { actionRows.take(3) }
    val supplierNeeds = remember(actionRows) {
        actionRows
            .filter { it.preferredSupplier.isNotBlank() }
            .groupBy { it.preferredSupplier }
            .map { (supplier, items) ->
                supplier to items.sumOf { it.suggestBuy }
            }
            .sortedByDescending { it.second }
            .take(5)
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionCard(
                title = "Smart Restock",
                subtitle = if (simpleMode) "Fokus pada barang yang perlu dibeli dulu." else "Target stok otomatis, hari aman, kebutuhan mingguan, dan prioritas restock.",
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip("Kritis ${criticalCount}")
                    InfoChip("Waspada ${warningCount}")
                    InfoChip("Lambat/Mati ${slowCount}")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip("Saran beli ${UiFormat.qty(buyTotal)}")
                    InfoChip("Kebutuhan minggu ${UiFormat.qty(weeklyActionNeed)}")
                    InfoChip("Item ${filteredRows.size}")
                }
                if (topPriorityRows.isNotEmpty()) {
                    Text("Prioritas teratas minggu ini")
                    topPriorityRows.forEach { priority ->
                        Text("• ${priority.name} — ${priority.status} • saran ${UiFormat.qty(priority.suggestBuy)}")
                    }
                }
                if (simpleMode && topPriorityRows.isNotEmpty()) {
                    Text("Daftar belanja cepat")
                    topPriorityRows.forEach { priority ->
                        Text("• ${priority.name} • beli ${UiFormat.qty(priority.suggestBuy)} ${priority.unit}")
                    }
                }
                if (simpleMode && supplierNeeds.isNotEmpty()) {
                    Text("Supplier yang paling perlu dihubungi")
                    supplierNeeds.forEach { (supplier, qty) ->
                        Text("• ${supplier} • kebutuhan ${UiFormat.qty(qty)}")
                    }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Cari barang yang mau dibeli") },
                    placeholder = { Text("Contoh: tomat, cabai, bawang") },
                    singleLine = true,
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = simpleMode,
                            onClick = { simpleMode = true },
                            label = { Text("Mode mudah") },
                        )
                    }
                    item {
                        FilterChip(
                            selected = !simpleMode,
                            onClick = { simpleMode = false },
                            label = { Text("Mode lengkap") },
                        )
                    }
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Hanya Perlu Aksi" to true, "Tampilkan Semua" to false)) { (label, selected) ->
                    FilterChip(
                        selected = actionOnly == selected,
                        onClick = { actionOnly = selected },
                        label = { Text(label) },
                    )
                }
            }
        }
        item {
            Text("Filter status")
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(if (simpleMode) listOf("Perlu Aksi", "Habis", "Kritis", "Aman") else listOf("Perlu Aksi", "Semua", "Habis", "Kritis", "Lambat", "Mati", "Aman")) { option ->
                    FilterChip(
                        selected = filter == option,
                        onClick = { filter = option },
                        label = { Text(option) },
                    )
                }
            }
        }
        if (!simpleMode) {
            item {
                Text("Kategori")
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categoryOptions) { option ->
                        FilterChip(
                            selected = category == option,
                            onClick = { category = option },
                            label = { Text(option) },
                        )
                    }
                }
            }
            item {
                Text("Urutkan")
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("Prioritas", "Hari Aman", "Saran Beli", "Nama")) { option ->
                        FilterChip(
                            selected = sort == option,
                            onClick = { sort = option },
                            label = { Text(option) },
                        )
                    }
                }
            }
        }

        if (filteredRows.isEmpty()) {
            item {
                EmptyHint(
                    title = "Belum ada item restock",
                    subtitle = if (rows.isEmpty()) {
                        "Tambahkan produk dan riwayat penjualan agar mesin restock bisa menghitung kebutuhan."
                    } else {
                        "Tidak ada item yang cocok dengan filter atau kata kunci saat ini."
                    },
                )
            }
        } else {
            items(filteredRows, key = { it.productId }) { item ->
                val categoryLabel = item.category.ifBlank { "Tanpa kategori" }
                SectionCard(
                    title = item.name,
                    subtitle = "$categoryLabel • status ${item.status}",
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip("Prioritas ${"%.0f".format(item.priorityScore)}")
                        InfoChip("Hari aman ${item.daysLeft.daysLeftLabel()}")
                    }
                    InlineLabelValue("Stok sekarang", UiFormat.qty(item.stockQty))
                    InlineLabelValue("Rata-rata jual / hari", UiFormat.qty(item.avgPerDay))
                    InlineLabelValue("Target stok", UiFormat.qty(item.targetQty))
                    InlineLabelValue("Kebutuhan mingguan", UiFormat.qty(item.weeklyNeed))
                    InlineLabelValue("Saran beli", UiFormat.qty(item.suggestBuy))
                    if (item.preferredSupplier.isNotBlank()) {
                        InlineLabelValue("Supplier saran", item.preferredSupplier)
                        if (item.latestBuyPrice > 0.0) {
                            InlineLabelValue("Harga beli terakhir", UiFormat.money(item.latestBuyPrice))
                        }
                    }
                    ListItem(
                        headlineContent = { Text("Aksi ${item.status}") },
                        supportingContent = {
                            Text(
                                when (item.status) {
                                    "HABIS" -> "Stok kosong. Restock sekarang."
                                    "KRITIS" -> "Stok hampir habis. Prioritaskan pembelian."
                                    "WASPADA" -> "Masih aman singkat, tetapi target stok belum tercapai."
                                    "LAMBAT" -> "Produk bergerak lambat. Beli secukupnya."
                                    "MATI" -> "Belum ada penjualan. Evaluasi pembelian dan display."
                                    else -> "Stok aman."
                                }
                            )
                        },
                    )
                }
            }
        }
    }
}
