package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.ui.redesign.NativeSalesScreen

@Composable
fun NativeSalesModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var sales by remember { mutableStateOf(emptyList<Sale>()) }

    LaunchedEffect(Unit) {
        sales = container.salesRepository.all().sortedByDescending { it.dateEpochDay }
    }

    NativeSalesScreen(
        sales = sales,
        onCreateSale = {},
        onOpenFastPos = {},
        onOpenSale = {},
    )
}
