package com.warungarasaan.app.domain

object PaymentMethods {
    const val CASH = "Cash"
    const val QRIS = "QRIS"
    const val TRANSFER = "Transfer"
    const val HUTANG = "Hutang"
    const val NON_CASH = "Non Cash"

    fun isCashFlow(method: String): Boolean = method.equals(CASH, ignoreCase = true)
}
