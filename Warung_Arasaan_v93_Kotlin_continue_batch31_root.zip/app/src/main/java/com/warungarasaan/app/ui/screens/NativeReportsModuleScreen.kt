package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.ReportingService
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.redesign.NativeReportBreakdownScreen
import com.warungarasaan.app.ui.redesign.ReportBreakdownRowUi
import com.warungarasaan.app.ui.redesign.ReportFilterUiState

@Composable
fun NativeReportsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var filters by remember { mutableStateOf(ReportFilterUiState()) }
    var rows by remember { mutableStateOf(emptyList<ReportBreakdownRowUi>()) }

    LaunchedEffect(filters) {
        val sales = container.salesRepository.all()
        val expenses = container.expenseRepository.all()
        val rejected = container.rejectedRepository.all()
        val products = container.productRepository.all().associateBy { it.id }

        val summary = ReportingService.summarize(
            sales = sales,
            expenses = expenses,
            rejectedItems = rejected,
        )

        val productRows = sales
            .flatMap { sale -> sale.items }
            .groupBy { it.productId }
            .entries
            .sortedByDescending { (_, items) -> items.sumOf { it.total } }
            .take(5)
            .mapIndexed { index, (productId, items) ->
                val name = products[productId]?.name ?: productId
                ReportBreakdownRowUi(
                    title = "Top ${index + 1} • $name",
                    value = UiFormat.money(items.sumOf { it.total }),
                    note = "${items.sumOf { it.qty }} item terjual"
                )
            }

        rows = buildList {
            add(ReportBreakdownRowUi("Omzet", UiFormat.money(summary.omzet), filters.selectedRange))
            add(ReportBreakdownRowUi("Laba Kotor", UiFormat.money(summary.labaKotor), "Sebelum biaya"))
            add(ReportBreakdownRowUi("HPP", UiFormat.money(summary.totalHpp), "Total modal barang terjual"))
            add(ReportBreakdownRowUi("Biaya", UiFormat.money(summary.totalBiaya), filters.selectedCategory))
            add(ReportBreakdownRowUi("Rugi Rejected", UiFormat.money(summary.rugiRejek), "Barang reject/rusak"))
            add(ReportBreakdownRowUi("Laba Bersih", UiFormat.money(summary.labaBersih), "Setelah biaya + rejected"))
            addAll(productRows)
        }
    }

    NativeReportBreakdownScreen(
        filters = filters,
        rows = rows,
        onRangeChange = { filters = filters.copy(selectedRange = it) },
        onPaymentChange = { filters = filters.copy(selectedPaymentMethod = it) },
        onCategoryChange = { filters = filters.copy(selectedCategory = it) }
    )
}
