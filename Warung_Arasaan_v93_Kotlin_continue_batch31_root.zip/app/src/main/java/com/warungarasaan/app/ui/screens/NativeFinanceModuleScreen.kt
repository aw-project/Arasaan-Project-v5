package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.CashEntry
import com.warungarasaan.app.domain.model.Debt
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.ui.redesign.NativeFinanceScreen

@Composable
fun NativeFinanceScreenModule(
    cashEntries: List<CashEntry>,
    expenses: List<Expense>,
    debts: List<Debt>,
    modifier: Modifier = Modifier,
) {
    NativeFinanceScreen(
        cashEntries = cashEntries,
        expenses = expenses,
        debts = debts,
        onOpenCash = {},
        onOpenExpenses = {},
        onOpenDebts = {},
    )
}

@Composable
fun NativeFinanceModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var cashEntries by remember { mutableStateOf(emptyList<CashEntry>()) }
    var expenses by remember { mutableStateOf(emptyList<Expense>()) }
    var debts by remember { mutableStateOf(emptyList<Debt>()) }

    LaunchedEffect(Unit) {
        cashEntries = container.cashRepository.all().sortedByDescending { it.dateEpochDay }
        expenses = container.expenseRepository.all().sortedByDescending { it.dateEpochDay }
        debts = container.debtRepository.all().sortedByDescending { it.dateEpochDay }
    }

    NativeFinanceScreenModule(
        cashEntries = cashEntries,
        expenses = expenses,
        debts = debts,
        modifier = modifier,
    )
}
