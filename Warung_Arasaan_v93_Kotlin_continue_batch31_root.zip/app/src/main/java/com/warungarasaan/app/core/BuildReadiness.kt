
package com.warungarasaan.app.core

data class ReadinessCheck(
    val key: String,
    val passed: Boolean,
    val message: String,
)

data class BuildReadinessReport(
    val checks: List<ReadinessCheck>,
) {
    val passedCount: Int get() = checks.count { it.passed }
    val failedCount: Int get() = checks.count { !it.passed }
    fun completionPercent(): Int {
        if (checks.isEmpty()) return 0
        return ((passedCount.toDouble() / checks.size.toDouble()) * 100.0).toInt()
    }
    fun summary(): String = "$passedCount/${checks.size} checks passed"
}

object BuildReadiness {
    fun evaluate(
        hasRootWiring: Boolean,
        hasReportParity: Boolean,
        hasAnalyticsParity: Boolean,
        hasBackupValidation: Boolean,
        hasReceiptTransport: Boolean,
        hasPermissionCenter: Boolean,
        hasRegressionCoverage: Boolean,
    ): BuildReadinessReport {
        val checks = listOf(
            ReadinessCheck("root_wiring", hasRootWiring, "Root module routing should point to native wrappers."),
            ReadinessCheck("report_parity", hasReportParity, "Reports should expose period/filter breakdown parity."),
            ReadinessCheck("analytics_parity", hasAnalyticsParity, "Analytics should expose breakdown and insight parity."),
            ReadinessCheck("backup_validation", hasBackupValidation, "Backup/restore should validate payload before import."),
            ReadinessCheck("receipt_transport", hasReceiptTransport, "Receipt share and thermal transport should both exist."),
            ReadinessCheck("permission_center", hasPermissionCenter, "Runtime permission requests should be centralized."),
            ReadinessCheck("regression_coverage", hasRegressionCoverage, "Regression-oriented tests should cover core flows."),
        )
        return BuildReadinessReport(checks)
    }
}
