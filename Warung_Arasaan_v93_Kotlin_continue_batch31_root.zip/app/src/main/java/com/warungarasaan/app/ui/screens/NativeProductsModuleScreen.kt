package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.redesign.NativeProductsScreen
import com.warungarasaan.app.ui.redesign.ProductRowUi

@Composable
fun NativeProductsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Semua") }
    var rows by remember { mutableStateOf(emptyList<ProductRowUi>()) }

    LaunchedEffect(Unit) {
        rows = container.productRepository.all().map {
            ProductRowUi(
                id = it.id,
                name = it.name,
                unit = it.unit,
                priceLabel = UiFormat.money(it.activeSellPrice),
                stockLabel = "${it.stockQty} ${it.unit}",
            )
        }
    }

    val filteredRows = rows.filter { row ->
        val matchesQuery = query.isBlank() || row.name.contains(query, ignoreCase = true)
        val matchesFilter = when (filter) {
            "Stok kritis" -> row.stockLabel.substringBefore(" ").toDoubleOrNull()?.let { it <= 5.0 } ?: false
            else -> true
        }
        matchesQuery && matchesFilter
    }

    NativeProductsScreen(
        query = query,
        onQueryChange = { query = it },
        selectedFilter = filter,
        onFilterChange = { filter = it },
        rows = filteredRows,
        onTapProduct = {},
        modifier = modifier,
    )
}
