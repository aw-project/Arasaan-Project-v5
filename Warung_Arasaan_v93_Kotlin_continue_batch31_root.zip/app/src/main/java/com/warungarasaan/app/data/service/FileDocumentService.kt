package com.warungarasaan.app.data.service

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedWriter
import java.io.OutputStreamWriter

object FileDocumentService {
    fun writeText(
        contentResolver: ContentResolver,
        uri: Uri,
        text: String,
    ) {
        contentResolver.openOutputStream(uri)?.use { output ->
            BufferedWriter(OutputStreamWriter(output)).use { writer ->
                writer.write(text)
                writer.flush()
            }
        } ?: error("Tidak bisa membuka output stream untuk file tujuan.")
    }

    fun readText(
        contentResolver: ContentResolver,
        uri: Uri,
    ): String {
        return contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: error("Tidak bisa membuka input stream dari file sumber.")
    }
}
