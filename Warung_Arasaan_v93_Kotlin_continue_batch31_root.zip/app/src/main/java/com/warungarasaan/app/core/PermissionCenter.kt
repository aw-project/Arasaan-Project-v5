package com.warungarasaan.app.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object PermissionCenter {
    fun bluetoothRuntimePermissions(): List<String> = buildList {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
        }
    }

    fun notificationRuntimePermissions(): List<String> = buildList {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun cameraRuntimePermissions(): List<String> = listOf(Manifest.permission.CAMERA)

    fun requiredRuntimePermissions(): List<String> =
        bluetoothRuntimePermissions() + notificationRuntimePermissions() + cameraRuntimePermissions()

    fun isGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun missingPermissions(context: Context, permissions: List<String>): List<String> =
        permissions.distinct().filterNot { isGranted(context, it) }
}
