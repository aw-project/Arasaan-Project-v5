package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddShoppingCart
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Sell
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.ui.UiFormat

@Composable
fun NativeSalesScreen(
    sales: List<Sale>,
    onCreateSale: () -> Unit = {},
    onOpenFastPos: () -> Unit = {},
    onOpenSale: (Sale) -> Unit = {},
) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        SectionHeader(
            title = "Penjualan",
            subtitle = "Riwayat transaksi, pembayaran, dan akses cepat ke kasir.",
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            FilledTonalButton(onClick = onCreateSale, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.AddShoppingCart, contentDescription = null)
                Text("  Buat Penjualan")
            }
            FilledTonalButton(onClick = onOpenFastPos, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Sell, contentDescription = null)
                Text("  Fast POS")
            }
        }

        SalesSummaryStrip(sales = sales)

        if (sales.isEmpty()) {
            NativeEmptyBlock(
                title = "Belum ada penjualan",
                subtitle = "Mulai dari transaksi pertama atau gunakan Fast POS untuk penjualan cepat.",
                primaryLabel = "Buat Penjualan",
                onPrimary = onCreateSale,
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 32.dp),
            ) {
                items(sales, key = { it.id }) { sale ->
                    SaleCard(sale = sale, onClick = { onOpenSale(sale) })
                }
            }
        }
    }
}

@Composable
private fun SalesSummaryStrip(sales: List<Sale>) {
    val todaySales = sales.take(10)
    val omzet = todaySales.sumOf { it.totalSales }
    val profit = todaySales.sumOf { it.totalProfit }
    val split = todaySales.count { it.isSplitPayment }

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        SummaryMiniCard("Omzet", UiFormat.money(omzet), Icons.Rounded.Payments, Modifier.weight(1f))
        SummaryMiniCard("Laba", UiFormat.money(profit), Icons.Rounded.ReceiptLong, Modifier.weight(1f))
        SummaryMiniCard("Split", split.toString(), Icons.Rounded.CreditCard, Modifier.weight(1f))
    }
}

@Composable
private fun SaleCard(sale: Sale, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Transaksi #${sale.id.takeLast(6)}", style = MaterialTheme.typography.titleMedium)
                    Text(UiFormat.date(sale.dateEpochDay), style = MaterialTheme.typography.bodySmall)
                }
                AssistChip(
                    onClick = {},
                    label = { Text(if (sale.isSplitPayment) "Split" else sale.paymentMethod) },
                    leadingIcon = { Icon(Icons.Rounded.Payments, contentDescription = null) },
                )
            }
            Text("${sale.items.size} item • ${sale.customerName.ifBlank { "Pelanggan Umum" }}")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total")
                Text(UiFormat.money(sale.totalSales), style = MaterialTheme.typography.titleMedium)
            }
            if (sale.hasDiscount) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Diskon")
                    Text(UiFormat.money(sale.discountAmount))
                }
            }
            Text("Bayar: ${sale.paymentSummary}", style = MaterialTheme.typography.bodySmall)
        }
    }
}
