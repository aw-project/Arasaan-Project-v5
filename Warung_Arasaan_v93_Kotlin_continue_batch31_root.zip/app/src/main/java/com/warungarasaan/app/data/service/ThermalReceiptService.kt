package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Sale

object ThermalReceiptService {
    fun toEscPosText(sale: Sale, productNames: Map<String, String>): String {
        val line = "-".repeat(32)
        val itemLines = sale.items.joinToString("\n") { item ->
            val name = productNames[item.productId] ?: item.productId
            val qty = "%.2f".format(item.qty)
            val price = "%.0f".format(item.sellPrice)
            val total = "%.0f".format(item.total)
            "$name\n$qty x $price = $total"
        }
        return buildString {
            appendLine("WARUNG ARASAAN")
            appendLine(line)
            appendLine("Sale ID : ${sale.id}")
            appendLine("Customer: ${sale.customerName.ifBlank { "Umum" }}")
            appendLine("Bayar   : ${sale.paymentSummary}")
            appendLine(line)
            appendLine(itemLines)
            appendLine(line)
            appendLine("Subtotal: %.0f".format(sale.grossSales))
            appendLine("Diskon  : %.0f".format(sale.discountAmount))
            appendLine("Total   : %.0f".format(sale.totalSales))
            appendLine("Profit  : %.0f".format(sale.totalProfit))
            appendLine(line)
            appendLine("Terima kasih")
        }
    }
}
