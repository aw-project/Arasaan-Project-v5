package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.StockMovement
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun OperationsToolsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var movements by remember { mutableStateOf<List<StockMovement>>(emptyList()) }

    LaunchedEffect(Unit) {
        products = container.productRepository.all().sortedBy { it.name.lowercase() }
        sales = container.salesRepository.all()
        movements = container.movementRepository.all()
    }

    val q = query.trim().lowercase()
    val lowStock = products.filter { it.minStock > 0.0 && it.stockQty <= it.minStock }.take(12)
    val productMatches = products.filter {
        q.isNotBlank() && (
            it.name.lowercase().contains(q) ||
            it.sku.lowercase().contains(q) ||
            it.category.lowercase().contains(q)
        )
    }.take(8)
    val saleMatches = sales.filter {
        q.isNotBlank() && (
            it.id.lowercase().contains(q) ||
            it.customerName.lowercase().contains(q) ||
            it.paymentMethod.lowercase().contains(q)
        )
    }.take(8)
    val recentMovements = movements.take(12)
    val productMap = products.associateBy { it.id }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(
                title = "Tools Operasional",
                subtitle = "Padanan operations_tools_page.dart untuk pencarian cepat, stok kritis, dan recent stock movement.",
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Cari produk, SKU, kategori, pelanggan, atau ID transaksi") },
                    singleLine = true,
                )
            }
        }

        item {
            SectionCard("Stok kritis", subtitle = "Prioritas untuk restock dan opname.") {
                if (lowStock.isEmpty()) {
                    Text("Tidak ada stok kritis.")
                } else {
                    lowStock.forEach { product ->
                        Text("${product.name} • stok ${UiFormat.qty(product.stockQty)} ${product.unit}")
                    }
                }
            }
        }

        item {
            Text("Hasil pencarian produk")
        }
        if (productMatches.isEmpty()) {
            item { EmptyHint("Tidak ada produk cocok", "Masukkan nama produk, SKU, atau kategori.") }
        } else {
            items(productMatches, key = { it.id }) { product ->
                ListItem(
                    headlineContent = { Text(product.name) },
                    supportingContent = { Text("${product.category} • SKU ${product.sku.ifBlank { "-"} }") },
                    trailingContent = { Text(UiFormat.qty(product.stockQty)) },
                )
            }
        }

        item {
            Text("Hasil pencarian penjualan")
        }
        if (saleMatches.isEmpty()) {
            item { EmptyHint("Tidak ada penjualan cocok", "Masukkan pelanggan, metode bayar, atau ID transaksi.") }
        } else {
            items(saleMatches, key = { it.id }) { sale ->
                ListItem(
                    headlineContent = { Text(sale.id) },
                    supportingContent = {
                        Text("${sale.customerName.ifBlank { "Umum" }} • ${sale.paymentMethod} • ${UiFormat.date(sale.dateEpochDay)}")
                    },
                    trailingContent = { Text(UiFormat.money(sale.totalSales)) },
                )
            }
        }

        item {
            Text("Pergerakan stok terbaru")
        }
        if (recentMovements.isEmpty()) {
            item { EmptyHint("Belum ada movement", "Riwayat stok akan muncul setelah ada transaksi.") }
        } else {
            items(recentMovements, key = { it.id }) { movement ->
                val product = productMap[movement.productId]
                ListItem(
                    headlineContent = { Text(product?.name ?: movement.productId) },
                    supportingContent = { Text("${movement.type} • ${movement.note} • ${UiFormat.date(movement.dateEpochDay)}") },
                    trailingContent = { Text(UiFormat.qty(movement.qtyDelta)) },
                )
            }
        }
    }
}
