package com.warungarasaan.app.ui.redesign

data class AnalyticsKpiUi(
    val title: String,
    val value: String,
    val note: String = ""
)

data class AnalyticsUiState(
    val periodLabel: String = "30 hari",
    val kpis: List<AnalyticsKpiUi> = emptyList(),
    val topProducts: List<String> = emptyList(),
    val topCustomers: List<String> = emptyList(),
    val supplierSpend: List<String> = emptyList(),
    val forecastSummary: String = ""
)
