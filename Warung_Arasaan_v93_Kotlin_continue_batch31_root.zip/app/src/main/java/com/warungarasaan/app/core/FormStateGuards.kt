package com.warungarasaan.app.core

data class FieldIssue(
    val field: String,
    val message: String
)

data class GuardResult(
    val isValid: Boolean,
    val issues: List<FieldIssue> = emptyList()
)

object FormStateGuards {
    fun requiredText(field: String, value: String): GuardResult {
        return if (value.isBlank()) {
            GuardResult(false, listOf(FieldIssue(field, "$field wajib diisi")))
        } else {
            GuardResult(true)
        }
    }

    fun positiveNumber(field: String, value: Double): GuardResult {
        return if (value <= 0.0) {
            GuardResult(false, listOf(FieldIssue(field, "$field harus lebih dari 0")))
        } else {
            GuardResult(true)
        }
    }

    fun merge(vararg results: GuardResult): GuardResult {
        val issues = results.flatMap { it.issues }
        return GuardResult(issues.isEmpty(), issues)
    }
}
