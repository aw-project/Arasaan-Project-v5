package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.domain.model.RejectedItem
import com.warungarasaan.app.domain.model.Sale

data class ReportSummary(
    val omzet: Double,
    val totalHpp: Double,
    val labaKotor: Double,
    val totalBiaya: Double,
    val rugiRejek: Double,
    val labaBersih: Double,
)

object ReportingService {
    fun summarize(
        sales: Iterable<Sale>,
        expenses: Iterable<Expense>,
        rejectedItems: Iterable<RejectedItem> = emptyList(),
    ): ReportSummary {
        val omzet = sales.sumOf { it.totalSales }
        val totalHpp = sales.sumOf { it.totalHpp }
        val totalBiaya = expenses.sumOf { it.amount }
        val rugiRejek = rejectedItems.sumOf { it.estimatedLoss }
        val labaKotor = omzet - totalHpp
        val labaBersih = omzet - totalHpp - totalBiaya - rugiRejek
        return ReportSummary(
            omzet = omzet,
            totalHpp = totalHpp,
            labaKotor = labaKotor,
            totalBiaya = totalBiaya,
            rugiRejek = rugiRejek,
            labaBersih = labaBersih,
        )
    }
}
