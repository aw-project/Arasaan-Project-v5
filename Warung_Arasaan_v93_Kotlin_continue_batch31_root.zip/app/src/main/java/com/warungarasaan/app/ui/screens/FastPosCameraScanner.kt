package com.warungarasaan.app.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Composable
fun FastPosCameraScannerDialog(
    onDismiss: () -> Unit,
    keepOpenOnSuccess: Boolean,
    onBarcodeDetected: (String) -> Boolean,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Scan barcode kamera") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    update = { view ->
                        bindCameraScanner(
                            context = context,
                            lifecycleOwner = lifecycleOwner,
                            previewView = view,
                            executor = cameraExecutor,
                            keepOpenOnSuccess = keepOpenOnSuccess,
                            onBarcodeDetected = onBarcodeDetected,
                        )
                    },
                )
                Text(
                    if (keepOpenOnSuccess) {
                        "Mode scan beruntun aktif. Barcode yang cocok akan langsung ditambahkan tanpa menutup kamera."
                    } else {
                        "Arahkan kamera ke barcode produk. Saat terbaca, produk akan dicari lalu ditambahkan ke keranjang."
                    },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup")
            }
        },
        dismissButton = {
            FilterChip(
                selected = false,
                onClick = onDismiss,
                label = { Text("Batal") },
            )
        },
    )
}

@SuppressLint("UnsafeOptInUsageError")
private fun bindCameraScanner(
    context: Context,
    lifecycleOwner: androidx.lifecycle.LifecycleOwner,
    previewView: PreviewView,
    executor: ExecutorService,
    keepOpenOnSuccess: Boolean,
    onBarcodeDetected: (String) -> Boolean,
) {
    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
    cameraProviderFuture.addListener({
        val cameraProvider = cameraProviderFuture.get()
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
        val scanner = BarcodeScanning.getClient()
        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()

        analysis.setAnalyzer(executor, object : ImageAnalysis.Analyzer {
            private var handled = false
            private var lastCode = ""
            private var lastDetectedAt = 0L

            @OptIn(ExperimentalGetImage::class)
            override fun analyze(imageProxy: ImageProxy) {
                val mediaImage = imageProxy.image
                if (mediaImage == null || handled) {
                    imageProxy.close()
                    return
                }
                val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                scanner.process(image)
                    .addOnSuccessListener { barcodes ->
                        val code = barcodes.firstNotNullOfOrNull { it.rawValue?.trim().takeUnless { s -> s.isNullOrBlank() } }
                        val now = System.currentTimeMillis()
                        if (!code.isNullOrBlank() && !handled) {
                            val isDuplicateBurst = code == lastCode && (now - lastDetectedAt) < 1200L
                            if (!isDuplicateBurst) {
                                lastCode = code
                                lastDetectedAt = now
                                val shouldClose = onBarcodeDetected(code)
                                if (shouldClose || !keepOpenOnSuccess) {
                                    handled = true
                                    cameraProvider.unbindAll()
                                }
                            }
                        }
                    }
                    .addOnFailureListener {
                        handled = false
                    }
                    .addOnCompleteListener {
                        imageProxy.close()
                    }
            }
        })

        cameraProvider.unbindAll()
        cameraProvider.bindToLifecycle(
            lifecycleOwner,
            CameraSelector.DEFAULT_BACK_CAMERA,
            preview,
            analysis,
        )
    }, ContextCompat.getMainExecutor(context))
}
