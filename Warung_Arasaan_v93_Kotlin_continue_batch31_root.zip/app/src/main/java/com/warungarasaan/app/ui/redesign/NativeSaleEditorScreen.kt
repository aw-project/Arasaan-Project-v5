package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun NativeSaleEditorScreen(
    state: TransactionEditorUi,
    paymentMethods: List<String>,
    selectedPaymentMethod: String,
    onPaymentMethodChange: (String) -> Unit,
    onPartnerChange: (String) -> Unit,
    onDateChange: (String) -> Unit,
    onNotesChange: (String) -> Unit,
    onAddLine: () -> Unit,
    onEditLine: (Int) -> Unit,
    onRemoveLine: (Int) -> Unit,
    onSave: () -> Unit
) {
    NativeTransactionEditor(
        state = state.copy(title = "Penjualan"),
        onPartnerChange = onPartnerChange,
        onDateChange = onDateChange,
        onNotesChange = onNotesChange,
        onAddLine = onAddLine,
        onEditLine = onEditLine,
        onRemoveLine = onRemoveLine,
        onSave = onSave
    )
}
