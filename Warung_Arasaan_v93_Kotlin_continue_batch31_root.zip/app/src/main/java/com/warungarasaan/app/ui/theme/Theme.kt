package com.warungarasaan.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Brand Palette: "Deep Jungle" ─────────────────────────────────────────────
object WarungColors {
    // Primary greens
    val Primary        = Color(0xFF0B5E38)
    val PrimaryLight   = Color(0xFF1A7A50)
    val PrimaryDark    = Color(0xFF073D25)
    val PrimaryContainer = Color(0xFFB7EFCE)
    val OnPrimaryContainer = Color(0xFF002112)

    // Accent gold
    val Gold           = Color(0xFFD4870A)
    val GoldLight      = Color(0xFFF5B942)

    // Surfaces (light)
    val BgLight        = Color(0xFFF2F7EF)
    val SurfaceLight   = Color(0xFFFFFFFF)
    val SurfaceVariantLight = Color(0xFFE4EEE0)
    val OutlineLight   = Color(0xFFA8BEA3)

    // Surfaces (dark)
    val BgDark         = Color(0xFF0D1A10)
    val SurfaceDark    = Color(0xFF121F15)
    val SurfaceVariantDark = Color(0xFF1E2D21)

    // Status
    val Positive       = Color(0xFF1A7A50)
    val Negative       = Color(0xFFBF2D0D)
    val Warning        = Color(0xFFB26A00)

    // Nav dark pill
    val NavBg          = Color(0xFF0D1E13)
    val NavActive      = Color(0xFFF5B942)   // gold for selected
}

private val LightScheme = lightColorScheme(
    primary              = WarungColors.Primary,
    onPrimary            = Color.White,
    primaryContainer     = WarungColors.PrimaryContainer,
    onPrimaryContainer   = WarungColors.OnPrimaryContainer,
    secondary            = WarungColors.Gold,
    onSecondary          = Color.White,
    secondaryContainer   = Color(0xFFFFE0A6),
    onSecondaryContainer = Color(0xFF3D2400),
    background           = WarungColors.BgLight,
    onBackground         = Color(0xFF111D0E),
    surface              = WarungColors.SurfaceLight,
    onSurface            = Color(0xFF111D0E),
    surfaceVariant       = WarungColors.SurfaceVariantLight,
    onSurfaceVariant     = Color(0xFF3D4E39),
    outline              = WarungColors.OutlineLight,
    outlineVariant       = Color(0xFFD0E0CB),
    error                = WarungColors.Negative,
    onError              = Color.White,
    errorContainer       = Color(0xFFFFDAD6),
    onErrorContainer     = Color(0xFF410002),
    inverseSurface       = Color(0xFF2D3F2A),
    inverseOnSurface     = Color(0xFFEEF4EB),
    inversePrimary       = Color(0xFF6ECF98),
    scrim                = Color(0xFF000000),
)

private val DarkScheme = darkColorScheme(
    primary              = Color(0xFF6ECF98),
    onPrimary            = Color(0xFF003822),
    primaryContainer     = Color(0xFF004D30),
    onPrimaryContainer   = WarungColors.PrimaryContainer,
    secondary            = WarungColors.GoldLight,
    onSecondary          = Color(0xFF3D2400),
    secondaryContainer   = Color(0xFF5A3700),
    onSecondaryContainer = Color(0xFFFFDDAA),
    background           = WarungColors.BgDark,
    onBackground         = Color(0xFFDCEBD6),
    surface              = WarungColors.SurfaceDark,
    onSurface            = Color(0xFFDCEBD6),
    surfaceVariant       = WarungColors.SurfaceVariantDark,
    onSurfaceVariant     = Color(0xFFB2C9AA),
    outline              = Color(0xFF5E7A58),
    outlineVariant       = Color(0xFF2E4A2A),
    error                = Color(0xFFFFB4AB),
    onError              = Color(0xFF690005),
    errorContainer       = Color(0xFF93000A),
    onErrorContainer     = Color(0xFFFFDAD6),
    inverseSurface       = Color(0xFFDCEBD6),
    inverseOnSurface     = Color(0xFF2D3F2A),
    inversePrimary       = WarungColors.Primary,
    scrim                = Color(0xFF000000),
)

@Composable
fun WarungArasaanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkScheme else LightScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography  = WarungTypography,
        content     = content,
    )
}
