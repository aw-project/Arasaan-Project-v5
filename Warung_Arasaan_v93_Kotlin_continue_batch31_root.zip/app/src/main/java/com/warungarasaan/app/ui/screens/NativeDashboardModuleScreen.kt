package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.redesign.DashboardSummary
import com.warungarasaan.app.ui.redesign.NativeDashboardScreen
import kotlinx.coroutines.launch

@Composable
fun NativeDashboardModuleScreen(
    container: AppContainer,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var summary by remember {
        mutableStateOf(
            DashboardSummary(
                omzetHariIni = UiFormat.money(0.0),
                labaHariIni = UiFormat.money(0.0),
                kasAktif = UiFormat.money(0.0),
                hutangAktif = UiFormat.money(0.0),
                lowStockCount = 0,
                latestActivities = emptyList(),
            )
        )
    }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scope.launch {
            val products = container.productRepository.all()
            val sales = container.salesRepository.all()
            val cash = container.cashRepository.all()
            val debts = container.debtRepository.all()
            val today = java.time.LocalDate.now().toEpochDay().toInt()
            val todaySales = sales.filter { it.dateEpochDay == today }
            summary = DashboardSummary(
                omzetHariIni = UiFormat.money(todaySales.sumOf { it.totalSales }),
                labaHariIni = UiFormat.money(todaySales.sumOf { it.totalProfit }),
                kasAktif = UiFormat.money(
                    cash.sumOf { if (it.direction.equals("in", true)) it.amount else -it.amount }
                ),
                hutangAktif = UiFormat.money(debts.sumOf { it.remaining }),
                lowStockCount = products.count { it.stockQty <= it.minStock },
                latestActivities = container.activityLogRepository.recent(8)
                    .map { if (it.newJson.isNotBlank()) it.newJson else "${it.type} · ${UiFormat.date(it.dateEpochDay)}" }
            )
        }
    }

    NativeDashboardScreen(
        summary = summary,
        onAction = onNavigate,
        modifier = modifier,
    )
}
