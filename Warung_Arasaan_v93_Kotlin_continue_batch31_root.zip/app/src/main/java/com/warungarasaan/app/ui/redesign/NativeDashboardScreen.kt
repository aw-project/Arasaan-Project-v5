package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class DashboardSummary(
    val omzetHariIni: String,
    val labaHariIni: String,
    val kasAktif: String,
    val hutangAktif: String,
    val lowStockCount: Int,
    val latestActivities: List<String>
)

@Composable
fun NativeDashboardScreen(
    summary: DashboardSummary,
    onAction: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            KpiStrip(
                items = listOf(
                    KpiItem("Omzet", summary.omzetHariIni),
                    KpiItem("Laba", summary.labaHariIni),
                    KpiItem("Kas", summary.kasAktif),
                    KpiItem("Hutang", summary.hutangAktif)
                )
            )
        }
        item {
            SectionHeader(title = "Aksi Cepat")
        }
        item {
            QuickActionGrid(onAction = onAction, actions = defaultQuickActions(),)
        }
        item {
            SectionHeader(title = "Perlu Perhatian")
        }
        item {
            Card {
                ListItem(
                    headlineContent = { Text("Stok kritis") },
                    supportingContent = { Text("${summary.lowStockCount} produk perlu restock") },
                    leadingContent = {
                        Icon(
                            if (summary.lowStockCount > 0) Icons.Rounded.WarningAmber else Icons.Rounded.Inventory2,
                            contentDescription = null
                        )
                    }
                )
            }
        }
        item {
            SectionHeader(title = "Aktivitas Terbaru", actionLabel = "Lihat Semua") { onAction("activity") }
        }
        items(summary.latestActivities.take(6)) { activity ->
            Card(modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                ListItem(
                    headlineContent = { Text(activity) }
                )
            }
        }
    }
}
