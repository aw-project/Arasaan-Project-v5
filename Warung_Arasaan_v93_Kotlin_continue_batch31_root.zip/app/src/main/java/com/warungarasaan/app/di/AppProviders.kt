package com.warungarasaan.app.di

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import com.warungarasaan.app.AppContainer

val LocalAppContainer = staticCompositionLocalOf<AppContainer> {
    error("AppContainer belum tersedia di CompositionLocal")
}

@Composable
fun ProvideAppContainer(
    container: AppContainer,
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalAppContainer provides container) {
        content()
    }
}

object AppProviders {
    val container: AppContainer
        @Composable
        @ReadOnlyComposable
        get() = LocalAppContainer.current
}
