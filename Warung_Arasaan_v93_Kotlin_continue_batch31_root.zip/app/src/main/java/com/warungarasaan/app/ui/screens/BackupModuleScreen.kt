package com.warungarasaan.app.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.BackupService
import com.warungarasaan.app.data.service.FileDocumentService
import com.warungarasaan.app.data.service.ReportExportService
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import kotlinx.coroutines.launch

@Composable
fun BackupModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var exportJson by remember { mutableStateOf("") }
    var importJson by remember { mutableStateOf("") }
    var resultMessage by remember { mutableStateOf("") }
    var autoBackup by remember { mutableStateOf(false) }
    var backupDays by remember { mutableStateOf("7") }
    var lastBackupText by remember { mutableStateOf("Belum pernah") }

    suspend fun loadBackupJson(): String = BackupService.exportJson(
        products = container.productRepository.all(),
        purchases = container.purchaseRepository.all(),
        sales = container.salesRepository.all(),
        expenses = container.expenseRepository.all(),
        debts = container.debtRepository.all(),
        movements = container.movementRepository.all(),
        cash = container.cashRepository.all(),
        rejectedItems = container.rejectedRepository.all(),
        activityLogs = container.activityLogRepository.all(),
        settings = container.settingsRepository.get(),
    )

    suspend fun reloadMeta() {
        autoBackup = container.metaRepository.autoBackupEnabled()
        backupDays = container.metaRepository.autoBackupDays().toString()
        val lastMs = container.metaRepository.lastAutoBackupMillis()
        lastBackupText = if (lastMs == 0L) "Belum pernah" else java.time.Instant.ofEpochMilli(lastMs).toString()
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                val json = loadBackupJson()
                exportJson = json
                FileDocumentService.writeText(context.contentResolver, uri, json)
                container.metaRepository.setLastAutoBackupMillis(System.currentTimeMillis())
                reloadMeta()
                resultMessage = "Backup berhasil disimpan ke file."
            }.onFailure {
                resultMessage = "Backup gagal: ${it.message}"
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                val text = FileDocumentService.readText(context.contentResolver, uri)
                importJson = text
                BackupService.restoreJson(container.database, text)
                resultMessage = "Import backup selesai."
            }.onFailure {
                resultMessage = "Import gagal: ${it.message}"
            }
        }
    }

    val exportReportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                val products = container.productRepository.all()
                val csv = ReportExportService.stockCsv(products)
                FileDocumentService.writeText(context.contentResolver, uri, csv)
                Toast.makeText(context, "Laporan stok disimpan.", Toast.LENGTH_SHORT).show()
            }.onFailure {
                resultMessage = "Export laporan gagal: ${it.message}"
            }
        }
    }

    LaunchedEffect(Unit) {
        reloadMeta()
        exportJson = loadBackupJson()
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(title = "Status backup") {
                InlineLabelValue("Auto backup", if (autoBackup) "Aktif" else "Nonaktif")
                InlineLabelValue("Interval", "$backupDays hari")
                InlineLabelValue("Backup terakhir", lastBackupText)
            }
        }
        item {
            SectionCard(title = "Pengaturan backup") {
                androidx.compose.material3.ListItem(
                    headlineContent = { Text("Aktifkan auto backup") },
                    trailingContent = {
                        Switch(
                            checked = autoBackup,
                            onCheckedChange = { checked ->
                                scope.launch {
                                    container.metaRepository.setAutoBackupEnabled(checked)
                                    reloadMeta()
                                }
                            },
                        )
                    },
                )
                OutlinedTextField(
                    value = backupDays,
                    onValueChange = { backupDays = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Interval backup (hari)") },
                )
                TextButton(onClick = {
                    scope.launch {
                        container.metaRepository.setAutoBackupDays(backupDays.toIntOrNull() ?: 7)
                        reloadMeta()
                    }
                }) { Text("Simpan interval") }
            }
        }
        item {
            SectionCard(title = "Backup file", subtitle = "Gunakan Storage Access Framework Android") {
                TextButton(onClick = { exportBackupLauncher.launch("warung_arasaan_backup.json") }) {
                    Text("Export backup ke file JSON")
                }
                TextButton(onClick = { importBackupLauncher.launch(arrayOf("application/json", "text/plain")) }) {
                    Text("Import backup dari file")
                }
                TextButton(onClick = { exportReportLauncher.launch("laporan_stok.csv") }) {
                    Text("Export laporan stok CSV")
                }
            }
        }
        item {
            SectionCard(title = "Payload backup", subtitle = "Masih tersedia untuk copy-paste manual") {
                if (exportJson.isBlank()) {
                    EmptyHint("Belum ada payload", "Tekan export atau tunggu data ter-load.")
                } else {
                    OutlinedTextField(
                        value = exportJson,
                        onValueChange = { exportJson = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 180.dp),
                        label = { Text("JSON backup") },
                    )
                }
            }
        }
        item {
            SectionCard(title = "Restore manual") {
                OutlinedTextField(
                    value = importJson,
                    onValueChange = { importJson = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp),
                    label = { Text("Tempel JSON di sini") },
                )
                TextButton(onClick = {
                    scope.launch {
                        runCatching {
                            BackupService.restoreJson(container.database, importJson)
                            resultMessage = "Restore manual selesai."
                        }.onFailure {
                            resultMessage = "Restore manual gagal: ${it.message}"
                        }
                    }
                }) {
                    Text("Restore JSON manual")
                }
            }
        }
        item {
            if (resultMessage.isNotBlank()) {
                Text(resultMessage)
            }
        }
    }
}
