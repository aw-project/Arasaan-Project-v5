package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.redesign.NativeRejectedScreen
import com.warungarasaan.app.ui.redesign.RejectedItemUi

@Composable
fun NativeRejectedModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var activeReason by remember { mutableStateOf("Semua") }
    var activeHandling by remember { mutableStateOf("Semua") }
    var rows by remember { mutableStateOf(emptyList<RejectedItemUi>()) }
    var reasons by remember { mutableStateOf(listOf("Semua")) }
    var handlings by remember { mutableStateOf(listOf("Semua")) }

    LaunchedEffect(Unit) {
        val products = container.productRepository.all().associateBy { it.id }
        val items = container.rejectedRepository.all().sortedByDescending { it.dateEpochDay }
        rows = items.map {
            RejectedItemUi(
                productName = products[it.productId]?.name ?: it.productId,
                qtyLabel = "${it.qty} unit • ${UiFormat.date(it.dateEpochDay)}",
                reason = it.reason,
                handling = it.handling,
                lossLabel = UiFormat.money(it.estimatedLoss),
            )
        }
        reasons = listOf("Semua") + items.map { it.reason }.distinct().sorted()
        handlings = listOf("Semua") + items.map { it.handling }.distinct().sorted()
    }

    val filtered = rows.filter {
        (activeReason == "Semua" || it.reason == activeReason) &&
        (activeHandling == "Semua" || it.handling == activeHandling)
    }

    NativeRejectedScreen(
        activeReason = activeReason,
        activeHandling = activeHandling,
        reasons = reasons,
        handlings = handlings,
        items = filtered,
        onReasonChange = { activeReason = it },
        onHandlingChange = { activeHandling = it },
    )
}
