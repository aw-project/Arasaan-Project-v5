package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun NativeFastPosCheckoutSheet(
    totalLabel: String,
    paidLabel: String,
    changeLabel: String,
    paymentMethods: List<String>,
    selectedMethod: String,
    onPaidChange: (String) -> Unit,
    onMethodChange: (String) -> Unit
) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Checkout Cepat")
        Text("Total: $totalLabel")
        OutlinedTextField(
            value = paidLabel,
            onValueChange = onPaidChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Uang diterima") }
        )
        Text("Kembalian: $changeLabel")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            paymentMethods.forEach { method ->
                FilterChip(
                    selected = method == selectedMethod,
                    onClick = { onMethodChange(method) },
                    label = { Text(method) }
                )
            }
        }
    }
}
