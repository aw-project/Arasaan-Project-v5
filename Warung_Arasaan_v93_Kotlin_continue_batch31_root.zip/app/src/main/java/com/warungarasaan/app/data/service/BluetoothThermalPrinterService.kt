package com.warungarasaan.app.data.service

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.io.IOException
import java.nio.charset.Charset
import java.util.UUID

object BluetoothThermalPrinterService {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    data class PrinterTarget(val name: String, val address: String)
    data class PrintResult(val ok: Boolean, val message: String)

    fun listBondedDevices(context: Context): List<PrinterTarget> {
        val adapter = context.bluetoothAdapterOrNull() ?: return emptyList()
        if (!hasConnectPermission(context)) return emptyList()
        return adapter.bondedDevices
            ?.map { PrinterTarget(it.name ?: "Bluetooth Printer", it.address) }
            ?.sortedBy { it.name.lowercase() }
            .orEmpty()
    }

    fun buildEscPosPayload(text: String): ByteArray {
        val header = byteArrayOf(0x1B, 0x40)
        val body = sanitize(text)
            .trim()
            .plus("\n\n\n")
            .toByteArray(Charset.forName("CP437"))
        val cut = byteArrayOf(0x1D, 0x56, 0x41, 0x10)
        return header + body + cut
    }

    fun sanitize(text: String): String = buildString {
        text.replace("\r\n", "\n")
            .replace("\r", "\n")
            .forEach { c ->
                append(
                    when {
                        c.code in 32..126 -> c
                        c == '\n' || c == '\t' -> c
                        else -> ' '
                    }
                )
            }
    }

    fun printText(
        context: Context,
        address: String,
        text: String,
    ): PrintResult = printBytes(context, address, buildEscPosPayload(text))

    fun printBytes(
        context: Context,
        address: String,
        payload: ByteArray,
    ): PrintResult {
        if (!hasConnectPermission(context)) {
            return PrintResult(false, "Izin BLUETOOTH_CONNECT belum tersedia.")
        }
        val adapter = context.bluetoothAdapterOrNull()
            ?: return PrintResult(false, "Bluetooth adapter tidak tersedia.")
        val device = adapter.bondedDevices?.firstOrNull { it.address == address }
            ?: return PrintResult(false, "Printer Bluetooth tidak ditemukan di daftar paired device.")

        return runCatching {
            device.print(payload)
            PrintResult(true, "Struk berhasil dikirim ke ${device.name ?: address}.")
        }.getOrElse { error ->
            PrintResult(false, error.message ?: "Gagal mengirim data ke printer Bluetooth.")
        }
    }

    private fun Context.bluetoothAdapterOrNull(): BluetoothAdapter? {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        return manager?.adapter
    }

    private fun hasConnectPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.BLUETOOTH_CONNECT,
        ) == PackageManager.PERMISSION_GRANTED
    }

    @Throws(IOException::class)
    private fun BluetoothDevice.print(payload: ByteArray) {
        createRfcommSocketToServiceRecord(sppUuid).use { socket ->
            socket.connect()
            socket.outputStream.use { output ->
                output.write(payload)
                output.flush()
            }
        }
    }
}
