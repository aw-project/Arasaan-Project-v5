
package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.StockMovement
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.LabeledNumberField
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

private data class ProductFormState(
    val id: String = "",
    val name: String = "",
    val unit: String = "pcs",
    val price: String = "0",
    val avgHpp: String = "0",
    val stockQty: String = "0",
    val minStock: String = "0",
    val targetStock: String = "0",
    val sku: String = "",
    val category: String = "Lainnya",
)

@Composable
fun ProductsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var editing by remember { mutableStateOf<Product?>(null) }
    var selected by remember { mutableStateOf<Product?>(null) }
    var adjusting by remember { mutableStateOf<Product?>(null) }
    var opnameTarget by remember { mutableStateOf<Product?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var easyMode by remember { mutableStateOf(true) }

    suspend fun reload() { products = container.productRepository.all() }

    LaunchedEffect(Unit) { reload() }

    val filtered = remember(products, query) {
        val q = query.trim().lowercase()
        products.filter {
            q.isBlank() ||
                it.name.lowercase().contains(q) ||
                it.sku.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
        }
    }

    if (showDialog) {
        ProductEditorDialog(
            initial = editing,
            onDismiss = { showDialog = false; editing = null },
            onSave = { form ->
                scope.launch {
                    val product = Product(
                        id = form.id.ifBlank { AppUtils.newId("prd") },
                        name = form.name.trim(),
                        unit = form.unit.trim().ifEmpty { "pcs" },
                        defaultMarginPercent = 0.0,
                        activeSellPrice = form.price.toDoubleOrNull() ?: 0.0,
                        stockQty = form.stockQty.toDoubleOrNull() ?: 0.0,
                        avgHpp = form.avgHpp.toDoubleOrNull() ?: 0.0,
                        minStock = form.minStock.toDoubleOrNull() ?: 0.0,
                        targetStock = form.targetStock.toDoubleOrNull() ?: 0.0,
                        sku = form.sku.trim(),
                        category = form.category.trim().ifEmpty { "Lainnya" },
                        imagePath = null,
                    )
                    container.productRepository.upsert(product)
                    container.activityLogRepository.log("product", "Produk disimpan: ${product.name}")
                    message = "Produk ${product.name} berhasil disimpan."
                    reload()
                    showDialog = false
                    editing = null
                }
            },
        )
    }

    adjusting?.let { product ->
        StockAdjustmentDialog(
            product = product,
            onDismiss = { adjusting = null },
            onApply = { delta, note ->
                scope.launch {
                    val latest = container.productRepository.getById(product.id) ?: return@launch
                    val newQty = (latest.stockQty + delta).coerceAtLeast(0.0)
                    container.productRepository.upsert(latest.copy(stockQty = newQty))
                    container.movementRepository.add(
                        StockMovement(
                            id = AppUtils.newId("mv"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            productId = latest.id,
                            type = "adjustment",
                            qtyDelta = delta,
                            note = note.ifBlank { "Penyesuaian stok manual" },
                        )
                    )
                    container.activityLogRepository.log("stock_adjustment", "Adjust ${latest.name}: ${UiFormat.qty(delta)}")
                    message = "Stok ${latest.name} disesuaikan menjadi ${UiFormat.qty(newQty)} ${latest.unit}."
                    reload()
                    adjusting = null
                }
            },
        )
    }

    opnameTarget?.let { product ->
        StockOpnameDialog(
            product = product,
            onDismiss = { opnameTarget = null },
            onApply = { physicalQty, note ->
                scope.launch {
                    val latest = container.productRepository.getById(product.id) ?: return@launch
                    val delta = physicalQty - latest.stockQty
                    container.productRepository.upsert(latest.copy(stockQty = physicalQty))
                    container.movementRepository.add(
                        StockMovement(
                            id = AppUtils.newId("mv"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            productId = latest.id,
                            type = "opname",
                            qtyDelta = delta,
                            note = note.ifBlank { "Stock opname" },
                        )
                    )
                    container.activityLogRepository.log("stock_opname", "Opname ${latest.name}: ${UiFormat.qty(physicalQty)}")
                    message = "Stock opname ${latest.name} tersimpan."
                    reload()
                    opnameTarget = null
                }
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showDialog = true }) {
                Text("+")
            }
        },
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(padding),
        ) {
            item {
                SectionCard(
                    title = if (easyMode) "Daftar Barang" else "Produk Lengkap",
                    subtitle = if (easyMode) "Cari barang, cek stok, lalu ubah bila perlu." else "Semua detail produk ditampilkan."
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { easyMode = true }) { Text("Mode Mudah") }
                        TextButton(onClick = { easyMode = false }) { Text("Mode Lengkap") }
                    }
                }
            }
            item {
                if (easyMode) {
                    SectionCard("Panduan singkat") {
                        Text("1. Cari barang yang ingin dicek.")
                        Text("2. Tekan Cek stok bila ingin cocokkan barang di rak.")
                        Text("3. Tekan Ubah bila ingin ganti harga atau nama.")
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(if (easyMode) "Cari barang" else "Cari produk / SKU / kategori") },
                    singleLine = true,
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip("Total ${products.size}")
                    InfoChip("Stok menipis ${products.count { it.minStock > 0 && it.stockQty <= it.minStock }}")
                }
            }
            if (message.isNotBlank()) {
                item { SectionCard("Status") { Text(message) } }
            }
            if (filtered.isEmpty()) {
                item {
                    EmptyHint(
                        "Belum ada produk",
                        "Tambahkan master produk terlebih dulu agar modul pembelian dan penjualan bisa dipakai.",
                        "Tambah Produk",
                    ) {
                        editing = null
                        showDialog = true
                    }
                }
            } else {
                items(filtered, key = { it.id }) { product ->
                    ListItem(
                        headlineContent = { Text(product.name) },
                        supportingContent = {
                            Text("${product.category} • ${UiFormat.qty(product.stockQty)} ${product.unit} • HPP ${UiFormat.money(product.avgHpp)}")
                        },
                        overlineContent = { Text(product.sku.ifBlank { product.id }) },
                        trailingContent = { Text(UiFormat.money(product.activeSellPrice)) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TextButton(onClick = { selected = product }) { Text(if (easyMode) "Lihat" else "Detail") }
                        TextButton(onClick = { adjusting = product }) { Text(if (easyMode) "Ubah stok" else "Adjust") }
                        TextButton(onClick = { opnameTarget = product }) { Text("Cek stok") }
                        TextButton(onClick = { editing = product; showDialog = true }) { Text("Ubah") }
                        TextButton(onClick = {
                            scope.launch {
                                container.productRepository.remove(product.id)
                                container.activityLogRepository.log("product_delete", "Produk dihapus: ${product.name}")
                                message = "Produk ${product.name} dihapus."
                                reload()
                            }
                        }) { Text("Hapus") }
                    }
                }
            }
        }
    }

    selected?.let { product ->
        ProductDetailDialog(
            product = product,
            container = container,
            onDismiss = { selected = null },
        )
    }
}

@Composable
private fun ProductEditorDialog(
    initial: Product?,
    onDismiss: () -> Unit,
    onSave: (ProductFormState) -> Unit,
) {
    var form by remember(initial) {
        mutableStateOf(
            ProductFormState(
                id = initial?.id.orEmpty(),
                name = initial?.name.orEmpty(),
                unit = initial?.unit ?: "pcs",
                price = ((initial?.activeSellPrice) ?: 0.0).toString(),
                avgHpp = ((initial?.avgHpp) ?: 0.0).toString(),
                stockQty = ((initial?.stockQty) ?: 0.0).toString(),
                minStock = ((initial?.minStock) ?: 0.0).toString(),
                targetStock = ((initial?.targetStock) ?: 0.0).toString(),
                sku = initial?.sku.orEmpty(),
                category = initial?.category ?: "Lainnya",
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(form) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text(if (initial == null) "Tambah Produk" else "Edit Produk") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(form.name, { form = form.copy(name = it) }, label = { Text("Nama") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(form.category, { form = form.copy(category = it) }, label = { Text("Kategori") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(form.sku, { form = form.copy(sku = it) }, label = { Text("SKU") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(form.unit, { form = form.copy(unit = it) }, label = { Text("Satuan") }, modifier = Modifier.fillMaxWidth()) }
                item { LabeledNumberField("Harga jual", form.price, { form = form.copy(price = it) }) }
                item { LabeledNumberField("HPP rata-rata", form.avgHpp, { form = form.copy(avgHpp = it) }) }
                item { LabeledNumberField("Stok", form.stockQty, { form = form.copy(stockQty = it) }) }
                item { LabeledNumberField("Min stok", form.minStock, { form = form.copy(minStock = it) }) }
                item { LabeledNumberField("Target stok", form.targetStock, { form = form.copy(targetStock = it) }) }
            }
        },
    )
}

@Composable
private fun ProductDetailDialog(
    product: Product,
    container: AppContainer,
    onDismiss: () -> Unit,
) {
    var movements by remember { mutableStateOf<List<StockMovement>>(emptyList()) }
    var purchasesTotal by remember { mutableStateOf(0.0) }
    var salesTotal by remember { mutableStateOf(0.0) }

    LaunchedEffect(product.id) {
        movements = container.movementRepository.byProduct(product.id).take(30)
        purchasesTotal = container.purchaseRepository.all()
            .flatMap { it.items }
            .filter { it.productId == product.id }
            .sumOf { it.qty }
        salesTotal = container.salesRepository.all()
            .flatMap { it.items }
            .filter { it.productId == product.id }
            .sumOf { it.qty }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Detail Produk") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text(product.name) }
                item { Text("SKU: ${product.sku.ifBlank { "-" }}") }
                item { Text("Kategori: ${product.category}") }
                item { Text("Stok: ${UiFormat.qty(product.stockQty)} ${product.unit}") }
                item { Text("Harga jual: ${UiFormat.money(product.activeSellPrice)}") }
                item { Text("Avg HPP: ${UiFormat.money(product.avgHpp)}") }
                item { Text("Min stok: ${UiFormat.qty(product.minStock)} • Target: ${UiFormat.qty(product.targetStock)}") }
                item { Text("Akumulasi beli: ${UiFormat.qty(purchasesTotal)} • Jual: ${UiFormat.qty(salesTotal)}") }
                item { Text("Riwayat stok terbaru") }
                if (movements.isEmpty()) {
                    item { Text("Belum ada movement") }
                } else {
                    itemsIndexed(movements) { _, row ->
                        ListItem(
                            headlineContent = { Text("${row.type} • ${UiFormat.qty(row.qtyDelta)}") },
                            supportingContent = { Text("${UiFormat.date(row.dateEpochDay)} • ${row.note}") },
                        )
                    }
                }
            }
        },
    )
}

@Composable
private fun StockAdjustmentDialog(
    product: Product,
    onDismiss: () -> Unit,
    onApply: (delta: Double, note: String) -> Unit,
) {
    var qtyDelta by remember { mutableStateOf("0") }
    var note by remember { mutableStateOf("Penyesuaian stok manual") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onApply(qtyDelta.toDoubleOrNull() ?: 0.0, note) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Stock Adjustment") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("${product.name} • Stok sekarang ${UiFormat.qty(product.stockQty)} ${product.unit}") }
                item { LabeledNumberField("Qty adjustment (+/-)", qtyDelta, { qtyDelta = it }) }
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}

@Composable
private fun StockOpnameDialog(
    product: Product,
    onDismiss: () -> Unit,
    onApply: (physicalQty: Double, note: String) -> Unit,
) {
    var physicalQty by remember { mutableStateOf(UiFormat.qty(product.stockQty)) }
    var note by remember { mutableStateOf("Stock opname") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onApply(physicalQty.toDoubleOrNull() ?: 0.0, note) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Stock Opname") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("${product.name} • Sistem ${UiFormat.qty(product.stockQty)} ${product.unit}") }
                item { LabeledNumberField("Stok fisik", physicalQty, { physicalQty = it }) }
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}
