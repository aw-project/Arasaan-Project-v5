package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.Dates
import com.warungarasaan.app.core.Ids
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.StockMovement
import com.warungarasaan.app.ui.widgets.NumberField
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockOpnameScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var selected by remember { mutableStateOf<Product?>(null) }
    var countedStockText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    suspend fun reload() {
        products = container.productRepository.all()
        if (selected != null) {
            selected = products.firstOrNull { it.id == selected?.id }
        }
    }

    LaunchedEffect(Unit) { reload() }

    Scaffold(
        modifier = modifier,
        topBar = { TopAppBar(title = { Text("Stock Opname") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("Set stok hasil hitung fisik. Sistem akan menghitung selisih otomatis.")
            }
            item {
                Card {
                    LazyColumn {
                        items(products) { product ->
                            ListItem(
                                headlineContent = { Text(product.name) },
                                supportingContent = { Text("Stok sistem: ${product.stockQty} ${product.unit}") },
                                overlineContent = {
                                    if (selected?.id == product.id) {
                                        Text("Dipilih")
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Button(
                                onClick = {
                                    selected = product
                                    countedStockText = product.stockQty.toString()
                                },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text(if (selected?.id == product.id) "Terpilih" else "Pilih ${product.name}") }
                        }
                    }
                }
            }
            item {
                NumberField(
                    value = countedStockText,
                    onValueChange = { countedStockText = it },
                    label = "Stok hasil hitung",
                )
            }
            item {
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Catatan opname") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
            }
            item {
                Button(
                    onClick = {
                        scope.launch {
                            val product = selected
                            val counted = countedStockText.replace(',', '.').toDoubleOrNull()
                            if (product == null || counted == null || counted < 0.0) {
                                snackbarHostState.showSnackbar("Pilih produk dan isi stok hasil hitung yang valid.")
                                return@launch
                            }
                            val delta = counted - product.stockQty
                            val updated = product.copy(stockQty = counted)
                            container.productRepository.upsert(updated)
                            if (delta != 0.0) {
                                container.movementRepository.add(
                                    StockMovement(
                                        id = Ids.movement(),
                                        dateEpochDay = Dates.epochDay(Dates.today()),
                                        productId = product.id,
                                        type = "opname",
                                        qtyDelta = delta,
                                        note = note.ifBlank { "Stock opname" },
                                    )
                                )
                            }
                            container.activityLogRepository.log("stock_opname", "${product.name}: ${product.stockQty} -> $counted")
                            reload()
                            snackbarHostState.showSnackbar("Stock opname tersimpan.")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Simpan hasil opname") }
            }
        }
    }
}
