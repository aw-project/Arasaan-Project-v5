package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddBusiness
import androidx.compose.material.icons.rounded.LocalShipping
import androidx.compose.material.icons.rounded.Store
import androidx.compose.material.icons.rounded.Warehouse
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.ui.UiFormat

@Composable
fun NativePurchasesScreen(
    purchases: List<Purchase>,
    onCreatePurchase: () -> Unit = {},
    onOpenPurchase: (Purchase) -> Unit = {},
) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        SectionHeader(
            title = "Pembelian",
            subtitle = "Supplier, stok masuk, dan histori belanja yang lebih ringkas.",
        )

        FilledTonalButton(onClick = onCreatePurchase, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.AddBusiness, contentDescription = null)
            Text("  Catat Pembelian")
        }

        PurchaseSummaryStrip(purchases)

        if (purchases.isEmpty()) {
            NativeEmptyBlock(
                title = "Belum ada pembelian",
                subtitle = "Catat pembelian untuk memperbarui stok dan rata-rata HPP.",
                primaryLabel = "Tambah Pembelian",
                onPrimary = onCreatePurchase,
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 32.dp),
            ) {
                items(purchases, key = { it.id }) { purchase ->
                    PurchaseCard(purchase = purchase, onClick = { onOpenPurchase(purchase) })
                }
            }
        }
    }
}

@Composable
private fun PurchaseSummaryStrip(purchases: List<Purchase>) {
    val totalInvoices = purchases.size
    val totalItems = purchases.sumOf { it.items.size }
    val spend = purchases.sumOf { purchase -> purchase.items.sumOf { it.qty * it.buyPrice } }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        SummaryMiniCard("Invoice", totalInvoices.toString(), Icons.Rounded.Store, Modifier.weight(1f))
        SummaryMiniCard("Baris", totalItems.toString(), Icons.Rounded.Warehouse, Modifier.weight(1f))
        SummaryMiniCard("Belanja", UiFormat.money(spend), Icons.Rounded.LocalShipping, Modifier.weight(1f))
    }
}

@Composable
private fun PurchaseCard(purchase: Purchase, onClick: () -> Unit) {
    val total = purchase.items.sumOf { it.qty * it.buyPrice }
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Pembelian #${purchase.id.takeLast(6)}", style = MaterialTheme.typography.titleMedium)
                    Text(UiFormat.date(purchase.dateEpochDay), style = MaterialTheme.typography.bodySmall)
                }
                AssistChip(onClick = {}, label = { Text(purchase.paymentMethod) })
            }
            Text(purchase.supplier.ifBlank { "Supplier belum diisi" })
            Text("${purchase.items.size} item", style = MaterialTheme.typography.bodySmall)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total")
                Text(UiFormat.money(total), style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
