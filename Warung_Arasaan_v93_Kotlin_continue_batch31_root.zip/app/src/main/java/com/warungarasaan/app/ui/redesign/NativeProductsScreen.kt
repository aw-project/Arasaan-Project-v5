package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ProductRowUi(
    val id: String,
    val name: String,
    val unit: String,
    val priceLabel: String,
    val stockLabel: String
)

@Composable
fun NativeProductsScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    selectedFilter: String,
    onFilterChange: (String) -> Unit,
    rows: List<ProductRowUi>,
    onTapProduct: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SmartSearchBar(
                value = query,
                placeholder = "Cari nama produk",
                onValueChange = onQueryChange
            )
        }
        item {
            CompactFilterRow(
                selected = selectedFilter,
                options = listOf("Semua", "Stok kritis", "Margin rendah", "Terlaris"),
                onChange = onFilterChange
            )
        }
        items(rows) { row ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                onClick = { onTapProduct(row.id) }
            ) {
                ListItem(
                    headlineContent = { Text(row.name) },
                    supportingContent = { Text("${row.priceLabel} • ${row.stockLabel} • ${row.unit}") }
                )
            }
        }
    }
}
