package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.Debt
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun PartnersModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var tab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    var debts by remember { mutableStateOf<List<Debt>>(emptyList()) }
    var purchases by remember { mutableStateOf<Map<String, Double>>(emptyMap()) }
    var sales by remember { mutableStateOf<Map<String, Double>>(emptyMap()) }
    var showNewDebt by remember { mutableStateOf(false) }
    var debtPaymentTarget by remember { mutableStateOf<Debt?>(null) }

    suspend fun reload() {
        debts = container.debtRepository.all()
        purchases = container.purchaseRepository.all()
            .groupBy { it.supplier.trim().ifEmpty { "Tanpa Supplier" } }
            .mapValues { (_, rows) -> rows.sumOf { purchase -> purchase.items.sumOf { it.qty * it.buyPrice } } }
        sales = container.salesRepository.all()
            .groupBy { it.customerName.trim().ifEmpty { "Umum" } }
            .mapValues { (_, rows) -> rows.sumOf { it.totalSales } }
    }

    LaunchedEffect(Unit) { reload() }

    if (showNewDebt) {
        NewDebtDialog(
            onDismiss = { showNewDebt = false },
            onSave = { creditor, note, principal ->
                scope.launch {
                    container.debtRepository.add(
                        Debt(
                            id = AppUtils.newId("debt"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            creditor = creditor,
                            note = note,
                            principal = principal,
                            paid = 0.0,
                        )
                    )
                    container.activityLogRepository.log("debt", "Hutang baru: $creditor")
                    reload()
                    showNewDebt = false
                }
            },
        )
    }

    debtPaymentTarget?.let { debt ->
        PayDebtDialog(
            debt = debt,
            onDismiss = { debtPaymentTarget = null },
            onSave = { amount, method ->
                scope.launch {
                    container.debtRepository.addPayment(debt.id, amount, AppUtils.epochDayNow(), method)
                    container.activityLogRepository.log("debt_payment", "Bayar hutang ${debt.creditor}")
                    reload()
                    debtPaymentTarget = null
                }
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { if (tab == 0) showNewDebt = true }) { Text("+") }
        },
    ) { padding ->
        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Hutang") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Supplier") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Customer") })
            }
            when (tab) {
                0 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (debts.isEmpty()) item { EmptyHint("Belum ada hutang", "Tambah hutang manual untuk mencatat kewajiban supplier atau pihak lain.") }
                    items(debts, key = { it.id }) { debt ->
                        ListItem(
                            headlineContent = { Text(debt.creditor) },
                            supportingContent = { Text(debt.note) },
                            overlineContent = { Text(UiFormat.date(debt.dateEpochDay)) },
                            trailingContent = { Text(UiFormat.money(debt.remaining)) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        androidx.compose.foundation.layout.Row(modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)) {
                            TextButton(onClick = { debtPaymentTarget = debt }) { Text("Bayar") }
                            TextButton(onClick = {
                                scope.launch {
                                    container.debtRepository.remove(debt.id)
                                    reload()
                                }
                            }) { Text("Hapus") }
                        }
                    }
                }
                1 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (purchases.isEmpty()) item { EmptyHint("Belum ada supplier", "Nama supplier akan terkumpul dari data pembelian.") }
                    items(purchases.toList(), key = { it.first }) { (name, amount) ->
                        ListItem(
                            headlineContent = { Text(name) },
                            supportingContent = { Text("Total nilai pembelian") },
                            trailingContent = { Text(UiFormat.money(amount)) },
                        )
                    }
                }
                else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (sales.isEmpty()) item { EmptyHint("Belum ada customer", "Nama customer akan terkumpul dari data penjualan.") }
                    items(sales.toList(), key = { it.first }) { (name, amount) ->
                        ListItem(
                            headlineContent = { Text(name) },
                            supportingContent = { Text("Total omzet customer") },
                            trailingContent = { Text(UiFormat.money(amount)) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NewDebtDialog(onDismiss: () -> Unit, onSave: (String, String, Double) -> Unit) {
    var creditor by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var principal by remember { mutableStateOf("0") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(creditor, note, principal.toDoubleOrNull() ?: 0.0) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Tambah Hutang") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(creditor, { creditor = it }, label = { Text("Kreditur") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(principal, { principal = it }, label = { Text("Pokok hutang") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}

@Composable
private fun PayDebtDialog(debt: Debt, onDismiss: () -> Unit, onSave: (Double, String) -> Unit) {
    var amount by remember { mutableStateOf(debt.remaining.toString()) }
    var method by remember { mutableStateOf("Cash") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(amount.toDoubleOrNull() ?: 0.0, method) }) { Text("Bayar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Bayar Hutang") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("${debt.creditor} • sisa ${UiFormat.money(debt.remaining)}") }
                item { OutlinedTextField(amount, { amount = it }, label = { Text("Nominal bayar") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(method, { method = it }, label = { Text("Metode") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}
