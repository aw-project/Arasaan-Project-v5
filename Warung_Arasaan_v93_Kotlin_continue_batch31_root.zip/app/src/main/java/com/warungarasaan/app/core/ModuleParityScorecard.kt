package com.warungarasaan.app.core

data class ModuleParityScore(
    val name: String,
    val score: Int,
    val notes: String = "",
)

object ModuleParityScorecard {
    fun summarize(modules: List<ModuleParityScore>): Int {
        if (modules.isEmpty()) return 0
        return modules.map { it.score.coerceIn(0, 100) }.average().toInt()
    }

    fun weakestModules(modules: List<ModuleParityScore>, limit: Int = 3): List<ModuleParityScore> {
        return modules.sortedBy { it.score }.take(limit.coerceAtLeast(1))
    }
}
