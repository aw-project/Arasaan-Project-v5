package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.Debt
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.LabeledNumberField
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun DebtsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var debts by remember { mutableStateOf<List<Debt>>(emptyList()) }
    var showCreate by remember { mutableStateOf(false) }
    var payDebtId by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    suspend fun reload() {
        debts = container.debtRepository.all()
    }

    LaunchedEffect(Unit) { reload() }

    val filtered = remember(debts, query) {
        val q = query.trim().lowercase()
        debts.filter {
            q.isBlank() || it.creditor.lowercase().contains(q) || it.note.lowercase().contains(q)
        }
    }

    if (showCreate) {
        DebtEditorDialog(
            onDismiss = { showCreate = false },
            onSave = { creditor, note, principal ->
                scope.launch {
                    container.debtRepository.add(
                        Debt(
                            id = AppUtils.newId("debt"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            creditor = creditor,
                            note = note,
                            principal = principal,
                            paid = 0.0,
                        )
                    )
                    container.activityLogRepository.log("debt", "Tambah hutang $creditor ${UiFormat.money(principal)}")
                    showCreate = false
                    reload()
                }
            },
        )
    }

    if (payDebtId != null) {
        PaymentDialog(
            onDismiss = { payDebtId = null },
            onSave = { amount, method ->
                scope.launch {
                    container.debtRepository.addPayment(payDebtId!!, amount, AppUtils.epochDayNow(), method)
                    container.activityLogRepository.log("debt_payment", "Bayar hutang ${UiFormat.money(amount)}")
                    payDebtId = null
                    reload()
                }
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }) { Text("+") }
        },
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SectionCard(
                    title = "Hutang",
                    subtitle = "Modul terpisah untuk mengejar parity debts_page.dart dari Flutter.",
                ) {
                    OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Cari kreditur / catatan") })
                    androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip("Aktif", filtered.count { !it.isSettled }.toString())
                        InfoChip("Sisa", UiFormat.money(filtered.sumOf { it.remaining }))
                    }
                }
            }
            if (filtered.isEmpty()) {
                item { EmptyHint("Belum ada hutang", "Tambah hutang agar arus kas dan jatuh tempo bisa dipantau.") }
            } else {
                items(filtered, key = { it.id }) { debt ->
                    ListItem(
                        headlineContent = { Text(debt.creditor) },
                        supportingContent = { Text("${debt.note.ifBlank { "Tanpa catatan" }} • Sisa ${UiFormat.money(debt.remaining)}") },
                        trailingContent = { TextButton(onClick = { payDebtId = debt.id }) { Text("Bayar") } },
                    )
                }
            }
        }
    }
}

@Composable
private fun DebtEditorDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Double) -> Unit,
) {
    var creditor by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var principalText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Hutang") },
        text = {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = creditor, onValueChange = { creditor = it }, label = { Text("Kreditur") })
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Catatan") })
                LabeledNumberField(label = "Nominal pokok", value = principalText, onValueChange = { principalText = it })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val principal = principalText.toDoubleOrNull() ?: 0.0
                    if (creditor.isNotBlank() && principal > 0.0) onSave(creditor.trim(), note.trim(), principal)
                },
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@Composable
private fun PaymentDialog(
    onDismiss: () -> Unit,
    onSave: (Double, String) -> Unit,
) {
    var amountText by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Cash") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bayar Hutang") },
        text = {
            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LabeledNumberField(label = "Nominal bayar", value = amountText, onValueChange = { amountText = it })
                OutlinedTextField(value = method, onValueChange = { method = it }, label = { Text("Metode bayar") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount > 0.0) onSave(amount, method.trim().ifBlank { "Cash" })
                },
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}
