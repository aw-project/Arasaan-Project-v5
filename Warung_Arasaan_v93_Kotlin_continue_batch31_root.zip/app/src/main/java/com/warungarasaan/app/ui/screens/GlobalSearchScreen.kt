package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer

@Composable
fun GlobalSearchScreen(
    container: AppContainer,
    modifier: Modifier = Modifier,
    onNavigate: ((String) -> Unit)? = null,
) {
    SearchModuleScreen(container = container, modifier = modifier, onNavigate = onNavigate)
}
