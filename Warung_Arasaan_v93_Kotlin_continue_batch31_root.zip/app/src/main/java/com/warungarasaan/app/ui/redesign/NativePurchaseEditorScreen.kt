package com.warungarasaan.app.ui.redesign

import androidx.compose.runtime.Composable

@Composable
fun NativePurchaseEditorScreen(
    state: TransactionEditorUi,
    onPartnerChange: (String) -> Unit,
    onDateChange: (String) -> Unit,
    onNotesChange: (String) -> Unit,
    onAddLine: () -> Unit,
    onEditLine: (Int) -> Unit,
    onRemoveLine: (Int) -> Unit,
    onSave: () -> Unit
) {
    NativeTransactionEditor(
        state = state.copy(title = "Pembelian"),
        onPartnerChange = onPartnerChange,
        onDateChange = onDateChange,
        onNotesChange = onNotesChange,
        onAddLine = onAddLine,
        onEditLine = onEditLine,
        onRemoveLine = onRemoveLine,
        onSave = onSave
    )
}
