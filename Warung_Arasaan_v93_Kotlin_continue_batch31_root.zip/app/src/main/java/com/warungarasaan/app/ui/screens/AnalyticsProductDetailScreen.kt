package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun AnalyticsProductDetailScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var rangeDays by remember { mutableStateOf(30) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var selectedProductId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        products = container.productRepository.all().sortedBy { it.name.lowercase() }
        sales = container.salesRepository.all()
        if (selectedProductId == null) {
            selectedProductId = products.firstOrNull()?.id
        }
    }

    val selectedProduct = remember(products, selectedProductId) {
        products.firstOrNull { it.id == selectedProductId }
    }

    val productSales = remember(sales, selectedProductId) {
        sales.flatMap { sale ->
            sale.items.filter { it.productId == selectedProductId }.map { item -> sale to item }
        }
    }

    val qtySold = productSales.sumOf { it.second.qty }
    val revenue = productSales.sumOf { it.second.total }
    val hpp = productSales.sumOf { it.second.totalHpp }
    val profit = revenue - hpp
    val avgSell = if (qtySold == 0.0) 0.0 else revenue / qtySold
    val avgHpp = if (qtySold == 0.0) 0.0 else hpp / qtySold
    val analyticsService = remember { AnalyticsService() }
    val topSellingIds = remember(sales, products, rangeDays) {
        analyticsService.topSelling(sales, products, rangeDays).map { it.productId }.toSet()
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Analytics Detail Produk", style = androidx.compose.material3.MaterialTheme.typography.headlineSmall) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7, 30, 90, 365).forEach { days ->
                    AssistChip(
                        onClick = { rangeDays = days },
                        label = { Text("$days hari") },
                    )
                }
            }
        }
        item {
            SectionCard(
                title = "Pilih Produk",
                subtitle = "Mengisi gap dari analytics_product_detail_page.dart agar ada detail kontribusi per produk.",
            ) {
                products.take(12).forEach { product ->
                    AssistChip(
                        onClick = { selectedProductId = product.id },
                        label = { Text(product.name + if (product.id in topSellingIds) " • top" else "") },
                    )
                }
            }
        }

        if (selectedProduct == null) {
            item { EmptyHint("Belum ada produk", "Tambahkan produk terlebih dahulu untuk melihat detail analitik.") }
        } else {
            item {
                SectionCard(
                    title = selectedProduct!!.name,
                    subtitle = "SKU ${selectedProduct!!.sku.ifBlank { "-"} } • Kategori ${selectedProduct!!.category}",
                ) {
                    InlineLabelValue("Stok", UiFormat.qty(selectedProduct!!.stockQty))
                    InlineLabelValue("Harga jual aktif", UiFormat.money(selectedProduct!!.activeSellPrice))
                    InlineLabelValue("HPP rata-rata", UiFormat.money(selectedProduct!!.avgHpp))
                    InlineLabelValue("Target stok", UiFormat.qty(selectedProduct!!.targetStock))
                }
            }
            item {
                SectionCard(title = "Kinerja Produk", subtitle = "Periode $rangeDays hari") {
                    InlineLabelValue("Qty terjual", UiFormat.qty(qtySold))
                    InlineLabelValue("Omzet", UiFormat.money(revenue))
                    InlineLabelValue("HPP total", UiFormat.money(hpp))
                    InlineLabelValue("Profit", UiFormat.money(profit))
                    InlineLabelValue("Rata-rata jual", UiFormat.money(avgSell))
                    InlineLabelValue("Rata-rata HPP", UiFormat.money(avgHpp))
                }
            }
            item { Text("Riwayat transaksi produk") }
            if (productSales.isEmpty()) {
                item { EmptyHint("Belum ada penjualan", "Produk ini belum muncul di transaksi penjualan.") }
            } else {
                items(productSales.takeLast(30).reversed(), key = { it.first.id + "-" + it.second.productId }) { (sale, item) ->
                    ListItem(
                        headlineContent = { Text("Sale ${sale.id}") },
                        supportingContent = { Text("Qty ${UiFormat.qty(item.qty)} • Harga ${UiFormat.money(item.sellPrice)} • Customer ${sale.customerName.ifBlank { "Umum" }}") },
                        trailingContent = { Text(UiFormat.money(item.total)) },
                    )
                }
            }
            item { HorizontalDivider() }
        }
    }
}
