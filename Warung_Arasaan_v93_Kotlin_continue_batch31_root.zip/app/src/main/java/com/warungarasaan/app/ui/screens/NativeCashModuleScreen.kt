package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.redesign.CashRowUi
import com.warungarasaan.app.ui.redesign.NativeCashScreen

@Composable
fun NativeCashModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var rows by remember { mutableStateOf(emptyList<CashRowUi>()) }
    var balance by remember { mutableStateOf(UiFormat.money(0.0)) }
    var totalIn by remember { mutableStateOf(UiFormat.money(0.0)) }
    var totalOut by remember { mutableStateOf(UiFormat.money(0.0)) }

    LaunchedEffect(Unit) {
        val entries = container.cashRepository.all()
            .sortedWith(compareByDescending<com.warungarasaan.app.domain.model.CashEntry> { it.dateEpochDay }.thenByDescending { it.id })

        val cashOnly = entries.filter { PaymentMethods.isCashFlow(it.method) }
        val inAmount = cashOnly.filter { it.direction.equals("in", true) }.sumOf { it.amount }
        val outAmount = cashOnly.filter { it.direction.equals("out", true) }.sumOf { it.amount }

        balance = UiFormat.money(inAmount - outAmount)
        totalIn = UiFormat.money(inAmount)
        totalOut = UiFormat.money(outAmount)
        rows = entries.map {
            CashRowUi(
                id = it.id,
                title = it.note.ifBlank { it.source.ifBlank { "Kas" } },
                subtitle = "${UiFormat.date(it.dateEpochDay)} • ${it.method} • ${it.source}",
                amount = UiFormat.money(it.amount),
                isInflow = it.direction.equals("in", true),
            )
        }
    }

    NativeCashScreen(
        rows = rows,
        balance = balance,
        totalIn = totalIn,
        totalOut = totalOut,
        modifier = modifier,
    )
}