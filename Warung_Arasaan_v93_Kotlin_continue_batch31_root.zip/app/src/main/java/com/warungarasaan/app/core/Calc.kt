package com.warungarasaan.app.core

import kotlin.math.max

object Calc {
    fun subtotal(unitPrice: Double, qty: Double): Double =
        AppUtils.normalizeMoney(unitPrice * qty)

    fun discountNominal(subtotal: Double, discountInput: Double): Double =
        AppUtils.normalizeMoney(max(0.0, minOf(subtotal, discountInput)))

    fun grandTotal(subtotal: Double, discount: Double = 0.0, extraCharge: Double = 0.0): Double =
        AppUtils.normalizeMoney(max(0.0, subtotal - discount + extraCharge))

    fun change(received: Double, total: Double): Double =
        AppUtils.normalizeMoney(max(0.0, received - total))

    fun profit(revenue: Double, hpp: Double, expense: Double = 0.0): Double =
        AppUtils.normalizeMoney(revenue - hpp - expense)

    fun marginPercent(revenue: Double, profit: Double): Double =
        if (revenue <= 0.0) 0.0 else AppUtils.normalizeMoney((profit / revenue) * 100.0)

    fun weightedAverageHpp(
        currentQty: Double,
        currentHpp: Double,
        incomingQty: Double,
        incomingUnitCost: Double,
    ): Double {
        val totalQty = currentQty + incomingQty
        if (totalQty <= 0.0) return 0.0
        val totalCost = (currentQty * currentHpp) + (incomingQty * incomingUnitCost)
        return AppUtils.hppWeightedAverage(totalQty, totalCost)
    }
}
