package com.warungarasaan.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.PermissionCenter
import com.warungarasaan.app.data.service.BluetoothThermalPrinterService
import com.warungarasaan.app.data.service.ReceiptShareService
import com.warungarasaan.app.data.service.ThermalReceiptService
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun PrintCenterModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val runtimePermissions = remember { PermissionCenter.requiredRuntimePermissions() }
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var selectedSaleId by remember { mutableStateOf<String?>(null) }
    var selectedPrinter by remember { mutableStateOf<String?>(null) }
    var printers by remember { mutableStateOf(BluetoothThermalPrinterService.listBondedDevices(context)) }
    var status by remember { mutableStateOf("") }
    var missingPermissions by remember { mutableStateOf(PermissionCenter.missingPermissions(context, runtimePermissions)) }

    suspend fun reload() {
        sales = container.salesRepository.all().sortedByDescending { it.dateEpochDay }
        products = container.productRepository.all()
        missingPermissions = PermissionCenter.missingPermissions(context, runtimePermissions)
        printers = BluetoothThermalPrinterService.listBondedDevices(context)
        if (selectedSaleId == null) selectedSaleId = sales.firstOrNull()?.id
        if (selectedPrinter == null) selectedPrinter = printers.firstOrNull()?.address
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        scope.launch {
            reload()
            status = if (missingPermissions.isEmpty()) {
                "Izin runtime sudah diberikan."
            } else {
                "Masih ada izin yang belum diberikan: ${missingPermissions.joinToString()}."
            }
        }
    }

    LaunchedEffect(Unit) { reload() }

    val productNames = remember(products) { products.associate { it.id to it.name } }
    val selectedSale = remember(sales, selectedSaleId) { sales.firstOrNull { it.id == selectedSaleId } }
    val receiptText = remember(selectedSale, productNames) {
        selectedSale?.let { ThermalReceiptService.toEscPosText(it, productNames) }.orEmpty()
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(
                title = "Print Center",
                subtitle = "Hub struk native untuk share teks, file .txt, dan starter Bluetooth thermal.",
            ) {
                Text("Pilih transaksi penjualan, preview struk, lalu kirim ke share sheet atau printer Bluetooth yang sudah di-pairing.")
            }
        }
        item {
            SectionCard(title = "Izin runtime") {
                if (runtimePermissions.isEmpty()) {
                    Text("Perangkat ini tidak membutuhkan izin runtime tambahan untuk notifikasi/Bluetooth.")
                } else {
                    Text(
                        if (missingPermissions.isEmpty()) {
                            "Semua izin penting sudah aktif."
                        } else {
                            "Izin yang masih dibutuhkan: ${missingPermissions.joinToString()}."
                        },
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = { permissionLauncher.launch(runtimePermissions.toTypedArray()) },
                        ) { Text("Minta izin") }
                        TextButton(
                            onClick = { scope.launch { reload() } },
                        ) { Text("Refresh") }
                    }
                }
            }
        }
        item {
            SectionCard(title = "Printer Bluetooth") {
                if (printers.isEmpty()) {
                    Text("Belum ada paired printer terdeteksi atau izin Bluetooth belum diberikan.")
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        printers.take(6).forEach { printer ->
                            AssistChip(
                                onClick = { selectedPrinter = printer.address },
                                label = { Text(printer.name) },
                            )
                        }
                    }
                    Text("Printer aktif: ${printers.firstOrNull { it.address == selectedPrinter }?.name ?: "-"}")
                }
            }
        }
        item {
            SectionCard(title = "Transaksi penjualan terbaru") {
                if (sales.isEmpty()) {
                    EmptyHint("Belum ada transaksi penjualan.", "Buat transaksi penjualan dulu agar struk bisa dicetak.")
                } else {
                    sales.take(12).forEach { sale ->
                        TextButton(onClick = { selectedSaleId = sale.id }) {
                            Text("${sale.id} • ${UiFormat.money(sale.totalSales)} • ${sale.customerName.ifBlank { "Umum" }}")
                        }
                    }
                }
            }
        }
        item {
            SectionCard(title = "Preview struk") {
                if (receiptText.isBlank()) {
                    EmptyHint("Belum ada struk yang dipilih.", "Pilih satu transaksi penjualan untuk melihat preview struk.")
                } else {
                    Text(receiptText)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = {
                                ReceiptShareService.sharePlainText(
                                    context = context,
                                    title = "Struk Penjualan",
                                    content = receiptText,
                                )
                            },
                        ) { Text("Share teks") }
                        TextButton(
                            onClick = {
                                val fileName = "receipt-${selectedSale?.id ?: "sale"}.txt"
                                ReceiptShareService.shareTextFile(
                                    context = context,
                                    title = "Share Struk",
                                    fileName = fileName,
                                    content = receiptText,
                                )
                            },
                        ) { Text("Share file") }
                        TextButton(
                            onClick = {
                                val address = selectedPrinter
                                if (missingPermissions.isNotEmpty()) {
                                    status = "Berikan izin runtime dulu sebelum print Bluetooth."
                                } else if (address == null) {
                                    status = "Pilih printer Bluetooth dulu."
                                } else {
                                    scope.launch {
                                        val result = BluetoothThermalPrinterService.printText(context, address, receiptText)
                                        status = result.message
                                    }
                                }
                            },
                        ) { Text("Print Bluetooth") }
                    }
                    if (status.isNotBlank()) {
                        Text(status)
                    }
                }
            }
        }
        items(sales.take(10)) { sale ->
            ListItem(
                headlineContent = { Text("Sale ${sale.id}") },
                supportingContent = { Text("Total ${UiFormat.money(sale.totalSales)} • ${sale.paymentSummary}") },
                trailingContent = {
                    TextButton(onClick = { selectedSaleId = sale.id }) {
                        Text("Pilih")
                    }
                },
            )
        }
    }
}
