package com.warungarasaan.app.core

import com.warungarasaan.app.data.service.BackupPayload

data class BackupRestoreRegressionMatrix(
    val hasProducts: Boolean,
    val hasPurchases: Boolean,
    val hasSales: Boolean,
    val hasExpenses: Boolean,
    val hasDebts: Boolean,
    val hasMovements: Boolean,
    val hasCash: Boolean,
    val hasRejected: Boolean,
    val hasActivityLogs: Boolean,
    val hasSettings: Boolean
) {
    fun completionRatio(): Double {
        val flags = listOf(
            hasProducts,
            hasPurchases,
            hasSales,
            hasExpenses,
            hasDebts,
            hasMovements,
            hasCash,
            hasRejected,
            hasActivityLogs,
            hasSettings
        )
        return flags.count { it }.toDouble() / flags.size.toDouble()
    }
}

object BackupRestoreRegressionAudit {
    fun fromPayload(payload: BackupPayload): BackupRestoreRegressionMatrix =
        BackupRestoreRegressionMatrix(
            hasProducts = payload.products.isNotEmpty(),
            hasPurchases = payload.purchases.isNotEmpty(),
            hasSales = payload.sales.isNotEmpty(),
            hasExpenses = payload.expenses.isNotEmpty(),
            hasDebts = payload.debts.isNotEmpty(),
            hasMovements = payload.movements.isNotEmpty(),
            hasCash = payload.cash.isNotEmpty(),
            hasRejected = payload.rejectedItems.isNotEmpty(),
            hasActivityLogs = payload.activityLogs.isNotEmpty(),
            hasSettings = payload.settings != null
        )
}
