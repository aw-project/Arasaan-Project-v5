package com.warungarasaan.app.core

import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.PurchaseItem
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import kotlin.math.abs

object TransactionValidation {
    fun validatePurchaseItems(items: List<PurchaseItem>) {
        require(items.isNotEmpty()) { "Pembelian harus memiliki minimal 1 item." }
        items.forEachIndexed { index, item ->
            require(item.productId.isNotBlank()) { "Item pembelian #${index + 1} belum memilih produk." }
            require(item.qty > 0.0) { "Qty pembelian #${index + 1} harus lebih dari 0." }
            require(item.buyPrice >= 0.0) { "Harga beli item #${index + 1} tidak valid." }
        }
    }

    fun validateSaleItems(items: List<SaleItem>) {
        require(items.isNotEmpty()) { "Penjualan harus memiliki minimal 1 item." }
        items.forEachIndexed { index, item ->
            require(item.productId.isNotBlank()) { "Item penjualan #${index + 1} belum memilih produk." }
            require(item.qty > 0.0) { "Qty penjualan #${index + 1} harus lebih dari 0." }
            require(item.sellPrice >= 0.0) { "Harga jual item #${index + 1} tidak valid." }
            require(item.hppAtSale >= 0.0) { "HPP item #${index + 1} tidak valid." }
        }
    }

    fun validatePaymentSplits(splits: List<PaymentSplit>, expectedTotal: Double) {
        if (splits.isEmpty()) return
        require(splits.all { it.method.isNotBlank() }) { "Metode split payment tidak boleh kosong." }
        require(splits.all { it.amount >= 0.0 }) { "Nominal split payment tidak boleh negatif." }
        val actual = splits.sumOf { it.amount }
        require(abs(actual - expectedTotal) < 0.01) { "Total split payment harus sama dengan total transaksi." }
    }

    fun validateSale(sale: Sale) {
        validateSaleItems(sale.items)
        require(sale.discountAmount >= 0.0) { "Diskon tidak boleh negatif." }
        validatePaymentSplits(sale.paymentSplits, sale.totalSales)
    }
}
