package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun SaleDetailScreen(
    sale: Sale,
    products: List<Product>,
    modifier: Modifier = Modifier,
) {
    val productsById = products.associateBy { it.id }
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionCard(title = "Detail penjualan ${sale.id}") {
                InlineLabelValue("Tanggal", sale.dateEpochDay.toString())
                InlineLabelValue("Pelanggan", sale.customerName.ifBlank { "Umum" })
                InlineLabelValue("Pembayaran", sale.paymentSummary)
                InlineLabelValue("Diskon", UiFormat.money(sale.discountAmount))
                InlineLabelValue("Total", UiFormat.money(sale.totalSales))
                InlineLabelValue("Profit", UiFormat.money(sale.totalProfit))
            }
        }
        items(sale.items) { item ->
            val product = productsById[item.productId]
            SectionCard(title = product?.name ?: item.productId) {
                InlineLabelValue("Qty", UiFormat.qty(item.qty))
                InlineLabelValue("Harga jual", UiFormat.money(item.sellPrice))
                InlineLabelValue("HPP", UiFormat.money(item.hppAtSale))
                InlineLabelValue("Subtotal", UiFormat.money(item.total))
            }
        }
    }
}
