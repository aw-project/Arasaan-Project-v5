package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.RejectedItem
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.LabeledNumberField
import com.warungarasaan.app.ui.QuickRangeChips
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun RejectedModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var rejected by remember { mutableStateOf<List<RejectedItem>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var showDialog by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var reasonFilter by remember { mutableStateOf("Semua") }
    var handlingFilter by remember { mutableStateOf("Semua") }
    var rangeDays by remember { mutableStateOf(30) }

    suspend fun reload() {
        rejected = container.rejectedRepository.all()
        products = container.productRepository.all()
    }

    LaunchedEffect(Unit) { reload() }
    val productMap = remember(products) { products.associateBy { it.id } }

    val reasons = remember(rejected) { listOf("Semua") + rejected.map { it.reason }.distinct().sorted() }
    val handlings = remember(rejected) { listOf("Semua") + rejected.map { it.handling }.distinct().sorted() }

    val filtered = remember(rejected, query, reasonFilter, handlingFilter, rangeDays) {
        val q = query.trim().lowercase()
        val today = AppUtils.epochDayNow()
        val minDay = today - (rangeDays - 1)
        rejected.filter {
            val name = productMap[it.productId]?.name.orEmpty().lowercase()
            val queryOk = q.isBlank() || it.reason.lowercase().contains(q) || it.handling.lowercase().contains(q) || name.contains(q)
            val reasonOk = reasonFilter == "Semua" || it.reason == reasonFilter
            val handlingOk = handlingFilter == "Semua" || it.handling == handlingFilter
            val dayOk = it.dateEpochDay in minDay..today
            queryOk && reasonOk && handlingOk && dayOk
        }
    }

    if (showDialog) {
        RejectedEditorDialog(
            products = products,
            onDismiss = { showDialog = false },
            onSave = { productId, qty, reason, handling, note ->
                scope.launch {
                    val product = products.firstOrNull { it.id == productId } ?: return@launch
                    val loss = qty * product.avgHpp
                    container.rejectedRepository.add(
                        RejectedItem(
                            id = AppUtils.newId("rej"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            productId = product.id,
                            qty = qty,
                            reason = reason,
                            handling = handling,
                            note = note,
                            hppAtTime = product.avgHpp,
                            estimatedLoss = loss,
                        )
                    )
                    container.activityLogRepository.log("rejected", "Rejected ${product.name} qty ${UiFormat.qty(qty)}")
                    showDialog = false
                    reload()
                }
            },
        )
    }

    val totalLoss = filtered.sumOf { it.estimatedLoss }
    val totalQty = filtered.sumOf { it.qty }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { showDialog = true }) { Text("+") }
        },
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SectionCard(
                    title = "Rejected / Rejek",
                    subtitle = "Sekarang punya filter alasan dan penanganan agar lebih dekat ke flow Flutter.",
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Cari alasan / penanganan / produk") },
                    )
                    QuickRangeChips(
                        currentValue = rangeDays,
                        options = listOf(7, 30, 90),
                        onSelect = { rangeDays = it },
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        reasons.take(4).forEach { candidate ->
                            TextButton(onClick = { reasonFilter = candidate }) { Text(candidate) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        handlings.take(4).forEach { candidate ->
                            TextButton(onClick = { handlingFilter = candidate }) { Text(candidate) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip("Item: ${filtered.size}")
                        InfoChip("Qty: ${UiFormat.qty(totalQty)}")
                    }
                    InfoChip("Range: $rangeDays hari")
                    InfoChip("Alasan: $reasonFilter")
                    InfoChip("Penanganan: $handlingFilter")
                    InfoChip("Estimasi rugi: ${UiFormat.money(totalLoss)}")
                }
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyHint(
                        title = "Belum ada data rejected",
                        subtitle = "Tambah catatan rejek, rusak, atau kadaluarsa.",
                    )
                }
            }

            items(filtered, key = { it.id }) { entry ->
                val product = productMap[entry.productId]
                ListItem(
                    headlineContent = { Text(product?.name ?: entry.productId) },
                    supportingContent = {
                        Text(
                            "${UiFormat.date(entry.dateEpochDay)} • ${UiFormat.qty(entry.qty)} • ${entry.reason} • ${entry.handling}"
                        )
                    },
                    trailingContent = { Text(UiFormat.money(entry.estimatedLoss)) },
                )
            }
        }
    }
}

@Composable
private fun RejectedEditorDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onSave: (productId: String, qty: Double, reason: String, handling: String, note: String) -> Unit,
) {
    var productId by remember(products) { mutableStateOf(products.firstOrNull()?.id.orEmpty()) }
    var qty by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("Rusak") }
    var handling by remember { mutableStateOf("Buang") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah rejected") },
        text = {
            androidx.compose.foundation.layout.Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = productId,
                    onValueChange = { productId = it },
                    label = { Text("Product ID") },
                )
                LabeledNumberField(
                    label = "Qty",
                    value = qty,
                    onValueChange = { qty = it },
                )
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Alasan") },
                )
                OutlinedTextField(
                    value = handling,
                    onValueChange = { handling = it },
                    label = { Text("Penanganan") },
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Catatan") },
                )
                Text("Produk tersedia: ${products.take(5).joinToString { it.id }}")
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(productId, qty.toDoubleOrNull() ?: 0.0, reason.trim(), handling.trim(), note.trim())
                },
            ) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        },
    )
}
