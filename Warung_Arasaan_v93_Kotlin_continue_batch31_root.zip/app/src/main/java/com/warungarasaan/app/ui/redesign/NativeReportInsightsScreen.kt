package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

data class ReportInsightRow(
    val label: String,
    val value: String
)

@Composable
fun NativeReportInsightsScreen(
    title: String,
    rows: List<ReportInsightRow>,
    footer: String
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text(title) }
        items(rows) { row ->
            Card {
                ListItem(
                    headlineContent = { Text(row.label) },
                    trailingContent = { Text(row.value) }
                )
            }
        }
        item { Text(footer) }
    }
}
