package com.warungarasaan.app.ui.redesign

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.warungarasaan.app.ui.theme.WarungColors

data class NativeNavItem(val key: String, val label: String, val icon: ImageVector)

@Composable
fun NativeHomeScaffold(
    selected: String,
    onSelect: (String) -> Unit,
    onQuickSale: () -> Unit,
    content: @Composable (PaddingValues) -> Unit
) {
    val navItems = listOf(
        NativeNavItem("home",     "Home",     Icons.Rounded.GridView),
        NativeNavItem("products", "Produk",   Icons.Rounded.Inventory2),
        NativeNavItem("sales",    "Kasir",    Icons.Rounded.PointOfSale),
        NativeNavItem("reports",  "Laporan",  Icons.Rounded.Analytics),
        NativeNavItem("more",     "Lainnya",  Icons.Rounded.Apps),
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            _FloatingDarkNav(
                items      = navItems,
                selected   = selected,
                onSelect   = onSelect,
                onQuickSale = onQuickSale,
            )
        },
        content = content,
    )
}

@Composable
private fun _FloatingDarkNav(
    items: List<NativeNavItem>,
    selected: String,
    onSelect: (String) -> Unit,
    onQuickSale: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 10.dp)
            .height(64.dp)
            .shadow(
                elevation = 24.dp,
                shape = RoundedCornerShape(32.dp),
                ambientColor = WarungColors.Primary.copy(alpha = 0.4f),
                spotColor = WarungColors.Primary.copy(alpha = 0.5f),
            )
            .clip(RoundedCornerShape(32.dp))
            .background(WarungColors.NavBg),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { item ->
                val isSelected = selected == item.key
                val isCenterFastPos = item.key == "sales"

                _NavPill(
                    item       = item,
                    isSelected = isSelected,
                    isFeatured = isCenterFastPos,
                    onClick    = { if (isCenterFastPos) onQuickSale() else onSelect(item.key) },
                    modifier   = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun _NavPill(
    item: NativeNavItem,
    isSelected: Boolean,
    isFeatured: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val activeColor   = if (isFeatured) WarungColors.NavActive else WarungColors.NavActive
    val inactiveColor = Color.White.copy(alpha = 0.38f)
    val iconColor     = if (isSelected) activeColor else inactiveColor

    val indicatorAlpha by animateFloatAsState(
        targetValue = if (isSelected) 1f else 0f,
        animationSpec = tween(200),
        label = "indicator",
    )

    Box(
        modifier = modifier
            .fillMaxHeight()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(width = 44.dp, height = 30.dp)
                    .graphicsLayer { alpha = indicatorAlpha }
                    .clip(RoundedCornerShape(15.dp))
                    .background(WarungColors.Primary.copy(alpha = 0.35f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector        = item.icon,
                    contentDescription = item.label,
                    tint               = activeColor,
                    modifier           = Modifier.size(19.dp),
                )
            }
            if (!isSelected) {
                Icon(
                    imageVector        = item.icon,
                    contentDescription = item.label,
                    tint               = inactiveColor,
                    modifier           = Modifier
                        .size(19.dp)
                        .graphicsLayer { alpha = 1f - indicatorAlpha },
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text       = item.label,
                fontSize   = 9.sp,
                fontWeight = if (isSelected) FontWeight.W700 else FontWeight.W400,
                color      = iconColor,
            )
        }
    }
}
