package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.isRouteAllowed
import com.warungarasaan.app.ui.theme.WarungColors

private data class MoreItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val route: String,
    val featured: Boolean = false,
)

private data class MoreGroup(val heading: String, val items: List<MoreItem>)

@Composable
fun MoreModuleScreen(
    container: AppContainer,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var saldoKas    by remember { mutableStateOf(0.0) }
    var rejectedCount by remember { mutableStateOf(0) }
    var activeRole  by remember { mutableStateOf("admin") }

    LaunchedEffect(Unit) {
        saldoKas = container.cashRepository.all()
            .filter { PaymentMethods.isCashFlow(it.method) }
            .sumOf { if (it.direction == "in") it.amount else -it.amount }
        rejectedCount = container.rejectedRepository.all().size
        activeRole = container.metaRepository.role()
    }

    val allGroups = listOf(
        MoreGroup("Keuangan", listOf(
            MoreItem("Kas",            "Saldo ${UiFormat.money(saldoKas)}", Icons.Rounded.AccountBalanceWallet, WarungColors.Primary,    "cash",     featured = true),
            MoreItem("Hutang",         "Pantau sisa pembayaran",           Icons.Rounded.Payments,             Color(0xFFB06000),        "debts"),
            MoreItem("Biaya",          "Catat biaya operasional",          Icons.Rounded.RequestQuote,         Color(0xFFC62828),        "expenses"),
            MoreItem("Barang Retur",   "$rejectedCount entri tercatat",    Icons.Rounded.RemoveShoppingCart,   Color(0xFFB83232),        "rejected"),
        )),
        MoreGroup("Laporan & Insight", listOf(
            MoreItem("Analytics",      "Insight penjualan dan margin",      Icons.Rounded.Insights,            Color(0xFF1565C0),        "analytics"),
            MoreItem("Analitik Produk","Detail kontribusi tiap produk",    Icons.Rounded.Analytics,            Color(0xFF1565C0),        "analytics_product_detail"),
            MoreItem("Restock",        "Forecast pembelian berikutnya",    Icons.Rounded.RestartAlt,           Color(0xFF2E7D32),        "restock"),
        )),
        MoreGroup("Mitra & Tools", listOf(
            MoreItem("Supplier",       "Pantau supplier dan hutang",       Icons.Rounded.LocalShipping,        Color(0xFF1565C0),        "suppliers"),
            MoreItem("Pelanggan",      "Ringkasan customer",               Icons.Rounded.PeopleAlt,            Color(0xFF6A1B9A),        "customers"),
            MoreItem("Tools Ops",      "Search cepat dan tool stok",       Icons.Rounded.BuildCircle,          Color(0xFFB06000),        "operations"),
            MoreItem("Print Center",   "Preview dan kirim struk",          Icons.Rounded.Print,                Color(0xFF37474F),        "print_center"),
            MoreItem("Backup",         "Export / import database",         Icons.Rounded.CloudUpload,          Color(0xFF37474F),        "backup"),
            MoreItem("Pengaturan",     "PIN, notifikasi, preferensi",      Icons.Rounded.Settings,             Color(0xFF37474F),        "settings"),
        )),
    )

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        allGroups.forEach { group ->
            val visibleItems = group.items.filter { isRouteAllowed(activeRole, it.route) }
            if (visibleItems.isEmpty()) return@forEach

            item {
                Text(
                    group.heading.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 0.8.sp,
                )
            }

            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Column {
                        visibleItems.forEachIndexed { idx, item ->
                            _MoreTile(item = item, onClick = { onNavigate(item.route) })
                            if (idx < visibleItems.lastIndex) {
                                Divider(
                                    modifier = Modifier.padding(start = 62.dp),
                                    thickness = 0.5.dp,
                                    color = MaterialTheme.colorScheme.outlineVariant,
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
private fun _MoreTile(item: MoreItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Icon container
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = item.color.copy(alpha = if (item.featured) 1f else 0.1f),
            modifier = Modifier.size(40.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    item.icon,
                    contentDescription = item.title,
                    tint = if (item.featured) Color.White else item.color,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(item.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(
            Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp),
        )
    }
}
