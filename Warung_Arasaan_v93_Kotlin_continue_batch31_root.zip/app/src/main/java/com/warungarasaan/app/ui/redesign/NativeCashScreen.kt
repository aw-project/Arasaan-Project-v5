package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class CashRowUi(
    val id: String,
    val title: String,
    val subtitle: String,
    val amount: String,
    val isInflow: Boolean,
)

@Composable
fun NativeCashScreen(
    rows: List<CashRowUi>,
    balance: String,
    totalIn: String,
    totalOut: String,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionHeader(
                title = "Kas",
                subtitle = "Arus kas dibuat lebih fokus untuk Android: saldo, masuk, keluar, lalu daftar transaksi terbaru.",
            )
        }
        item {
            androidx.compose.foundation.layout.Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillParentMaxWidth(),
            ) {
                SummaryMiniCard("Saldo", balance, Icons.Rounded.AccountBalanceWallet, Modifier.weight(1f))
            }
        }
        item {
            androidx.compose.foundation.layout.Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillParentMaxWidth(),
            ) {
                SummaryMiniCard("Kas Masuk", totalIn, Icons.Rounded.KeyboardArrowUp, Modifier.weight(1f))
                SummaryMiniCard("Kas Keluar", totalOut, Icons.Rounded.KeyboardArrowDown, Modifier.weight(1f))
            }
        }

        if (rows.isEmpty()) {
            item {
                NativeEmptyBlock(
                    title = "Belum ada arus kas",
                    subtitle = "Entry kas akan muncul otomatis dari pembelian, penjualan, hutang, dan biaya.",
                )
            }
        } else {
            items(rows, key = { it.id }) { row ->
                ListItem(
                    headlineContent = { Text(row.title) },
                    supportingContent = { Text(row.subtitle) },
                    trailingContent = {
                        Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                            Text(
                                row.amount,
                                style = MaterialTheme.typography.titleSmall,
                            )
                            Text(
                                if (row.isInflow) "Masuk" else "Keluar",
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                    },
                    leadingContent = {
                        Icon(
                            imageVector = if (row.isInflow) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                            contentDescription = null,
                        )
                    },
                )
            }
        }
    }
}