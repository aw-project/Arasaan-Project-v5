package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.ui.redesign.NativePurchasesScreen

@Composable
fun NativePurchasesModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var purchases by remember { mutableStateOf(emptyList<Purchase>()) }

    LaunchedEffect(Unit) {
        purchases = container.purchaseRepository.all().sortedByDescending { it.dateEpochDay }
    }

    NativePurchasesScreen(
        purchases = purchases,
        onCreatePurchase = {},
        onOpenPurchase = {},
    )
}
