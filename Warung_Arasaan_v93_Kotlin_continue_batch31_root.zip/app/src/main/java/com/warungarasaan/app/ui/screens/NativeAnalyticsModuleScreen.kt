package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.redesign.AnalyticsBreakdownCalculator
import com.warungarasaan.app.ui.redesign.AnalyticsUiState
import com.warungarasaan.app.ui.redesign.AnalyticsKpiUi
import com.warungarasaan.app.ui.redesign.NativeAnalyticsBreakdownScreen

@Composable
fun NativeAnalyticsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var state by remember { mutableStateOf(AnalyticsUiState()) }
    var breakdown by remember {
        mutableStateOf(
            AnalyticsBreakdownCalculator.build(
                sales = emptyList(),
                products = emptyList(),
                purchases = emptyList(),
            )
        )
    }

    LaunchedEffect(state.periodLabel) {
        val sales = container.salesRepository.all()
        val products = container.productRepository.all()
        val purchases = container.purchaseRepository.all()

        breakdown = AnalyticsBreakdownCalculator.build(
            sales = sales,
            products = products,
            purchases = purchases,
        )

        state = state.copy(
            kpis = listOf(
                AnalyticsKpiUi(
                    title = "Total transaksi",
                    value = breakdown.totalTransactions.toString(),
                    note = state.periodLabel
                ),
                AnalyticsKpiUi(
                    title = "Produk teratas",
                    value = breakdown.topProductNames.firstOrNull() ?: "-",
                    note = "Berdasar revenue"
                ),
                AnalyticsKpiUi(
                    title = "Margin rendah",
                    value = breakdown.lowMarginProductNames.firstOrNull() ?: "-",
                    note = "Perlu evaluasi harga"
                )
            ),
            topProducts = breakdown.topProductNames,
            forecastSummary = "Rata-rata keranjang ${breakdown.averageBasket}"
        )
    }

    NativeAnalyticsBreakdownScreen(
        rangeLabel = state.periodLabel,
        summary = breakdown,
    )
}
