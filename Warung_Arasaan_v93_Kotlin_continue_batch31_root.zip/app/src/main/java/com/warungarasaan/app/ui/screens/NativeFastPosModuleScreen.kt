package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.redesign.FastPosCartRowUi
import com.warungarasaan.app.ui.redesign.FastPosProductUi
import com.warungarasaan.app.ui.redesign.NativeFastPosScreen

@Composable
fun NativeFastPosModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var products by remember { mutableStateOf(emptyList<FastPosProductUi>()) }
    var cart by remember { mutableStateOf(emptyList<FastPosCartRowUi>()) }

    LaunchedEffect(Unit) {
        val all = container.productRepository.all()
        products = all.map {
            FastPosProductUi(
                id = it.id,
                title = it.name,
                subtitle = "${it.stockQty} ${it.unit}",
                price = UiFormat.money(it.activeSellPrice),
            )
        }
        cart = all.take(3).map {
            FastPosCartRowUi(
                id = it.id,
                title = it.name,
                qty = "1 ${it.unit}",
                subtotal = UiFormat.money(it.activeSellPrice),
            )
        }
    }

    val filtered = products.filter { query.isBlank() || it.title.contains(query, ignoreCase = true) }
    NativeFastPosScreen(
        query = query,
        onQueryChange = { query = it },
        products = filtered,
        cartItems = cart,
        subtotal = UiFormat.money(cart.sumOf { row -> row.subtotal.filter { c -> c.isDigit() }.toDoubleOrNull() ?: 0.0 }),
        paymentMethod = "Cash",
        onPaymentMethodChange = {},
        modifier = modifier,
    )
}
