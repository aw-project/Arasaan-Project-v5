package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.Sale

object ReportExportService {
    fun salesCsv(sales: List<Sale>, products: List<Product>): String {
        val names = products.associateBy({ it.id }, { it.name })
        return buildString {
            appendLine("sale_id,date,payment_method,customer,discount,gross,total,hpp,profit,items")
            sales.forEach { sale ->
                val itemsSummary = sale.items.joinToString(" | ") { item ->
                    "${csv(names[item.productId] ?: item.productId)} x${item.qty} @${item.sellPrice}"
                }
                appendLine(
                    listOf(
                        sale.id,
                        sale.dateEpochDay,
                        sale.paymentMethod,
                        csv(sale.customerName),
                        sale.discountAmount,
                        sale.grossSales,
                        sale.totalSales,
                        sale.totalHpp,
                        sale.totalProfit,
                        csv(itemsSummary),
                    ).joinToString(","),
                )
            }
        }
    }

    fun purchasesCsv(purchases: List<Purchase>, products: List<Product>): String {
        val names = products.associateBy({ it.id }, { it.name })
        return buildString {
            appendLine("purchase_id,date,supplier,payment_method,total,items")
            purchases.forEach { purchase ->
                val total = purchase.items.sumOf { it.qty * it.buyPrice }
                val itemsSummary = purchase.items.joinToString(" | ") { item ->
                    "${csv(names[item.productId] ?: item.productId)} x${item.qty} @${item.buyPrice}"
                }
                appendLine(
                    listOf(
                        purchase.id,
                        purchase.dateEpochDay,
                        csv(purchase.supplier),
                        purchase.paymentMethod,
                        total,
                        csv(itemsSummary),
                    ).joinToString(","),
                )
            }
        }
    }

    fun stockCsv(products: List<Product>): String = buildString {
        appendLine("product_id,sku,name,category,unit,stock_qty,avg_hpp,sell_price,min_stock,target_stock,stock_value")
        products.forEach { product ->
            appendLine(
                listOf(
                    product.id,
                    csv(product.sku),
                    csv(product.name),
                    csv(product.category),
                    product.unit,
                    product.stockQty,
                    product.avgHpp,
                    product.activeSellPrice,
                    product.minStock,
                    product.targetStock,
                    product.stockQty * product.avgHpp,
                ).joinToString(","),
            )
        }
    }


    fun exportSummaryCsv(summary: ReportSummary): String = buildString {
        appendLine("omzet,total_hpp,laba_kotor,total_biaya,rugi_rejek,laba_bersih")
        appendLine(
            listOf(
                summary.omzet,
                summary.totalHpp,
                summary.labaKotor,
                summary.totalBiaya,
                summary.rugiRejek,
                summary.labaBersih,
            ).joinToString(","),
        )
    }

    fun expensesCsv(expenses: List<Expense>): String = buildString {
        appendLine("expense_id,date,category,note,payment_method,amount")
        expenses.forEach { expense ->
            appendLine(
                listOf(
                    expense.id,
                    expense.dateEpochDay,
                    csv(expense.category),
                    csv(expense.note),
                    expense.paymentMethod,
                    expense.amount,
                ).joinToString(","),
            )
        }
    }

    private fun csv(value: Any?): String {
        val raw = value?.toString().orEmpty().replace("\"", "\"\"")
        return "\"$raw\""
    }
}
