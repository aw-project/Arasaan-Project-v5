package com.warungarasaan.app.ui.redesign

import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.Sale

data class AnalyticsBreakdownUi(
    val totalRevenue: Double,
    val totalProfit: Double,
    val totalTransactions: Int,
    val averageBasket: Double,
    val topProductNames: List<String>,
    val lowMarginProductNames: List<String>
)

object AnalyticsBreakdownCalculator {
    fun build(
        sales: List<Sale>,
        products: List<Product>,
        purchases: List<Purchase> = emptyList()
    ): AnalyticsBreakdownUi {
        val totalRevenue = sales.sumOf { it.totalSales }
        val totalProfit = sales.sumOf { it.totalProfit }
        val totalTransactions = sales.size
        val averageBasket = if (sales.isEmpty()) 0.0 else totalRevenue / sales.size

        val nameById = products.associateBy({ it.id }, { it.name })
        val revenueByProduct = linkedMapOf<String, Double>()
        val marginByProduct = linkedMapOf<String, Pair<Double, Double>>()

        sales.flatMap { it.items }.forEach { item ->
            revenueByProduct[item.productId] = (revenueByProduct[item.productId] ?: 0.0) + item.total
            val current = marginByProduct[item.productId] ?: (0.0 to 0.0)
            marginByProduct[item.productId] = (current.first + item.total) to (current.second + item.totalHpp)
        }

        val topProductNames = revenueByProduct.entries
            .sortedByDescending { it.value }
            .take(5)
            .map { nameById[it.key] ?: it.key }

        val lowMarginProductNames = marginByProduct.entries
            .map { entry ->
                val salesAmount = entry.value.first
                val hppAmount = entry.value.second
                val margin = if (salesAmount <= 0.0) 0.0 else ((salesAmount - hppAmount) / salesAmount) * 100.0
                entry.key to margin
            }
            .sortedBy { it.second }
            .take(5)
            .map { nameById[it.first] ?: it.first }

        return AnalyticsBreakdownUi(
            totalRevenue = totalRevenue,
            totalProfit = totalProfit,
            totalTransactions = totalTransactions,
            averageBasket = averageBasket,
            topProductNames = topProductNames,
            lowMarginProductNames = lowMarginProductNames
        )
    }
}
