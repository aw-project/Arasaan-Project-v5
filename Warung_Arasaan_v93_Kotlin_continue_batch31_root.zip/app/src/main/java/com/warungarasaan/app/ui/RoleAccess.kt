package com.warungarasaan.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.ui.redesign.NativeModuleRoutes

private val kasirBlockedRoutes = setOf(
    NativeModuleRoutes.Purchases,
    NativeModuleRoutes.Expenses,
    NativeModuleRoutes.Debts,
    NativeModuleRoutes.Backup,
    NativeModuleRoutes.Settings,
    NativeModuleRoutes.Suppliers,
    NativeModuleRoutes.ActivityLog,
    NativeModuleRoutes.Analytics,
    NativeModuleRoutes.Reports,
    NativeModuleRoutes.PrintCenter,
    "analytics_product_detail",
    "operations",
)

fun normalizedRole(role: String): String = role.trim().lowercase().ifBlank { "admin" }

fun isRouteAllowed(role: String, route: String): Boolean {
    val normalizedRoute = route.trim()
    return when (normalizedRole(role)) {
        "kasir" -> normalizedRoute !in kasirBlockedRoutes
        else -> true
    }
}

fun sanitizeRouteForRole(role: String, route: String): String {
    return if (isRouteAllowed(role, route)) route else NativeModuleRoutes.Home
}

@androidx.compose.runtime.Composable
fun AccessDeniedScreen(role: String, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("Akses dibatasi") }
        item { Text("Role aktif: ${normalizedRole(role).replaceFirstChar { it.uppercase() }}") }
        item { Text("Menu ini hanya tersedia untuk admin. Ganti role di pengaturan jika memang diperlukan.") }
    }
}
