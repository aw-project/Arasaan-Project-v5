package com.warungarasaan.app.data.local

data class StorageUnit(
    val key: String,
    val description: String,
    val backingStore: String,
)

object StorageRegistry {
    val units: List<StorageUnit> = listOf(
        StorageUnit("products", "Master produk dan stok", "Room"),
        StorageUnit("purchases", "Header pembelian", "Room"),
        StorageUnit("purchase_items", "Item pembelian", "Room"),
        StorageUnit("sales", "Header penjualan", "Room"),
        StorageUnit("sale_items", "Item penjualan", "Room"),
        StorageUnit("expenses", "Biaya operasional", "Room"),
        StorageUnit("debts", "Hutang dan pembayaran", "Room"),
        StorageUnit("cash_ledger", "Arus kas", "Room"),
        StorageUnit("stock_movements", "Pergerakan stok", "Room"),
        StorageUnit("rejected", "Barang reject/rusak", "Room"),
        StorageUnit("activity_logs", "Audit aktivitas", "Room"),
        StorageUnit("settings", "Pengaturan aplikasi", "DataStore"),
        StorageUnit("meta", "Metadata migrasi/unit", "DataStore"),
    )

    fun summary(): String = units.joinToString(separator = "\n") { unit ->
        "${unit.key} -> ${unit.backingStore} (${unit.description})"
    }
}
