package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class KpiItem(
    val label: String,
    val value: String,
    val icon: ImageVector? = null,
    val valueColor: androidx.compose.ui.graphics.Color? = null,
)

@Composable
fun KpiStrip(
    items: List<KpiItem>,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        items.forEachIndexed { index, item ->
            _KpiChip(item = item)
            if (index < items.lastIndex) {
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(32.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                        .align(Alignment.CenterVertically)
                )
            }
        }
    }
}

@Composable
private fun _KpiChip(item: KpiItem) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 4.dp),
    ) {
        item.icon?.let {
            Icon(
                imageVector = it,
                contentDescription = null,
                tint = item.valueColor ?: MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(15.dp),
            )
            Spacer(Modifier.height(3.dp))
        }
        Text(
            text = item.value,
            fontSize = 12.sp,
            fontWeight = FontWeight.W800,
            color = item.valueColor ?: MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
        Text(
            text = item.label,
            fontSize = 9.sp,
            fontWeight = FontWeight.W500,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
