package com.warungarasaan.app.ui.screens

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.Debt
import com.warungarasaan.app.ui.redesign.NativeDebtsScreen

@Composable
fun NativeDebtsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var debts by remember { mutableStateOf(emptyList<Debt>()) }

    LaunchedEffect(Unit) {
        debts = container.debtRepository.all().sortedByDescending { it.dateEpochDay }
    }

    NativeDebtsScreen(
        debts = debts,
        onCreateDebt = {},
        onPayDebt = {},
    )
}
