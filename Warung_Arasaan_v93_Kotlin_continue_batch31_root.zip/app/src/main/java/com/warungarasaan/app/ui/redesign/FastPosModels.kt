package com.warungarasaan.app.ui.redesign

data class FastPosProductUi(
    val id: String,
    val title: String,
    val subtitle: String,
    val price: String
)

data class FastPosCartRowUi(
    val id: String,
    val title: String,
    val qty: String,
    val subtotal: String
)
