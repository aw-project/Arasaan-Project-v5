package com.warungarasaan.app.core

sealed interface RepositoryResult<out T> {
    data class Success<T>(val value: T) : RepositoryResult<T>
    data class Error(val message: String, val cause: Throwable? = null) : RepositoryResult<Nothing>
}

inline fun <T> runRepositoryAction(block: () -> T): RepositoryResult<T> {
    return try {
        RepositoryResult.Success(block())
    } catch (t: Throwable) {
        RepositoryResult.Error(
            message = t.message ?: "Unknown repository error",
            cause = t
        )
    }
}
