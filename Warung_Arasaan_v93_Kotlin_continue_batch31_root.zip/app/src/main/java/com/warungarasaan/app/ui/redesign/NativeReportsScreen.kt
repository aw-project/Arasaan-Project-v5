package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

data class ReportOverviewUi(
    val omzet: String,
    val laba: String,
    val hpp: String,
    val biaya: String,
    val topProducts: List<String>
)

@Composable
fun NativeReportsScreen(
    selectedRange: String,
    onRangeChange: (String) -> Unit,
    overview: ReportOverviewUi,
    onExport: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(title = "Ringkasan Laporan", actionLabel = "Ekspor", onAction = onExport)
        }
        item {
            CompactFilterRow(
                selected = selectedRange,
                options = listOf("Hari ini", "7 hari", "30 hari", "Custom"),
                onChange = onRangeChange
            )
        }
        item { Card { ListItem(headlineContent = { Text("Omzet") }, supportingContent = { Text(overview.omzet) }) } }
        item { Card { ListItem(headlineContent = { Text("Laba") }, supportingContent = { Text(overview.laba) }) } }
        item { Card { ListItem(headlineContent = { Text("HPP") }, supportingContent = { Text(overview.hpp) }) } }
        item { Card { ListItem(headlineContent = { Text("Biaya") }, supportingContent = { Text(overview.biaya) }) } }
        item { SectionHeader("Produk Teratas") }
        overview.topProducts.forEach { item ->
            item { Card { ListItem(headlineContent = { Text(item) }) } }
        }
    }
}
