package com.warungarasaan.app.core

object Ids {
    fun product(): String = AppUtils.newId("prd")
    fun purchase(): String = AppUtils.newId("pur")
    fun sale(): String = AppUtils.newId("sal")
    fun expense(): String = AppUtils.newId("exp")
    fun debt(): String = AppUtils.newId("debt")
    fun movement(): String = AppUtils.newId("mov")
    fun activity(): String = AppUtils.newId("act")
    fun rejected(): String = AppUtils.newId("rej")
}
