package com.warungarasaan.app.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class UiDebouncer(
    private val scope: CoroutineScope,
    private val delayMillis: Long = 300L,
) {
    private var job: Job? = null

    fun submit(block: suspend () -> Unit) {
        job?.cancel()
        job = scope.launch {
            delay(delayMillis)
            block()
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
    }
}
