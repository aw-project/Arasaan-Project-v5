
package com.warungarasaan.app.core

object RegressionGuards {
    fun preventNegativeStock(projectedStock: Double): Boolean = projectedStock >= 0.0

    fun preventOverpayment(principal: Double, paid: Double): Boolean {
        if (principal < 0.0 || paid < 0.0) return false
        return paid <= principal
    }

    fun preventInvalidCashMutation(before: Double, delta: Double): Boolean {
        val after = before + delta
        return after.isFinite() && after >= 0.0
    }

    fun preventEmptyTransaction(itemsCount: Int, total: Double): Boolean {
        return itemsCount > 0 && total > 0.0
    }
}
