package com.warungarasaan.app.data.service

data class BackupRegressionInput(
    val payloadNotBlank: Boolean,
    val looksLikeJson: Boolean,
    val hasVersionMarker: Boolean,
    val hasProductsSection: Boolean,
    val hasTransactionsSection: Boolean,
)

data class BackupRegressionResult(
    val valid: Boolean,
    val reasons: List<String>,
)

object BackupRegressionAudit {
    fun validate(input: BackupRegressionInput): BackupRegressionResult {
        val reasons = mutableListOf<String>()
        if (!input.payloadNotBlank) reasons += "Payload backup kosong."
        if (!input.looksLikeJson) reasons += "Payload backup tidak terlihat seperti JSON."
        if (!input.hasVersionMarker) reasons += "Payload backup belum memiliki penanda versi."
        if (!input.hasProductsSection) reasons += "Section produk tidak ditemukan pada backup."
        if (!input.hasTransactionsSection) reasons += "Section transaksi tidak ditemukan pada backup."
        return BackupRegressionResult(valid = reasons.isEmpty(), reasons = reasons)
    }
}
