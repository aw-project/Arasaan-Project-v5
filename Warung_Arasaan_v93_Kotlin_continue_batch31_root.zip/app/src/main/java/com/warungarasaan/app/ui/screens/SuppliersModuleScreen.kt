package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.model.Debt
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

private data class SupplierStats(
    val name: String,
    val purchaseCount: Int,
    val totalSpend: Double,
    val totalQty: Double,
    val outstandingDebt: Double,
    val totalDebtPrincipal: Double,
    val lastEpochDay: Int?,
)

@Composable
fun SuppliersModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<SupplierStats>>(emptyList()) }

    LaunchedEffect(Unit) {
        val stats = linkedMapOf<String, SupplierStats>()
        val purchases = container.purchaseRepository.all()
        val debts = container.debtRepository.all()

        purchases.forEach { purchase ->
            val name = purchase.supplier.trim()
            if (name.isEmpty()) return@forEach
            val prev = stats[name]
            stats[name] = SupplierStats(
                name = name,
                purchaseCount = (prev?.purchaseCount ?: 0) + 1,
                totalSpend = (prev?.totalSpend ?: 0.0) + purchase.items.sumOf { it.qty * it.buyPrice },
                totalQty = (prev?.totalQty ?: 0.0) + purchase.items.sumOf { it.qty },
                outstandingDebt = prev?.outstandingDebt ?: 0.0,
                totalDebtPrincipal = prev?.totalDebtPrincipal ?: 0.0,
                lastEpochDay = maxOf(prev?.lastEpochDay ?: Int.MIN_VALUE, purchase.dateEpochDay).takeIf { it != Int.MIN_VALUE },
            )
        }

        debts.groupBy(Debt::creditor).forEach { (creditor, entries) ->
            val name = creditor.trim()
            if (name.isEmpty()) return@forEach
            val prev = stats[name] ?: SupplierStats(name, 0, 0.0, 0.0, 0.0, 0.0, null)
            stats[name] = prev.copy(
                outstandingDebt = entries.sumOf { it.remaining },
                totalDebtPrincipal = entries.sumOf { it.principal },
            )
        }

        items = stats.values.sortedByDescending { it.totalSpend }
    }

    val filtered = remember(items, query) {
        val q = query.trim().lowercase()
        items.filter { q.isBlank() || it.name.lowercase().contains(q) }
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(
                title = "Supplier",
                subtitle = "Padanan suppliers_page.dart dengan agregasi pembelian dan hutang supplier.",
            ) {
                Text("Jumlah supplier: ${filtered.size}")
                Text("Outstanding hutang: ${UiFormat.money(filtered.sumOf { it.outstandingDebt })}")
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Cari supplier") },
                singleLine = true,
            )
        }
        if (filtered.isEmpty()) {
            item { EmptyHint("Belum ada supplier", "Supplier akan terbentuk dari histori pembelian dan hutang.") }
        } else {
            items(filtered, key = { it.name }) { supplier ->
                ListItem(
                    headlineContent = { Text(supplier.name) },
                    supportingContent = {
                        Text(
                            "Pembelian ${supplier.purchaseCount}x • Qty ${UiFormat.qty(supplier.totalQty)} • Hutang ${UiFormat.money(supplier.outstandingDebt)}"
                        )
                    },
                    trailingContent = { Text(UiFormat.money(supplier.totalSpend)) },
                    overlineContent = {
                        Text(
                            buildString {
                                append("Pokok hutang ${UiFormat.money(supplier.totalDebtPrincipal)}")
                                supplier.lastEpochDay?.let { append(" • Terakhir ${UiFormat.date(it)}") }
                            }
                        )
                    },
                )
            }
        }
    }
}
