package com.warungarasaan.app.data.service

import com.warungarasaan.app.core.AppUtils.newId
import com.warungarasaan.app.core.UnitUtils
import com.warungarasaan.app.data.repository.MetaRepository
import com.warungarasaan.app.data.repository.MovementRepository
import com.warungarasaan.app.data.repository.ProductRepository
import com.warungarasaan.app.data.repository.PurchaseRepository
import com.warungarasaan.app.data.repository.SalesRepository
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.StockMovement

class UnitMigrationService(
    private val productRepository: ProductRepository,
    private val purchaseRepository: PurchaseRepository,
    private val salesRepository: SalesRepository,
    private val movementRepository: MovementRepository,
    private val metaRepository: MetaRepository,
) {
    suspend fun migrateKgToGramOnce() {
        val done = metaRepository.getBoolean(UnitUtils.UNIT_MIGRATION_V5_FINAL, false)
        if (done) return

        val products = productRepository.all()
        val gramProductIds = mutableSetOf<String>()

        products.forEach { product ->
            val unit = product.unit.trim().lowercase()
            when (unit) {
                "kg", "kilogram", "kilograms" -> {
                    gramProductIds += product.id
                    productRepository.upsert(
                        product.copy(
                            unit = "gram",
                            stockQty = UnitUtils.normalizeQty(product.stockQty * 1000.0),
                            minStock = UnitUtils.normalizeQty(product.minStock * 1000.0),
                            targetStock = UnitUtils.normalizeQty(product.targetStock * 1000.0),
                            avgHpp = UnitUtils.normalizeRate(product.avgHpp / 1000.0),
                            activeSellPrice = UnitUtils.normalizeRate(product.activeSellPrice / 1000.0),
                        ),
                    )
                }
                "gr" -> productRepository.upsert(product.copy(unit = "gram"))
            }
        }

        if (gramProductIds.isNotEmpty()) {
            purchaseRepository.all().forEach { purchase ->
                val changedItems = purchase.items.map { item ->
                    if (item.productId !in gramProductIds) item else item.copy(
                        qty = UnitUtils.normalizeQty(item.qty * 1000.0),
                        buyPrice = UnitUtils.normalizeRate(item.buyPrice / 1000.0),
                    )
                }
                purchaseRepository.replace(purchase.copy(items = changedItems))
            }

            salesRepository.all().forEach { sale ->
                val changedItems = sale.items.map { item ->
                    if (item.productId !in gramProductIds) item else item.copy(
                        qty = UnitUtils.normalizeQty(item.qty * 1000.0),
                        sellPrice = UnitUtils.normalizeRate(item.sellPrice / 1000.0),
                        hppAtSale = UnitUtils.normalizeRate(item.hppAtSale / 1000.0),
                    )
                }
                salesRepository.replace(sale.copy(items = changedItems))
            }

            movementRepository.all().forEach { movement ->
                if (movement.productId !in gramProductIds) return@forEach
                movementRepository.add(
                    StockMovement(
                        id = movement.id.ifBlank { newId("move") },
                        dateEpochDay = movement.dateEpochDay,
                        productId = movement.productId,
                        type = movement.type,
                        qtyDelta = UnitUtils.normalizeQty(movement.qtyDelta * 1000.0),
                        note = movement.note,
                        lossType = movement.lossType,
                        lossAmount = movement.lossAmount,
                    ),
                )
            }
        }

        metaRepository.setBoolean(UnitUtils.UNIT_MIGRATION_V5_FINAL, true)
    }
}
