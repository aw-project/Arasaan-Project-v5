package com.warungarasaan.app.core

import java.security.MessageDigest
import java.time.LocalDate
import java.util.UUID
import kotlin.math.round

object AppUtils {
    fun newId(prefix: String): String = "$prefix-${UUID.randomUUID().toString().replace("-", "").take(16)}"
    fun epochDayNow(): Int = LocalDate.now().toEpochDay().toInt()
    fun normalizeQty(value: Double): Double = round(value * 1000.0) / 1000.0
    fun normalizeMoney(value: Double): Double = round(value * 100.0) / 100.0
    fun hppWeightedAverage(totalQty: Double, totalCost: Double): Double =
        if (totalQty <= 0.0) 0.0 else normalizeMoney(totalCost / totalQty)

    fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
