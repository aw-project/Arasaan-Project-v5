package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun PurchaseDetailScreen(
    purchase: Purchase,
    products: List<Product>,
    modifier: Modifier = Modifier,
) {
    val productsById = products.associateBy { it.id }
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionCard(title = "Detail pembelian ${purchase.id}") {
                InlineLabelValue("Tanggal", purchase.dateEpochDay.toString())
                InlineLabelValue("Supplier", purchase.supplier.ifBlank { "Tanpa Supplier" })
                InlineLabelValue("Pembayaran", purchase.paymentMethod)
                InlineLabelValue("Total", UiFormat.money(purchase.items.sumOf { it.qty * it.buyPrice }))
            }
        }
        items(purchase.items) { item ->
            val product = productsById[item.productId]
            SectionCard(title = product?.name ?: item.productId) {
                InlineLabelValue("Qty", UiFormat.qty(item.qty))
                InlineLabelValue("Harga beli", UiFormat.money(item.buyPrice))
                InlineLabelValue("Subtotal", UiFormat.money(item.qty * item.buyPrice))
            }
        }
    }
}
