package com.warungarasaan.app.core

data class FinalGapCloseout(
    val compileReady: Boolean,
    val regressionReady: Boolean,
    val backupReady: Boolean,
    val printReady: Boolean,
    val routeCoverage: Int,
    val weakestModules: List<String>,
) {
    val completionPercent: Int
        get() {
            val binary = listOf(compileReady, regressionReady, backupReady, printReady)
                .count { it } * 20
            val routes = (routeCoverage.coerceIn(0, 100) * 20) / 100
            return (binary + routes).coerceIn(0, 100)
        }

    fun remainingPriorities(): List<String> {
        val priorities = mutableListOf<String>()
        if (!compileReady) priorities += "compile_hardening"
        if (!regressionReady) priorities += "transaction_regression"
        if (!backupReady) priorities += "backup_restore_regression"
        if (!printReady) priorities += "thermal_print_validation"
        if (routeCoverage < 100) priorities += "route_wiring"
        priorities += weakestModules.take(3)
        return priorities.distinct()
    }
}

object FinalGapCloseoutFactory {
    fun create(
        compileReady: Boolean,
        regressionReady: Boolean,
        backupReady: Boolean,
        printReady: Boolean,
        routeCoverage: Int,
        weakestModules: List<String>,
    ): FinalGapCloseout = FinalGapCloseout(
        compileReady = compileReady,
        regressionReady = regressionReady,
        backupReady = backupReady,
        printReady = printReady,
        routeCoverage = routeCoverage,
        weakestModules = weakestModules.filter { it.isNotBlank() },
    )
}
