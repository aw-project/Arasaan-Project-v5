package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ReportFilterUiState(
    val selectedRange: String = "30 hari",
    val selectedPaymentMethod: String = "Semua",
    val selectedCategory: String = "Semua"
)

@Composable
fun ReportParityFilters(
    state: ReportFilterUiState,
    paymentOptions: List<String>,
    categoryOptions: List<String>,
    onRangeChange: (String) -> Unit,
    onPaymentChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Filter laporan")
        CompactFilterRow(
            selected = state.selectedRange,
            options = listOf("Hari ini", "7 hari", "30 hari", "90 hari", "Custom"),
            onChange = onRangeChange
        )
        FilterChipRow(
            title = "Metode bayar",
            selected = state.selectedPaymentMethod,
            options = paymentOptions,
            onChange = onPaymentChange
        )
        FilterChipRow(
            title = "Kategori",
            selected = state.selectedCategory,
            options = categoryOptions,
            onChange = onCategoryChange
        )
    }
}

@Composable
private fun FilterChipRow(
    title: String,
    selected: String,
    options: List<String>,
    onChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.take(4).forEach { option ->
                FilterChip(
                    selected = option == selected,
                    onClick = { onChange(option) },
                    label = { Text(option) }
                )
            }
        }
    }
}
