package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.CashEntry
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.RejectedItem
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun FinanceModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var tab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    var cash by remember { mutableStateOf<List<CashEntry>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var rejected by remember { mutableStateOf<List<RejectedItem>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var showExpenseDialog by remember { mutableStateOf(false) }
    var showRejectDialog by remember { mutableStateOf(false) }
    var showCashDialog by remember { mutableStateOf(false) }
    var easyMode by remember { mutableStateOf(true) }

    suspend fun reload() {
        cash = container.cashRepository.all()
        expenses = container.expenseRepository.all()
        rejected = container.rejectedRepository.all()
        products = container.productRepository.all()
    }

    LaunchedEffect(Unit) { reload() }

    val cashIn = cash.filter { it.direction.equals("in", true) }.sumOf { it.amount }
    val cashOut = cash.filter { it.direction.equals("out", true) }.sumOf { it.amount }
    val cashBalance = cashIn - cashOut
    val ownerCapital = cash
        .filter { it.direction.equals("in", true) && (it.source.equals("owner_capital", true) || it.note.contains("modal", true)) }
        .sumOf { it.amount }
    val ownerDraw = cash
        .filter { it.direction.equals("out", true) && (it.source.contains("owner", true) || it.note.contains("pribadi", true)) }
        .sumOf { it.amount }
    val inventoryAsset = products.sumOf { it.stockQty.coerceAtLeast(0.0) * it.avgHpp.coerceAtLeast(0.0) }

    if (showCashDialog) {
        CashEntryDialog(
            onDismiss = { showCashDialog = false },
            onSave = { note, amount, direction, method, source ->
                scope.launch {
                    container.cashRepository.add(
                        CashEntry(
                            id = AppUtils.newId("cash"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            direction = direction,
                            source = source,
                            method = method,
                            note = note,
                            amount = amount,
                            refId = "",
                        )
                    )
                    container.activityLogRepository.log(
                        "cash",
                        "${if (direction.equals("in", true)) "Kas masuk" else "Kas keluar"}: $note",
                    )
                    reload()
                    showCashDialog = false
                }
            },
        )
    }

    if (showExpenseDialog) {
        ExpenseDialog(
            onDismiss = { showExpenseDialog = false },
            onSave = { note, amount, method, category ->
                scope.launch {
                    container.expenseRepository.add(
                        Expense(
                            id = AppUtils.newId("exp"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            note = note,
                            amount = amount,
                            paymentMethod = method,
                            category = category,
                        )
                    )
                    container.activityLogRepository.log("expense", "Biaya ditambah: $note")
                    reload()
                    showExpenseDialog = false
                }
            },
        )
    }

    if (showRejectDialog) {
        RejectDialog(
            products = products,
            onDismiss = { showRejectDialog = false },
            onSave = { productId, qty, reason ->
                scope.launch {
                    val product = products.firstOrNull { it.id == productId } ?: return@launch
                    container.rejectedRepository.add(
                        RejectedItem(
                            id = AppUtils.newId("reject"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            productId = productId,
                            qty = qty,
                            reason = reason,
                            handling = "Buang",
                            note = "",
                            hppAtTime = product.avgHpp,
                            estimatedLoss = qty * product.avgHpp,
                        )
                    )
                    container.activityLogRepository.log("reject", "Barang rejek ${product.name}")
                    reload()
                    showRejectDialog = false
                }
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { if (tab == 0) showCashDialog = true else if (tab == 1) showExpenseDialog = true else if (tab == 2) showRejectDialog = true }) {
                Text("+")
            }
        },
    ) { padding ->
        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(padding)) {
            SectionCard(
                title = if (easyMode) "Keuangan Harian" else "Keuangan Lengkap",
                subtitle = if (easyMode) "Pakai Kas untuk modal awal, Biaya untuk pengeluaran, dan Barang Rusak bila ada stok rusak." else "Semua tab keuangan ditampilkan."
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { easyMode = true }) { Text("Mode Mudah") }
                    TextButton(onClick = { easyMode = false }) { Text("Mode Lengkap") }
                }
            }
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Kas") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Biaya") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text(if (easyMode) "Barang Rusak" else "Rejek") })
            }
            when (tab) {
                0 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            InfoChip("Masuk ${UiFormat.money(cashIn)}")
                            InfoChip("Keluar ${UiFormat.money(cashOut)}")
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            InfoChip("Saldo kas ${UiFormat.money(cashBalance)}")
                            InfoChip("Modal owner ${UiFormat.money(ownerCapital)}")
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            InfoChip("Prive owner ${UiFormat.money(ownerDraw)}")
                            InfoChip("Nilai stok ${UiFormat.money(inventoryAsset)}")
                        }
                    }
                    item {
                        Text(
                            "Tips modal awal: catat setoran modal sebagai kas masuk. Jika modal awal dipakai untuk stok, tambahkan kas masuk dulu lalu input pembelian stok awal agar saldo kas, stok, dan HPP tetap rapi.",
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    item {
                        Text(
                            "Alur paling aman: 1) tambah produk, 2) input kas masuk modal awal, 3) input pembelian stok awal. Dengan pola ini laporan kas, persediaan, dan laba tidak rancu.",
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    if (cash.isEmpty()) item { EmptyHint("Belum ada kas", "Kas akan terbentuk otomatis dari pembelian, penjualan, dan biaya.") }
                    items(cash, key = { it.id }) { entry ->
                        ListItem(
                            headlineContent = { Text(entry.note) },
                            supportingContent = { Text("${entry.source} • ${entry.method}") },
                            overlineContent = { Text(UiFormat.date(entry.dateEpochDay)) },
                            trailingContent = { Text(UiFormat.money(entry.amount)) },
                        )
                    }
                }
                1 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (expenses.isEmpty()) item { EmptyHint("Belum ada biaya", "Tambahkan biaya operasional dari tombol tambah.") }
                    items(expenses, key = { it.id }) { expense ->
                        ListItem(
                            headlineContent = { Text(expense.note) },
                            supportingContent = { Text("${expense.category} • ${expense.paymentMethod}") },
                            overlineContent = { Text(UiFormat.date(expense.dateEpochDay)) },
                            trailingContent = { Text(UiFormat.money(expense.amount)) },
                        )
                        TextButton(
                            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp),
                            onClick = {
                                scope.launch {
                                    container.expenseRepository.remove(expense.id)
                                    reload()
                                }
                            },
                        ) { Text("Hapus") }
                    }
                }
                else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (rejected.isEmpty()) item { EmptyHint("Belum ada data rejek", "Tambah data barang rusak / hilang dari tombol tambah.") }
                    items(rejected, key = { it.id }) { item ->
                        val product = products.firstOrNull { it.id == item.productId }
                        ListItem(
                            headlineContent = { Text(product?.name ?: item.productId) },
                            supportingContent = { Text("${item.reason} • Qty ${UiFormat.qty(item.qty)}") },
                            overlineContent = { Text(UiFormat.date(item.dateEpochDay)) },
                            trailingContent = { Text(UiFormat.money(item.estimatedLoss)) },
                        )
                    }
                }
            }
        }
    }
}


@Composable
private fun CashEntryDialog(
    onDismiss: () -> Unit,
    onSave: (String, Double, String, String, String) -> Unit,
) {
    var note by remember { mutableStateOf("Setoran modal awal") }
    var amount by remember { mutableStateOf("0") }
    var direction by remember { mutableStateOf("in") }
    var method by remember { mutableStateOf("Cash") }
    var source by remember { mutableStateOf("owner_capital") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        note.ifBlank { if (direction == "in") "Kas masuk" else "Kas keluar" },
                        amount.toDoubleOrNull() ?: 0.0,
                        direction,
                        method,
                        source.ifBlank { if (direction == "in") "manual_in" else "manual_out" },
                    )
                },
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Tambah Kas / Modal") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(amount, { amount = it }, label = { Text("Nominal") }, modifier = Modifier.fillMaxWidth()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = {
                            note = "Setoran modal awal"
                            direction = "in"
                            source = "owner_capital"
                            method = "Cash"
                        }) { Text("Preset modal") }
                        TextButton(onClick = {
                            note = "Prive owner"
                            direction = "out"
                            source = "owner_draw"
                            method = "Cash"
                        }) { Text("Preset prive") }
                    }
                }
                item { OutlinedTextField(direction, { direction = it.lowercase() }, label = { Text("Arah kas: in / out") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(method, { method = it }, label = { Text("Metode") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(source, { source = it }, label = { Text("Sumber") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}

@Composable
private fun ExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (String, Double, String, String) -> Unit,
) {
    var note by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("0") }
    var method by remember { mutableStateOf("Cash") }
    var category by remember { mutableStateOf("Lainnya") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(note, amount.toDoubleOrNull() ?: 0.0, method, category) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Tambah Biaya") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(amount, { amount = it }, label = { Text("Nominal") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(method, { method = it }, label = { Text("Metode bayar") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(category, { category = it }, label = { Text("Kategori") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}

@Composable
private fun RejectDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onSave: (String, Double, String) -> Unit,
) {
    var productId by remember { mutableStateOf(products.firstOrNull()?.id.orEmpty()) }
    var qty by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("Rusak") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(productId, qty.toDoubleOrNull() ?: 0.0, reason) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Tambah Rejek") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(productId, { productId = it }, label = { Text("Product ID") }, modifier = Modifier.fillMaxWidth()) }
                item { Text("Produk tersedia: " + products.take(5).joinToString { "${it.id}=${it.name}" }) }
                item { OutlinedTextField(qty, { qty = it }, label = { Text("Qty") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(reason, { reason = it }, label = { Text("Alasan") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}
