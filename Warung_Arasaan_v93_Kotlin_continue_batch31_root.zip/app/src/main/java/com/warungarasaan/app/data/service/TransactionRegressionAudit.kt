
package com.warungarasaan.app.data.service

import com.warungarasaan.app.core.RegressionGuards

data class RegressionAuditInput(
    val itemCount: Int,
    val transactionTotal: Double,
    val projectedStock: Double,
    val debtPrincipal: Double = 0.0,
    val debtPaid: Double = 0.0,
    val cashBefore: Double = 0.0,
    val cashDelta: Double = 0.0,
)

data class RegressionAuditResult(
    val valid: Boolean,
    val reasons: List<String>,
)

object TransactionRegressionAudit {
    fun validate(input: RegressionAuditInput): RegressionAuditResult {
        val reasons = mutableListOf<String>()
        if (!RegressionGuards.preventEmptyTransaction(input.itemCount, input.transactionTotal)) {
            reasons += "Transaksi harus punya item dan total yang valid."
        }
        if (!RegressionGuards.preventNegativeStock(input.projectedStock)) {
            reasons += "Stok hasil transaksi tidak boleh negatif."
        }
        if (!RegressionGuards.preventOverpayment(input.debtPrincipal, input.debtPaid)) {
            reasons += "Pembayaran hutang melebihi pokok."
        }
        if (!RegressionGuards.preventInvalidCashMutation(input.cashBefore, input.cashDelta)) {
            reasons += "Mutasi kas menghasilkan saldo tidak valid."
        }
        return RegressionAuditResult(valid = reasons.isEmpty(), reasons = reasons)
    }
}
