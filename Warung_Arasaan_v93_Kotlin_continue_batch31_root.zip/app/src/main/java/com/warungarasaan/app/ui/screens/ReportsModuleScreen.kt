package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.data.service.ReportExportService
import com.warungarasaan.app.data.service.ReportingService
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.ui.QuickRangeChips
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat

private data class ProductSalesRow(
    val productName: String,
    val qty: Double,
    val omzet: Double,
    val hpp: Double,
)

@Composable
fun ReportsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var rangeDays by remember { mutableStateOf(7) }
    var omzet by remember { mutableStateOf(0.0) }
    var hpp by remember { mutableStateOf(0.0) }
    var expense by remember { mutableStateOf(0.0) }
    var purchase by remember { mutableStateOf(0.0) }
    var debtRemaining by remember { mutableStateOf(0.0) }
    var stockValue by remember { mutableStateOf(0.0) }
    var rejectLoss by remember { mutableStateOf(0.0) }
    var csvPreview by remember { mutableStateOf("") }
    var topProducts by remember { mutableStateOf<List<ProductSalesRow>>(emptyList()) }
    var lowStock by remember { mutableStateOf<List<Product>>(emptyList()) }

    LaunchedEffect(rangeDays) {
        val today = AppUtils.epochDayNow()
        val minDay = today - (rangeDays - 1)
        val sales = container.salesRepository.all().filter { it.dateEpochDay in minDay..today }
        val expenses = container.expenseRepository.all().filter { it.dateEpochDay in minDay..today }
        val purchases = container.purchaseRepository.all().filter { it.dateEpochDay in minDay..today }
        val debts = container.debtRepository.all()
        val products = container.productRepository.all()
        val rejected = container.rejectedRepository.all().filter { it.dateEpochDay in minDay..today }

        val summary = ReportingService.summarize(sales, expenses, rejected)
        omzet = summary.omzet
        hpp = summary.totalHpp
        expense = summary.totalBiaya
        purchase = purchases.sumOf { it.items.sumOf { item -> item.qty * item.buyPrice } }
        debtRemaining = debts.sumOf { it.remaining }
        stockValue = products.sumOf { it.stockQty * it.avgHpp }
        rejectLoss = summary.rugiRejek
        csvPreview = ReportExportService.salesCsv(sales.take(25), products)

        val productNames = products.associateBy({ it.id }, { it.name })
        topProducts = sales
            .flatMap { sale -> sale.items }
            .groupBy { it.productId }
            .map { (productId, rows) ->
                ProductSalesRow(
                    productName = productNames[productId] ?: productId,
                    qty = rows.sumOf { it.qty },
                    omzet = rows.sumOf { it.total },
                    hpp = rows.sumOf { it.totalHpp },
                )
            }
            .sortedByDescending { it.omzet }
            .take(10)

        lowStock = products.filter { it.minStock > 0.0 && it.stockQty <= it.minStock }.sortedBy { it.stockQty - it.minStock }.take(10)
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Laporan", style = MaterialTheme.typography.headlineSmall) }
        item {
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7, 30, 90, 365).forEach { days ->
                    AssistChip(
                        onClick = { rangeDays = days },
                        label = { Text("$days hari") },
                    )
                }
            }
        }
        item { StatCard("Periode Aktif", "$rangeDays hari", "Filter ringkas untuk mendekatkan halaman reports Flutter") }
        item { StatCard("Omzet", UiFormat.money(omzet), "Akumulasi total penjualan") }
        item { StatCard("HPP", UiFormat.money(hpp), "Akumulasi cost barang terjual") }
        item { StatCard("Profit kotor", UiFormat.money(omzet - hpp), "Omzet - HPP") }
        item { StatCard("Biaya operasional", UiFormat.money(expense), "Total pengeluaran") }
        item { StatCard("Profit bersih estimasi", UiFormat.money((omzet - hpp) - expense - rejectLoss), "Profit kotor - biaya - kerugian rejek") }
        item { HorizontalDivider() }
        item { StatCard("Nilai pembelian", UiFormat.money(purchase), "Pembelian stok pada periode aktif") }
        item { StatCard("Sisa hutang", UiFormat.money(debtRemaining), "Outstanding hutang yang belum lunas") }
        item { StatCard("Nilai stok", UiFormat.money(stockValue), "StockQty x AvgHPP") }
        item { StatCard("Rugi rejek", UiFormat.money(rejectLoss), "Estimasi loss barang reject/retur") }
        item { HorizontalDivider() }
        item {
            SectionCard("Produk terlaris", subtitle = "Top 10 berdasarkan omzet periode aktif") {
                if (topProducts.isEmpty()) {
                    Text("Belum ada data penjualan pada periode ini.")
                } else {
                    topProducts.forEach { row ->
                        Text("${row.productName} • Qty ${UiFormat.qty(row.qty)} • Omzet ${UiFormat.money(row.omzet)} • Profit ${UiFormat.money(row.omzet - row.hpp)}")
                    }
                }
            }
        }
        item {
            SectionCard("Stok kritis", subtitle = "Produk yang perlu restock segera") {
                if (lowStock.isEmpty()) {
                    Text("Tidak ada stok kritis.")
                } else {
                    lowStock.forEach { product ->
                        Text("${product.name} • Stok ${UiFormat.qty(product.stockQty)} / Min ${UiFormat.qty(product.minStock)}")
                    }
                }
            }
        }
        item {
            SectionCard("Preview CSV Penjualan", subtitle = "Potongan isi export CSV, belum menulis langsung ke file pada layar ini.") {
                OutlinedTextField(
                    value = csvPreview,
                    onValueChange = {},
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp),
                    readOnly = true,
                    label = { Text("CSV") },
                )
                TextButton(onClick = {
                    csvPreview = csvPreview
                }) { Text("Refresh Preview") }
            }
        }
    }
}
