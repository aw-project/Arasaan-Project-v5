package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

private data class CustomerStats(
    val name: String,
    val saleCount: Int,
    val totalSpend: Double,
    val totalProfit: Double,
    val totalQty: Double,
    val creditSales: Double,
    val lastEpochDay: Int?,
)

@Composable
fun CustomersModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<CustomerStats>>(emptyList()) }

    LaunchedEffect(Unit) {
        val stats = linkedMapOf<String, CustomerStats>()
        container.salesRepository.all().forEach { sale ->
            val name = sale.customerName.trim()
            if (name.isEmpty()) return@forEach
            val previous = stats[name]
            val next = CustomerStats(
                name = name,
                saleCount = (previous?.saleCount ?: 0) + 1,
                totalSpend = (previous?.totalSpend ?: 0.0) + sale.totalSales,
                totalProfit = (previous?.totalProfit ?: 0.0) + sale.totalProfit,
                totalQty = (previous?.totalQty ?: 0.0) + sale.items.sumOf { it.qty },
                creditSales = (previous?.creditSales ?: 0.0) + if (sale.paymentMethod.equals("Hutang", true)) sale.totalSales else 0.0,
                lastEpochDay = maxOf(previous?.lastEpochDay ?: Int.MIN_VALUE, sale.dateEpochDay).takeIf { it != Int.MIN_VALUE },
            )
            stats[name] = next
        }
        items = stats.values.sortedByDescending { it.totalSpend }
    }

    val filtered = remember(items, query) {
        val q = query.trim().lowercase()
        items.filter { q.isBlank() || it.name.lowercase().contains(q) }
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(
                title = "Pelanggan",
                subtitle = "Padanan customers_page.dart dengan ringkasan pelanggan dari histori penjualan.",
            ) {
                Text("Jumlah pelanggan: ${filtered.size}")
                Text("Total spend: ${UiFormat.money(filtered.sumOf { it.totalSpend })}")
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Cari pelanggan") },
                modifier = Modifier,
                singleLine = true,
            )
        }
        if (filtered.isEmpty()) {
            item {
                EmptyHint(
                    title = "Belum ada pelanggan",
                    subtitle = "Nama pelanggan akan muncul otomatis dari transaksi penjualan.",
                )
            }
        } else {
            items(filtered, key = { it.name }) { customer ->
                ListItem(
                    headlineContent = { Text(customer.name) },
                    supportingContent = {
                        Text(
                            "Belanja ${customer.saleCount}x • Qty ${UiFormat.qty(customer.totalQty)} • Profit ${UiFormat.money(customer.totalProfit)}"
                        )
                    },
                    trailingContent = {
                        Text(UiFormat.money(customer.totalSpend))
                    },
                    overlineContent = {
                        Text(
                            buildString {
                                append("Piutang jual ")
                                append(UiFormat.money(customer.creditSales))
                                customer.lastEpochDay?.let { append(" • Terakhir ${UiFormat.date(it)}") }
                            }
                        )
                    },
                )
            }
        }
    }
}
