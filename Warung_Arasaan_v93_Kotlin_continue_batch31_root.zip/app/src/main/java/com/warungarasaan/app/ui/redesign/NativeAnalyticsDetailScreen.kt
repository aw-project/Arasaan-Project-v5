package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

data class AnalyticsInsightUi(
    val title: String,
    val value: String,
    val note: String
)

@Composable
fun NativeAnalyticsDetailScreen(
    range: String,
    productName: String,
    insights: List<AnalyticsInsightUi>
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Analitik Produk • $productName") }
        item { Text("Rentang: $range") }
        items(insights.size) { index ->
            val item = insights[index]
            Card {
                ListItem(
                    headlineContent = { Text(item.title) },
                    supportingContent = { Text(item.note) },
                    trailingContent = { Text(item.value) }
                )
            }
        }
    }
}
