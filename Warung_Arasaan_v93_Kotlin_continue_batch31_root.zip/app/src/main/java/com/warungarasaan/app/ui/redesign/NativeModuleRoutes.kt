package com.warungarasaan.app.ui.redesign

object NativeModuleRoutes {
    const val Home = "home"
    const val Dashboard = "dashboard"
    const val Products = "products"
    const val Purchases = "purchases"
    const val Sales = "sales"
    const val FastPos = "fast_pos"
    const val Finance = "finance"
    const val Cash = "cash"
    const val Expenses = "expenses"
    const val Debts = "debts"
    const val Rejected = "rejected"
    const val Reports = "reports"
    const val Analytics = "analytics"
    const val Customers = "customers"
    const val Suppliers = "suppliers"
    const val Settings = "settings"
    const val Backup = "backup"
    const val PrintCenter = "print_center"
    const val GlobalSearch = "global_search"
    const val ActivityLog = "activity_log"
    const val StockAdjustment = "stock_adjustment"
    const val StockOpname = "stock_opname"
}

fun nativePrimaryRoutes(): List<String> = listOf(
    NativeModuleRoutes.Home,
    NativeModuleRoutes.Dashboard,
    NativeModuleRoutes.Products,
    NativeModuleRoutes.Purchases,
    NativeModuleRoutes.Sales,
    NativeModuleRoutes.FastPos,
    NativeModuleRoutes.Finance,
    NativeModuleRoutes.Cash,
    NativeModuleRoutes.Expenses,
    NativeModuleRoutes.Debts,
    NativeModuleRoutes.Rejected,
    NativeModuleRoutes.Reports,
    NativeModuleRoutes.Analytics
)
