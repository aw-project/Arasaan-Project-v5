package com.warungarasaan.app.core

data class RegressionScenario(
    val key: String,
    val covered: Boolean,
    val critical: Boolean = true,
)

data class RegressionScenarioMatrix(
    val scenarios: List<RegressionScenario>,
) {
    fun coveragePercent(): Int {
        if (scenarios.isEmpty()) return 0
        return ((scenarios.count { it.covered }.toDouble() / scenarios.size.toDouble()) * 100.0).toInt()
    }

    fun criticalBlockers(): List<String> =
        scenarios.filter { it.critical && !it.covered }.map { it.key }

    fun isPilotSafe(): Boolean = criticalBlockers().isEmpty()
}

object RegressionScenarioMatrixFactory {
    fun createDefault(
        saleCreate: Boolean,
        saleEdit: Boolean,
        purchaseCreate: Boolean,
        purchaseEdit: Boolean,
        stockAdjustment: Boolean,
        stockOpname: Boolean,
        reportExport: Boolean,
        backupRestore: Boolean,
        receiptShare: Boolean,
        thermalPrint: Boolean,
    ): RegressionScenarioMatrix = RegressionScenarioMatrix(
        scenarios = listOf(
            RegressionScenario("sale_create", saleCreate),
            RegressionScenario("sale_edit", saleEdit),
            RegressionScenario("purchase_create", purchaseCreate),
            RegressionScenario("purchase_edit", purchaseEdit),
            RegressionScenario("stock_adjustment", stockAdjustment),
            RegressionScenario("stock_opname", stockOpname),
            RegressionScenario("report_export", reportExport, critical = false),
            RegressionScenario("backup_restore", backupRestore),
            RegressionScenario("receipt_share", receiptShare, critical = false),
            RegressionScenario("thermal_print", thermalPrint, critical = false),
        )
    )
}
