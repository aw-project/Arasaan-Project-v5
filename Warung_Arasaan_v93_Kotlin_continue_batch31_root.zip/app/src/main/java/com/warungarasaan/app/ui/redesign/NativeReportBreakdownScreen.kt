package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

data class ReportBreakdownRowUi(
    val title: String,
    val value: String,
    val note: String = ""
)

@Composable
fun NativeReportBreakdownScreen(
    filters: ReportFilterUiState,
    rows: List<ReportBreakdownRowUi>,
    onRangeChange: (String) -> Unit,
    onPaymentChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionHeader("Breakdown Laporan") }
        item {
            ReportParityFilters(
                state = filters,
                paymentOptions = listOf("Semua", "Cash", "QRIS", "Transfer"),
                categoryOptions = listOf("Semua", "Operasional", "Belanja", "Lainnya"),
                onRangeChange = onRangeChange,
                onPaymentChange = onPaymentChange,
                onCategoryChange = onCategoryChange
            )
        }
        items(rows.size) { index ->
            val row = rows[index]
            Card {
                ListItem(
                    headlineContent = { Text(row.title) },
                    supportingContent = { if (row.note.isNotBlank()) Text(row.note) },
                    trailingContent = { Text(row.value) }
                )
            }
        }
    }
}
