package com.warungarasaan.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import kotlinx.coroutines.launch

@Composable
fun LockGate(
    container: AppContainer,
    content: @Composable () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var pinEnabled by remember { mutableStateOf(false) }
    var unlocked by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        pinEnabled = container.settingsRepository.get()?.pinEnabled == true
        unlocked = !pinEnabled
    }

    content()

    if (pinEnabled && !unlocked) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        unlocked = container.settingsRepository.verifyPin(pinInput)
                        errorText = if (unlocked) "" else "PIN salah."
                        if (unlocked) {
                            pinInput = ""
                        }
                    }
                }) { Text("Buka") }
            },
            title = { Text("Aplikasi Terkunci") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Masukkan PIN untuk membuka Warung Arasaan.")
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { pinInput = it },
                        label = { Text("PIN") },
                    )
                    if (errorText.isNotBlank()) {
                        Text(errorText)
                    }
                }
            },
        )
    }
}
