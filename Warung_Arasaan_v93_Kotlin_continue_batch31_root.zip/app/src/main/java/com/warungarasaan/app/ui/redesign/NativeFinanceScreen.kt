package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.CreditScore
import androidx.compose.material.icons.rounded.MoneyOff
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.domain.model.CashEntry
import com.warungarasaan.app.domain.model.Debt
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.ui.UiFormat

@Composable
fun NativeFinanceScreen(
    cashEntries: List<CashEntry>,
    expenses: List<Expense>,
    debts: List<Debt>,
    onOpenCash: () -> Unit = {},
    onOpenExpenses: () -> Unit = {},
    onOpenDebts: () -> Unit = {},
) {
    val cashIn = cashEntries.filter { it.direction.equals("in", true) }.sumOf { it.amount }
    val cashOut = cashEntries.filter { it.direction.equals("out", true) }.sumOf { it.amount }
    val expenseTotal = expenses.sumOf { it.amount }
    val debtRemaining = debts.sumOf { it.remaining }

    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        SectionHeader(
            title = "Keuangan",
            subtitle = "Ringkas, cepat, dan fokus ke saldo harian serta kewajiban aktif.",
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryMiniCard("Kas Masuk", UiFormat.money(cashIn), Icons.Rounded.Payments, Modifier.weight(1f))
            SummaryMiniCard("Kas Keluar", UiFormat.money(cashOut), Icons.Rounded.MoneyOff, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryMiniCard("Biaya", UiFormat.money(expenseTotal), Icons.Rounded.AccountBalanceWallet, Modifier.weight(1f))
            SummaryMiniCard("Sisa Hutang", UiFormat.money(debtRemaining), Icons.Rounded.CreditScore, Modifier.weight(1f))
        }

        FilledTonalButton(onClick = onOpenCash, modifier = Modifier.fillMaxWidth()) { Text("Buka Kas") }
        FilledTonalButton(onClick = onOpenExpenses, modifier = Modifier.fillMaxWidth()) { Text("Buka Biaya") }
        FilledTonalButton(onClick = onOpenDebts, modifier = Modifier.fillMaxWidth()) { Text("Buka Hutang") }
    }
}
