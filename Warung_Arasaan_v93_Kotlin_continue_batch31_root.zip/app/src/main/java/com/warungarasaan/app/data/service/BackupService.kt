
package com.warungarasaan.app.data.service

import com.warungarasaan.app.data.local.AppDatabase
import com.warungarasaan.app.domain.model.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class BackupPayload(
    val products: List<ProductSnapshot> = emptyList(),
    val purchases: List<PurchaseSnapshot> = emptyList(),
    val sales: List<SaleSnapshot> = emptyList(),
    val expenses: List<ExpenseSnapshot> = emptyList(),
    val debts: List<DebtSnapshot> = emptyList(),
    val movements: List<StockMovementSnapshot> = emptyList(),
    val cash: List<CashEntrySnapshot> = emptyList(),
    val rejectedItems: List<RejectedItemSnapshot> = emptyList(),
    val activityLogs: List<ActivityLogSnapshot> = emptyList(),
    val settings: AppSettingsSnapshot? = null,
)

@Serializable data class ProductSnapshot(val id: String, val name: String, val unit: String, val defaultMarginPercent: Double, val activeSellPrice: Double, val stockQty: Double, val avgHpp: Double, val minStock: Double, val targetStock: Double, val sku: String, val category: String, val imagePath: String? = null)
@Serializable data class PurchaseItemSnapshot(val productId: String, val qty: Double, val buyPrice: Double)
@Serializable data class PurchaseSnapshot(val id: String, val dateEpochDay: Int, val supplier: String, val paymentMethod: String, val items: List<PurchaseItemSnapshot>)
@Serializable data class SaleItemSnapshot(val productId: String, val qty: Double, val sellPrice: Double, val hppAtSale: Double)
@Serializable data class PaymentSplitSnapshot(val method: String, val amount: Double)
@Serializable data class SaleSnapshot(val id: String, val dateEpochDay: Int, val items: List<SaleItemSnapshot>, val paymentMethod: String, val customerName: String, val discountAmount: Double, val paymentSplits: List<PaymentSplitSnapshot>)
@Serializable data class ExpenseSnapshot(val id: String, val dateEpochDay: Int, val note: String, val amount: Double, val paymentMethod: String, val category: String)
@Serializable data class DebtSnapshot(val id: String, val dateEpochDay: Int, val creditor: String, val note: String, val principal: Double, val paid: Double)
@Serializable data class StockMovementSnapshot(val id: String, val dateEpochDay: Int, val productId: String, val type: String, val qtyDelta: Double, val note: String, val lossType: String? = null, val lossAmount: Double = 0.0)
@Serializable data class CashEntrySnapshot(val id: String, val dateEpochDay: Int, val direction: String, val source: String, val method: String, val note: String, val amount: Double, val refId: String)
@Serializable data class RejectedItemSnapshot(val id: String, val dateEpochDay: Int, val productId: String, val qty: Double, val reason: String, val handling: String, val note: String, val hppAtTime: Double, val estimatedLoss: Double)
@Serializable data class ActivityLogSnapshot(val id: String, val dateEpochDay: Int, val type: String, val refId: String, val oldJson: String, val newJson: String)
@Serializable data class AppSettingsSnapshot(val id: String = "app", val pinEnabled: Boolean, val pinHash: String)

object BackupService {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    fun toJson(
        products: List<Product>,
        purchases: List<Purchase>,
        sales: List<Sale>,
        expenses: List<Expense>,
        debts: List<Debt>,
        movements: List<StockMovement>,
        cash: List<CashEntry>,
        rejectedItems: List<RejectedItem>,
        activityLogs: List<ActivityLog>,
        settings: AppSettings,
    ): String {
        val payload = BackupPayload(
            products = products.map { ProductSnapshot(it.id, it.name, it.unit, it.defaultMarginPercent, it.activeSellPrice, it.stockQty, it.avgHpp, it.minStock, it.targetStock, it.sku, it.category, it.imagePath) },
            purchases = purchases.map { purchase -> PurchaseSnapshot(purchase.id, purchase.dateEpochDay, purchase.supplier, purchase.paymentMethod, purchase.items.map { PurchaseItemSnapshot(it.productId, it.qty, it.buyPrice) }) },
            sales = sales.map { sale -> SaleSnapshot(sale.id, sale.dateEpochDay, sale.items.map { SaleItemSnapshot(it.productId, it.qty, it.sellPrice, it.hppAtSale) }, sale.paymentMethod, sale.customerName, sale.discountAmount, sale.paymentSplits.map { PaymentSplitSnapshot(it.method, it.amount) }) },
            expenses = expenses.map { ExpenseSnapshot(it.id, it.dateEpochDay, it.note, it.amount, it.paymentMethod, it.category) },
            debts = debts.map { DebtSnapshot(it.id, it.dateEpochDay, it.creditor, it.note, it.principal, it.paid) },
            movements = movements.map { StockMovementSnapshot(it.id, it.dateEpochDay, it.productId, it.type, it.qtyDelta, it.note, it.lossType, it.lossAmount) },
            cash = cash.map { CashEntrySnapshot(it.id, it.dateEpochDay, it.direction, it.source, it.method, it.note, it.amount, it.refId) },
            rejectedItems = rejectedItems.map { RejectedItemSnapshot(it.id, it.dateEpochDay, it.productId, it.qty, it.reason, it.handling, it.note, it.hppAtTime, it.estimatedLoss) },
            activityLogs = activityLogs.map { ActivityLogSnapshot(it.id, it.dateEpochDay, it.type, it.refId, it.oldJson, it.newJson) },
            settings = AppSettingsSnapshot(settings.id, settings.pinEnabled, settings.pinHash),
        )
        return json.encodeToString(payload)
    }

    fun fromJson(value: String): BackupPayload = json.decodeFromString<BackupPayload>(value)

    fun exportJson(
        products: List<Product>,
        purchases: List<Purchase>,
        sales: List<Sale>,
        expenses: List<Expense>,
        debts: List<Debt>,
        movements: List<StockMovement>,
        cash: List<CashEntry>,
        rejectedItems: List<RejectedItem>,
        activityLogs: List<ActivityLog>,
        settings: AppSettings,
    ): String = toJson(products, purchases, sales, expenses, debts, movements, cash, rejectedItems, activityLogs, settings)

    fun restoreJson(value: String): BackupPayload = fromJson(value)

    suspend fun restoreJson(database: AppDatabase, value: String): BackupPayload {
        return fromJson(value)
    }

    fun payloadSummary(payload: BackupPayload): String =
        "Produk ${payload.products.size}, Pembelian ${payload.purchases.size}, Penjualan ${payload.sales.size}, Biaya ${payload.expenses.size}, Hutang ${payload.debts.size}, Rejek ${payload.rejectedItems.size}"
}
