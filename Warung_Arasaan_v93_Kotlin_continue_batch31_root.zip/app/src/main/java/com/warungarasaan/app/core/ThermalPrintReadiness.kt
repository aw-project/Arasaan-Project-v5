package com.warungarasaan.app.core

data class ThermalPrintReadiness(
    val bluetoothEnabled: Boolean,
    val connectGranted: Boolean,
    val scanGranted: Boolean,
    val pairedPrinterAvailable: Boolean,
) {
    val canAttemptPrint: Boolean =
        bluetoothEnabled && connectGranted && pairedPrinterAvailable

    val warnings: List<String>
        get() = buildList {
            if (!bluetoothEnabled) add("Bluetooth belum aktif")
            if (!connectGranted) add("Izin BLUETOOTH_CONNECT belum diberikan")
            if (!scanGranted) add("Izin BLUETOOTH_SCAN belum diberikan")
            if (!pairedPrinterAvailable) add("Belum ada printer thermal yang terpasang")
        }

    companion object {
        fun fromPermissions(
            bluetoothEnabled: Boolean,
            permissions: Set<String>,
            pairedPrinterAvailable: Boolean,
        ): ThermalPrintReadiness {
            return ThermalPrintReadiness(
                bluetoothEnabled = bluetoothEnabled,
                connectGranted = "BLUETOOTH_CONNECT" in permissions,
                scanGranted = "BLUETOOTH_SCAN" in permissions,
                pairedPrinterAvailable = pairedPrinterAvailable,
            )
        }
    }
}
