package com.warungarasaan.app.data.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class NotificationService(private val context: Context) {
    private val manager: NotificationManagerCompat = NotificationManagerCompat.from(context)

    fun init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_LOW_STOCK,
                "Stok Menipis",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "Notifikasi produk dengan stok di bawah minimum"
            }
            context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    fun checkLowStock(products: List<com.warungarasaan.app.domain.model.Product>) {
        val lowStock = products.filter { it.minStock > 0.0 && it.stockQty <= it.minStock }
        if (lowStock.isEmpty()) {
            manager.cancel(LOW_STOCK_NOTIFICATION_ID)
            return
        }
        if (!canPostNotifications()) return

        val names = lowStock.take(3).joinToString(", ") { it.name }
        val extra = if (lowStock.size > 3) ", dan ${lowStock.size - 3} lainnya" else ""
        val body = if (lowStock.size == 1) {
            "$names hampir habis. Segera lakukan restok."
        } else {
            "$names$extra hampir habis."
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_LOW_STOCK)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⚠️ ${lowStock.size} Produk Stok Menipis")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .build()

        manager.notify(LOW_STOCK_NOTIFICATION_ID, notification)
    }

    private fun canPostNotifications(): Boolean {
        return Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val CHANNEL_LOW_STOCK = "low_stock"
        private const val LOW_STOCK_NOTIFICATION_ID = 1
    }
}
