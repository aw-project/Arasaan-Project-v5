# Batch 12 Architecture Cleanup

- satukan repository interfaces
- tambah ViewModel per screen
- tambah use-case layer untuk import/export/report
- pisahkan mapper entity/domain/snapshot
- tambah instrumented test untuk Room transaction parity
