# Conversion Status V32

## Fokus batch
- Menutup gap parity pada **Reports** dan **Analytics**
- Menambah audit **backup/restore regression**
- Menurunkan risiko compile dengan menyelaraskan module screen ke utility/state yang sudah ada

## Perubahan source nyata
- `NativeReportsModuleScreen.kt`
  - sekarang memakai `ReportingService`
  - memasukkan `rejectedRepository`
  - menampilkan breakdown yang lebih dekat ke alur laporan operasional
- `NativeAnalyticsModuleScreen.kt`
  - sekarang memakai `AnalyticsBreakdownCalculator`
  - menurunkan mismatch antara state analitik dan screen breakdown
- `BackupRestoreRegressionMatrix.kt`
  - menambah audit coverage payload restore
- test tambahan:
  - `BackupRestoreRegressionMatrixTest.kt`
  - `NativeAnalyticsModuleScreenContractTest.kt`

## Status jujur
Belum 100% dan belum build-verified.

## Estimasi setelah V32
- overall parity vs Flutter awal: ~97%
- reports/analytics parity: ~92%
- hardening/testing: ~73%

## Gap yang tersisa
1. Build verification nyata di Android Studio/Gradle
2. Regression transaksi + backup/restore end-to-end
3. Validasi Bluetooth/thermal di device nyata
4. Wiring akhir beberapa detail/breakdown flow
