V25 melanjutkan sprint akselerasi dengan fokus parity laporan dan analytics.

File baru:
- ReportParityFilters.kt
- NativeReportBreakdownScreen.kt
- AnalyticsBreakdownCalculator.kt
- NativeAnalyticsBreakdownScreen.kt
- AnalyticsBreakdownCalculatorTest.kt

Catatan:
Batch ini sengaja kecil tapi langsung menyentuh gap terbesar setelah transaksi:
laporan, breakdown analytics, dan regression-friendly test.
