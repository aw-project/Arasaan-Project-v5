# Batch 10 Parity Checklist

- verifikasi weighted HPP sesudah pembelian
- verifikasi pengurangan stok sesudah penjualan
- verifikasi split payment sale == total akhir
- verifikasi cash entry untuk purchase/sale/expense/debt/reject
- verifikasi stock movement purchase/sale/reject/adjust
- verifikasi report summary vs source Flutter
- verifikasi analytics top selling/top profit/top loss
