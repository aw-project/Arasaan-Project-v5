# CONTINUATION_2_NOTES

Perubahan batch lanjutan:
- Produk:
  - detail produk
  - stock adjustment manual
  - stock opname
  - riwayat movement per produk
- Pembelian:
  - edit transaksi existing
  - reuse multi-item form untuk create/update
- Penjualan:
  - edit transaksi existing
  - reuse multi-item form untuk create/update
- Repository:
  - `getById(...)`
  - `replace(...)` untuk purchase dan sale

Catatan:
- Ini masih best-effort parity Kotlin native, bukan hasil build-verified.
- Stock adjustment/opname saat ini memperbarui stok dan movement, namun belum menghitung ulang HPP kompleks.
- Receipt printer dan SAF file picker Android belum ditambahkan pada batch ini.
