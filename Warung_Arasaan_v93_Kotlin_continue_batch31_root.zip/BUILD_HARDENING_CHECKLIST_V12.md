# Build Hardening Checklist V12

- [ ] sync Gradle di Android Studio
- [ ] pastikan plugin versions cocok dengan Compose compiler
- [ ] jalankan `./gradlew assembleDebug`
- [ ] jalankan unit test
- [ ] jalankan androidTest repository
- [ ] verifikasi SAF export/import di device Android 13+
- [ ] verifikasi BLUETOOTH_CONNECT runtime permission
- [ ] uji print thermal dengan printer ESC/POS nyata
