# Batch 5 — Kas, Pengeluaran, Rejek

- finance shell
- expense/reject/cash mapping
