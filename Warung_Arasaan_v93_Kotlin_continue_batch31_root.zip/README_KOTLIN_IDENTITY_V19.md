# Kotlin Identity Pass V19

Pass ini melanjutkan arah native Android:
- menjaga fungsi inti hasil konversi sebelumnya
- menambah komponen UI yang terasa lebih Kotlin/Compose
- memperhatikan fitur lain sambil redesign, bukan hanya kosmetik

## Fokus V19
- navigasi bawah native
- quick actions untuk alur harian
- pencarian inline yang konsisten
- KPI strip ringkas
- filter row yang lebih cepat
- draft layar native untuk dashboard, produk, kasir, dan laporan

## Catatan
Pass ini belum memaksa penggantian root lama.
Komponen baru disiapkan sebagai lapisan redesign bertahap agar integrasi ke source existing lebih aman.
