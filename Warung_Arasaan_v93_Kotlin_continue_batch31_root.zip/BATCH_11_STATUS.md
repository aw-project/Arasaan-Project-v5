# Batch 11 — UX polish

- modular screen shell
- navigable feature cards
