# Batch 8 — Reports dan Analytics

- report summary service
- analytics service
- forecast/top selling/top profit/top loss
