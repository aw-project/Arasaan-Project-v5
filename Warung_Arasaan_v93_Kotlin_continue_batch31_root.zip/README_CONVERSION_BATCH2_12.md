# Warung Arasaan Kotlin Native — Auto Batch 2 to 12

Paket ini melanjutkan `batch1` dan menambahkan:

- shell UI Compose untuk seluruh modul utama
- service `AnalyticsService`, `ReportingService`, `BackupService`, `ReceiptService`
- pemetaan batch 2 sampai 12 ke modul Kotlin native
- catatan status per batch

Target utama paket ini adalah mempercepat parity fungsi dari source Flutter besar secara bertahap tanpa menghapus aturan bisnis inti yang sudah dipindahkan pada batch 1.
