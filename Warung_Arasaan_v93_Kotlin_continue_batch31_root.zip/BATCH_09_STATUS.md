# Batch 9 — Settings dan Backup

- settings shell
- backup JSON payload service
