# Warung Arasaan Kotlin Identity V22

Batch ini mempercepat progress dengan cara:
1. mengintegrasikan redesign ke root,
2. tetap memakai repository lama,
3. mengurangi jarak antara source Flutter dan flow native Kotlin.

Target batch berikutnya:
- create/edit transaction parity
- compile-hardening
- regression pass
