# Build Hardening Checklist V9

## Fokus saat dibuka di Android Studio
- sync Gradle
- generate Room schema / KSP output
- cek manifest permission dan FileProvider
- jalankan unit test service
- cek import Compose yang bentrok
- verifikasi resource launcher icon
- verifikasi package namespace
- verifikasi target / compile SDK lokal

## Prioritas bugfix
1. compile error import / unresolved reference
2. Room annotation / DAO mismatch
3. Compose state / remember misuse
4. SAF file picker contract
5. instrumented test dependency mismatch
