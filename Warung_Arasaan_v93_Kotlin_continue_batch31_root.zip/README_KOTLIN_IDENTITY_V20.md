# Warung Arasaan Kotlin Identity V20

Pass ini melanjutkan redesign native Kotlin tanpa mengejar identik Flutter.

## Fokus V20
- redesign modul operasional yang sering dipakai
- tetap menjaga coverage fitur inti
- mulai membangun pola tampilan yang konsisten untuk transaksi dan keuangan

## Tambahan utama
- NativeSalesScreen
- NativePurchasesScreen
- NativeFinanceScreen
- NativeDebtsScreen
- NativeExpensesScreen
- RedesignBuildingBlocks

## Catatan
Pass ini adalah lanjutan source-level best effort dan belum diverifikasi build Gradle/Android Studio.
