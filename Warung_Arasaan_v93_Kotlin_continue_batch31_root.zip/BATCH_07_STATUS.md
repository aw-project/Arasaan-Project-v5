# Batch 7 — Dashboard, Search, Activity

- dashboard shell
- activity shell
- global search preparation
