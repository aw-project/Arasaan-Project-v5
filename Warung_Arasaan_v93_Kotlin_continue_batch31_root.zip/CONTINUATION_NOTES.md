
Continuation update after batch 2-12 realized:

Added in this continuation:
- Global Search module across products, purchases, sales, debts, activity logs.
- Backup module with JSON export/import textarea flow.
- Purchase module upgraded from quick-entry to multi-item form + detail dialog.
- Sales module upgraded from quick-entry to multi-item form + split payment + detail dialog.
- AppContainer now exposes AppDatabase for restore/import routines.
- BackupService now supports fromJson() and payload summary.

Notes:
- This is still a migration scaffold, not guaranteed 1:1 parity with every Flutter screen.
- Backup import currently restores local database records directly from JSON payload.
- Search is global but currently read-only.
