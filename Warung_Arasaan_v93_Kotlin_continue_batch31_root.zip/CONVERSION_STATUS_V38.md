# CONVERSION STATUS V38

This pass focuses on build readiness handoff.

## Added
- repository/plugin management in `settings.gradle.kts`
- root `clean` task in `build.gradle.kts`
- build + validation docs
- preflight scripts for shell and PowerShell
- pre-deploy and regression checklists

## Current status
- Source parity with the Flutter baseline is very high.
- A real Android Studio / Gradle build is still required before claiming full deployment parity.
- Bluetooth thermal, backup/restore, and end-to-end transaction regression must be validated on a real device.
