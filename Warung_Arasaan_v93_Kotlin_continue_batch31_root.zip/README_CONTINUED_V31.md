# Warung Arasaan Kotlin identity v31

Focus:
- compile-hardening pass on wrapper screens
- parity audit against the original Flutter repo
- reduce obvious source mismatches before final regression work
