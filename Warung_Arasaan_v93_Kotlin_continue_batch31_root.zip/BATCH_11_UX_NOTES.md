# Batch 11 UX Notes

- modul sudah diberi shell Compose per area
- root screen sudah bisa dipakai sebagai peta kerja migrasi
- langkah berikutnya: ganti shell dengan screen CRUD penuh per halaman Flutter
