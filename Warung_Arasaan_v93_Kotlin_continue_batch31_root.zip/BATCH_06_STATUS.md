# Batch 6 — Hutang dan Partner

- partner shell
- debt flow mapping
