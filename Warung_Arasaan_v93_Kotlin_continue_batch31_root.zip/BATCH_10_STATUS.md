# Batch 10 — Testing parity

- dokumen checklist parity
- catatan edge cases
