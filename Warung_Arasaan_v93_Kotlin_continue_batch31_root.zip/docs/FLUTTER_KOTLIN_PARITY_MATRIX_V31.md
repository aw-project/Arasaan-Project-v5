# Flutter → Kotlin parity matrix v31

This matrix is generated from the uploaded Flutter repo and the current Kotlin source tree.

- `lib/ui/reports/reports_page.dart` → **covered** via `NativeReportsModuleScreen.kt, NativeReportsScreen.kt, ReportsModuleScreen.kt`
- `lib/ui/more/more_page.dart` → **covered** via `MoreModuleScreen.kt`
- `lib/ui/sales/sale_form.dart` → **covered** via `NativeSaleEditorScreen.kt, NativeSalesModuleScreen.kt, NativeSalesScreen.kt, SaleDetailScreen.kt, SalesModuleScreen.kt`
- `lib/ui/sales/sale_detail_page.dart` → **covered** via `NativeSaleEditorScreen.kt, NativeSalesModuleScreen.kt, NativeSalesScreen.kt, SaleDetailScreen.kt, SalesModuleScreen.kt`
- `lib/ui/sales/sales_page.dart` → **covered** via `NativeSalesModuleScreen.kt, NativeSalesScreen.kt, SalesModuleScreen.kt`
- `lib/ui/sales/fast_pos_page.dart` → **covered** via `FastPosModels.kt, FastPosModuleScreen.kt, FastPosParityGuards.kt, NativeFastPosCheckoutSheet.kt, NativeFastPosModuleScreen.kt`
- `lib/ui/operations/operations_tools_page.dart` → **covered** via `OperationsToolsModuleScreen.kt`
- `lib/ui/products/product_detail_page.dart` → **covered** via `AnalyticsProductDetailScreen.kt, NativeProductEditorScreen.kt, NativeProductsModuleScreen.kt, NativeProductsScreen.kt, ProductsModuleScreen.kt`
- `lib/ui/products/stock_opname_page.dart` → **gap**
- `lib/ui/products/products_page.dart` → **covered** via `NativeProductsModuleScreen.kt, NativeProductsScreen.kt, ProductsModuleScreen.kt`
- `lib/ui/products/stock_adjustment_page.dart` → **gap**
- `lib/ui/settings/backup_page.dart` → **covered** via `BackupModuleScreen.kt`
- `lib/ui/settings/lock_gate.dart` → **covered** via `LockGate.kt`
- `lib/ui/restock/restock_page.dart` → **covered** via `RestockModuleScreen.kt`
- `lib/ui/cash/cash_page.dart` → **covered** via `NativeCashModuleScreen.kt, NativeCashScreen.kt`
- `lib/ui/rejected/rejected_page.dart` → **covered** via `NativeRejectedModuleScreen.kt, NativeRejectedScreen.kt, RejectedModuleScreen.kt`
- `lib/ui/widgets/date_picker_field.dart` → **covered** via `DatePickerField.kt`
- `lib/ui/widgets/money_field.dart` → **covered** via `MoneyField.kt`
- `lib/ui/widgets/empty_state.dart` → **covered** via `EmptyState.kt`
- `lib/ui/widgets/date_range_picker.dart` → **covered** via `DateRangePicker.kt`
- `lib/ui/widgets/number_field.dart` → **gap**
- `lib/ui/expenses/expenses_page.dart` → **covered** via `ExpensesModuleScreen.kt, NativeExpensesModuleScreen.kt, NativeExpensesScreen.kt`
- `lib/ui/purchases/purchase_detail_page.dart` → **covered** via `NativePurchaseEditorScreen.kt, NativePurchasesModuleScreen.kt, NativePurchasesScreen.kt, PurchaseDetailScreen.kt, PurchasesModuleScreen.kt`
- `lib/ui/purchases/purchase_form.dart` → **covered** via `NativePurchaseEditorScreen.kt, NativePurchasesModuleScreen.kt, NativePurchasesScreen.kt, PurchaseDetailScreen.kt, PurchasesModuleScreen.kt`
- `lib/ui/purchases/purchases_page.dart` → **covered** via `NativePurchasesModuleScreen.kt, NativePurchasesScreen.kt, PurchasesModuleScreen.kt`
- `lib/ui/home/home_page.dart` → **covered** via `HomeHubScreen.kt, NativeHomeScaffold.kt`
- `lib/ui/dashboard/dashboard_page.dart` → **covered** via `DashboardScreen.kt, NativeDashboardModuleScreen.kt, NativeDashboardScreen.kt`
- `lib/ui/partners/customers_page.dart` → **covered** via `CustomersModuleScreen.kt`
- `lib/ui/partners/suppliers_page.dart` → **covered** via `SuppliersModuleScreen.kt`
- `lib/ui/activity/activity_log_page.dart` → **gap**
- `lib/ui/analytics/analytics_product_detail_page.dart` → **covered** via `AnalyticsProductDetailScreen.kt`
- `lib/ui/analytics/analytics_page.dart` → **covered** via `AnalyticsBreakdownCalculator.kt, AnalyticsModuleScreen.kt, AnalyticsProductDetailScreen.kt, AnalyticsUiState.kt, NativeAnalyticsBreakdownScreen.kt`
- `lib/ui/splash/splash_screen.dart` → **covered** via `SplashGate.kt`
- `lib/ui/debts/debts_page.dart` → **covered** via `DebtsModuleScreen.kt, NativeDebtsModuleScreen.kt, NativeDebtsScreen.kt`
- `lib/ui/search/global_search_page.dart` → **gap**

UI coverage by filename heuristic: **30/35**