# Design Decisions V19

## Prinsip
1. Native lebih penting daripada mirip Flutter.
2. Aksi yang sering dipakai harus bisa dicapai 1-2 tap.
3. Filter dan pencarian harus selalu dekat dengan daftar data.
4. Dashboard harus terasa operasional, bukan hanya informatif.
5. Redesign tidak boleh mengorbankan fungsi inti.

## Implikasi
- Home memakai bottom navigation dan FAB kasir.
- Dashboard memakai KPI strip + quick actions.
- Produk dan laporan memakai filter chips horizontal.
- Fast POS memakai pencarian produk paling atas dan pembayaran sebagai filter cepat.

## Modul yang disentuh
- home
- dashboard
- products
- fast pos
- reports
