# DESIGN DECISIONS V20

## Prinsip
1. Kotlin tidak harus meniru Flutter.
2. Fitur inti tetap dijaga.
3. Flow harian harus lebih cepat dipakai di Android.
4. Komponen reusable dipakai lintas modul agar UI lebih konsisten.

## Perubahan arah
- Transaksi dibuat lebih ringkas dengan summary cards.
- State kosong dibuat lebih jelas dan actionable.
- Modul keuangan dipecah menjadi blok yang lebih mudah dipahami.
- Aksi utama selalu ditempatkan di atas agar mudah dijangkau.

## Fokus berikutnya
- integrasi redesign ke root lama
- harmonisasi form create/edit
- compile-hardening pass
