# Design Decisions V21

## Kenapa Sprint A+B digabung
Modul transaksi dan laporan saling terkait. Saat editor transaksi diperjelas, laporan dan analitik ikut lebih konsisten.

## Prinsip desain
- cepat dipakai kasir
- fokus pada ringkasan yang mudah dibaca
- form edit tetap padat
- laporan disederhanakan menjadi insight card
- tetap membuka ruang untuk hardening build berikutnya
