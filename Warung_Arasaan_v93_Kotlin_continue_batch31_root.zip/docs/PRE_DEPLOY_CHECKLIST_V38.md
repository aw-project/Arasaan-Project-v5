# Pre-deploy checklist

## Build readiness
- [ ] Gradle sync succeeds
- [ ] `:app:assembleDebug` succeeds
- [ ] `:app:assembleRelease` succeeds
- [ ] Unit tests pass
- [ ] Instrumentation tests pass

## Functional parity
- [ ] Products CRUD
- [ ] Stock adjustment
- [ ] Stock opname
- [ ] Purchases CRUD
- [ ] Sales CRUD
- [ ] Fast POS happy path
- [ ] Fast POS edge cases
- [ ] Cash ledger
- [ ] Expenses
- [ ] Debts and settlement
- [ ] Rejected items
- [ ] Reports filter parity
- [ ] Analytics breakdown parity
- [ ] Search
- [ ] Activity log
- [ ] Settings
- [ ] Backup export/import

## Device validation
- [ ] Notification permission
- [ ] Bluetooth permission
- [ ] Bluetooth printer pairing
- [ ] Thermal print payload
- [ ] Storage Access Framework export/import

## Release polish
- [ ] App icon
- [ ] Version bump
- [ ] Release notes
- [ ] Smoke test on low-end device
