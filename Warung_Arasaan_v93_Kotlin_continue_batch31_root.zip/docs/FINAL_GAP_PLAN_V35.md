# Final Gap Plan V35

Fokus batch ini:
- menutup gap `providers.dart` dengan `AppProviders.kt`
- menutup gap `hive_boxes.dart` / `hive_adapters.dart` dengan `StorageRegistry.kt`
- menyiapkan entry point Compose yang lebih rapi untuk wiring final

Dampak:
- root wiring lebih konsisten
- dependency akses repository lebih jelas
- peta storage native lebih terdokumentasi

Gap besar yang masih tersisa:
1. build verification nyata di Android Studio / Gradle
2. regression end-to-end transaksi
3. backup/restore end-to-end
4. validasi printer thermal di device nyata
