# Manual regression matrix

## Transactions
1. Create purchase with multiple items.
2. Edit purchase and verify stock recalculation.
3. Create sale with split payment.
4. Edit sale and verify stock + cash recalculation.
5. Create rejected entry and verify stock / cash impact.

## Reports
1. Switch date filters.
2. Compare totals with transactions entered above.
3. Verify rejected totals are reflected.

## Backup / restore
1. Export JSON backup.
2. Clear app data or use a second device/profile.
3. Import backup.
4. Verify counts of products, purchases, sales, expenses, debts.

## Printing
1. Preview receipt.
2. Share text receipt.
3. Share txt file.
4. Send to Bluetooth printer.
