
# V42 redesign + button fix pass

## Fokus
- Root layout dibuat lebih ringkas dengan bottom navigation 5 area utama.
- Fitur operasional penting diarahkan ke layar legacy/module yang lebih matang.
- Fitur sekunder dipindahkan ke halaman **Lainnya** agar pengguna tidak kewalahan.

## Perubahan utama
- `WarungArasaanRoot.kt`
  - ganti chip-row besar menjadi scaffold navigasi bawah
  - top bar ringkas dengan akses cepat ke pencarian dan pengaturan
  - route produk/penjualan/laporan mengarah ke module screen yang lebih lengkap
- `HomeHubScreen.kt`
  - shortcut disederhanakan ke 8 aksi utama
  - ringkasan harian dibuat lebih padat
- `MoreModuleScreen.kt`
  - fitur lanjutan dikelompokkan ke Operasional / Insight / Tools

## Dampak
- Navigasi lebih jelas
- Tombol di area utama lebih konsisten karena memakai screen yang lebih matang
- Risiko tombol mati berkurang karena wrapper redesign yang parsial tidak lagi jadi jalur utama untuk operasi harian
