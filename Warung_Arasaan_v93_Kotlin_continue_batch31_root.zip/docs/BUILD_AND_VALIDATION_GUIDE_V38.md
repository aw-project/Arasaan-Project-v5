# Build and validation guide

This package is the current Kotlin/Android conversion baseline with final gap-closing notes.

## Recommended environment
- Android Studio Koala or newer
- Android SDK 35
- JDK 17
- Gradle sync with internet access enabled

## First build
1. Open the project root in Android Studio.
2. Let Gradle sync.
3. Set the app module as the startup module.
4. Build `debug`.
5. Run unit tests.
6. Run on a real Android device for Bluetooth / storage / notification checks.

## Suggested command order
```bash
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
./gradlew :app:connectedDebugAndroidTest
```

## High-risk areas to verify manually
- purchase create/edit/delete
- sale create/edit/delete
- fast POS checkout
- rejected flow
- backup export/import
- Bluetooth thermal print
- report filters
- analytics breakdown

## Known truth
This repository is source-close to the Flutter baseline, but full parity still depends on a real Android Studio build and device validation.
