Write-Host "== Warung Arasaan Native preflight =="
Write-Host "Java:"
java -version
Write-Host ""
Write-Host "Gradle:"
gradle -v
Write-Host ""
Write-Host "Running debug assemble..."
gradle :app:assembleDebug
Write-Host ""
Write-Host "Running unit tests..."
gradle :app:testDebugUnitTest
Write-Host ""
Write-Host "Done. Run instrumentation tests from Android Studio or with a connected device."
