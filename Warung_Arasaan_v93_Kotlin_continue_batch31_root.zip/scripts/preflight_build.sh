#!/usr/bin/env bash
set -euo pipefail

echo "== Warung Arasaan Native preflight =="
echo "Java:"
java -version || true
echo
echo "Gradle:"
gradle -v || true
echo
echo "Running debug assemble..."
gradle :app:assembleDebug
echo
echo "Running unit tests..."
gradle :app:testDebugUnitTest
echo
echo "Done. Run instrumentation tests from Android Studio or with a connected device."
