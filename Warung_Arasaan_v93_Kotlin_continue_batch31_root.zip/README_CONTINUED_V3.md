# Warung Arasaan Kotlin Continuation V3

Batch lanjutan ini menambahkan fokus pada hardening Android-native:

- Lock gate berbasis PIN pada root app.
- Restock module 14 hari berbasis data penjualan.
- Backup/export/import file memakai Storage Access Framework.
- Report export CSV untuk stok, penjualan, pembelian, dan biaya.
- Detail screen untuk pembelian dan penjualan.
- Utility baca/tulis file dokumen Android.

Status:
- Masih best-effort migration, belum build-verified.
- File export/import sudah diarahkan ke pola Android native, menggantikan textarea-only flow sebelumnya.
