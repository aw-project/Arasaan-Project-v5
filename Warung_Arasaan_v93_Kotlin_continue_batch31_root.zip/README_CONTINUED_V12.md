# Warung Arasaan Kotlin Continued V12

Batch ini menambah parity untuk utilitas unit, migrasi data lama, validasi transaksi, dan widget form reusable.

## File baru
- `app/src/main/java/com/warungarasaan/app/core/UnitUtils.kt`
- `app/src/main/java/com/warungarasaan/app/data/service/UnitMigrationService.kt`
- `app/src/main/java/com/warungarasaan/app/core/TransactionValidation.kt`
- `app/src/main/java/com/warungarasaan/app/ui/widgets/FormFields.kt`

## Catatan
- migrasi unit dijalankan sekali saat startup melalui `WarungArasaanApp`
- status tetap best-effort dan belum build-verified
