
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../providers.dart';
import '../debts/debts_page.dart';
import '../partners/customers_page.dart';
import '../partners/suppliers_page.dart';
import '../products/product_detail_page.dart';
import '../purchases/purchase_detail_page.dart';
import '../sales/sale_detail_page.dart';

class GlobalSearchPage extends ConsumerStatefulWidget {
  const GlobalSearchPage({super.key});

  @override
  ConsumerState<GlobalSearchPage> createState() => _GlobalSearchPageState();
}

class _GlobalSearchPageState extends ConsumerState<GlobalSearchPage> {
  final _controller = TextEditingController();
  String _query = '';
  String _filter = 'semua';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toLowerCase();
    final products = ref.watch(productRepoProvider).all();
    final sales = ref.watch(salesRepoProvider).all();
    final purchases = ref.watch(purchaseRepoProvider).all();
    final debts = ref.watch(debtRepoProvider).all();
    final productById = {for (final p in products) p.id: p};

    final customerMap = <String, ({int count, double total})>{};
    for (final sale in sales) {
      final name = sale.customerName.trim();
      if (name.isEmpty) continue;
      final cur = customerMap[name] ?? (count: 0, total: 0.0);
      customerMap[name] = (count: cur.count + 1, total: cur.total + sale.totalSales);
    }

    final supplierMap = <String, ({int count, double total})>{};
    for (final purchase in purchases) {
      final name = purchase.supplier.trim();
      if (name.isEmpty) continue;
      final total = purchase.items.fold<double>(0, (sum, it) => sum + (it.qty * it.buyPrice));
      final cur = supplierMap[name] ?? (count: 0, total: 0.0);
      supplierMap[name] = (count: cur.count + 1, total: cur.total + total);
    }

    final allResults = <_SearchResult>[
      ...products.map((p) {
        final haystack = '${p.name} ${p.sku} ${p.category}'.toLowerCase();
        return _SearchResult.product(
          title: p.name,
          subtitle: '${p.category} • SKU ${p.sku.isEmpty ? '-' : p.sku}',
          trailing: _fmtQty(p.stockQty, p.unit),
          score: _scoreText(q, haystack, exactBoost: p.sku.toLowerCase() == q || p.name.toLowerCase() == q),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id)),
          ),
        );
      }),
      ...sales.map((s) {
        final names = s.items.map((e) => productById[e.productId]?.name ?? '').join(' ');
        final haystack = '${s.id} ${s.customerName} ${s.paymentMethod} $names'.toLowerCase();
        return _SearchResult.sale(
          title: s.customerName.trim().isEmpty ? 'Transaksi ${s.id}' : s.customerName,
          subtitle: '${fmtDateFromEpochDay(s.dateEpochDay)} • ${s.paymentSummary}',
          trailing: fmtMoney(s.totalSales),
          score: _scoreText(q, haystack, exactBoost: s.id.toLowerCase() == q),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => SaleDetailPage(saleId: s.id)),
          ),
        );
      }),
      ...purchases.map((p) {
        final names = p.items.map((e) => productById[e.productId]?.name ?? '').join(' ');
        final total = p.items.fold<double>(0, (sum, it) => sum + (it.qty * it.buyPrice));
        final haystack = '${p.id} ${p.supplier} $names'.toLowerCase();
        return _SearchResult.purchase(
          title: p.supplier.trim().isEmpty ? 'Pembelian ${p.id}' : p.supplier,
          subtitle: '${fmtDateFromEpochDay(p.dateEpochDay)} • ${p.items.length} item',
          trailing: fmtMoney(total),
          score: _scoreText(q, haystack, exactBoost: p.id.toLowerCase() == q),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => PurchaseDetailPage(purchaseId: p.id)),
          ),
        );
      }),
      ...debts.map((d) {
        final haystack = '${d.id} ${d.creditor} ${d.note}'.toLowerCase();
        return _SearchResult.debt(
          title: d.creditor,
          subtitle: '${fmtDateFromEpochDay(d.dateEpochDay)} • ${d.note.isEmpty ? 'Tanpa catatan' : d.note}',
          trailing: fmtMoney(d.remaining),
          score: _scoreText(q, haystack, exactBoost: d.id.toLowerCase() == q),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const DebtsPage()),
          ),
        );
      }),
      ...customerMap.entries.map((e) {
        final haystack = e.key.toLowerCase();
        return _SearchResult.customer(
          title: e.key,
          subtitle: '${e.value.count} transaksi',
          trailing: fmtMoney(e.value.total),
          score: _scoreText(q, haystack, exactBoost: e.key.toLowerCase() == q),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CustomersPage()),
          ),
        );
      }),
      ...supplierMap.entries.map((e) {
        final haystack = e.key.toLowerCase();
        return _SearchResult.supplier(
          title: e.key,
          subtitle: '${e.value.count} pembelian',
          trailing: fmtMoney(e.value.total),
          score: _scoreText(q, haystack, exactBoost: e.key.toLowerCase() == q),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SuppliersPage()),
          ),
        );
      }),
    ];

    final filtered = allResults
        .where((e) => _filter == 'semua' || e.type == _filter)
        .where((e) => q.isEmpty || e.score > 0)
        .toList()
      ..sort((a, b) {
        final byScore = b.score.compareTo(a.score);
        if (byScore != 0) return byScore;
        return a.title.toLowerCase().compareTo(b.title.toLowerCase());
      });

    final groupedCounts = <String, int>{
      'produk': allResults.where((e) => e.type == 'produk' && (q.isEmpty || e.score > 0)).length,
      'penjualan': allResults.where((e) => e.type == 'penjualan' && (q.isEmpty || e.score > 0)).length,
      'pembelian': allResults.where((e) => e.type == 'pembelian' && (q.isEmpty || e.score > 0)).length,
      'hutang': allResults.where((e) => e.type == 'hutang' && (q.isEmpty || e.score > 0)).length,
      'pelanggan': allResults.where((e) => e.type == 'pelanggan' && (q.isEmpty || e.score > 0)).length,
      'supplier': allResults.where((e) => e.type == 'supplier' && (q.isEmpty || e.score > 0)).length,
    };

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Global Search')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
        children: [
          TextField(
            controller: _controller,
            autofocus: true,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: 'Cari produk, SKU, transaksi, supplier, pelanggan, hutang...',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () {
                        _controller.clear();
                        setState(() => _query = '');
                      },
                      icon: const Icon(Icons.close_rounded),
                    ),
            ),
            onChanged: (v) => setState(() => _query = v),
          ),
          const SizedBox(height: 12),
          _SearchSummaryCard(query: _query, totalHits: filtered.length),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _FilterPill(
                    label: 'Semua (${filtered.length})',
                    selected: _filter == 'semua',
                    onTap: () => setState(() => _filter = 'semua'),
                  ),
                  _FilterPill(
                    label: 'Produk (${groupedCounts['produk']})',
                    selected: _filter == 'produk',
                    onTap: () => setState(() => _filter = 'produk'),
                  ),
                  _FilterPill(
                    label: 'Penjualan (${groupedCounts['penjualan']})',
                    selected: _filter == 'penjualan',
                    onTap: () => setState(() => _filter = 'penjualan'),
                  ),
                  _FilterPill(
                    label: 'Pembelian (${groupedCounts['pembelian']})',
                    selected: _filter == 'pembelian',
                    onTap: () => setState(() => _filter = 'pembelian'),
                  ),
                  _FilterPill(
                    label: 'Hutang (${groupedCounts['hutang']})',
                    selected: _filter == 'hutang',
                    onTap: () => setState(() => _filter = 'hutang'),
                  ),
                  _FilterPill(
                    label: 'Pelanggan (${groupedCounts['pelanggan']})',
                    selected: _filter == 'pelanggan',
                    onTap: () => setState(() => _filter = 'pelanggan'),
                  ),
                  _FilterPill(
                    label: 'Supplier (${groupedCounts['supplier']})',
                    selected: _filter == 'supplier',
                    onTap: () => setState(() => _filter = 'supplier'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (filtered.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: _NoResult(
                  text: 'Belum ada hasil. Coba kata kunci lain, SKU, ID transaksi, atau nama mitra.',
                ),
              ),
            )
          else
            ...filtered.take(40).map(
              (item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Card(
                  child: ListTile(
                    dense: true,
                    leading: CircleAvatar(
                      backgroundColor: item.color.withOpacity(0.12),
                      foregroundColor: item.color,
                      child: Icon(item.icon, size: 18),
                    ),
                    title: Text(item.title),
                    subtitle: Text(item.subtitle),
                    trailing: SizedBox(
                      width: 84,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(item.trailing, maxLines: 1, overflow: TextOverflow.ellipsis),
                          const SizedBox(height: 4),
                          Text(item.typeLabel, style: Theme.of(context).textTheme.labelSmall),
                        ],
                      ),
                    ),
                    onTap: item.onTap,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  int _scoreText(String query, String haystack, {bool exactBoost = false}) {
    if (query.isEmpty) return 1;
    if (exactBoost) return 100;
    if (haystack.startsWith(query)) return 80;
    if (haystack.contains(' $query')) return 60;
    if (haystack.contains(query)) return 40;
    final parts = query.split(RegExp(r'\s+')).where((e) => e.isNotEmpty);
    int score = 0;
    for (final part in parts) {
      if (haystack.contains(part)) score += 10;
    }
    return score;
  }

  String _fmtQty(double qty, String unit) {
    if (qty == qty.roundToDouble()) return '${qty.toStringAsFixed(0)} $unit';
    return '${qty.toStringAsFixed(2)} $unit';
  }
}

class _SearchResult {
  final String type;
  final String typeLabel;
  final String title;
  final String subtitle;
  final String trailing;
  final int score;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _SearchResult({
    required this.type,
    required this.typeLabel,
    required this.title,
    required this.subtitle,
    required this.trailing,
    required this.score,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  factory _SearchResult.product({
    required String title,
    required String subtitle,
    required String trailing,
    required int score,
    required VoidCallback onTap,
  }) => _SearchResult(
        type: 'produk',
        typeLabel: 'Produk',
        title: title,
        subtitle: subtitle,
        trailing: trailing,
        score: score,
        icon: Icons.inventory_2_rounded,
        color: AppColors.primary,
        onTap: onTap,
      );

  factory _SearchResult.sale({
    required String title,
    required String subtitle,
    required String trailing,
    required int score,
    required VoidCallback onTap,
  }) => _SearchResult(
        type: 'penjualan',
        typeLabel: 'Penjualan',
        title: title,
        subtitle: subtitle,
        trailing: trailing,
        score: score,
        icon: Icons.point_of_sale_rounded,
        color: AppColors.iconGreen,
        onTap: onTap,
      );

  factory _SearchResult.purchase({
    required String title,
    required String subtitle,
    required String trailing,
    required int score,
    required VoidCallback onTap,
  }) => _SearchResult(
        type: 'pembelian',
        typeLabel: 'Pembelian',
        title: title,
        subtitle: subtitle,
        trailing: trailing,
        score: score,
        icon: Icons.shopping_cart_rounded,
        color: AppColors.iconBlue,
        onTap: onTap,
      );

  factory _SearchResult.debt({
    required String title,
    required String subtitle,
    required String trailing,
    required int score,
    required VoidCallback onTap,
  }) => _SearchResult(
        type: 'hutang',
        typeLabel: 'Hutang',
        title: title,
        subtitle: subtitle,
        trailing: trailing,
        score: score,
        icon: Icons.payments_rounded,
        color: AppColors.iconAmber,
        onTap: onTap,
      );

  factory _SearchResult.customer({
    required String title,
    required String subtitle,
    required String trailing,
    required int score,
    required VoidCallback onTap,
  }) => _SearchResult(
        type: 'pelanggan',
        typeLabel: 'Pelanggan',
        title: title,
        subtitle: subtitle,
        trailing: trailing,
        score: score,
        icon: Icons.people_alt_rounded,
        color: AppColors.iconPurple,
        onTap: onTap,
      );

  factory _SearchResult.supplier({
    required String title,
    required String subtitle,
    required String trailing,
    required int score,
    required VoidCallback onTap,
  }) => _SearchResult(
        type: 'supplier',
        typeLabel: 'Supplier',
        title: title,
        subtitle: subtitle,
        trailing: trailing,
        score: score,
        icon: Icons.local_shipping_rounded,
        color: AppColors.iconBlue,
        onTap: onTap,
      );
}

class _FilterPill extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterPill({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
    );
  }
}

class _SearchSummaryCard extends StatelessWidget {
  final String query;
  final int totalHits;

  const _SearchSummaryCard({
    required this.query,
    required this.totalHits,
  });

  @override
  Widget build(BuildContext context) {
    final hasQuery = query.trim().isNotEmpty;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.primaryContainer,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(Icons.travel_explore_rounded, color: AppColors.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasQuery ? 'Hasil untuk "$query"' : 'Pencarian terpadu Warung Arasaan',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    hasQuery
                        ? '$totalHits hasil paling relevan ditampilkan.'
                        : 'Cari data produk, transaksi, pembelian, supplier, pelanggan, dan hutang dalam satu tempat.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NoResult extends StatelessWidget {
  final String text;

  const _NoResult({required this.text});

  @override
  Widget build(BuildContext context) {
    return Text(text, style: Theme.of(context).textTheme.bodySmall);
  }
}
