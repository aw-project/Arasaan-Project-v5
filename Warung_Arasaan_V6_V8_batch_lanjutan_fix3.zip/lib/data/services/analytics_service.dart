import 'package:hive/hive.dart';

import '../../core/dates.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/stock_movement.dart';
import '../../domain/models/rejected_item.dart';
import '../../domain/models/purchase.dart';

class ProductKpi {
  final String productId;
  final String name;
  final double qty;
  final double revenue;
  final double hpp;
  final double profit;

  const ProductKpi({
    required this.productId,
    required this.name,
    required this.qty,
    required this.revenue,
    required this.hpp,
    required this.profit,
  });

  double get marginPercent => revenue == 0 ? 0 : (profit / revenue) * 100.0;
}

class LossProductKpi {
  final String productId;
  final String name;
  final double qty;
  final double amount;
  final String source;

  const LossProductKpi({
    required this.productId,
    required this.name,
    required this.qty,
    required this.amount,
    required this.source,
  });
}

class ForecastKpi {
  final String productId;
  final String name;
  final String unit;
  final double stockQty;
  final double avgPerDay;
  final double horizonNeed;
  final double suggestBuy;

  const ForecastKpi({
    required this.productId,
    required this.name,
    required this.unit,
    required this.stockQty,
    required this.avgPerDay,
    required this.horizonNeed,
    required this.suggestBuy,
  });
}

class DayPoint {
  final int epochDayValue;
  final double value;
  const DayPoint(this.epochDayValue, this.value);
}


class CategoryKpi {
  final String category;
  final double qty;
  final double revenue;
  final double hpp;
  final double profit;
  final int productCount;

  const CategoryKpi({
    required this.category,
    required this.qty,
    required this.revenue,
    required this.hpp,
    required this.profit,
    required this.productCount,
  });

  double get marginPercent => revenue == 0 ? 0 : (profit / revenue) * 100.0;
}

class PriceTrendKpi {
  final String productId;
  final String name;
  final String unit;
  final double avgPrice;
  final double minPrice;
  final double maxPrice;
  final double latestPrice;
  final double earliestPrice;
  final int sampleCount;

  const PriceTrendKpi({
    required this.productId,
    required this.name,
    required this.unit,
    required this.avgPrice,
    required this.minPrice,
    required this.maxPrice,
    required this.latestPrice,
    required this.earliestPrice,
    required this.sampleCount,
  });

  double get changePercent {
    if (earliestPrice <= 0) return 0;
    return ((latestPrice - earliestPrice) / earliestPrice) * 100.0;
  }
}

class PartnerKpi {
  final String name;
  final int transactionCount;
  final double totalAmount;
  final String kind;

  const PartnerKpi({
    required this.name,
    required this.transactionCount,
    required this.totalAmount,
    required this.kind,
  });
}

class AnalyticsService {
  const AnalyticsService();

  List<Sale> _salesInRange(Box<Sale> salesBox, DateTime start, DateTime end) {
    final s = epochDay(start);
    final e = epochDay(end);
    return salesBox.values.where((x) => x.dateEpochDay >= s && x.dateEpochDay <= e).toList();
  }

  List<ProductKpi> topSelling(Box<Sale> salesBox, Box<Product> productsBox, DateTime start, DateTime end) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <String, ({double qty, double rev, double hpp})>{};

    for (final sale in sales) {
      for (final it in sale.items) {
        final cur = map[it.productId] ?? (qty: 0.0, rev: 0.0, hpp: 0.0);
        map[it.productId] = (
          qty: cur.qty + it.qty,
          rev: cur.rev + it.total,
          hpp: cur.hpp + it.totalHpp,
        );
      }
    }

    final res = <ProductKpi>[];
    map.forEach((pid, v) {
      final p = productsBox.get(pid);
      res.add(ProductKpi(
        productId: pid,
        name: p?.name ?? pid,
        qty: v.qty,
        revenue: v.rev,
        hpp: v.hpp,
        profit: v.rev - v.hpp,
      ));
    });

    res.sort((a, b) => b.qty.compareTo(a.qty));
    return res;
  }

  List<ProductKpi> topProfit(Box<Sale> salesBox, Box<Product> productsBox, DateTime start, DateTime end) {
    final list = topSelling(salesBox, productsBox, start, end);
    list.sort((a, b) => b.profit.compareTo(a.profit));
    return list;
  }

  ProductKpi productKpi(
    Box<Sale> salesBox,
    Box<Product> productsBox,
    String productId,
    DateTime start,
    DateTime end,
  ) {
    final sales = _salesInRange(salesBox, start, end);
    double qty = 0, rev = 0, hpp = 0;
    for (final sale in sales) {
      for (final it in sale.items) {
        if (it.productId != productId) continue;
        qty += it.qty;
        rev += it.total;
        hpp += it.totalHpp;
      }
    }
    final p = productsBox.get(productId);
    return ProductKpi(
      productId: productId,
      name: p?.name ?? productId,
      qty: qty,
      revenue: rev,
      hpp: hpp,
      profit: rev - hpp,
    );
  }

  List<({int day, double qty, double price, double hppAtSale, double total})> productSalesRows(
    Box<Sale> salesBox,
    String productId,
    DateTime start,
    DateTime end, {
    int limit = 30,
  }) {
    final sales = _salesInRange(salesBox, start, end);
    final rows = <({int day, double qty, double price, double hppAtSale, double total})>[];
    for (final s in sales) {
      for (final it in s.items) {
        if (it.productId != productId) continue;
        rows.add((
          day: s.dateEpochDay,
          qty: it.qty,
          price: it.sellPrice,
          hppAtSale: it.hppAtSale,
          total: it.total,
        ));
      }
    }
    rows.sort((a, b) => b.day.compareTo(a.day));
    if (rows.length <= limit) return rows;
    return rows.take(limit).toList();
  }

  List<DayPoint> productQtyTrend(Box<Sale> salesBox, String productId, DateTime start, DateTime end) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <int, double>{};
    for (final s in sales) {
      final day = s.dateEpochDay;
      final totalQty = s.items.where((it) => it.productId == productId).fold(0.0, (sum, it) => sum + it.qty);
      if (totalQty > 0) {
        map[day] = (map[day] ?? 0.0) + totalQty;
      }
    }

    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final res = <DayPoint>[];
    for (int d = sDay; d <= eDay; d++) {
      res.add(DayPoint(d, map[d] ?? 0));
    }
    return res;
  }

  List<(Product product, double marginActual)> lossProducts(Box<Product> productsBox) {
    final res = <(Product, double)>[];
    for (final p in productsBox.values) {
      if (p.activeSellPrice <= 0) continue;
      final profitPerUnit = p.activeSellPrice - p.avgHpp;
      final marginActual = (profitPerUnit / p.activeSellPrice) * 100.0;
      if (p.activeSellPrice < p.avgHpp || marginActual < p.defaultMarginPercent) {
        res.add((p, marginActual));
      }
    }
    res.sort((a, b) => a.$2.compareTo(b.$2));
    return res;
  }

  List<LossProductKpi> lossByProduct(
    Box<Product> productsBox,
    Box<StockMovement> movementsBox,
    Box<RejectedItem> rejectedItemsBox,
    DateTime start,
    DateTime end,
  ) {
    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final map = <String, ({double qty, double amount, Set<String> sources})>{};

    for (final m in movementsBox.values) {
      if (m.dateEpochDay < sDay || m.dateEpochDay > eDay) continue;
      if (m.lossAmount <= 0) continue;
      final cur = map[m.productId] ?? (qty: 0.0, amount: 0.0, sources: <String>{});
      map[m.productId] = (
        qty: cur.qty + m.qtyDelta.abs(),
        amount: cur.amount + m.lossAmount,
        sources: {...cur.sources, 'Adjustment'},
      );
    }

    for (final r in rejectedItemsBox.values) {
      if (r.dateEpochDay < sDay || r.dateEpochDay > eDay) continue;
      if (r.estimatedLoss <= 0) continue;
      final cur = map[r.productId] ?? (qty: 0.0, amount: 0.0, sources: <String>{});
      map[r.productId] = (
        qty: cur.qty + r.qty,
        amount: cur.amount + r.estimatedLoss,
        sources: {...cur.sources, 'Rejek'},
      );
    }

    final res = <LossProductKpi>[];
    map.forEach((pid, v) {
      final p = productsBox.get(pid);
      res.add(LossProductKpi(
        productId: pid,
        name: p?.name ?? pid,
        qty: v.qty,
        amount: v.amount,
        source: v.sources.join(' + '),
      ));
    });
    res.sort((a, b) => b.amount.compareTo(a.amount));
    return res;
  }

  List<DayPoint> revenueTrend(Box<Sale> salesBox, DateTime start, DateTime end) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <int, double>{};
    for (final s in sales) {
      final day = s.dateEpochDay;
      map[day] = (map[day] ?? 0.0) + s.items.fold(0.0, (sum, it) => sum + it.total);
    }

    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final res = <DayPoint>[];
    for (int d = sDay; d <= eDay; d++) {
      res.add(DayPoint(d, map[d] ?? 0));
    }
    return res;
  }

  List<DayPoint> productRevenueTrend(Box<Sale> salesBox, String productId, DateTime start, DateTime end) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <int, double>{};
    for (final s in sales) {
      final day = s.dateEpochDay;
      final total = s.items.where((it) => it.productId == productId).fold(0.0, (sum, it) => sum + it.total);
      if (total > 0) {
        map[day] = (map[day] ?? 0.0) + total;
      }
    }

    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final res = <DayPoint>[];
    for (int d = sDay; d <= eDay; d++) {
      res.add(DayPoint(d, map[d] ?? 0));
    }
    return res;
  }

  List<ForecastKpi> restockForecast(
    Box<Sale> salesBox,
    Box<Product> productsBox,
    DateTime anchorDate, {
    int windowDays = 7,
    int horizonDays = 3,
  }) {
    final todayEpoch = epochDay(anchorDate);
    final startEpoch = todayEpoch - (windowDays - 1);
    final soldQty = <String, double>{};
    for (final s in salesBox.values) {
      if (s.dateEpochDay < startEpoch || s.dateEpochDay > todayEpoch) continue;
      for (final it in s.items) {
        soldQty[it.productId] = (soldQty[it.productId] ?? 0) + it.qty;
      }
    }

    final res = <ForecastKpi>[];
    for (final p in productsBox.values) {
      final total = soldQty[p.id] ?? 0.0;
      if (total <= 0) continue;
      final avgPerDay = total / windowDays;
      final need = avgPerDay * horizonDays;
      final suggestBuy = need - p.stockQty;
      res.add(ForecastKpi(
        productId: p.id,
        name: p.name,
        unit: p.unit,
        stockQty: p.stockQty,
        avgPerDay: avgPerDay,
        horizonNeed: need,
        suggestBuy: suggestBuy > 0 ? suggestBuy : 0,
      ));
    }
    res.sort((a, b) {
      final c = b.suggestBuy.compareTo(a.suggestBuy);
      if (c != 0) return c;
      return b.horizonNeed.compareTo(a.horizonNeed);
    });
    return res;
  }

  List<CategoryKpi> categoryPerformance(
    Box<Sale> salesBox,
    Box<Product> productsBox,
    DateTime start,
    DateTime end,
  ) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <String, ({double qty, double revenue, double hpp, Set<String> ids})>{};
    for (final sale in sales) {
      for (final it in sale.items) {
        final product = productsBox.get(it.productId);
        final category = (product?.category.trim().isNotEmpty ?? false) ? product!.category.trim() : 'Tanpa Kategori';
        final cur = map[category] ?? (qty: 0.0, revenue: 0.0, hpp: 0.0, ids: <String>{});
        map[category] = (
          qty: cur.qty + it.qty,
          revenue: cur.revenue + it.total,
          hpp: cur.hpp + it.totalHpp,
          ids: {...cur.ids, it.productId},
        );
      }
    }
    final res = <CategoryKpi>[];
    map.forEach((category, v) {
      res.add(CategoryKpi(
        category: category,
        qty: v.qty,
        revenue: v.revenue,
        hpp: v.hpp,
        profit: v.revenue - v.hpp,
        productCount: v.ids.length,
      ));
    });
    res.sort((a, b) => b.revenue.compareTo(a.revenue));
    return res;
  }

  List<PriceTrendKpi> purchasePriceInsights(
    Box<Purchase> purchasesBox,
    Box<Product> productsBox,
    DateTime start,
    DateTime end, {
    int limit = 10,
  }) {
    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final grouped = <String, List<({int day, double price})>>{};
    for (final purchase in purchasesBox.values) {
      if (purchase.dateEpochDay < sDay || purchase.dateEpochDay > eDay) continue;
      for (final item in purchase.items) {
        grouped.putIfAbsent(item.productId, () => []).add((day: purchase.dateEpochDay, price: item.buyPrice));
      }
    }
    final res = <PriceTrendKpi>[];
    grouped.forEach((pid, rows) {
      if (rows.isEmpty) return;
      rows.sort((a, b) => a.day.compareTo(b.day));
      final prices = rows.map((e) => e.price).toList();
      final total = prices.fold<double>(0, (p, e) => p + e);
      final product = productsBox.get(pid);
      res.add(PriceTrendKpi(
        productId: pid,
        name: product?.name ?? pid,
        unit: product?.unit ?? '',
        avgPrice: prices.isEmpty ? 0 : total / prices.length,
        minPrice: prices.reduce((a, b) => a < b ? a : b),
        maxPrice: prices.reduce((a, b) => a > b ? a : b),
        latestPrice: rows.last.price,
        earliestPrice: rows.first.price,
        sampleCount: rows.length,
      ));
    });
    res.sort((a, b) => b.changePercent.abs().compareTo(a.changePercent.abs()));
    if (res.length <= limit) return res;
    return res.take(limit).toList();
  }

  List<PartnerKpi> topCustomers(Box<Sale> salesBox, DateTime start, DateTime end, {int limit = 10}) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <String, ({int count, double total})>{};
    for (final sale in sales) {
      final name = sale.customerName.trim().isEmpty ? 'Pelanggan Umum' : sale.customerName.trim();
      final cur = map[name] ?? (count: 0, total: 0.0);
      map[name] = (count: cur.count + 1, total: cur.total + sale.totalSales);
    }
    final res = map.entries
        .map((e) => PartnerKpi(name: e.key, transactionCount: e.value.count, totalAmount: e.value.total, kind: 'customer'))
        .toList()
      ..sort((a, b) => b.totalAmount.compareTo(a.totalAmount));
    if (res.length <= limit) return res;
    return res.take(limit).toList();
  }

  List<PartnerKpi> topSuppliers(Box<Purchase> purchasesBox, DateTime start, DateTime end, {int limit = 10}) {
    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final map = <String, ({int count, double total})>{};
    for (final purchase in purchasesBox.values) {
      if (purchase.dateEpochDay < sDay || purchase.dateEpochDay > eDay) continue;
      final name = purchase.supplier.trim().isEmpty ? 'Supplier Umum' : purchase.supplier.trim();
      double total = 0;
      for (final item in purchase.items) {
        total += item.qty * item.buyPrice;
      }
      final cur = map[name] ?? (count: 0, total: 0.0);
      map[name] = (count: cur.count + 1, total: cur.total + total);
    }
    final res = map.entries
        .map((e) => PartnerKpi(name: e.key, transactionCount: e.value.count, totalAmount: e.value.total, kind: 'supplier'))
        .toList()
      ..sort((a, b) => b.totalAmount.compareTo(a.totalAmount));
    if (res.length <= limit) return res;
    return res.take(limit).toList();
  }
}
