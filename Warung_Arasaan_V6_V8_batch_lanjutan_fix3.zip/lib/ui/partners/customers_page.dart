import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../core/dates.dart';
import '../../providers.dart';
import '../widgets/empty_state.dart';

class CustomersPage extends ConsumerStatefulWidget {
  const CustomersPage({super.key});

  @override
  ConsumerState<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends ConsumerState<CustomersPage> {
  final searchC = TextEditingController();
  @override
  void dispose() { searchC.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final sales = ref.watch(salesRepoProvider).all();
    final recent = ref.watch(metaRepoProvider).recentCustomers;
    final q = searchC.text.trim().toLowerCase();
    final map = <String, _CustomerStats>{};
    for (final s in sales) {
      final name = s.customerName.trim();
      if (name.isEmpty) continue;
      final entry = map.putIfAbsent(name, () => _CustomerStats(name: name));
      entry.saleCount += 1;
      entry.totalSpend += s.totalSales;
      entry.totalProfit += s.totalProfit;
      entry.totalItems += s.items.length;
      entry.totalQty += s.items.fold<double>(0, (p, e) => p + e.qty);
      if (s.paymentMethod == 'Hutang') entry.creditSales += s.totalSales;
      if (entry.lastEpochDay == null || s.dateEpochDay > entry.lastEpochDay!) entry.lastEpochDay = s.dateEpochDay;
    }
    final items = map.values.where((e) {
      if (q.isEmpty) return true;
      return e.name.toLowerCase().contains(q);
    }).toList()
      ..sort((a, b) {
        final ra = recent.indexWhere((e) => e.toLowerCase() == a.name.toLowerCase());
        final rb = recent.indexWhere((e) => e.toLowerCase() == b.name.toLowerCase());
        final pa = ra == -1 ? 9999 : ra;
        final pb = rb == -1 ? 9999 : rb;
        final recCmp = pa.compareTo(pb);
        if (recCmp != 0) return recCmp;
        return b.totalSpend.compareTo(a.totalSpend);
      });

    return Scaffold(
      appBar: AppBar(title: const Text('Pelanggan')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
          child: Column(children: [
            _CustomerSummary(items: items),
            const SizedBox(height: 12),
            TextField(
              controller: searchC,
              decoration: InputDecoration(
                labelText: 'Cari pelanggan',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: searchC.text.isEmpty ? null : IconButton(onPressed: () { searchC.clear(); setState(() {}); }, icon: const Icon(Icons.close_rounded)),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ]),
        ),
        Expanded(
          child: items.isEmpty
              ? const EmptyState(title: 'Belum ada pelanggan', subtitle: 'Nama pelanggan akan muncul otomatis dari data penjualan.')
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final c = items[i];
                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppColors.surfaceVariant,
                          child: Text(c.name.isEmpty ? '?' : c.name[0].toUpperCase(), style: GoogleFonts.poppins(fontWeight: FontWeight.w700, color: AppColors.primary)),
                        ),
                        title: Text(c.name, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                        subtitle: Text(
                          'Transaksi: ${c.saleCount}x • Qty: ${c.totalQty.toStringAsFixed(2)} • Terakhir: ${c.lastEpochDay == null ? '-' : fmtDateFromEpochDay(c.lastEpochDay!)}',
                          style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint),
                        ),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(fmtMoney(c.totalSpend), style: GoogleFonts.poppins(fontWeight: FontWeight.w700, fontSize: 12)),
                            const SizedBox(height: 2),
                            Text('Kredit: ${fmtMoney(c.creditSales)}', style: GoogleFonts.poppins(fontSize: 10, color: c.creditSales > 0 ? AppColors.negative : AppColors.hint)),
                          ],
                        ),
                        onTap: () => showModalBottomSheet(
                          context: context,
                          showDragHandle: true,
                          isScrollControlled: true,
                          builder: (_) => _CustomerDetailSheet(stats: c),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

class _CustomerStats {
  final String name;
  int saleCount = 0;
  int totalItems = 0;
  double totalQty = 0;
  double totalSpend = 0;
  double totalProfit = 0;
  double creditSales = 0;
  int? lastEpochDay;
  _CustomerStats({required this.name});
}

class _CustomerSummary extends StatelessWidget {
  final List<_CustomerStats> items;
  const _CustomerSummary({required this.items});
  @override
  Widget build(BuildContext context) {
    final totalSpend = items.fold<double>(0, (s, e) => s + e.totalSpend);
    final totalCredit = items.fold<double>(0, (s, e) => s + e.creditSales);
    final totalProfit = items.fold<double>(0, (s, e) => s + e.totalProfit);
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.7,
      children: [
        _InfoCard(title: 'Pelanggan aktif', value: '${items.length}', color: AppColors.primary),
        _InfoCard(title: 'Total omzet', value: fmtMoney(totalSpend), color: AppColors.iconBlue),
        _InfoCard(title: 'Penjualan kredit', value: fmtMoney(totalCredit), color: AppColors.negative),
        _InfoCard(title: 'Laba pelanggan', value: fmtMoney(totalProfit), color: AppColors.positive),
      ],
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  const _InfoCard({required this.title, required this.value, required this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(0.18))),
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(title, style: GoogleFonts.poppins(fontSize: 11, color: AppColors.hint)),
        const SizedBox(height: 6),
        Text(value, style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w700, color: color), maxLines: 2, overflow: TextOverflow.ellipsis),
      ]),
    );
  }
}

class _CustomerDetailSheet extends StatelessWidget {
  final _CustomerStats stats;
  const _CustomerDetailSheet({required this.stats});
  @override
  Widget build(BuildContext context) {
    final avgSpend = stats.saleCount == 0 ? 0 : stats.totalSpend / stats.saleCount;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(stats.name, style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          _detail('Total transaksi', '${stats.saleCount}x'),
          _detail('Total omzet', fmtMoney(stats.totalSpend)),
          _detail('Rata-rata belanja', fmtMoney(avgSpend)),
          _detail('Total laba', fmtMoney(stats.totalProfit)),
          _detail('Penjualan kredit', fmtMoney(stats.creditSales), emphasize: stats.creditSales > 0),
          _detail('Qty dibeli', stats.totalQty.toStringAsFixed(2)),
          _detail('Transaksi terakhir', stats.lastEpochDay == null ? '-' : fmtDateFromEpochDay(stats.lastEpochDay!)),
        ]),
      ),
    );
  }
  Widget _detail(String label, String value, {bool emphasize = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [Expanded(child: Text(label, style: GoogleFonts.poppins(fontSize: 12, color: AppColors.hint))), Text(value, style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: emphasize ? AppColors.negative : AppColors.onSurface))]),
  );
}
