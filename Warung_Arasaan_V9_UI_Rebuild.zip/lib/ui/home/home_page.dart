import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_theme.dart';
import '../../providers.dart';

import '../dashboard/dashboard_page.dart';
import '../products/products_page.dart';
import '../purchases/purchases_page.dart';
import '../sales/sales_page.dart';
import '../more/more_page.dart';

import '../reports/reports_page.dart';
import '../settings/backup_page.dart';
import '../analytics/analytics_page.dart';
import '../restock/restock_page.dart';
import '../activity/activity_log_page.dart';
import '../partners/suppliers_page.dart';
import '../partners/customers_page.dart';
import '../operations/operations_tools_page.dart';
import '../debts/debts_page.dart';
import '../expenses/expenses_page.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage>
    with TickerProviderStateMixin {
  int _index = 0;

  // 5 tabs — Kas & Retur diakses via MorePage
  final _pages = const [
    DashboardPage(key: PageStorageKey('tab-dashboard')),
    ProductsPage(key: PageStorageKey('tab-products')),
    SalesPage(key: PageStorageKey('tab-sales')),
    PurchasesPage(key: PageStorageKey('tab-purchases')),
    MorePage(key: PageStorageKey('tab-more')),
  ];

  final _labels = const ['Dashboard', 'Produk', 'Penjualan', 'Pembelian', 'Lainnya'];

  // icon asset paths — empty string = pakai IconData
  final _iconAssets = const [
    'assets/icons/ic_dashboard.png',
    'assets/icons/ic_products.png',
    'assets/icons/ic_sales.png',
    'assets/icons/ic_purchases.png',
    '',
  ];

  final _iconFallback = const [
    Icons.grid_view_rounded,
    Icons.inventory_2_rounded,
    Icons.point_of_sale_rounded,
    Icons.shopping_cart_rounded,
    Icons.apps_rounded,
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await ref.read(backupServiceProvider).autoBackupIfDue(
              meta: ref.read(metaRepoProvider),
              logs: ref.read(activityLogRepoProvider),
            );
      } catch (_) {}
    });
  }

  void _openPage(String title, Widget page) {
    Navigator.of(context).pop(); // close drawer if open
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: Text(title)),
          body: page,
        ),
      ),
    );
  }

  Future<void> _switchRole() async {
    final meta = ref.read(metaRepoProvider);
    final settings = ref.read(settingsRepoProvider);
    final cur = meta.role;
    final next = cur == 'admin' ? 'kasir' : 'admin';

    if (next == 'admin' && settings.get().pinEnabled) {
      final controller = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Masuk mode Admin'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(labelText: 'PIN Admin'),
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Batal')),
            FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('OK')),
          ],
        ),
      );
      if (ok != true) return;
      if (!settings.verifyPin(controller.text)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('PIN salah.')));
        }
        return;
      }
    }

    await meta.setRole(next);
    await ref
        .read(activityLogRepoProvider)
        .log('switch_role', 'Role berubah: $cur -> $next');
    if (mounted) {
      setState(() {});
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Mode aktif: $next')));
    }
  }

  void _selectTab(int i, bool isAdmin) {
    // Tab Pembelian (3) terbatas untuk kasir
    if (!isAdmin && i == 3) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Mode kasir tidak bisa membuka menu ini.'),
        ),
      );
      return;
    }
    if (i == _index) return;
    setState(() => _index = i);
  }

  @override
  Widget build(BuildContext context) {
    final role = ref.watch(metaRepoProvider).role;
    final isAdmin = role == 'admin';

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: _buildAppBar(isAdmin),
      drawer: _buildDrawer(role, isAdmin),
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: _buildFloatingNav(isAdmin),
    );
  }

  PreferredSizeWidget _buildAppBar(bool isAdmin) {
    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      scrolledUnderElevation: 1,
      shadowColor: Colors.black.withOpacity(0.08),
      title: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.cardGreen1, AppColors.cardGreen2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.storefront_rounded,
                color: Colors.white, size: 16),
          ),
          const SizedBox(width: 10),
          Text(
            _labels[_index],
            style: GoogleFonts.poppins(
              fontSize: 19,
              fontWeight: FontWeight.w700,
              color: AppColors.onSurface,
              letterSpacing: -0.3,
            ),
          ),
        ],
      ),
      actions: [
        // Role badge — tap to switch
        GestureDetector(
          onTap: _switchRole,
          child: Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: isAdmin
                  ? AppColors.primaryContainer
                  : AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  isAdmin
                      ? Icons.admin_panel_settings_rounded
                      : Icons.person_rounded,
                  size: 13,
                  color: isAdmin ? AppColors.primary : AppColors.hint,
                ),
                const SizedBox(width: 4),
                Text(
                  isAdmin ? 'Admin' : 'Kasir',
                  style: GoogleFonts.poppins(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: isAdmin ? AppColors.primary : AppColors.hint,
                  ),
                ),
                const SizedBox(width: 3),
                Icon(
                  Icons.swap_horiz_rounded,
                  size: 11,
                  color: isAdmin ? AppColors.primary : AppColors.hint,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFloatingNav(bool isAdmin) {
    // Dark floating pill — futuristik
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).padding.bottom + 12,
        top: 8,
      ),
      child: Container(
        height: 64,
        decoration: BoxDecoration(
          color: const Color(0xFF0D1E13),
          borderRadius: BorderRadius.circular(32),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF0B5E38).withOpacity(0.45),
              blurRadius: 28,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: List.generate(
            _labels.length,
            (i) => _NavItem(
              index: i,
              selected: _index == i,
              asset: _iconAssets[i],
              fallbackIcon: _iconFallback[i],
              label: _labels[i],
              onTap: () => _selectTab(i, isAdmin),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer(String role, bool isAdmin) {
    return Drawer(
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(24)),
      ),
      child: Column(
        children: [
          // Gradient header
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.drawerHeader1, AppColors.drawerHeader2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius:
                  BorderRadius.vertical(bottom: Radius.circular(20)),
            ),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 20,
              left: 20,
              right: 20,
              bottom: 24,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                        color: Colors.white.withOpacity(0.25), width: 1.5),
                  ),
                  child: const Icon(Icons.storefront_rounded,
                      color: Colors.white, size: 26),
                ),
                const SizedBox(height: 14),
                Text(
                  'Warung Arasaan',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(height: 6),
                InkWell(
                  onTap: () async {
                    Navigator.of(context).pop();
                    await _switchRole();
                  },
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: Colors.white.withOpacity(0.25), width: 1),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isAdmin
                              ? Icons.admin_panel_settings_rounded
                              : Icons.person_rounded,
                          size: 12,
                          color: Colors.white.withOpacity(0.85),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          isAdmin ? 'Mode Admin' : 'Mode Kasir',
                          style: GoogleFonts.poppins(
                            color: Colors.white.withOpacity(0.85),
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Icon(Icons.swap_horiz_rounded,
                            size: 12,
                            color: Colors.white.withOpacity(0.6)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Menu items
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              children: [
                _DrawerSection(title: 'Laporan & Analisis'),
                _DrawerItem(
                  icon: Icons.receipt_long_rounded,
                  color: AppColors.iconGreen,
                  title: 'Laporan',
                  onTap: () => _openPage('Laporan', const ReportsPage()),
                ),
                if (isAdmin)
                  _DrawerItem(
                    icon: Icons.insights_rounded,
                    color: AppColors.iconBlue,
                    title: 'Analytics',
                    onTap: () =>
                        _openPage('Analytics', const AnalyticsPage()),
                  ),
                if (isAdmin)
                  _DrawerItem(
                    icon: Icons.shopping_basket_rounded,
                    color: AppColors.iconRed,
                    title: 'Saran Belanja',
                    onTap: () =>
                        _openPage('Saran Belanja', const RestockPage()),
                  ),
                if (isAdmin)
                  _DrawerItem(
                    icon: Icons.history_rounded,
                    color: AppColors.iconPurple,
                    title: 'Log Aktivitas',
                    onTap: () =>
                        _openPage('Log Aktivitas', const ActivityLogPage()),
                  ),
                if (isAdmin)
                  _DrawerItem(
                    icon: Icons.build_circle_outlined,
                    color: AppColors.iconAmber,
                    title: 'Tools Operasional',
                    onTap: () => _openPage(
                        'Tools Operasional', const OperationsToolsPage()),
                  ),
                const SizedBox(height: 6),
                _DrawerSection(title: 'Mitra'),
                if (isAdmin)
                  _DrawerItem(
                    icon: Icons.local_shipping_rounded,
                    color: AppColors.iconBlue,
                    title: 'Supplier',
                    onTap: () =>
                        _openPage('Supplier', const SuppliersPage()),
                  ),
                _DrawerItem(
                  icon: Icons.people_alt_rounded,
                  color: AppColors.iconPurple,
                  title: 'Pelanggan',
                  onTap: () =>
                      _openPage('Pelanggan', const CustomersPage()),
                ),
                if (isAdmin) ...[
                  const SizedBox(height: 6),
                  _DrawerSection(title: 'Keuangan'),
                  _DrawerItem(
                    icon: Icons.payments_rounded,
                    color: AppColors.iconAmber,
                    title: 'Hutang',
                    onTap: () => _openPage('Hutang', const DebtsPage()),
                  ),
                  _DrawerItem(
                    icon: Icons.request_quote_rounded,
                    color: AppColors.iconCrimson,
                    title: 'Biaya',
                    onTap: () => _openPage('Biaya', const ExpensesPage()),
                  ),
                  const SizedBox(height: 6),
                  _DrawerSection(title: 'Pengaturan'),
                  _DrawerItem(
                    icon: Icons.backup_rounded,
                    color: AppColors.iconSlate,
                    title: 'Backup & Restore',
                    onTap: () =>
                        _openPage('Backup & Restore', const BackupPage()),
                  ),
                ],
              ],
            ),
          ),

          const Divider(height: 1),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                Icon(Icons.storefront_rounded,
                    size: 12, color: AppColors.hint.withOpacity(0.5)),
                const SizedBox(width: 6),
                Text(
                  'Warung Arasaan',
                  style: GoogleFonts.poppins(
                      fontSize: 11, color: AppColors.hint),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.primaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'V6–V8',
                    style: GoogleFonts.poppins(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Floating Nav Item ────────────────────────────────────────────────────────

class _NavItem extends StatelessWidget {
  final int index;
  final bool selected;
  final String asset;
  final IconData fallbackIcon;
  final String label;
  final VoidCallback onTap;

  const _NavItem({
    required this.index,
    required this.selected,
    required this.asset,
    required this.fallbackIcon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final activeColor = AppColors.goldLight;
    final inactiveColor = Colors.white.withOpacity(0.38);

    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeInOut,
              width: selected ? 44 : 36,
              height: selected ? 32 : 28,
              decoration: selected
                  ? BoxDecoration(
                      color: AppColors.primary.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(16),
                    )
                  : null,
              alignment: Alignment.center,
              child: _buildIcon(asset, fallbackIcon,
                  selected ? activeColor : inactiveColor),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 9,
                fontWeight:
                    selected ? FontWeight.w700 : FontWeight.w400,
                color: selected ? activeColor : inactiveColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIcon(String assetPath, IconData icon, Color color) {
    if (assetPath.isEmpty) {
      return Icon(icon, color: color, size: 19);
    }
    return ColorFiltered(
      colorFilter: ColorFilter.mode(color, BlendMode.srcIn),
      child: Image.asset(assetPath, width: 19, height: 19),
    );
  }
}

// ─── Drawer Helpers ───────────────────────────────────────────────────────────

class _DrawerSection extends StatelessWidget {
  final String title;
  const _DrawerSection({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 4),
      child: Text(
        title.toUpperCase(),
        style: GoogleFonts.poppins(
          fontSize: 10,
          fontWeight: FontWeight.w700,
          color: AppColors.hint,
          letterSpacing: 0.8,
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 16),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: AppColors.onSurface,
                ),
              ),
              const Spacer(),
              const Icon(Icons.chevron_right_rounded,
                  color: AppColors.hint, size: 16),
            ],
          ),
        ),
      ),
    );
  }
}
