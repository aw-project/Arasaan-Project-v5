package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.ActivityLog
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat

private data class HomeShortcut(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val onTap: () -> Unit,
)

@Composable
fun HomeHubScreen(
    container: AppContainer,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var omzetToday by remember { mutableStateOf(0.0) }
    var purchaseToday by remember { mutableStateOf(0.0) }
    var lowStockCount by remember { mutableStateOf(0) }
    var rejectedLoss by remember { mutableStateOf(0.0) }
    var recentLogs by remember { mutableStateOf<List<ActivityLog>>(emptyList()) }

    LaunchedEffect(Unit) {
        val today = AppUtils.epochDayNow()
        val sales = container.salesRepository.all()
        val purchases = container.purchaseRepository.all()
        val products = container.productRepository.all()
        val rejected = container.rejectedRepository.all()

        recentLogs = container.activityLogRepository.recent(6)
        omzetToday = sales.filter { it.dateEpochDay == today }.sumOf { it.totalSales }
        purchaseToday = purchases
            .filter { it.dateEpochDay == today }
            .sumOf { purchase -> purchase.items.sumOf { it.qty * it.buyPrice } }
        lowStockCount = products.count { it.stockQty <= it.minStock && it.minStock > 0.0 }
        rejectedLoss = rejected.filter { it.dateEpochDay == today }.sumOf { it.estimatedLoss }
    }

    val shortcuts = remember(onNavigate, lowStockCount) {
        listOf(
            HomeShortcut("Kasir", "Transaksi cepat untuk penjualan harian", Icons.Rounded.PointOfSale) { onNavigate("fast_pos") },
            HomeShortcut("Produk", "Kelola katalog dan stok", Icons.Rounded.Inventory2) { onNavigate("products") },
            HomeShortcut("Pembelian", "Input stok masuk cepat", Icons.Rounded.ShoppingCart) { onNavigate("purchases") },
            HomeShortcut("Keuangan", "Kas, biaya, dan hutang", Icons.Rounded.Payments) { onNavigate("finance") },
            HomeShortcut("Laporan", "Ringkasan performa usaha", Icons.Rounded.ReceiptLong) { onNavigate("reports") },
            HomeShortcut("Analytics", "Top selling dan margin", Icons.Rounded.Analytics) { onNavigate("analytics") },
            HomeShortcut("Restock", "Stok kritis: $lowStockCount", Icons.Rounded.RestartAlt) { onNavigate("restock") },
            HomeShortcut("Backup", "Ekspor atau restore data", Icons.Rounded.Backup) { onNavigate("backup") },
        )
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Ringkasan Hari Ini", style = MaterialTheme.typography.headlineSmall) }
        item { StatCard("Omzet", UiFormat.money(omzetToday), "Penjualan pada tanggal aktif perangkat") }
        item { StatCard("Modal Pembelian", UiFormat.money(purchaseToday), "Total barang masuk hari ini") }
        item {
            StatCard(
                "Perlu Perhatian",
                "$lowStockCount stok kritis · Rugi reject ${UiFormat.money(rejectedLoss)}",
                "Pantau item yang perlu aksi cepat",
            )
        }
        item { Text("Aksi utama", style = MaterialTheme.typography.titleMedium) }
        item {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 220.dp, max = 520.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                userScrollEnabled = false,
            ) {
                gridItems(shortcuts) { shortcut ->
                    Card(
                        modifier = Modifier.clickable(onClick = shortcut.onTap),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        ListItem(
                            leadingContent = { Icon(shortcut.icon, contentDescription = shortcut.title) },
                            headlineContent = { Text(shortcut.title) },
                            supportingContent = { Text(shortcut.subtitle) },
                        )
                    }
                }
            }
        }
        item { Text("Aktivitas terbaru", style = MaterialTheme.typography.titleMedium) }
        items(recentLogs, key = { it.id }) { log ->
            Card {
                ListItem(
                    headlineContent = { Text(log.type.ifBlank { "Aktivitas" }) },
                    supportingContent = {
                        Text(
                            buildString {
                                append(log.refId.ifBlank { log.id })
                                if (log.newJson.isNotBlank()) {
                                    append(" · diperbarui")
                                } else if (log.oldJson.isNotBlank()) {
                                    append(" · tersimpan")
                                }
                            }
                        )
                    },
                )
            }
        }
    }
}
