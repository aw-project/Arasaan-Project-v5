package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.Sale
import kotlin.math.max

data class ProductKpi(
    val productId: String,
    val name: String,
    val qty: Double,
    val revenue: Double,
    val hpp: Double,
    val profit: Double,
) {
    val marginPercent: Double get() = if (revenue == 0.0) 0.0 else (profit / revenue) * 100.0
}

data class ForecastKpi(
    val productId: String,
    val name: String,
    val stockQty: Double,
    val avgPerDay: Double,
    val suggestBuy: Double,
)

class AnalyticsService {
    fun topSelling(
        sales: List<Sale>,
        products: List<Product>,
        days: Int,
    ): List<ProductKpi> {
        val productNames = products.associateBy({ it.id }, { it.name })
        val acc = linkedMapOf<String, ProductKpi>()
        sales.flatMap { it.items }.forEach { item ->
            val old = acc[item.productId]
            val next = ProductKpi(
                productId = item.productId,
                name = productNames[item.productId] ?: item.productId,
                qty = (old?.qty ?: 0.0) + item.qty,
                revenue = (old?.revenue ?: 0.0) + item.total,
                hpp = (old?.hpp ?: 0.0) + item.totalHpp,
                profit = (old?.profit ?: 0.0) + (item.total - item.totalHpp),
            )
            acc[item.productId] = next
        }
        return acc.values.sortedByDescending { it.qty }
    }

    fun topProfit(sales: List<Sale>, products: List<Product>, days: Int): List<ProductKpi> =
        topSelling(sales, products, days).sortedByDescending { it.profit }

    fun lowMarginProducts(products: List<Product>): List<Pair<Product, Double>> =
        products.map { product ->
            val profit = product.activeSellPrice - product.avgHpp
            val margin = if (product.activeSellPrice <= 0.0) 0.0 else (profit / product.activeSellPrice) * 100.0
            product to margin
        }.sortedBy { it.second }

    fun restockForecast(sales: List<Sale>, products: List<Product>, horizonDays: Int): List<ForecastKpi> {
        val qtyByProduct = mutableMapOf<String, Double>()
        sales.flatMap { it.items }.forEach { item ->
            qtyByProduct[item.productId] = (qtyByProduct[item.productId] ?: 0.0) + item.qty
        }
        val observedDays = max(1, sales.map { it.dateEpochDay }.distinct().size)
        return products.map { product ->
            val avgPerDay = (qtyByProduct[product.id] ?: 0.0) / observedDays.toDouble()
            val target = max(product.targetStock, product.minStock)
            val projectedNeed = max(target, avgPerDay * horizonDays)
            ForecastKpi(
                productId = product.id,
                name = product.name,
                stockQty = product.stockQty,
                avgPerDay = avgPerDay,
                suggestBuy = max(0.0, projectedNeed - product.stockQty),
            )
        }.sortedByDescending { it.suggestBuy }
    }

    fun supplierSpend(purchases: List<Purchase>): List<Pair<String, Double>> =
        purchases.groupBy { it.supplier.trim().ifEmpty { "Tanpa Supplier" } }
            .map { (supplier, rows) -> supplier to rows.sumOf { purchase -> purchase.items.sumOf { it.qty * it.buyPrice } } }
            .sortedByDescending { it.second }

    fun customerRevenue(sales: List<Sale>): List<Pair<String, Double>> =
        sales.groupBy { it.customerName.trim().ifEmpty { "Umum" } }
            .map { (customer, rows) -> customer to rows.sumOf { it.totalSales } }
            .sortedByDescending { it.second }
}
