package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.data.service.ForecastKpi
import com.warungarasaan.app.data.service.ProductKpi
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.QuickRangeChips
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun AnalyticsModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var rangeDays by remember { mutableStateOf(30) }
    var horizonDays by remember { mutableStateOf(14) }
    var topSelling by remember { mutableStateOf<List<ProductKpi>>(emptyList()) }
    var topProfit by remember { mutableStateOf<List<ProductKpi>>(emptyList()) }
    var lowMargin by remember { mutableStateOf<List<Pair<Product, Double>>>(emptyList()) }
    var forecast by remember { mutableStateOf<List<ForecastKpi>>(emptyList()) }
    var supplierSpend by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }
    var customerRevenue by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }

    LaunchedEffect(rangeDays, horizonDays) {
        val sales = container.salesRepository.all()
        val purchases = container.purchaseRepository.all()
        val products = container.productRepository.all()
        val service = AnalyticsService()
        topSelling = service.topSelling(sales, products, rangeDays).take(10)
        topProfit = service.topProfit(sales, products, rangeDays).take(10)
        lowMargin = service.lowMarginProducts(products).take(10)
        forecast = service.restockForecast(sales, products, horizonDays = horizonDays).filter { it.suggestBuy > 0 }.take(10)
        supplierSpend = service.supplierSpend(purchases).take(8)
        customerRevenue = service.customerRevenue(sales).take(8)
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Analytics", style = androidx.compose.material3.MaterialTheme.typography.headlineSmall) }
        item {
            QuickRangeChips(
                currentValue = rangeDays,
                options = listOf(7, 30, 90, 365),
                onSelect = { rangeDays = it },
            )
        }
        item {
            QuickRangeChips(
                currentValue = horizonDays,
                options = listOf(7, 14, 30),
                onSelect = { horizonDays = it },
            )
        }
        item { StatCard("Periode Analitik", "$rangeDays hari", "Fast filter untuk mendekatkan parity analytics Flutter") }
        item { StatCard("Horizon Restock", "$horizonDays hari", "Forecast kebutuhan pembelian berdasarkan rata-rata penjualan") }

        item { Text("Top selling") }
        if (topSelling.isEmpty()) item { EmptyHint("Belum ada data penjualan", "Analitik akan muncul setelah transaksi penjualan tersedia.") }
        items(topSelling, key = { it.productId }) { item ->
            ListItem(
                headlineContent = { Text(item.name) },
                supportingContent = { Text("Qty ${UiFormat.qty(item.qty)} • Profit ${UiFormat.money(item.profit)}") },
                trailingContent = { Text(UiFormat.money(item.revenue)) },
            )
        }
        item { HorizontalDivider() }
        item { Text("Top profit") }
        items(topProfit, key = { it.productId }) { item ->
            ListItem(
                headlineContent = { Text(item.name) },
                supportingContent = { Text("Margin ${"%.1f".format(item.marginPercent)}%") },
                trailingContent = { Text(UiFormat.money(item.profit)) },
            )
        }
        item { HorizontalDivider() }
        item { Text("Margin terendah") }
        items(lowMargin, key = { it.first.id }) { (product, margin) ->
            ListItem(
                headlineContent = { Text(product.name) },
                supportingContent = { Text("HPP ${UiFormat.money(product.avgHpp)} • Jual ${UiFormat.money(product.activeSellPrice)}") },
                trailingContent = { Text("${"%.1f".format(margin)}%") },
            )
        }
        item { HorizontalDivider() }
        item { Text("Forecast restock") }
        items(forecast, key = { it.productId }) { item ->
            ListItem(
                headlineContent = { Text(item.name) },
                supportingContent = { Text("Stok ${UiFormat.qty(item.stockQty)} • Avg/hari ${UiFormat.qty(item.avgPerDay)}") },
                trailingContent = { Text("Beli ${UiFormat.qty(item.suggestBuy)}") },
            )
        }
        item { HorizontalDivider() }
        item { Text("Belanja per supplier") }
        items(supplierSpend, key = { it.first }) { (supplier, amount) ->
            ListItem(
                headlineContent = { Text(supplier) },
                trailingContent = { Text(UiFormat.money(amount)) },
            )
        }
        item { HorizontalDivider() }
        item { Text("Omzet per customer") }
        items(customerRevenue, key = { it.first }) { (customer, amount) ->
            ListItem(
                headlineContent = { Text(customer) },
                trailingContent = { Text(UiFormat.money(amount)) },
            )
        }
    }
}
