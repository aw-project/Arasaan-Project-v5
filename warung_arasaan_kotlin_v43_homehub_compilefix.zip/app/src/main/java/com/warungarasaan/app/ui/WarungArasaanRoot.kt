
package com.warungarasaan.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.di.AppProviders
import com.warungarasaan.app.ui.redesign.NativeHomeScaffold
import com.warungarasaan.app.ui.redesign.NativeModuleRoutes
import com.warungarasaan.app.ui.screens.*

private fun primaryRouteOf(route: String): String = when (route) {
    NativeModuleRoutes.Home -> NativeModuleRoutes.Home
    NativeModuleRoutes.Products,
    NativeModuleRoutes.StockAdjustment,
    NativeModuleRoutes.StockOpname -> NativeModuleRoutes.Products

    NativeModuleRoutes.Sales,
    NativeModuleRoutes.Purchases,
    NativeModuleRoutes.FastPos,
    NativeModuleRoutes.Finance,
    NativeModuleRoutes.Cash,
    NativeModuleRoutes.Expenses,
    NativeModuleRoutes.Debts,
    NativeModuleRoutes.Rejected -> NativeModuleRoutes.Sales

    NativeModuleRoutes.Reports,
    NativeModuleRoutes.Analytics -> NativeModuleRoutes.Reports
    else -> "more"
}

private fun titleFor(route: String): String = when (route) {
    NativeModuleRoutes.Home -> "Warung Arasaan"
    NativeModuleRoutes.Products -> "Produk"
    NativeModuleRoutes.StockAdjustment -> "Penyesuaian Stok"
    NativeModuleRoutes.StockOpname -> "Stock Opname"
    NativeModuleRoutes.Sales -> "Penjualan"
    NativeModuleRoutes.Purchases -> "Pembelian"
    NativeModuleRoutes.FastPos -> "Kasir Cepat"
    NativeModuleRoutes.Finance -> "Keuangan"
    NativeModuleRoutes.Cash -> "Kas"
    NativeModuleRoutes.Expenses -> "Biaya"
    NativeModuleRoutes.Debts -> "Hutang"
    NativeModuleRoutes.Rejected -> "Rejected"
    NativeModuleRoutes.Reports -> "Laporan"
    NativeModuleRoutes.Analytics -> "Analytics"
    NativeModuleRoutes.GlobalSearch, "search" -> "Pencarian"
    NativeModuleRoutes.ActivityLog, "activity" -> "Aktivitas"
    NativeModuleRoutes.Backup, "backup" -> "Backup"
    NativeModuleRoutes.PrintCenter, "print_center" -> "Print Center"
    NativeModuleRoutes.Settings, "settings" -> "Pengaturan"
    NativeModuleRoutes.Customers, "customers" -> "Pelanggan"
    NativeModuleRoutes.Suppliers, "suppliers" -> "Supplier"
    "partners" -> "Partner"
    "restock" -> "Restock"
    "operations" -> "Tools Operasional"
    "analytics_product_detail" -> "Analitik Produk"
    "more" -> "Lainnya"
    else -> "Warung Arasaan"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WarungArasaanRoot() {
    WarungArasaanRoot(AppProviders.container)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WarungArasaanRoot(container: AppContainer) {
    var selected by remember { mutableStateOf(NativeModuleRoutes.Home) }

    LockGate(container = container) {
        NativeHomeScaffold(
            selected = primaryRouteOf(selected),
            onSelect = { selected = it },
            onQuickSale = { selected = NativeModuleRoutes.FastPos },
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                androidx.compose.material3.Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text(titleFor(selected)) },
                            actions = {
                                IconButton(onClick = { selected = NativeModuleRoutes.GlobalSearch }) {
                                    Icon(Icons.Rounded.Search, contentDescription = "Cari")
                                }
                                IconButton(onClick = { selected = "settings" }) {
                                    Icon(Icons.Rounded.Settings, contentDescription = "Pengaturan")
                                }
                            },
                        )
                    },
                ) { topPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(topPadding)
                    ) {
                        when (selected) {
                            NativeModuleRoutes.Home -> HomeHubScreen(container, onNavigate = { selected = it }, modifier = Modifier.fillMaxSize())

                            NativeModuleRoutes.Products -> ProductsModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.StockAdjustment -> StockAdjustmentScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.StockOpname -> StockOpnameScreen(container, Modifier.fillMaxSize())

                            NativeModuleRoutes.Sales -> SalesModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Purchases -> PurchasesModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.FastPos -> FastPosModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Finance -> FinanceModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Cash -> NativeCashModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Expenses -> ExpensesModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Debts -> DebtsModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Rejected -> RejectedModuleScreen(container, Modifier.fillMaxSize())

                            NativeModuleRoutes.Reports -> ReportsModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Analytics -> AnalyticsModuleScreen(container, Modifier.fillMaxSize())

                            NativeModuleRoutes.GlobalSearch, "search" -> GlobalSearchScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.ActivityLog, "activity" -> ActivityLogPageScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Backup, "backup" -> BackupModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.PrintCenter, "print_center" -> PrintCenterModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Customers, "customers" -> CustomersModuleScreen(container, Modifier.fillMaxSize())
                            NativeModuleRoutes.Suppliers, "suppliers" -> SuppliersModuleScreen(container, Modifier.fillMaxSize())
                            "partners" -> PartnersModuleScreen(container, Modifier.fillMaxSize())
                            "restock" -> RestockModuleScreen(container, Modifier.fillMaxSize())
                            "operations" -> OperationsToolsModuleScreen(container, Modifier.fillMaxSize())
                            "analytics_product_detail" -> AnalyticsProductDetailScreen(container, Modifier.fillMaxSize())
                            "settings" -> SettingsModuleScreen(container, Modifier.fillMaxSize())
                            "more" -> MoreModuleScreen(container, onNavigate = { selected = it }, modifier = Modifier.fillMaxSize())
                            else -> HomeHubScreen(container, onNavigate = { selected = it }, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }
        }
    }
}
