package com.warungarasaan.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Entity(tableName = "products")
data class ProductEntity(@PrimaryKey val id: String, val name: String, val unit: String, val defaultMarginPercent: Double, val activeSellPrice: Double, val stockQty: Double, val avgHpp: Double, val minStock: Double, val targetStock: Double, val sku: String, val category: String, val imagePath: String?)
@Entity(tableName = "purchases") data class PurchaseEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val supplier: String, val paymentMethod: String)
@Entity(tableName = "purchase_items", primaryKeys = ["purchaseId", "productId"]) data class PurchaseItemEntity(val purchaseId: String, val productId: String, val qty: Double, val buyPrice: Double)
@Entity(tableName = "sales") data class SaleEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val paymentMethod: String, val customerName: String, val discountAmount: Double)
@Entity(tableName = "sale_items", primaryKeys = ["saleId", "productId"]) data class SaleItemEntity(val saleId: String, val productId: String, val qty: Double, val sellPrice: Double, val hppAtSale: Double)
@Entity(tableName = "payment_splits", primaryKeys = ["saleId", "method"]) data class PaymentSplitEntity(val saleId: String, val method: String, val amount: Double)
@Entity(tableName = "expenses") data class ExpenseEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val note: String, val amount: Double, val paymentMethod: String, val category: String)
@Entity(tableName = "debts") data class DebtEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val creditor: String, val note: String, val principal: Double, val paid: Double)
@Entity(tableName = "cash_entries") data class CashEntryEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val direction: String, val source: String, val method: String, val note: String, val amount: Double, val refId: String)
@Entity(tableName = "stock_movements") data class StockMovementEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val productId: String, val type: String, val qtyDelta: Double, val note: String, val lossType: String?, val lossAmount: Double)
@Entity(tableName = "rejected_items") data class RejectedItemEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val productId: String, val qty: Double, val reason: String, val handling: String, val note: String, val hppAtTime: Double, val estimatedLoss: Double)
@Entity(tableName = "activity_logs") data class ActivityLogEntity(@PrimaryKey val id: String, val dateEpochDay: Int, val type: String, val refId: String, val oldJson: String, val newJson: String)
@Entity(tableName = "app_settings") data class AppSettingsEntity(@PrimaryKey val id: String = "app", val pinEnabled: Boolean, val pinHash: String)

@Dao interface ProductDao {
    @Query("SELECT * FROM products ORDER BY LOWER(name) ASC") suspend fun getAll(): List<ProductEntity>
    @Query("SELECT * FROM products WHERE id = :id") suspend fun getById(id: String): ProductEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: ProductEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<ProductEntity>)
    @Query("DELETE FROM products WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM products") suspend fun clear()
}
@Dao interface PurchaseDao {
    @Query("SELECT * FROM purchases ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<PurchaseEntity>
    @Query("SELECT * FROM purchases WHERE id = :id") suspend fun getById(id: String): PurchaseEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: PurchaseEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<PurchaseEntity>)
    @Query("DELETE FROM purchases WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM purchases") suspend fun clear()
}
@Dao interface PurchaseItemDao {
    @Query("SELECT * FROM purchase_items WHERE purchaseId = :purchaseId") suspend fun getByPurchaseId(purchaseId: String): List<PurchaseItemEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<PurchaseItemEntity>)
    @Query("DELETE FROM purchase_items WHERE purchaseId = :purchaseId") suspend fun deleteByPurchaseId(purchaseId: String)
    @Query("DELETE FROM purchase_items") suspend fun clear()
}
@Dao interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<SaleEntity>
    @Query("SELECT * FROM sales WHERE id = :id") suspend fun getById(id: String): SaleEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: SaleEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<SaleEntity>)
    @Query("DELETE FROM sales WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM sales") suspend fun clear()
}
@Dao interface SaleItemDao {
    @Query("SELECT * FROM sale_items WHERE saleId = :saleId") suspend fun getBySaleId(saleId: String): List<SaleItemEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<SaleItemEntity>)
    @Query("DELETE FROM sale_items WHERE saleId = :saleId") suspend fun deleteBySaleId(saleId: String)
    @Query("DELETE FROM sale_items") suspend fun clear()
}
@Dao interface PaymentSplitDao {
    @Query("SELECT * FROM payment_splits WHERE saleId = :saleId") suspend fun getBySaleId(saleId: String): List<PaymentSplitEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<PaymentSplitEntity>)
    @Query("DELETE FROM payment_splits WHERE saleId = :saleId") suspend fun deleteBySaleId(saleId: String)
    @Query("DELETE FROM payment_splits") suspend fun clear()
}
@Dao interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<ExpenseEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: ExpenseEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<ExpenseEntity>)
    @Query("DELETE FROM expenses WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM expenses") suspend fun clear()
}
@Dao interface DebtDao {
    @Query("SELECT * FROM debts ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<DebtEntity>
    @Query("SELECT * FROM debts WHERE id = :id") suspend fun getById(id: String): DebtEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: DebtEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<DebtEntity>)
    @Query("DELETE FROM debts WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM debts") suspend fun clear()
}
@Dao interface CashDao {
    @Query("SELECT * FROM cash_entries ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<CashEntryEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: CashEntryEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<CashEntryEntity>)
    @Query("DELETE FROM cash_entries WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM cash_entries WHERE source = :source AND refId = :refId") suspend fun deleteByRef(source: String, refId: String)
    @Query("DELETE FROM cash_entries") suspend fun clear()
}
@Dao interface StockMovementDao {
    @Query("SELECT * FROM stock_movements ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<StockMovementEntity>
    @Query("SELECT * FROM stock_movements WHERE productId = :productId ORDER BY dateEpochDay DESC, id DESC") suspend fun byProduct(productId: String): List<StockMovementEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: StockMovementEntity)
    @Query("DELETE FROM stock_movements WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM stock_movements") suspend fun clear()
    @Query("SELECT * FROM stock_movements WHERE type = :type AND note = :note") suspend fun getByTypeAndNote(type: String, note: String): List<StockMovementEntity>
    @Query("SELECT * FROM stock_movements WHERE productId = :productId") suspend fun getAllByProduct(productId: String): List<StockMovementEntity>
}
@Dao interface RejectedItemDao {
    @Query("SELECT * FROM rejected_items ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<RejectedItemEntity>
    @Query("SELECT * FROM rejected_items WHERE id = :id") suspend fun getById(id: String): RejectedItemEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: RejectedItemEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<RejectedItemEntity>)
    @Query("DELETE FROM rejected_items WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM rejected_items") suspend fun clear()
}
@Dao interface ActivityLogDao {
    @Query("SELECT * FROM activity_logs ORDER BY dateEpochDay DESC, id DESC") suspend fun getAll(): List<ActivityLogEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: ActivityLogEntity)
    @Query("DELETE FROM activity_logs WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM activity_logs") suspend fun clear()
}
@Dao interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 'app'") suspend fun get(): AppSettingsEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(entity: AppSettingsEntity)
}

@Database(
    entities = [ProductEntity::class, PurchaseEntity::class, PurchaseItemEntity::class, SaleEntity::class, SaleItemEntity::class, PaymentSplitEntity::class, ExpenseEntity::class, DebtEntity::class, CashEntryEntity::class, StockMovementEntity::class, RejectedItemEntity::class, ActivityLogEntity::class, AppSettingsEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun purchaseItemDao(): PurchaseItemDao
    abstract fun saleDao(): SaleDao
    abstract fun saleItemDao(): SaleItemDao
    abstract fun paymentSplitDao(): PaymentSplitDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun debtDao(): DebtDao
    abstract fun cashDao(): CashDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun rejectedItemDao(): RejectedItemDao
    abstract fun activityLogDao(): ActivityLogDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "warung_arasaan.db").build()
    }
}

private val Context.dataStore by preferencesDataStore("meta_store")

class MetaStore(private val context: Context) {
    private val roleKey = stringPreferencesKey("role")
    private val autoBackupEnabledKey = booleanPreferencesKey("auto_backup_enabled")
    private val autoBackupDaysKey = intPreferencesKey("auto_backup_days")
    private val lastAutoBackupKey = longPreferencesKey("last_auto_backup_ms")

    suspend fun role(): String = context.dataStore.data.map { it[roleKey] ?: "admin" }.first()
    suspend fun setRole(value: String) = context.dataStore.edit { it[roleKey] = value }
    suspend fun autoBackupEnabled(): Boolean = context.dataStore.data.map { it[autoBackupEnabledKey] ?: false }.first()
    suspend fun setAutoBackupEnabled(value: Boolean) = context.dataStore.edit { it[autoBackupEnabledKey] = value }
    suspend fun autoBackupDays(): Int = context.dataStore.data.map { it[autoBackupDaysKey] ?: 7 }.first()
    suspend fun setAutoBackupDays(value: Int) = context.dataStore.edit { it[autoBackupDaysKey] = value }
    suspend fun lastAutoBackupEpochMs(): Long = context.dataStore.data.map { it[lastAutoBackupKey] ?: 0L }.first()
    suspend fun setLastAutoBackupEpochMs(value: Long) = context.dataStore.edit { it[lastAutoBackupKey] = value }

    suspend fun getBoolean(key: String, defaultValue: Boolean = false): Boolean {
        val prefKey = booleanPreferencesKey(key)
        return context.dataStore.data.map { it[prefKey] ?: defaultValue }.first()
    }

    suspend fun setBoolean(key: String, value: Boolean) {
        val prefKey = booleanPreferencesKey(key)
        context.dataStore.edit { it[prefKey] = value }
    }
}
