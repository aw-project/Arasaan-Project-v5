package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.PaymentSplit
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Sale
import com.warungarasaan.app.domain.model.SaleItem
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun FastPosModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var salesToday by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<MutableMap<String, Int>>(mutableMapOf()) }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var customerName by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("0") }
    var cashReceivedText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    suspend fun reload() {
        products = container.productRepository.all().filter { it.stockQty > 0.0 }
        salesToday = container.salesRepository.all().filter { it.dateEpochDay == AppUtils.epochDayNow() }
    }

    LaunchedEffect(Unit) { reload() }

    val filtered = remember(products, query) {
        val q = query.trim().lowercase()
        products.filter {
            q.isBlank() ||
                it.name.lowercase().contains(q) ||
                it.sku.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
        }
    }

    val cart = remember(products, selected) {
        products.mapNotNull { product ->
            val qty = selected[product.id] ?: 0
            if (qty <= 0) null else product to qty.toDouble()
        }
    }
    val grossTotal = remember(cart) { cart.sumOf { (product, qty) -> product.activeSellPrice * qty } }
    val itemCount = remember(cart) { cart.sumOf { it.second } }
    val discountAmount = remember(discountText) { discountText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0 }
    val netTotal = (grossTotal - discountAmount).coerceAtLeast(0.0)
    val cashReceived = remember(cashReceivedText) { cashReceivedText.toDoubleOrNull() ?: 0.0 }
    val changeAmount = (cashReceived - netTotal).coerceAtLeast(0.0)
    val lastSale = salesToday.maxByOrNull { it.id }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (cart.isEmpty()) {
                        message = "Keranjang masih kosong."
                        return@FloatingActionButton
                    }
                    if (paymentMethod.equals("Cash", ignoreCase = true) && cashReceived > 0.0 && cashReceived < netTotal) {
                        message = "Uang bayar masih kurang."
                        return@FloatingActionButton
                    }
                    scope.launch {
                        val items = cart.map { (product, qty) ->
                            SaleItem(
                                productId = product.id,
                                qty = qty,
                                sellPrice = product.activeSellPrice,
                                hppAtSale = product.avgHpp,
                            )
                        }
                        val sale = Sale(
                            id = AppUtils.newId("sale"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            items = items,
                            paymentMethod = paymentMethod,
                            customerName = customerName.trim(),
                            discountAmount = discountAmount,
                            paymentSplits = listOf(PaymentSplit(paymentMethod, netTotal)),
                        )
                        container.salesRepository.add(sale)
                        container.activityLogRepository.log(
                            "fast_pos",
                            "Fast POS ${sale.id} total ${UiFormat.money(netTotal)} untuk ${customerName.ifBlank { "umum" }}",
                        )
                        selected = mutableMapOf()
                        customerName = ""
                        discountText = "0"
                        cashReceivedText = ""
                        message = "Transaksi tersimpan."
                        reload()
                    }
                },
            ) { Text("Bayar") }
        },
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SectionCard(
                    title = "Fast POS",
                    subtitle = "Checkout cepat dengan diskon, uang diterima, dan ringkasan transaksi terakhir.",
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Cari produk / SKU / kategori") },
                    )
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Nama customer") },
                    )
                    OutlinedTextField(
                        value = paymentMethod,
                        onValueChange = { paymentMethod = it },
                        label = { Text("Metode bayar") },
                    )
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { discountText = it },
                        label = { Text("Diskon nominal") },
                    )
                    OutlinedTextField(
                        value = cashReceivedText,
                        onValueChange = { cashReceivedText = it },
                        label = { Text("Uang diterima") },
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { paymentMethod = "Cash" }) { Text("Cash") }
                        TextButton(onClick = { paymentMethod = "QRIS" }) { Text("QRIS") }
                        TextButton(onClick = { paymentMethod = "Transfer" }) { Text("Transfer") }
                    }
                    InfoChip("Item: ${UiFormat.qty(itemCount)}")
                    InfoChip("Subtotal: ${UiFormat.money(grossTotal)}")
                    InfoChip("Diskon: ${UiFormat.money(discountAmount)}")
                    InfoChip("Total: ${UiFormat.money(netTotal)}")
                    if (cashReceived > 0.0) {
                        InfoChip("Kembalian: ${UiFormat.money(changeAmount)}")
                    }
                    if (lastSale != null) {
                        Text("Transaksi terakhir: ${lastSale.id} • ${UiFormat.money(lastSale.totalSales)}")
                    }
                    if (salesToday.isNotEmpty()) {
                        Text("Transaksi hari ini: ${salesToday.size}")
                    }
                    if (message.isNotBlank()) {
                        Text(message)
                    }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyHint(
                        title = "Produk tidak ditemukan",
                        subtitle = "Coba kata kunci lain atau tambah stok dahulu.",
                    )
                }
            }

            items(filtered, key = { it.id }) { product ->
                val currentQty = selected[product.id] ?: 0
                ListItem(
                    headlineContent = { Text(product.name) },
                    supportingContent = {
                        Text("Stock ${UiFormat.qty(product.stockQty)} • ${UiFormat.money(product.activeSellPrice)}")
                    },
                    trailingContent = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(
                                onClick = {
                                    val next = (currentQty - 1).coerceAtLeast(0)
                                    selected = selected.toMutableMap().apply {
                                        if (next == 0) remove(product.id) else put(product.id, next)
                                    }
                                },
                            ) { Text("-") }
                            Text(currentQty.toString())
                            TextButton(
                                onClick = {
                                    val next = currentQty + 1
                                    selected = selected.toMutableMap().apply { put(product.id, next) }
                                },
                            ) { Text("+") }
                        }
                    },
                )
            }
        }
    }
}
