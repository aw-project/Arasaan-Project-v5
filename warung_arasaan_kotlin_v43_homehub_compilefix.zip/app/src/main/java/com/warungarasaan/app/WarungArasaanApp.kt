package com.warungarasaan.app

import android.app.Application
import com.warungarasaan.app.data.local.AppDatabase
import com.warungarasaan.app.data.local.MetaStore
import com.warungarasaan.app.data.repository.*
import com.warungarasaan.app.data.service.UnitMigrationService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class WarungArasaanApp : Application() {
    lateinit var container: AppContainer
        private set

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.create(this)
        val metaStore = MetaStore(this)
        container = AppContainer(
            database = database,
            productRepository = ProductRepository(database.productDao()),
            purchaseRepository = PurchaseRepository(
                purchaseDao = database.purchaseDao(),
                purchaseItemDao = database.purchaseItemDao(),
                productDao = database.productDao(),
                stockMovementDao = database.stockMovementDao(),
                cashDao = database.cashDao(),
            ),
            salesRepository = SalesRepository(
                saleDao = database.saleDao(),
                saleItemDao = database.saleItemDao(),
                paymentSplitDao = database.paymentSplitDao(),
                productDao = database.productDao(),
                stockMovementDao = database.stockMovementDao(),
                cashDao = database.cashDao(),
            ),
            expenseRepository = ExpenseRepository(database.expenseDao(), database.cashDao()),
            debtRepository = DebtRepository(database.debtDao(), database.cashDao()),
            cashRepository = CashRepository(database.cashDao()),
            movementRepository = MovementRepository(database.stockMovementDao()),
            rejectedRepository = RejectedRepository(
                rejectedItemDao = database.rejectedItemDao(),
                productDao = database.productDao(),
                stockMovementDao = database.stockMovementDao(),
                cashDao = database.cashDao(),
            ),
            activityLogRepository = ActivityLogRepository(database.activityLogDao()),
            settingsRepository = SettingsRepository(database.appSettingsDao()),
            metaRepository = MetaRepository(metaStore),
        )

        applicationScope.launch {
            UnitMigrationService(
                productRepository = container.productRepository,
                purchaseRepository = container.purchaseRepository,
                salesRepository = container.salesRepository,
                movementRepository = container.movementRepository,
                metaRepository = container.metaRepository,
            ).migrateKgToGramOnce()
        }
    }
}

data class AppContainer(
    val database: AppDatabase,
    val productRepository: ProductRepository,
    val purchaseRepository: PurchaseRepository,
    val salesRepository: SalesRepository,
    val expenseRepository: ExpenseRepository,
    val debtRepository: DebtRepository,
    val cashRepository: CashRepository,
    val movementRepository: MovementRepository,
    val rejectedRepository: RejectedRepository,
    val activityLogRepository: ActivityLogRepository,
    val settingsRepository: SettingsRepository,
    val metaRepository: MetaRepository,
)
