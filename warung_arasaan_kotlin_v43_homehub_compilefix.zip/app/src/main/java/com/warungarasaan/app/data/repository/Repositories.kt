package com.warungarasaan.app.data.repository

import com.warungarasaan.app.core.AppUtils.epochDayNow
import com.warungarasaan.app.core.AppUtils.hppWeightedAverage
import com.warungarasaan.app.core.AppUtils.newId
import com.warungarasaan.app.core.AppUtils.normalizeMoney
import com.warungarasaan.app.core.AppUtils.normalizeQty
import com.warungarasaan.app.core.AppUtils.sha256
import com.warungarasaan.app.data.local.*
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.domain.model.*
import kotlin.math.abs

private fun ProductEntity.toDomain() = Product(id, name, unit, defaultMarginPercent, activeSellPrice, stockQty, avgHpp, minStock, targetStock, sku, category, imagePath)
private fun Product.toEntity() = ProductEntity(id, name, unit, defaultMarginPercent, activeSellPrice, stockQty, avgHpp, minStock, targetStock, sku, category, imagePath)
private fun ExpenseEntity.toDomain() = Expense(id, dateEpochDay, note, amount, paymentMethod, category)
private fun Expense.toEntity() = ExpenseEntity(id, dateEpochDay, note, amount, paymentMethod, category)
private fun DebtEntity.toDomain() = Debt(id, dateEpochDay, creditor, note, principal, paid)
private fun Debt.toEntity() = DebtEntity(id, dateEpochDay, creditor, note, principal, paid)
private fun CashEntry.toEntity() = CashEntryEntity(id, dateEpochDay, direction, source, method, note, amount, refId)
private fun CashEntryEntity.toDomain() = CashEntry(id, dateEpochDay, direction, source, method, note, amount, refId)
private fun StockMovementEntity.toDomain() = StockMovement(id, dateEpochDay, productId, type, qtyDelta, note, lossType, lossAmount)
private fun StockMovement.toEntity() = StockMovementEntity(id, dateEpochDay, productId, type, qtyDelta, note, lossType, lossAmount)
private fun RejectedItemEntity.toDomain() = RejectedItem(id, dateEpochDay, productId, qty, reason, handling, note, hppAtTime, estimatedLoss)
private fun RejectedItem.toEntity() = RejectedItemEntity(id, dateEpochDay, productId, qty, reason, handling, note, hppAtTime, estimatedLoss)
private fun ActivityLogEntity.toDomain() = ActivityLog(id, dateEpochDay, type, refId, oldJson, newJson)
private fun ActivityLog.toEntity() = ActivityLogEntity(id, dateEpochDay, type, refId, oldJson, newJson)
private fun AppSettingsEntity.toDomain() = AppSettings(id, pinEnabled, pinHash)
private fun AppSettings.toEntity() = AppSettingsEntity(id, pinEnabled, pinHash)
private fun PurchaseEntity.toDomain(items: List<PurchaseItem>) = Purchase(id, dateEpochDay, supplier, paymentMethod, items)
private fun Purchase.toEntity() = PurchaseEntity(id, dateEpochDay, supplier, paymentMethod)
private fun PurchaseItemEntity.toDomain() = PurchaseItem(productId, qty, buyPrice)
private fun PurchaseItem.toEntity(purchaseId: String) = PurchaseItemEntity(purchaseId, productId, qty, buyPrice)
private fun SaleEntity.toDomain(items: List<SaleItem>, splits: List<PaymentSplit>) = Sale(id, dateEpochDay, items, paymentMethod, customerName, discountAmount, splits)
private fun Sale.toEntity() = SaleEntity(id, dateEpochDay, paymentMethod, customerName, discountAmount)
private fun SaleItemEntity.toDomain() = SaleItem(productId, qty, sellPrice, hppAtSale)
private fun SaleItem.toEntity(saleId: String) = SaleItemEntity(saleId, productId, qty, sellPrice, hppAtSale)
private fun PaymentSplitEntity.toDomain() = PaymentSplit(method, amount)
private fun PaymentSplit.toEntity(saleId: String) = PaymentSplitEntity(saleId, method, amount)

class ProductRepository(private val dao: ProductDao) {
    suspend fun all(): List<Product> = dao.getAll().map { it.toDomain() }
    suspend fun getById(id: String): Product? = dao.getById(id)?.toDomain()
    suspend fun upsert(product: Product) = dao.upsert(product.toEntity())
    suspend fun remove(id: String) = dao.delete(id)
}

class CashRepository(private val dao: CashDao) {
    suspend fun all(): List<CashEntry> = dao.getAll().map { it.toDomain() }
    suspend fun add(entry: CashEntry) = dao.upsert(entry.toEntity())
    suspend fun remove(id: String) = dao.delete(id)
    suspend fun removeByRef(source: String, refId: String) = dao.deleteByRef(source, refId)
}

class ExpenseRepository(private val expenseDao: ExpenseDao, private val cashDao: CashDao) {
    suspend fun all(): List<Expense> = expenseDao.getAll().map { it.toDomain() }
    suspend fun add(expense: Expense) {
        require(expense.amount > 0) { "Nominal biaya harus lebih dari 0." }
        expenseDao.upsert(expense.toEntity())
        cashDao.upsert(CashEntry(newId("cash"), expense.dateEpochDay, "out", "expense", expense.paymentMethod, expense.note, expense.amount, expense.id).toEntity())
    }
    suspend fun remove(id: String) {
        expenseDao.delete(id)
        cashDao.deleteByRef("expense", id)
    }
}

class DebtRepository(private val debtDao: DebtDao, private val cashDao: CashDao) {
    suspend fun all(): List<Debt> = debtDao.getAll().map { it.toDomain() }
    suspend fun add(debt: Debt) = debtDao.upsert(debt.toEntity())
    suspend fun remove(id: String) {
        cashDao.deleteByRef("debt_payment", id)
        debtDao.delete(id)
    }
    suspend fun addPayment(id: String, amount: Double, dateEpochDay: Int, method: String = "Cash") {
        require(amount > 0) { "Nominal pembayaran hutang harus lebih dari 0." }
        val debt = debtDao.getById(id) ?: return
        debtDao.upsert(debt.copy(paid = (debt.paid + amount).coerceAtMost(debt.principal)))
        cashDao.upsert(CashEntry(newId("cash"), dateEpochDay, "out", "debt_payment", method, "Bayar hutang: ${debt.creditor}", amount, debt.id).toEntity())
    }
}

class MovementRepository(private val dao: StockMovementDao) {
    suspend fun all(): List<StockMovement> = dao.getAll().map { it.toDomain() }
    suspend fun byProduct(productId: String): List<StockMovement> = dao.byProduct(productId).map { it.toDomain() }
    suspend fun add(movement: StockMovement) = dao.upsert(movement.toEntity())
    suspend fun clear() = dao.clear()
}

class RejectedRepository(private val rejectedItemDao: RejectedItemDao, private val productDao: ProductDao, private val stockMovementDao: StockMovementDao, private val cashDao: CashDao) {
    suspend fun all(): List<RejectedItem> = rejectedItemDao.getAll().map { it.toDomain() }
    suspend fun add(item: RejectedItem) {
        require(item.qty > 0) { "Jumlah barang rejek harus lebih dari 0." }
        val product = productDao.getById(item.productId) ?: error("Produk tidak ditemukan.")
        require(product.stockQty >= item.qty) { "Stok tidak cukup. Stok tersedia: ${product.stockQty} ${product.unit}." }
        rejectedItemDao.upsert(item.toEntity())
        productDao.upsert(product.copy(stockQty = product.stockQty - item.qty))
        stockMovementDao.upsert(StockMovement(newId("mv"), item.dateEpochDay, item.productId, "reject", -item.qty, "Rejek: ${item.reason} — ${item.note}", item.reason, item.estimatedLoss).toEntity())
        if (item.estimatedLoss > 0) {
            cashDao.upsert(CashEntry(newId("cash"), item.dateEpochDay, "out", "reject", PaymentMethods.NON_CASH, "Kerugian Rejek: ${item.reason}", item.estimatedLoss, item.id).toEntity())
        }
    }
    suspend fun remove(id: String) {
        val item = rejectedItemDao.getById(id)?.toDomain() ?: return
        productDao.getById(item.productId)?.let { productDao.upsert(it.copy(stockQty = it.stockQty + item.qty)) }
        stockMovementDao.getAllByProduct(item.productId).filter { it.type == "reject" && it.dateEpochDay == item.dateEpochDay && abs(it.qtyDelta + item.qty) < 0.001 }.forEach { stockMovementDao.delete(it.id) }
        cashDao.deleteByRef("reject", id)
        rejectedItemDao.delete(id)
    }
}

class ActivityLogRepository(private val dao: ActivityLogDao) {
    private val maxLogs = 500
    suspend fun all(): List<ActivityLog> = dao.getAll().map { it.toDomain() }
    suspend fun recent(limit: Int = 100): List<ActivityLog> = all().take(limit)
    suspend fun add(log: ActivityLog) {
        dao.upsert(log.toEntity())
        all().drop(maxLogs).forEach { dao.delete(it.id) }
    }
    suspend fun log(type: String, message: String) = add(ActivityLog(newId("log"), epochDayNow(), type, "", "", message))
    suspend fun clear() = dao.clear()
}

class SettingsRepository(private val dao: AppSettingsDao) {
    suspend fun get(): AppSettings = dao.get()?.toDomain() ?: AppSettings(pinEnabled = false, pinHash = "")
    suspend fun setPin(pin: String) = dao.upsert(AppSettings(pinEnabled = true, pinHash = sha256(pin)).toEntity())
    suspend fun disablePin() = dao.upsert(AppSettings(pinEnabled = false, pinHash = "").toEntity())
    suspend fun verifyPin(pin: String): Boolean {
        val settings = get()
        return !settings.pinEnabled || sha256(pin) == settings.pinHash
    }
}

class MetaRepository(private val store: MetaStore) {
    suspend fun role(): String = store.role()
    suspend fun setRole(value: String) = store.setRole(value)
    suspend fun autoBackupEnabled(): Boolean = store.autoBackupEnabled()
    suspend fun setAutoBackupEnabled(value: Boolean) = store.setAutoBackupEnabled(value)
    suspend fun autoBackupDays(): Int = store.autoBackupDays()
    suspend fun setAutoBackupDays(value: Int) = store.setAutoBackupDays(value)
    suspend fun lastAutoBackupEpochMs(): Long = store.lastAutoBackupEpochMs()
    suspend fun setLastAutoBackupEpochMs(value: Long) = store.setLastAutoBackupEpochMs(value)
    suspend fun lastAutoBackupMillis(): Long = lastAutoBackupEpochMs()
    suspend fun setLastAutoBackupMillis(value: Long) = setLastAutoBackupEpochMs(value)
    suspend fun getBoolean(key: String, defaultValue: Boolean = false): Boolean = store.getBoolean(key, defaultValue)
    suspend fun setBoolean(key: String, value: Boolean) = store.setBoolean(key, value)
}

class PurchaseRepository(private val purchaseDao: PurchaseDao, private val purchaseItemDao: PurchaseItemDao, private val productDao: ProductDao, private val stockMovementDao: StockMovementDao, private val cashDao: CashDao) {
    suspend fun all(): List<Purchase> = purchaseDao.getAll().map { it.toDomain(purchaseItemDao.getByPurchaseId(it.id).map { item -> item.toDomain() }) }
    suspend fun getById(id: String): Purchase? = purchaseDao.getById(id)?.toDomain(purchaseItemDao.getByPurchaseId(id).map { it.toDomain() })

    suspend fun add(purchase: Purchase) {
        require(purchase.items.isNotEmpty()) { "Transaksi pembelian tidak boleh kosong." }
        purchase.items.forEach {
            require(it.qty > 0) { "Qty pembelian harus lebih dari 0 untuk ${it.productId}." }
            require(it.buyPrice >= 0) { "Harga beli tidak boleh negatif untuk ${it.productId}." }
            requireNotNull(productDao.getById(it.productId)) { "Produk tidak ditemukan: ${it.productId}" }
        }
        if (!purchase.paymentMethod.equals(PaymentMethods.HUTANG, true)) {
            val total = purchase.items.sumOf { it.qty * it.buyPrice }
            cashDao.upsert(CashEntry(newId("cash"), purchase.dateEpochDay, "out", "purchase", purchase.paymentMethod, if (purchase.supplier.isBlank()) "Pembelian" else "Pembelian (${purchase.supplier})", total, purchase.id).toEntity())
        }
        purchase.items.forEach { item ->
            stockMovementDao.upsert(StockMovement(newId("mv"), purchase.dateEpochDay, item.productId, "purchase", item.qty, "Pembelian#${purchase.id}").toEntity())
            val product = productDao.getById(item.productId)!!
            val oldCost = product.stockQty * product.avgHpp
            val incomingCost = item.qty * item.buyPrice
            val newQty = product.stockQty + item.qty
            productDao.upsert(product.copy(stockQty = normalizeQty(newQty), avgHpp = hppWeightedAverage(newQty, oldCost + incomingCost)))
        }
        purchaseDao.upsert(purchase.toEntity())
        purchaseItemDao.deleteByPurchaseId(purchase.id)
        purchaseItemDao.upsertAll(purchase.items.map { it.toEntity(purchase.id) })
    }

    suspend fun replace(purchase: Purchase) {
        if (purchaseDao.getById(purchase.id) != null) {
            remove(purchase.id)
        }
        add(purchase)
    }

    suspend fun remove(id: String) {
        val purchase = purchaseDao.getById(id)?.toDomain(purchaseItemDao.getByPurchaseId(id).map { it.toDomain() }) ?: run { purchaseDao.delete(id); return }
        stockMovementDao.getByTypeAndNote("purchase", "Pembelian#$id").forEach { stockMovementDao.delete(it.id) }
        purchaseDao.delete(id)
        purchaseItemDao.deleteByPurchaseId(id)
        cashDao.deleteByRef("purchase", id)
        purchase.items.map { it.productId }.toSet().forEach { productId ->
            val product = productDao.getById(productId) ?: return@forEach
            val stock = stockMovementDao.getAllByProduct(productId).sumOf { it.qtyDelta }
            var totalQty = 0.0
            var totalCost = 0.0
            all().forEach { existing ->
                existing.items.filter { it.productId == productId }.forEach { item ->
                    totalQty += item.qty
                    totalCost += item.qty * item.buyPrice
                }
            }
            productDao.upsert(product.copy(stockQty = normalizeQty(stock.coerceAtLeast(0.0)), avgHpp = if (totalQty <= 0.0) 0.0 else hppWeightedAverage(totalQty, totalCost)))
        }
    }
}

class SalesRepository(private val saleDao: SaleDao, private val saleItemDao: SaleItemDao, private val paymentSplitDao: PaymentSplitDao, private val productDao: ProductDao, private val stockMovementDao: StockMovementDao, private val cashDao: CashDao) {
    suspend fun all(): List<Sale> = saleDao.getAll().map { it.toDomain(saleItemDao.getBySaleId(it.id).map { item -> item.toDomain() }, paymentSplitDao.getBySaleId(it.id).map { split -> split.toDomain() }) }
    suspend fun getById(id: String): Sale? = saleDao.getById(id)?.toDomain(saleItemDao.getBySaleId(id).map { it.toDomain() }, paymentSplitDao.getBySaleId(id).map { it.toDomain() })

    suspend fun add(sale: Sale) {
        require(sale.items.isNotEmpty()) { "Transaksi penjualan tidak boleh kosong." }
        require(sale.discountAmount >= 0) { "Diskon tidak boleh negatif." }
        require(sale.discountAmount <= sale.grossSales) { "Diskon melebihi total bruto penjualan." }
        sale.items.forEach { item ->
            require(item.qty > 0) { "Qty penjualan harus lebih dari 0 untuk ${item.productId}." }
            val product = productDao.getById(item.productId) ?: error("Produk tidak ditemukan: ${item.productId}")
            require(item.qty <= product.stockQty) { "Stok tidak cukup untuk ${product.name}. Stok: ${"%.2f".format(product.stockQty)}" }
        }
        val normalizedSplits = sale.normalizedSplits
        val splitTotal = normalizedSplits.sumOf { it.amount }
        require(abs(normalizeMoney(splitTotal) - normalizeMoney(sale.totalSales)) <= 0.51) { "Pembagian pembayaran tidak sama dengan total akhir." }
        normalizedSplits.filterNot { it.method.equals(PaymentMethods.HUTANG, true) }.forEach { split ->
            cashDao.upsert(CashEntry(newId("cash"), sale.dateEpochDay, "in", "sale", split.method, if (sale.isSplitPayment) "Penjualan (${sale.paymentSummary})" else "Penjualan", split.amount, sale.id).toEntity())
        }
        sale.items.forEach { item ->
            val product = productDao.getById(item.productId)!!
            productDao.upsert(product.copy(stockQty = normalizeQty((product.stockQty - item.qty).coerceAtLeast(0.0))))
            stockMovementDao.upsert(StockMovement(newId("mv"), sale.dateEpochDay, item.productId, "sale", -item.qty, "Penjualan#${sale.id}").toEntity())
        }
        saleDao.upsert(sale.toEntity())
        saleItemDao.deleteBySaleId(sale.id)
        saleItemDao.upsertAll(sale.items.map { it.toEntity(sale.id) })
        paymentSplitDao.deleteBySaleId(sale.id)
        paymentSplitDao.upsertAll(sale.paymentSplits.map { it.toEntity(sale.id) })
    }

    suspend fun replace(sale: Sale) {
        if (saleDao.getById(sale.id) != null) {
            remove(sale.id)
        }
        add(sale)
    }

    suspend fun remove(id: String) {
        val sale = saleDao.getById(id)?.toDomain(saleItemDao.getBySaleId(id).map { it.toDomain() }, paymentSplitDao.getBySaleId(id).map { it.toDomain() }) ?: run { saleDao.delete(id); return }
        stockMovementDao.getByTypeAndNote("sale", "Penjualan#$id").forEach { stockMovementDao.delete(it.id) }
        saleDao.delete(id)
        saleItemDao.deleteBySaleId(id)
        paymentSplitDao.deleteBySaleId(id)
        cashDao.deleteByRef("sale", id)
        sale.items.map { it.productId }.toSet().forEach { productId ->
            val product = productDao.getById(productId) ?: return@forEach
            val stock = stockMovementDao.getAllByProduct(productId).sumOf { it.qtyDelta }
            productDao.upsert(product.copy(stockQty = normalizeQty(stock.coerceAtLeast(0.0))))
        }
    }
}