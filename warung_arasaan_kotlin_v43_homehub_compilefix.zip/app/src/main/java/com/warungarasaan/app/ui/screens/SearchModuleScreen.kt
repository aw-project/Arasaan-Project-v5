
package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.UiFormat

private data class SearchHit(
    val kind: String,
    val title: String,
    val subtitle: String,
    val trailing: String,
)

@Composable
fun SearchModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<SearchHit>>(emptyList()) }

    suspend fun reload(keyword: String) {
        val q = keyword.trim().lowercase()
        if (q.isBlank()) {
            hits = emptyList()
            return
        }
        val products = container.productRepository.all().filter {
            it.name.lowercase().contains(q) || it.sku.lowercase().contains(q) || it.id.lowercase().contains(q)
        }.map {
            SearchHit("Produk", it.name, "${it.category} • SKU ${it.sku.ifBlank { "-" }}", "Stok ${UiFormat.qty(it.stockQty)}")
        }
        val purchases = container.purchaseRepository.all().filter {
            it.id.lowercase().contains(q) || it.supplier.lowercase().contains(q) || it.items.any { row -> row.productId.lowercase().contains(q) }
        }.map {
            SearchHit("Pembelian", it.supplier.ifBlank { "Tanpa supplier" }, "${it.id} • ${UiFormat.date(it.dateEpochDay)}", UiFormat.money(it.items.sumOf { row -> row.qty * row.buyPrice }))
        }
        val sales = container.salesRepository.all().filter {
            it.id.lowercase().contains(q) || it.customerName.lowercase().contains(q) || it.paymentMethod.lowercase().contains(q)
        }.map {
            SearchHit("Penjualan", it.customerName.ifBlank { "Umum" }, "${it.id} • ${it.paymentSummary}", UiFormat.money(it.totalSales))
        }
        val debts = container.debtRepository.all().filter {
            it.creditor.lowercase().contains(q) || it.note.lowercase().contains(q) || it.id.lowercase().contains(q)
        }.map {
            SearchHit("Hutang", it.creditor, it.note.ifBlank { "Tanpa catatan" }, UiFormat.money(it.remaining))
        }
        val logs = container.activityLogRepository.recent(200).filter {
            it.type.lowercase().contains(q) || it.newJson.lowercase().contains(q) || it.refId.lowercase().contains(q)
        }.map {
            SearchHit("Aktivitas", it.type, it.newJson.ifBlank { it.refId }, UiFormat.date(it.dateEpochDay))
        }
        hits = (products + purchases + sales + debts + logs)
            .sortedWith(compareBy<SearchHit> { it.kind }.thenBy { it.title })
    }

    LaunchedEffect(query) { reload(query) }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Cari produk, transaksi, hutang, aktivitas") },
                singleLine = true,
            )
        }
        item {
            InfoChip(if (query.isBlank()) "Masukkan kata kunci" else "Hasil ${hits.size}")
        }
        if (query.isBlank()) {
            item { EmptyHint("Pencarian global", "Cari SKU, nama produk, supplier, customer, hutang, atau ID transaksi.") }
        } else if (hits.isEmpty()) {
            item { EmptyHint("Tidak ada hasil", "Coba kata kunci lain atau gunakan ID transaksi.") }
        } else {
            items(hits) { hit ->
                ListItem(
                    headlineContent = { Text("${hit.kind} • ${hit.title}") },
                    supportingContent = { Text(hit.subtitle) },
                    trailingContent = { Text(hit.trailing) },
                )
            }
        }
    }
}
