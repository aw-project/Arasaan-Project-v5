package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.CashEntry
import com.warungarasaan.app.domain.model.Expense
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.RejectedItem
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

@Composable
fun FinanceModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var tab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    var cash by remember { mutableStateOf<List<CashEntry>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var rejected by remember { mutableStateOf<List<RejectedItem>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var showExpenseDialog by remember { mutableStateOf(false) }
    var showRejectDialog by remember { mutableStateOf(false) }

    suspend fun reload() {
        cash = container.cashRepository.all()
        expenses = container.expenseRepository.all()
        rejected = container.rejectedRepository.all()
        products = container.productRepository.all()
    }

    LaunchedEffect(Unit) { reload() }

    if (showExpenseDialog) {
        ExpenseDialog(
            onDismiss = { showExpenseDialog = false },
            onSave = { note, amount, method, category ->
                scope.launch {
                    container.expenseRepository.add(
                        Expense(
                            id = AppUtils.newId("exp"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            note = note,
                            amount = amount,
                            paymentMethod = method,
                            category = category,
                        )
                    )
                    container.activityLogRepository.log("expense", "Biaya ditambah: $note")
                    reload()
                    showExpenseDialog = false
                }
            },
        )
    }

    if (showRejectDialog) {
        RejectDialog(
            products = products,
            onDismiss = { showRejectDialog = false },
            onSave = { productId, qty, reason ->
                scope.launch {
                    val product = products.firstOrNull { it.id == productId } ?: return@launch
                    container.rejectedRepository.add(
                        RejectedItem(
                            id = AppUtils.newId("reject"),
                            dateEpochDay = AppUtils.epochDayNow(),
                            productId = productId,
                            qty = qty,
                            reason = reason,
                            handling = "Buang",
                            note = "",
                            hppAtTime = product.avgHpp,
                            estimatedLoss = qty * product.avgHpp,
                        )
                    )
                    container.activityLogRepository.log("reject", "Barang rejek ${product.name}")
                    reload()
                    showRejectDialog = false
                }
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(onClick = { if (tab == 1) showExpenseDialog = true else if (tab == 2) showRejectDialog = true }) {
                Text("+")
            }
        },
    ) { padding ->
        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Kas") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Biaya") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Rejek") })
            }
            when (tab) {
                0 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            InfoChip("Masuk ${UiFormat.money(cash.filter { it.direction == "in" }.sumOf { it.amount })}")
                            InfoChip("Keluar ${UiFormat.money(cash.filter { it.direction == "out" }.sumOf { it.amount })}")
                        }
                    }
                    if (cash.isEmpty()) item { EmptyHint("Belum ada kas", "Kas akan terbentuk otomatis dari pembelian, penjualan, dan biaya.") }
                    items(cash, key = { it.id }) { entry ->
                        ListItem(
                            headlineContent = { Text(entry.note) },
                            supportingContent = { Text("${entry.source} • ${entry.method}") },
                            overlineContent = { Text(UiFormat.date(entry.dateEpochDay)) },
                            trailingContent = { Text(UiFormat.money(entry.amount)) },
                        )
                    }
                }
                1 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (expenses.isEmpty()) item { EmptyHint("Belum ada biaya", "Tambahkan biaya operasional dari tombol tambah.") }
                    items(expenses, key = { it.id }) { expense ->
                        ListItem(
                            headlineContent = { Text(expense.note) },
                            supportingContent = { Text("${expense.category} • ${expense.paymentMethod}") },
                            overlineContent = { Text(UiFormat.date(expense.dateEpochDay)) },
                            trailingContent = { Text(UiFormat.money(expense.amount)) },
                        )
                        TextButton(
                            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp),
                            onClick = {
                                scope.launch {
                                    container.expenseRepository.remove(expense.id)
                                    reload()
                                }
                            },
                        ) { Text("Hapus") }
                    }
                }
                else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (rejected.isEmpty()) item { EmptyHint("Belum ada data rejek", "Tambah data barang rusak / hilang dari tombol tambah.") }
                    items(rejected, key = { it.id }) { item ->
                        val product = products.firstOrNull { it.id == item.productId }
                        ListItem(
                            headlineContent = { Text(product?.name ?: item.productId) },
                            supportingContent = { Text("${item.reason} • Qty ${UiFormat.qty(item.qty)}") },
                            overlineContent = { Text(UiFormat.date(item.dateEpochDay)) },
                            trailingContent = { Text(UiFormat.money(item.estimatedLoss)) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (String, Double, String, String) -> Unit,
) {
    var note by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("0") }
    var method by remember { mutableStateOf("Cash") }
    var category by remember { mutableStateOf("Lainnya") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(note, amount.toDoubleOrNull() ?: 0.0, method, category) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Tambah Biaya") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(note, { note = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(amount, { amount = it }, label = { Text("Nominal") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(method, { method = it }, label = { Text("Metode bayar") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(category, { category = it }, label = { Text("Kategori") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}

@Composable
private fun RejectDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onSave: (String, Double, String) -> Unit,
) {
    var productId by remember { mutableStateOf(products.firstOrNull()?.id.orEmpty()) }
    var qty by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("Rusak") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onSave(productId, qty.toDoubleOrNull() ?: 0.0, reason) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Tambah Rejek") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(productId, { productId = it }, label = { Text("Product ID") }, modifier = Modifier.fillMaxWidth()) }
                item { Text("Produk tersedia: " + products.take(5).joinToString { "${it.id}=${it.name}" }) }
                item { OutlinedTextField(qty, { qty = it }, label = { Text("Qty") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(reason, { reason = it }, label = { Text("Alasan") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
    )
}
