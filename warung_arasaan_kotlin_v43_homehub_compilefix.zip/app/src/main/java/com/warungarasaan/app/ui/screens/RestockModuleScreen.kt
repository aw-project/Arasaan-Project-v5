package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.data.service.AnalyticsService
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InlineLabelValue
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

@Composable
fun RestockModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    var rows by remember { mutableStateOf(emptyList<com.warungarasaan.app.data.service.ForecastKpi>()) }

    LaunchedEffect(Unit) {
        val sales = container.salesRepository.all()
        val products = container.productRepository.all()
        rows = AnalyticsService().restockForecast(sales, products, horizonDays = 14)
            .filter { it.suggestBuy > 0.0 || it.stockQty <= 0.0 }
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Saran restock 14 hari") }
        if (rows.isEmpty()) {
            item { EmptyHint("Belum ada saran restock", "Tambahkan produk dan data penjualan dulu.") }
        } else {
            items(rows) { item ->
                SectionCard(
                    title = item.name,
                    subtitle = "Rata-rata jual ${UiFormat.qty(item.avgPerDay)} / hari",
                ) {
                    InlineLabelValue("Stok sekarang", UiFormat.qty(item.stockQty))
                    InlineLabelValue("Saran beli", UiFormat.qty(item.suggestBuy))
                }
            }
        }
    }
}
