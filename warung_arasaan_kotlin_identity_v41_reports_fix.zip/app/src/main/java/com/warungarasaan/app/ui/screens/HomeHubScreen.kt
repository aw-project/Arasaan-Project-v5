package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.ActivityLog
import com.warungarasaan.app.ui.StatCard
import com.warungarasaan.app.ui.UiFormat

private data class HomeShortcut(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val onTap: () -> Unit,
)

@Composable
fun HomeHubScreen(
    container: AppContainer,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var omzetToday by remember { mutableStateOf(0.0) }
    var purchaseToday by remember { mutableStateOf(0.0) }
    var lowStockCount by remember { mutableStateOf(0) }
    var rejectedLoss by remember { mutableStateOf(0.0) }
    var recentLogs by remember { mutableStateOf<List<ActivityLog>>(emptyList()) }

    LaunchedEffect(Unit) {
        val today = AppUtils.epochDayNow()
        val sales = container.salesRepository.all()
        val purchases = container.purchaseRepository.all()
        val products = container.productRepository.all()
        val rejected = container.rejectedRepository.all()
        recentLogs = container.activityLogRepository.recent(8)
        omzetToday = sales.filter { it.dateEpochDay == today }.sumOf { it.totalSales }
        purchaseToday = purchases.filter { it.dateEpochDay == today }.sumOf { purchase -> purchase.items.sumOf { it.qty * it.buyPrice } }
        lowStockCount = products.count { it.stockQty <= it.minStock && it.minStock > 0.0 }
        rejectedLoss = rejected.filter { it.dateEpochDay == today }.sumOf { it.estimatedLoss }
    }

    val shortcuts = remember(onNavigate, omzetToday, lowStockCount) {
        listOf(
            HomeShortcut("Produk", "Kelola katalog dan stok", Icons.Rounded.Inventory2) { onNavigate("products") },
            HomeShortcut("Penjualan", "Omzet hari ini ${UiFormat.money(omzetToday)}", Icons.Rounded.PointOfSale) { onNavigate("sales") },
            HomeShortcut("Pembelian", "Input stok masuk cepat", Icons.Rounded.ShoppingCart) { onNavigate("purchases") },
            HomeShortcut("Kas & Biaya", "Mutasi kas harian", Icons.Rounded.Payments) { onNavigate("finance") },
            HomeShortcut("Laporan", "Ringkasan performa usaha", Icons.Rounded.ReceiptLong) { onNavigate("reports") },
            HomeShortcut("Analytics", "Top selling dan margin", Icons.Rounded.Analytics) { onNavigate("analytics") },
            HomeShortcut("Restock", "Stok kritis: $lowStockCount", Icons.Rounded.RestartAlt) { onNavigate("restock") },
            HomeShortcut("Pencarian", "Cari transaksi dan produk", Icons.Rounded.Search) { onNavigate("search") },
            HomeShortcut("Backup", "Ekspor atau restore data", Icons.Rounded.Backup) { onNavigate("backup") },
            HomeShortcut("Rejected", "Loss hari ini ${UiFormat.money(rejectedLoss)}", Icons.Rounded.WarningAmber) { onNavigate("rejected") },
        )
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Home", style = MaterialTheme.typography.headlineSmall) }
        item { StatCard("Omzet Hari Ini", UiFormat.money(omzetToday), "Akumulasi penjualan pada tanggal aktif perangkat") }
        item { StatCard("Pembelian Hari Ini", UiFormat.money(purchaseToday), "Total modal barang masuk hari ini") }
        item { StatCard("Stok Kritis", lowStockCount.toString(), "Produk dengan stok <= batas minimum") }
        item {
            Text(
                "Shortcut kerja cepat",
                style = MaterialTheme.typography.titleMedium,
            )
        }
        item {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 220.dp, max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                userScrollEnabled = false,
            ) {
                items(shortcuts) { item ->
                    Card(
                        modifier = Modifier.clickable(onClick = item.onTap),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        ListItem(
                            leadingContent = { Icon(item.icon, contentDescription = item.title) },
                            headlineContent = { Text(item.title) },
                            supportingContent = { Text(item.subtitle) },
                        )
                    }
                }
            }
        }
        item { Text("Aktivitas terbaru", style = MaterialTheme.typography.titleMedium) }
        if (recentLogs.isEmpty()) {
            item { Text("Belum ada log aktivitas.") }
        } else {
            items(recentLogs.size) { index ->
                val item = recentLogs[index]
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    ListItem(
                        headlineContent = { Text(item.type.ifBlank { "Aktivitas" }) },
                        supportingContent = { Text(item.newJson.ifBlank { item.refId.ifBlank { "-" } }) },
                        trailingContent = { Text(UiFormat.date(item.dateEpochDay)) },
                    )
                }
            }
        }
    }
}
