package com.warungarasaan.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Report
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.di.AppProviders
import com.warungarasaan.app.ui.screens.*
import com.warungarasaan.app.ui.redesign.*

data class ModuleItem(
    val key: String,
    val title: String,
    val icon: ImageVector,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WarungArasaanRoot() {
    WarungArasaanRoot(AppProviders.container)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WarungArasaanRoot(container: AppContainer) {
    val modules = remember {
        listOf(
            ModuleItem(NativeModuleRoutes.Home, "Home", Icons.Rounded.Home),
            ModuleItem(NativeModuleRoutes.Dashboard, "Dashboard", Icons.Rounded.Dashboard),
            ModuleItem(NativeModuleRoutes.Products, "Produk", Icons.Rounded.Inventory2),
            ModuleItem(NativeModuleRoutes.Purchases, "Pembelian", Icons.Rounded.Storefront),
            ModuleItem(NativeModuleRoutes.Sales, "Penjualan", Icons.Rounded.PointOfSale),
            ModuleItem(NativeModuleRoutes.FastPos, "Fast POS", Icons.Rounded.Bolt),
            ModuleItem(NativeModuleRoutes.Finance, "Kas & Biaya", Icons.Rounded.Payments),
            ModuleItem(NativeModuleRoutes.Cash, "Kas", Icons.Rounded.AccountBalanceWallet),
            ModuleItem(NativeModuleRoutes.Expenses, "Biaya", Icons.Rounded.Payments),
            ModuleItem(NativeModuleRoutes.Rejected, "Rejected", Icons.Rounded.DeleteSweep),
            ModuleItem("partners", "Hutang & Partner", Icons.Rounded.Category),
            ModuleItem(NativeModuleRoutes.Debts, "Hutang", Icons.Rounded.ReceiptLong),
            ModuleItem("suppliers", "Supplier", Icons.Rounded.Groups),
            ModuleItem("customers", "Pelanggan", Icons.Rounded.People),
            ModuleItem(NativeModuleRoutes.Reports, "Laporan", Icons.Rounded.Report),
            ModuleItem(NativeModuleRoutes.Analytics, "Analytics", Icons.Rounded.Analytics),
            ModuleItem("analytics_product_detail", "Analitik Produk", Icons.Rounded.Analytics),
            ModuleItem(NativeModuleRoutes.GlobalSearch, "Pencarian", Icons.Rounded.Search),
            ModuleItem("restock", "Restock", Icons.Rounded.RestartAlt),
            ModuleItem(NativeModuleRoutes.ActivityLog, "Aktivitas", Icons.Rounded.ReceiptLong),
            ModuleItem("backup", "Backup", Icons.Rounded.Save),
            ModuleItem("print_center", "Print", Icons.Rounded.Print),
            ModuleItem("operations", "Ops Tools", Icons.Rounded.Build),
            ModuleItem("more", "Lainnya", Icons.Rounded.Apps),
            ModuleItem(NativeModuleRoutes.StockAdjustment, "Adj Stok", Icons.Rounded.Inventory2),
            ModuleItem(NativeModuleRoutes.StockOpname, "Opname", Icons.Rounded.Category),
            ModuleItem("settings", "Settings", Icons.Rounded.Settings),
        )
    }
    var selected by remember { mutableStateOf("home") }

    LockGate(container = container) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Warung Arasaan Native Kotlin") }) },
        ) { padding ->
            androidx.compose.foundation.layout.Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
            ) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(modules) { item ->
                        AssistChip(
                            onClick = { selected = item.key },
                            leadingIcon = { Icon(item.icon, contentDescription = item.title) },
                            label = { Text(item.title) },
                        )
                    }
                }
                when (selected) {
                    "home" -> HomeHubScreen(container, onNavigate = { selected = it }, modifier = Modifier.fillMaxSize())
                    "dashboard" -> NativeDashboardModuleScreen(container, onNavigate = { selected = it }, modifier = Modifier.fillMaxSize())
                    "products" -> NativeProductsModuleScreen(container, Modifier.fillMaxSize())
                    "purchases" -> NativePurchasesModuleScreen(container, Modifier.fillMaxSize())
                    "sales" -> NativeSalesModuleScreen(container, Modifier.fillMaxSize())
                    "fast_pos" -> NativeFastPosModuleScreen(container, Modifier.fillMaxSize())
                    "finance" -> NativeFinanceModuleScreen(container, Modifier.fillMaxSize())
                    "cash" -> NativeCashModuleScreen(container, Modifier.fillMaxSize())
                    "expenses" -> NativeExpensesModuleScreen(container, Modifier.fillMaxSize())
                    "rejected" -> NativeRejectedModuleScreen(container, Modifier.fillMaxSize())
                    "partners" -> PartnersModuleScreen(container, Modifier.fillMaxSize())
                    "debts" -> NativeDebtsModuleScreen(container, Modifier.fillMaxSize())
                    "suppliers" -> SuppliersModuleScreen(container, Modifier.fillMaxSize())
                    "customers" -> CustomersModuleScreen(container, Modifier.fillMaxSize())
                    "reports" -> NativeReportsModuleScreen(container, Modifier.fillMaxSize())
                    "analytics" -> NativeAnalyticsModuleScreen(container, Modifier.fillMaxSize())
                    "analytics_product_detail" -> AnalyticsProductDetailScreen(container, Modifier.fillMaxSize())
                    "search" -> SearchModuleScreen(container, Modifier.fillMaxSize())
                    NativeModuleRoutes.GlobalSearch -> GlobalSearchScreen(container, Modifier.fillMaxSize())
                    "activity" -> ActivityModuleScreen(container, Modifier.fillMaxSize())
                    NativeModuleRoutes.ActivityLog -> ActivityLogPageScreen(container, Modifier.fillMaxSize())
                    "restock" -> RestockModuleScreen(container, Modifier.fillMaxSize())
                    "backup" -> BackupModuleScreen(container, Modifier.fillMaxSize())
                    "print_center" -> PrintCenterModuleScreen(container, Modifier.fillMaxSize())
                    "operations" -> OperationsToolsModuleScreen(container, Modifier.fillMaxSize())
                    "more" -> MoreModuleScreen(container, onNavigate = { selected = it }, modifier = Modifier.fillMaxSize())
                    NativeModuleRoutes.StockAdjustment -> StockAdjustmentScreen(container, Modifier.fillMaxSize())
                    NativeModuleRoutes.StockOpname -> StockOpnameScreen(container, Modifier.fillMaxSize())
                    "settings" -> SettingsModuleScreen(container, Modifier.fillMaxSize())
                }
            }
        }
    }
}
