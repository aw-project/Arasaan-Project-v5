package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.RemoveShoppingCart
import androidx.compose.material.icons.rounded.Report
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat

private data class MoreNavItem(val title: String, val subtitle: String, val icon: ImageVector, val target: String)

@Composable
fun MoreModuleScreen(
    container: AppContainer,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var saldoKas by remember { mutableStateOf(0.0) }
    var rejectedCount by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        saldoKas = container.cashRepository.all()
            .filter { PaymentMethods.isCashFlow(it.method) }
            .sumOf { if (it.direction == "in") it.amount else -it.amount }
        rejectedCount = container.rejectedRepository.all().size
    }

    val items = listOf(
        MoreNavItem("Kas", "Saldo ${UiFormat.money(saldoKas)}", Icons.Rounded.AccountBalanceWallet, "cash"),
        MoreNavItem("Biaya", "Biaya operasional terpisah", Icons.Rounded.Description, "expenses"),
        MoreNavItem("Barang Retur", "$rejectedCount entri tercatat", Icons.Rounded.RemoveShoppingCart, "rejected"),
        MoreNavItem("Analytics", "Insight penjualan dan margin", Icons.Rounded.Analytics, "analytics"),
        MoreNavItem("Analitik Produk", "Detail kontribusi tiap produk", Icons.Rounded.Analytics, "analytics_product_detail"),
        MoreNavItem("Laporan", "Ringkasan operasional warung", Icons.Rounded.Report, "reports"),
        MoreNavItem("Restock", "Forecast pembelian berikutnya", Icons.Rounded.RestartAlt, "restock"),
        MoreNavItem("Aktivitas", "Jejak perubahan data", Icons.Rounded.ReceiptLong, "activity"),
        MoreNavItem("Hutang", "Pantau sisa hutang dan pembayaran", Icons.Rounded.ReceiptLong, "debts"),
        MoreNavItem("Supplier", "Pantau supplier dan hutang", Icons.Rounded.Groups, "suppliers"),
        MoreNavItem("Pelanggan", "Ringkasan customer", Icons.Rounded.People, "customers"),
        MoreNavItem("Tools Operasional", "Search cepat dan tool stok", Icons.Rounded.Build, "operations"),
        MoreNavItem("Backup", "Export / import database", Icons.Rounded.CloudUpload, "backup"),
        MoreNavItem("Print Center", "Preview dan kirim struk ke thermal", Icons.Rounded.Print, "print_center"),
    )

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(
                title = "Lainnya",
                subtitle = "Padanan more_page.dart sebagai hub ke modul sekunder dan operasional.",
            ) {
                Text("Akses cepat ke kas, retur, laporan, analytics, backup, supplier, dan pelanggan.")
            }
        }
        items(items) { item ->
            ListItem(
                headlineContent = { Text(item.title) },
                supportingContent = { Text(item.subtitle) },
                leadingContent = { Icon(item.icon, contentDescription = item.title) },
                modifier = Modifier,
            )
            androidx.compose.material3.TextButton(onClick = { onNavigate(item.target) }) {
                Text("Buka ${item.title}")
            }
        }
    }
}
