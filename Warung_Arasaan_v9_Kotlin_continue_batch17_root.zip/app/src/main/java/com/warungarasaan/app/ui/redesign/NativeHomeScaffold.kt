package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

data class NativeNavItem(
    val key: String,
    val label: String
)

@Composable
fun NativeHomeScaffold(
    selected: String,
    onSelect: (String) -> Unit,
    onQuickSale: () -> Unit,
    content: @Composable (PaddingValues) -> Unit
) {
    val items = listOf(
        NativeNavItem("home", "Home"),
        NativeNavItem("products", "Produk"),
        NativeNavItem("sales", "Kasir"),
        NativeNavItem("reports", "Laporan"),
        NativeNavItem("more", "Lainnya")
    )
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(onClick = onQuickSale) {
                Icon(Icons.Rounded.PointOfSale, contentDescription = "Buka kasir")
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = selected == item.key,
                        onClick = { onSelect(item.key) },
                        icon = {
                            val icon = when (item.key) {
                                "home" -> Icons.Rounded.Home
                                "products" -> Icons.Rounded.Inventory2
                                "sales" -> Icons.Rounded.PointOfSale
                                "reports" -> Icons.Rounded.Analytics
                                else -> Icons.Rounded.Menu
                            }
                            Icon(icon, contentDescription = item.label)
                        },
                        label = { Text(item.label) }
                    )
                }
            }
        },
        content = content
    )
}
