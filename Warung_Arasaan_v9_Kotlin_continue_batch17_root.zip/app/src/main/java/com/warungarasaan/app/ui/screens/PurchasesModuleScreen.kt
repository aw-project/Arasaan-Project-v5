
package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.core.AppUtils
import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.PurchaseItem
import com.warungarasaan.app.ui.EmptyHint
import com.warungarasaan.app.ui.InfoChip
import com.warungarasaan.app.ui.LabeledNumberField
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import kotlinx.coroutines.launch

private data class PurchaseDraftRow(
    val key: String = AppUtils.newId("row"),
    val productId: String = "",
    val qty: String = "1",
    val buyPrice: String = "0",
)

@Composable
fun PurchasesModuleScreen(container: AppContainer, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var purchases by remember { mutableStateOf<List<Purchase>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Purchase?>(null) }
    var editing by remember { mutableStateOf<Purchase?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    suspend fun reload() {
        purchases = container.purchaseRepository.all()
        products = container.productRepository.all()
    }

    LaunchedEffect(Unit) { reload() }

    val productMap = remember(products) { products.associateBy { it.id } }
    val filtered = remember(purchases, query) {
        val q = query.trim().lowercase()
        purchases.filter {
            q.isBlank() ||
                it.supplier.lowercase().contains(q) ||
                it.id.lowercase().contains(q) ||
                it.paymentMethod.lowercase().contains(q)
        }
    }

    if (showDialog) {
        PurchaseEditorDialog(
            products = products,
            initial = editing,
            onDismiss = { showDialog = false; editing = null },
            onSave = { id, supplier, paymentMethod, rows ->
                scope.launch {
                    runCatching {
                        val purchase = Purchase(
                            id = id.ifBlank { AppUtils.newId("pur") },
                            dateEpochDay = editing?.dateEpochDay ?: AppUtils.epochDayNow(),
                            supplier = supplier,
                            paymentMethod = paymentMethod,
                            items = rows.map { PurchaseItem(it.productId, it.qty.toDouble(), it.buyPrice.toDouble()) },
                        )
                        if (editing == null) {
                            container.purchaseRepository.add(purchase)
                            container.activityLogRepository.log("purchase", "Pembelian ${purchase.id} disimpan")
                            message = "Pembelian ${purchase.id} berhasil disimpan."
                        } else {
                            container.purchaseRepository.replace(purchase)
                            container.activityLogRepository.log("purchase_edit", "Pembelian ${purchase.id} diperbarui")
                            message = "Pembelian ${purchase.id} berhasil diperbarui."
                        }
                        reload()
                        showDialog = false
                        editing = null
                    }.onFailure { message = it.message ?: "Gagal menyimpan pembelian." }
                }
            },
        )
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = { FloatingActionButton(onClick = { editing = null; showDialog = true }) { Text("+") } },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Cari supplier / ID / metode bayar") },
                    singleLine = true,
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip("Transaksi ${purchases.size}")
                    InfoChip("Supplier ${purchases.map { it.supplier.trim() }.filter { it.isNotEmpty() }.distinct().size}")
                }
            }
            if (message.isNotBlank()) item { SectionCard("Status") { Text(message) } }
            if (products.isEmpty()) {
                item { EmptyHint("Belum ada master produk", "Tambahkan produk dulu agar pembelian bisa dicatat.") }
            } else if (filtered.isEmpty()) {
                item { EmptyHint("Belum ada pembelian", "Gunakan tombol tambah untuk input transaksi pembelian.") }
            } else {
                itemsIndexed(filtered, key = { _, item -> item.id }) { _, purchase ->
                    val total = purchase.items.sumOf { it.qty * it.buyPrice }
                    val itemText = purchase.items.joinToString { item ->
                        val name = productMap[item.productId]?.name ?: item.productId
                        "$name x ${UiFormat.qty(item.qty)}"
                    }
                    SectionCard(
                        title = purchase.supplier.ifBlank { "Tanpa Supplier" },
                        subtitle = "${purchase.id} • ${UiFormat.date(purchase.dateEpochDay)} • ${purchase.paymentMethod}",
                    ) {
                        Text(itemText)
                        Text("Total: ${UiFormat.money(total)}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { selected = purchase }) { Text("Detail") }
                            TextButton(onClick = { editing = purchase; showDialog = true }) { Text("Edit") }
                            TextButton(onClick = {
                                scope.launch {
                                    container.purchaseRepository.remove(purchase.id)
                                    container.activityLogRepository.log("purchase_delete", "Pembelian ${purchase.id} dihapus")
                                    message = "Pembelian ${purchase.id} dihapus."
                                    reload()
                                }
                            }) { Text("Hapus") }
                        }
                    }
                }
            }
        }
    }

    selected?.let { purchase ->
        AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Tutup") } },
            title = { Text("Detail pembelian") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Text("${purchase.id} • ${UiFormat.date(purchase.dateEpochDay)}") }
                    item { Text("Supplier: ${purchase.supplier.ifBlank { "-" }}") }
                    item { Text("Pembayaran: ${purchase.paymentMethod}") }
                    itemsIndexed(purchase.items) { _, item ->
                        val product = productMap[item.productId]
                        ListItem(
                            headlineContent = { Text(product?.name ?: item.productId) },
                            supportingContent = { Text("Qty ${UiFormat.qty(item.qty)} • ${UiFormat.money(item.buyPrice)}") },
                            trailingContent = { Text(UiFormat.money(item.qty * item.buyPrice)) },
                        )
                    }
                }
            },
        )
    }
}

@Composable
private fun PurchaseEditorDialog(
    products: List<Product>,
    initial: Purchase?,
    onDismiss: () -> Unit,
    onSave: (id: String, supplier: String, paymentMethod: String, rows: List<PurchaseDraftRow>) -> Unit,
) {
    var supplier by remember(initial) { mutableStateOf(initial?.supplier.orEmpty()) }
    var paymentMethod by remember(initial) { mutableStateOf(initial?.paymentMethod ?: "Cash") }
    var rows by remember(initial, products) {
        mutableStateOf(
            initial?.items?.map {
                PurchaseDraftRow(
                    productId = it.productId,
                    qty = UiFormat.qty(it.qty),
                    buyPrice = UiFormat.qty(it.buyPrice),
                )
            } ?: listOf(
                PurchaseDraftRow(
                    productId = products.firstOrNull()?.id.orEmpty(),
                    buyPrice = UiFormat.qty(products.firstOrNull()?.avgHpp ?: 0.0),
                ),
            )
        )
    }

    fun update(index: Int, transform: (PurchaseDraftRow) -> PurchaseDraftRow) {
        rows = rows.mapIndexed { i, row -> if (i == index) transform(row) else row }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        initial?.id.orEmpty(),
                        supplier,
                        paymentMethod,
                        rows.filter { it.productId.isNotBlank() && (it.qty.toDoubleOrNull() ?: 0.0) > 0.0 },
                    )
                },
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text(if (initial == null) "Form pembelian multi-item" else "Edit pembelian") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(supplier, { supplier = it }, label = { Text("Supplier") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(paymentMethod, { paymentMethod = it }, label = { Text("Metode bayar") }, modifier = Modifier.fillMaxWidth()) }
                itemsIndexed(rows, key = { _, row -> row.key }) { index, row ->
                    SectionCard(title = "Baris ${index + 1}", subtitle = "Gunakan product ID dari master produk.") {
                        OutlinedTextField(
                            value = row.productId,
                            onValueChange = { value -> update(index) { rowValue -> rowValue.copy(productId = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Product ID") },
                            singleLine = true,
                        )
                        LabeledNumberField("Qty", row.qty, { value -> update(index) { rowValue -> rowValue.copy(qty = value) } })
                        LabeledNumberField("Harga beli", row.buyPrice, { value -> update(index) { rowValue -> rowValue.copy(buyPrice = value) } })
                        val productName = products.firstOrNull { it.id == row.productId }?.name
                        if (productName != null) Text("Produk: $productName")
                        TextButton(onClick = { if (rows.size > 1) rows = rows.filterIndexed { i, _ -> i != index } }) { Text("Hapus baris") }
                    }
                }
                item {
                    TextButton(
                        onClick = {
                            rows = rows + PurchaseDraftRow(
                                productId = products.firstOrNull()?.id.orEmpty(),
                                buyPrice = UiFormat.qty(products.firstOrNull()?.avgHpp ?: 0.0),
                            )
                        },
                    ) { Text("+ Tambah baris") }
                }
            }
        },
    )
}
