package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

data class QuickAction(
    val label: String,
    val icon: ImageVector,
    val route: String
)

fun defaultQuickActions(): List<QuickAction> = listOf(
    QuickAction("Kasir", Icons.Rounded.PointOfSale, "fast_pos"),
    QuickAction("Produk", Icons.Rounded.Inventory2, "products"),
    QuickAction("Pembelian", Icons.Rounded.ArrowDownward, "purchases"),
    QuickAction("Penjualan", Icons.Rounded.ArrowUpward, "sales"),
    QuickAction("Biaya", Icons.Rounded.Payments, "expenses"),
    QuickAction("Hutang", Icons.Rounded.Person, "debts"),
    QuickAction("Laporan", Icons.Rounded.ReceiptLong, "reports"),
    QuickAction("Backup", Icons.Rounded.Backup, "backup")
)

@Composable
fun QuickActionGrid(
    actions: List<QuickAction> = defaultQuickActions(),
    onAction: (String) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        contentPadding = PaddingValues(0.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        userScrollEnabled = false,
        modifier = Modifier.fillMaxWidth()
    ) {
        items(actions) { action ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clickable { onAction(action.route) }
            ) {
                androidx.compose.foundation.layout.Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                ) {
                    Icon(action.icon, contentDescription = action.label)
                    Text(
                        text = action.label,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }
}
