package com.warungarasaan.app.data.service

import com.warungarasaan.app.domain.model.Product
import com.warungarasaan.app.domain.model.Purchase
import com.warungarasaan.app.domain.model.Sale
import kotlin.math.abs
import kotlin.math.max

data class ProductKpi(
    val productId: String,
    val name: String,
    val qty: Double,
    val revenue: Double,
    val hpp: Double,
    val profit: Double,
) {
    val marginPercent: Double get() = if (revenue == 0.0) 0.0 else (profit / revenue) * 100.0
}

data class ForecastKpi(
    val productId: String,
    val name: String,
    val stockQty: Double,
    val avgPerDay: Double,
    val suggestBuy: Double,
)

data class SmartRestockKpi(
    val productId: String,
    val name: String,
    val category: String,
    val stockQty: Double,
    val avgPerDay: Double,
    val targetQty: Double,
    val weeklyNeed: Double,
    val suggestBuy: Double,
    val daysLeft: Double,
    val status: String,
    val priorityScore: Double,
    val preferredSupplier: String = "",
    val latestBuyPrice: Double = 0.0,
    val supplierScore: Double = 0.0,
)

data class SupplierInsight(
    val supplier: String,
    val totalSpend: Double,
    val purchaseCount: Int,
    val averageOrderValue: Double,
    val lastPurchaseDay: Int?,
) {
    val stabilityLabel: String
        get() = when {
            purchaseCount >= 8 -> "Stabil"
            purchaseCount >= 4 -> "Cukup stabil"
            purchaseCount >= 2 -> "Mulai aktif"
            else -> "Masih minim data"
        }
}

data class PurchasePriceTrend(
    val productId: String,
    val name: String,
    val firstPrice: Double,
    val latestPrice: Double,
    val averagePrice: Double,
    val changePercent: Double,
    val purchaseCount: Int,
)

data class ProfitAlert(
    val productId: String,
    val name: String,
    val sellPrice: Double,
    val avgHpp: Double,
    val marginPercent: Double,
    val profitPerUnit: Double,
    val status: String,
)

data class SupplierScorecard(
    val supplier: String,
    val totalSpend: Double,
    val purchaseCount: Int,
    val averageOrderValue: Double,
    val productCoverage: Int,
    val priceIndexPercent: Double,
    val stabilityScore: Double,
    val totalScore: Double,
    val recommendation: String,
)

data class SalePriceRecommendation(
    val productId: String,
    val name: String,
    val currentSellPrice: Double,
    val avgHpp: Double,
    val targetMarginPercent: Double,
    val recommendedSellPrice: Double,
    val gapPercent: Double,
    val status: String,
)

data class MarginDropAlert(
    val productId: String,
    val name: String,
    val currentSellPrice: Double,
    val previousBuyPrice: Double,
    val latestBuyPrice: Double,
    val previousMarginPercent: Double,
    val currentMarginPercent: Double,
    val dropPercent: Double,
    val status: String,
)

data class BusinessDecisionSummary(
    val criticalRestockCount: Int,
    val criticalRestockBuyQty: Double,
    val marginAlertCount: Int,
    val priceReviewCount: Int,
    val bestSupplierName: String,
    val bestSupplierScore: Double,
)

class AnalyticsService {
    fun topSelling(
        sales: List<Sale>,
        products: List<Product>,
        days: Int,
    ): List<ProductKpi> {
        val productNames = products.associateBy({ it.id }, { it.name })
        val acc = linkedMapOf<String, ProductKpi>()
        sales.flatMap { it.items }.forEach { item ->
            val old = acc[item.productId]
            val next = ProductKpi(
                productId = item.productId,
                name = productNames[item.productId] ?: item.productId,
                qty = (old?.qty ?: 0.0) + item.qty,
                revenue = (old?.revenue ?: 0.0) + item.total,
                hpp = (old?.hpp ?: 0.0) + item.totalHpp,
                profit = (old?.profit ?: 0.0) + (item.total - item.totalHpp),
            )
            acc[item.productId] = next
        }
        return acc.values.sortedByDescending { it.qty }
    }

    fun topProfit(sales: List<Sale>, products: List<Product>, days: Int): List<ProductKpi> =
        topSelling(sales, products, days).sortedByDescending { it.profit }

    fun lowMarginProducts(products: List<Product>): List<Pair<Product, Double>> =
        products.map { product ->
            val profit = product.activeSellPrice - product.avgHpp
            val margin = if (product.activeSellPrice <= 0.0) 0.0 else (profit / product.activeSellPrice) * 100.0
            product to margin
        }.sortedBy { it.second }

    fun restockForecast(sales: List<Sale>, products: List<Product>, horizonDays: Int): List<ForecastKpi> {
        val qtyByProduct = mutableMapOf<String, Double>()
        sales.flatMap { it.items }.forEach { item ->
            qtyByProduct[item.productId] = (qtyByProduct[item.productId] ?: 0.0) + item.qty
        }
        val observedDays = max(1, sales.map { it.dateEpochDay }.distinct().size)
        return products.map { product ->
            val avgPerDay = (qtyByProduct[product.id] ?: 0.0) / observedDays.toDouble()
            val target = max(product.targetStock, product.minStock)
            val projectedNeed = max(target, avgPerDay * horizonDays)
            ForecastKpi(
                productId = product.id,
                name = product.name,
                stockQty = product.stockQty,
                avgPerDay = avgPerDay,
                suggestBuy = max(0.0, projectedNeed - product.stockQty),
            )
        }.sortedByDescending { it.suggestBuy }
    }

    fun smartRestock(
        sales: List<Sale>,
        products: List<Product>,
        horizonDays: Int = 7,
        safeDays: Int = 7,
        purchases: List<Purchase> = emptyList(),
    ): List<SmartRestockKpi> {
        val qtyByProduct = mutableMapOf<String, Double>()
        sales.flatMap { it.items }.forEach { item ->
            qtyByProduct[item.productId] = (qtyByProduct[item.productId] ?: 0.0) + item.qty
        }

        val supplierRowsByProduct = mutableMapOf<String, MutableList<Triple<String, Int, Double>>>()
        purchases.forEach { purchase ->
            val supplierName = purchase.supplier.trim().ifEmpty { "Tanpa Supplier" }
            purchase.items.forEach { item ->
                supplierRowsByProduct.getOrPut(item.productId) { mutableListOf() }
                    .add(Triple(supplierName, purchase.dateEpochDay, item.buyPrice))
            }
        }

        val observedDays = max(7, sales.map { it.dateEpochDay }.distinct().size)
        return products.map { product ->
            val soldQty = qtyByProduct[product.id] ?: 0.0
            val avgPerDay = soldQty / observedDays.toDouble()
            val weeklyNeed = avgPerDay * horizonDays.toDouble()
            val targetQty = listOf(product.targetStock, product.minStock, avgPerDay * safeDays.toDouble()).maxOrNull() ?: 0.0
            val suggestBuy = max(0.0, targetQty - product.stockQty)
            val daysLeft = if (avgPerDay <= 0.0001) Double.POSITIVE_INFINITY else product.stockQty / avgPerDay

            val status = when {
                product.stockQty <= 0.0 -> "HABIS"
                avgPerDay <= 0.0001 && product.stockQty > 0.0 -> "MATI"
                product.stockQty <= max(1.0, product.minStock) || daysLeft <= 1.5 -> "KRITIS"
                avgPerDay < 0.3 && product.stockQty > 0.0 -> "LAMBAT"
                suggestBuy > 0.0 || daysLeft <= 3.0 -> "WASPADA"
                else -> "AMAN"
            }

            val priorityScore = when (status) {
                "HABIS" -> 1000.0 + suggestBuy
                "KRITIS" -> 700.0 + suggestBuy + max(0.0, 7.0 - daysLeft)
                "WASPADA" -> 400.0 + suggestBuy
                "LAMBAT" -> 200.0 + soldQty
                "MATI" -> 100.0
                else -> suggestBuy
            }

            val supplierSummary = supplierRowsByProduct[product.id]
                .orEmpty()
                .groupBy { it.first }
                .map { (supplier, rows) ->
                    val latestDay = rows.maxOfOrNull { it.second } ?: 0
                    val latestPrice = rows.sortedBy { it.second }.lastOrNull()?.third ?: 0.0
                    val avgPrice = rows.map { it.third }.average()
                    val frequency = rows.size.toDouble()
                    val score = (frequency * 15.0) + (1000.0 / max(1.0, avgPrice)) + (latestDay / 1000.0)
                    Triple(supplier, latestPrice, score)
                }
                .sortedByDescending { it.third }
                .firstOrNull()

            SmartRestockKpi(
                productId = product.id,
                name = product.name,
                category = product.category,
                stockQty = product.stockQty,
                avgPerDay = avgPerDay,
                targetQty = targetQty,
                weeklyNeed = weeklyNeed,
                suggestBuy = suggestBuy,
                daysLeft = daysLeft,
                status = status,
                priorityScore = priorityScore,
                preferredSupplier = supplierSummary?.first.orEmpty(),
                latestBuyPrice = supplierSummary?.second ?: 0.0,
                supplierScore = supplierSummary?.third ?: 0.0,
            )
        }.sortedWith(
            compareByDescending<SmartRestockKpi> { it.priorityScore }
                .thenBy { it.daysLeft }
                .thenByDescending { it.suggestBuy }
                .thenBy { it.name.lowercase() }
        )
    }

    fun supplierSpend(purchases: List<Purchase>): List<Pair<String, Double>> =
        purchases.groupBy { it.supplier.trim().ifEmpty { "Tanpa Supplier" } }
            .map { (supplier, rows) -> supplier to rows.sumOf { purchase -> purchase.items.sumOf { it.qty * it.buyPrice } } }
            .sortedByDescending { it.second }

    fun customerRevenue(sales: List<Sale>): List<Pair<String, Double>> =
        sales.groupBy { it.customerName.trim().ifEmpty { "Umum" } }
            .map { (customer, rows) -> customer to rows.sumOf { it.totalSales } }
            .sortedByDescending { it.second }

    fun supplierInsights(purchases: List<Purchase>): List<SupplierInsight> =
        purchases.groupBy { it.supplier.trim().ifEmpty { "Tanpa Supplier" } }
            .map { (supplier, rows) ->
                val totalSpend = rows.sumOf { purchase -> purchase.items.sumOf { it.qty * it.buyPrice } }
                SupplierInsight(
                    supplier = supplier,
                    totalSpend = totalSpend,
                    purchaseCount = rows.size,
                    averageOrderValue = if (rows.isEmpty()) 0.0 else totalSpend / rows.size.toDouble(),
                    lastPurchaseDay = rows.maxOfOrNull { it.dateEpochDay },
                )
            }
            .sortedWith(
                compareByDescending<SupplierInsight> { it.purchaseCount }
                    .thenByDescending { it.totalSpend }
                    .thenBy { it.supplier.lowercase() }
            )

    fun purchasePriceTrends(
        purchases: List<Purchase>,
        products: List<Product>,
    ): List<PurchasePriceTrend> {
        val productNames = products.associateBy({ it.id }, { it.name })
        val historyByProduct = mutableMapOf<String, MutableList<Pair<Int, Double>>>()
        purchases.forEach { purchase ->
            purchase.items.forEach { item ->
                historyByProduct.getOrPut(item.productId) { mutableListOf() }
                    .add(purchase.dateEpochDay to item.buyPrice)
            }
        }
        return historyByProduct.map { (productId, history) ->
            val sorted = history.sortedBy { it.first }
            val firstPrice = sorted.firstOrNull()?.second ?: 0.0
            val latestPrice = sorted.lastOrNull()?.second ?: 0.0
            val averagePrice = if (sorted.isEmpty()) 0.0 else sorted.map { it.second }.average()
            val changePercent = if (firstPrice <= 0.0) 0.0 else ((latestPrice - firstPrice) / firstPrice) * 100.0
            PurchasePriceTrend(
                productId = productId,
                name = productNames[productId] ?: productId,
                firstPrice = firstPrice,
                latestPrice = latestPrice,
                averagePrice = averagePrice,
                changePercent = changePercent,
                purchaseCount = sorted.size,
            )
        }.sortedByDescending { abs(it.changePercent) }
    }

    fun profitAlerts(products: List<Product>): List<ProfitAlert> =
        products.map { product ->
            val profitPerUnit = product.activeSellPrice - product.avgHpp
            val marginPercent = if (product.activeSellPrice <= 0.0) 0.0 else (profitPerUnit / product.activeSellPrice) * 100.0
            val status = when {
                product.activeSellPrice <= 0.0 -> "BELUM ADA HARGA"
                profitPerUnit < 0.0 -> "RUGI"
                marginPercent < 10.0 -> "TIPIS"
                marginPercent < 20.0 -> "PERLU REVIEW"
                else -> "AMAN"
            }
            ProfitAlert(
                productId = product.id,
                name = product.name,
                sellPrice = product.activeSellPrice,
                avgHpp = product.avgHpp,
                marginPercent = marginPercent,
                profitPerUnit = profitPerUnit,
                status = status,
            )
        }.sortedWith(
            compareBy<ProfitAlert> {
                when (it.status) {
                    "RUGI" -> 0
                    "TIPIS" -> 1
                    "PERLU REVIEW" -> 2
                    "AMAN" -> 3
                    else -> 4
                }
            }.thenBy { it.marginPercent }
        )

    fun supplierScorecards(purchases: List<Purchase>): List<SupplierScorecard> {
        val globalAverageByProduct = mutableMapOf<String, Double>()
        val globalRowsByProduct = purchases
            .flatMap { purchase -> purchase.items.map { item -> item.productId to item.buyPrice } }
            .groupBy({ it.first }, { it.second })
        globalRowsByProduct.forEach { (productId, prices) ->
            globalAverageByProduct[productId] = if (prices.isEmpty()) 0.0 else prices.average()
        }

        return purchases.groupBy { it.supplier.trim().ifEmpty { "Tanpa Supplier" } }
            .map { (supplier, rows) ->
                val flattened = rows.flatMap { it.items }
                val totalSpend = flattened.sumOf { it.qty * it.buyPrice }
                val productCoverage = flattened.map { it.productId }.distinct().size
                val averageOrderValue = if (rows.isEmpty()) 0.0 else totalSpend / rows.size.toDouble()

                val productPriceComparisons = flattened.mapNotNull { item ->
                    val globalAverage = globalAverageByProduct[item.productId] ?: return@mapNotNull null
                    if (globalAverage <= 0.0) return@mapNotNull null
                    ((globalAverage - item.buyPrice) / globalAverage) * 100.0
                }
                val priceIndexPercent = if (productPriceComparisons.isEmpty()) 0.0 else productPriceComparisons.average()

                val stabilityScore = when {
                    rows.size >= 10 -> 100.0
                    rows.size >= 6 -> 85.0
                    rows.size >= 3 -> 70.0
                    rows.size >= 2 -> 55.0
                    else -> 35.0
                }

                val priceScore = (50.0 + priceIndexPercent).coerceIn(0.0, 100.0)
                val coverageScore = (productCoverage * 8.0).coerceAtMost(100.0)
                val spendScore = if (totalSpend <= 0.0) 0.0 else (totalSpend / 100000.0).coerceAtMost(100.0)
                val totalScore = (stabilityScore * 0.35) + (priceScore * 0.35) + (coverageScore * 0.20) + (spendScore * 0.10)

                val recommendation = when {
                    totalScore >= 80.0 -> "Prioritas utama"
                    totalScore >= 65.0 -> "Layak dipertahankan"
                    totalScore >= 50.0 -> "Perlu evaluasi harga"
                    else -> "Bandingkan lagi"
                }

                SupplierScorecard(
                    supplier = supplier,
                    totalSpend = totalSpend,
                    purchaseCount = rows.size,
                    averageOrderValue = averageOrderValue,
                    productCoverage = productCoverage,
                    priceIndexPercent = priceIndexPercent,
                    stabilityScore = stabilityScore,
                    totalScore = totalScore,
                    recommendation = recommendation,
                )
            }
            .sortedWith(
                compareByDescending<SupplierScorecard> { it.totalScore }
                    .thenByDescending { it.totalSpend }
                    .thenBy { it.supplier.lowercase() }
            )
    }

    fun salePriceRecommendations(
        products: List<Product>,
        targetMarginPercent: Double = 20.0,
    ): List<SalePriceRecommendation> =
        products.map { product ->
            val effectiveTarget = max(targetMarginPercent, product.defaultMarginPercent)
            val recommendedSellPrice = if (effectiveTarget >= 99.0) {
                product.activeSellPrice
            } else {
                product.avgHpp / (1.0 - (effectiveTarget / 100.0))
            }
            val gapPercent = if (recommendedSellPrice <= 0.0) 0.0 else ((product.activeSellPrice - recommendedSellPrice) / recommendedSellPrice) * 100.0
            val status = when {
                product.activeSellPrice <= 0.0 -> "BELUM ADA HARGA"
                product.avgHpp <= 0.0 -> "DATA HPP KURANG"
                gapPercent <= -10.0 -> "NAIKKAN"
                gapPercent in -10.0..-3.0 -> "REVIEW"
                gapPercent >= 20.0 -> "TERLALU TINGGI"
                else -> "AMAN"
            }
            SalePriceRecommendation(
                productId = product.id,
                name = product.name,
                currentSellPrice = product.activeSellPrice,
                avgHpp = product.avgHpp,
                targetMarginPercent = effectiveTarget,
                recommendedSellPrice = recommendedSellPrice,
                gapPercent = gapPercent,
                status = status,
            )
        }
            .sortedWith(
                compareBy<SalePriceRecommendation> {
                    when (it.status) {
                        "NAIKKAN" -> 0
                        "REVIEW" -> 1
                        "TERLALU TINGGI" -> 2
                        "AMAN" -> 3
                        else -> 4
                    }
                }.thenBy { it.gapPercent }
            )

    fun marginDropAlerts(
        purchases: List<Purchase>,
        products: List<Product>,
    ): List<MarginDropAlert> {
        val productNames = products.associateBy({ it.id }, { it })
        val historyByProduct = mutableMapOf<String, MutableList<Pair<Int, Double>>>()
        purchases.forEach { purchase ->
            purchase.items.forEach { item ->
                historyByProduct.getOrPut(item.productId) { mutableListOf() }
                    .add(purchase.dateEpochDay to item.buyPrice)
            }
        }
        return historyByProduct.mapNotNull { (productId, history) ->
            val product = productNames[productId] ?: return@mapNotNull null
            val sorted = history.sortedBy { it.first }
            val previousBuyPrice = sorted.dropLast(1).lastOrNull()?.second ?: sorted.firstOrNull()?.second ?: return@mapNotNull null
            val latestBuyPrice = sorted.lastOrNull()?.second ?: return@mapNotNull null
            if (product.activeSellPrice <= 0.0) return@mapNotNull null

            val previousMarginPercent = ((product.activeSellPrice - previousBuyPrice) / product.activeSellPrice) * 100.0
            val currentMarginPercent = ((product.activeSellPrice - latestBuyPrice) / product.activeSellPrice) * 100.0
            val dropPercent = previousMarginPercent - currentMarginPercent

            val status = when {
                currentMarginPercent < 0.0 -> "RUGI"
                dropPercent >= 15.0 -> "TURUN TAJAM"
                dropPercent >= 7.5 -> "TURUN"
                currentMarginPercent < 15.0 -> "TIPIS"
                else -> "AMAN"
            }

            MarginDropAlert(
                productId = productId,
                name = product.name,
                currentSellPrice = product.activeSellPrice,
                previousBuyPrice = previousBuyPrice,
                latestBuyPrice = latestBuyPrice,
                previousMarginPercent = previousMarginPercent,
                currentMarginPercent = currentMarginPercent,
                dropPercent = dropPercent,
                status = status,
            )
        }
            .filter { it.status != "AMAN" }
            .sortedWith(
                compareBy<MarginDropAlert> {
                    when (it.status) {
                        "RUGI" -> 0
                        "TURUN TAJAM" -> 1
                        "TURUN" -> 2
                        "TIPIS" -> 3
                        else -> 4
                    }
                }.thenByDescending { it.dropPercent }
            )
    }


    fun businessDecisionSummary(
        sales: List<Sale>,
        purchases: List<Purchase>,
        products: List<Product>,
    ): BusinessDecisionSummary {
        val restockRows = smartRestock(sales, products, purchases = purchases)
        val criticalRows = restockRows.filter { it.status in setOf("HABIS", "KRITIS") }
        val marginAlerts = marginDropAlerts(purchases, products)
        val priceReviews = salePriceRecommendations(products).count { it.status in setOf("NAIKKAN", "REVIEW") }
        val bestSupplier = supplierScorecards(purchases).firstOrNull()

        return BusinessDecisionSummary(
            criticalRestockCount = criticalRows.size,
            criticalRestockBuyQty = criticalRows.sumOf { it.suggestBuy },
            marginAlertCount = marginAlerts.size,
            priceReviewCount = priceReviews,
            bestSupplierName = bestSupplier?.supplier ?: "-",
            bestSupplierScore = bestSupplier?.totalScore ?: 0.0,
        )
    }

}