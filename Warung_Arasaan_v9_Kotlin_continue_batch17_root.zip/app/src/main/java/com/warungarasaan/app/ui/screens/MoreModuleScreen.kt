
package com.warungarasaan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.RemoveShoppingCart
import androidx.compose.material.icons.rounded.Report
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.AppContainer
import com.warungarasaan.app.domain.PaymentMethods
import com.warungarasaan.app.ui.SectionCard
import com.warungarasaan.app.ui.UiFormat
import com.warungarasaan.app.ui.isRouteAllowed

private data class MoreNavItem(val title: String, val subtitle: String, val icon: ImageVector, val target: String)

@Composable
fun MoreModuleScreen(
    container: AppContainer,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var saldoKas by remember { mutableStateOf(0.0) }
    var rejectedCount by remember { mutableStateOf(0) }
    var activeRole by remember { mutableStateOf("admin") }

    LaunchedEffect(Unit) {
        saldoKas = container.cashRepository.all()
            .filter { PaymentMethods.isCashFlow(it.method) }
            .sumOf { if (it.direction == "in") it.amount else -it.amount }
        rejectedCount = container.rejectedRepository.all().size
        activeRole = container.metaRepository.role()
    }

    val operationalItems = listOf(
        MoreNavItem("Kas", "Saldo ${UiFormat.money(saldoKas)}", Icons.Rounded.AccountBalanceWallet, "cash"),
        MoreNavItem("Biaya", "Catat biaya operasional", Icons.Rounded.Description, "expenses"),
        MoreNavItem("Hutang", "Pantau pembayaran dan sisa", Icons.Rounded.ReceiptLong, "debts"),
        MoreNavItem("Barang rejected", "$rejectedCount entri tercatat", Icons.Rounded.RemoveShoppingCart, "rejected"),
        MoreNavItem("Restock", "Forecast pembelian berikutnya", Icons.Rounded.RestartAlt, "restock"),
    )
    val insightItems = listOf(
        MoreNavItem("Analytics", "Insight penjualan dan margin", Icons.Rounded.Analytics, "analytics"),
        MoreNavItem("Analitik Produk", "Detail kontribusi tiap produk", Icons.Rounded.Analytics, "analytics_product_detail"),
        MoreNavItem("Laporan", "Ringkasan operasional warung", Icons.Rounded.Report, "reports"),
    )
    val toolsItems = listOf(
        MoreNavItem("Supplier", "Pantau supplier dan hutang", Icons.Rounded.Groups, "suppliers"),
        MoreNavItem("Pelanggan", "Ringkasan customer", Icons.Rounded.People, "customers"),
        MoreNavItem("Tools Operasional", "Search cepat dan tool stok", Icons.Rounded.Build, "operations"),
        MoreNavItem("Backup", "Export / import database", Icons.Rounded.CloudUpload, "backup"),
        MoreNavItem("Print Center", "Preview dan kirim struk", Icons.Rounded.Print, "print_center"),
    )

    val visibleOperationalItems = operationalItems.filter { isRouteAllowed(activeRole, it.target) }
    val visibleInsightItems = insightItems.filter { isRouteAllowed(activeRole, it.target) }
    val visibleToolsItems = toolsItems.filter { isRouteAllowed(activeRole, it.target) }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(
                title = "Lainnya",
                subtitle = "Fitur lanjutan dikumpulkan di satu tempat agar layar utama tetap ringkas.",
            ) {
                Text("Fitur harian utama tetap ada di navigasi bawah. Modul lanjutan dikelompokkan agar akses lebih rapi.")
                Text("Role aktif: $activeRole")
            }
        }
        item { Text("Operasional", style = androidx.compose.material3.MaterialTheme.typography.titleMedium) }
        items(visibleOperationalItems) { item ->
            SectionCard(title = item.title, subtitle = item.subtitle) {
                ListItem(
                    headlineContent = { Text(item.title) },
                    supportingContent = { Text(item.subtitle) },
                    leadingContent = { Icon(item.icon, contentDescription = item.title) }
                )
                androidx.compose.material3.TextButton(onClick = { onNavigate(item.target) }) {
                    Text("Buka")
                }
            }
        }
        item { Text("Insight", style = androidx.compose.material3.MaterialTheme.typography.titleMedium) }
        items(visibleInsightItems) { item ->
            SectionCard(title = item.title, subtitle = item.subtitle) {
                ListItem(
                    headlineContent = { Text(item.title) },
                    supportingContent = { Text(item.subtitle) },
                    leadingContent = { Icon(item.icon, contentDescription = item.title) }
                )
                androidx.compose.material3.TextButton(onClick = { onNavigate(item.target) }) {
                    Text("Buka")
                }
            }
        }
        item { Text("Tools", style = androidx.compose.material3.MaterialTheme.typography.titleMedium) }
        items(visibleToolsItems) { item ->
            SectionCard(title = item.title, subtitle = item.subtitle) {
                ListItem(
                    headlineContent = { Text(item.title) },
                    supportingContent = { Text(item.subtitle) },
                    leadingContent = { Icon(item.icon, contentDescription = item.title) }
                )
                androidx.compose.material3.TextButton(onClick = { onNavigate(item.target) }) {
                    Text("Buka")
                }
            }
        }
    }
}
