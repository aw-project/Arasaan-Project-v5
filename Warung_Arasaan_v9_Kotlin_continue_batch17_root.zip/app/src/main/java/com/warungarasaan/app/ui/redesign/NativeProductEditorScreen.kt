package com.warungarasaan.app.ui.redesign

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.warungarasaan.app.core.FormStateGuards

@Composable
fun NativeProductEditorScreen(
    initialName: String = "",
    initialSku: String = "",
    initialUnit: String = "pcs",
    initialCostPrice: String = "",
    initialSellPrice: String = "",
    onSave: (
        name: String,
        sku: String,
        unit: String,
        costPrice: Double,
        sellPrice: Double
    ) -> Unit = { _, _, _, _, _ -> }
) {
    var name by remember { mutableStateOf(initialName) }
    var sku by remember { mutableStateOf(initialSku) }
    var unit by remember { mutableStateOf(initialUnit) }
    var costPrice by remember { mutableStateOf(initialCostPrice) }
    var sellPrice by remember { mutableStateOf(initialSellPrice) }
    var errorText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionHeader(
            title = "Editor Produk",
            subtitle = "Fokus ke input cepat yang nyaman untuk Android"
        )
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama produk") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = sku,
                    onValueChange = { sku = it },
                    label = { Text("SKU / kode") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = unit,
                    onValueChange = { unit = it },
                    label = { Text("Satuan") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = costPrice,
                    onValueChange = { costPrice = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Harga modal") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = sellPrice,
                    onValueChange = { sellPrice = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Harga jual") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText.isNotBlank()) {
                    Text(text = errorText)
                }
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val cost = costPrice.toDoubleOrNull() ?: 0.0
                        val sell = sellPrice.toDoubleOrNull() ?: 0.0
                        val guards = FormStateGuards.merge(
                            FormStateGuards.requiredText("Nama produk", name),
                            FormStateGuards.requiredText("Satuan", unit),
                            FormStateGuards.positiveNumber("Harga modal", cost),
                            FormStateGuards.positiveNumber("Harga jual", sell)
                        )
                        if (!guards.isValid) {
                            errorText = guards.issues.joinToString("\n") { it.message }
                            return@Button
                        }
                        errorText = ""
                        onSave(name.trim(), sku.trim(), unit.trim(), cost, sell)
                    }
                ) {
                    Text("Simpan produk")
                }
            }
        }
    }
}
